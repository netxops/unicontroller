package api

import (
	"fmt"
	"gin-vue-admin/model"
	"strings"
	"time"
)

type HuaweiSDNTime time.Time

const hwTimeLayout = "2006-01-02 15:04:05"

func (ct *HuaweiSDNTime) UnmarshalJSON(b []byte) error {
	if b == nil || len(b) == 0 {
		*ct = HuaweiSDNTime(time.Time{})
		return nil
	}
	s := strings.Trim(string(b), "\"")
	t, err := time.Parse(hwTimeLayout, s)
	if err != nil {
		return err
	}
	*ct = HuaweiSDNTime(t)
	return nil
}

func (ct *HuaweiSDNTime) String() string {
	t := time.Time(*ct)
	return fmt.Sprintf("%q", t.Format(hwTimeLayout))
}

type HuaweiSDNBulkObjects struct {
	TotalNum  int `json:"totalNum"`
	PageIndex int `json:"pageIndex"`
	PageSize  int `json:"pageSize"`
}

type DevicePortsRequest struct {
	DeviceIdList []string `json:"deviceIdList"`
	PageSize     string   `json:"pageSize"`
	PageIndex    string   `json:"pageIndex"`
}

type HuaweiSDNResponseData struct {
	TokenId     string        `json:"token_id"`
	ExpiredDate HuaweiSDNTime `json:"expiredDate"`
}

type HuaweiSDNResponse struct {
	Data    HuaweiSDNResponseData `json:"data"`
	ErrCode string                `json:"errcode"`
	ErrMsg  string                `json:"errmsg"`
}

type FabricResponse struct {
	Fabric []model.Fabric `json:"fabric"`
}

type VPCResponse struct {
	HuaweiSDNBulkObjects
	Network []model.VPC `json:"network"`
}

type SubnetResponse struct {
	HuaweiSDNBulkObjects
	Subnet []model.Subnet `json:"subnet"`
}

type LogicPortResponse struct {
	HuaweiSDNBulkObjects
	Port []model.LogicPort `json:"port"`
}

type DeviceResponse struct {
	Device []model.DcimDevice `json:"device"`
}

package api

type Auth struct {
	ip       string
	Username string `json:"userName"`
	Password string `json:"password"`
}

var auths = map[string]Auth{
	"DT": Auth{
		ip:       "10.66.254.1",
		Username: "DT@huawei.com",
		Password: "Admin@123DT",
	},
	"FJY": Auth{
		ip:       "10.64.254.1",
		Username: "FJY@huawei.com",
		Password: "Admin@123FJY",
	},
	"INT": Auth{
		ip:       "192.168.190.1",
		Username: "INT@huawei.com",
		Password: "Admin@123INT",
	},
}

func GetAuthByIp(ip string) *Auth {
	for _, au := range auths {
		if au.ip == ip {
			return &au
		}
	}
	return nil
}

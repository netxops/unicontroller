package main

import (
	"fmt"
	"gin-vue-admin/cmd/sdn/selector"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

var (
	DEFAULT_CONFIG_FILE = "./config.yaml"
	configRack          = &selector.ConfigRack{}
)

func ConfigViper(path string) {
	v := viper.New()
	v.SetConfigFile(path)

	err := v.ReadInConfig()
	if err != nil {
		panic(fmt.Errorf("Fatal error config file: %s \n", err))
	}
	v.WatchConfig()

	v.OnConfigChange(func(e fsnotify.Event) {
		fmt.Println("config file changed:", e.Name)
		if err := v.Unmarshal(configRack); err != nil {
			fmt.Println(err)
		}
	})

	if err := v.Unmarshal(configRack); err != nil {
		fmt.Println(err)
	}

}

func init() {
	ConfigViper(DEFAULT_CONFIG_FILE)
}

func main() {
	newSelector := initSelector()
	devices := newSelector.SelectDevice(configRack.RackList)
	for i, device := range devices {
		fmt.Println(i, " select device: ", device.Name)
	}
}

func initSelector() (s selector.Selector) {
	var role selector.Role
	role.Name = "DT"
	s.Role = role
	s.PortNumber = 3
	s.Rack = "rack2"
	s.Bandwidth = 1
	s.Priority = true
	return
}

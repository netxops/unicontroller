package selector

import (
	"gin-vue-admin/model"
	"strings"
)

// func getAllDevice(rackList []Rack) (deviceList []Device) {
// for _, r := range rackList {
// if len(r.Devices) != 0 {
// for _, d := range r.Devices {
// deviceList = append(deviceList, d)
// }
// }
// }
// return
// }

func getRackByName(rackList []model.Rack, name string) (rack *model.Rack) {
	for _, r := range rackList {
		if strings.ToUpper(name) == strings.ToUpper(r.Name) {
			return &r
		}
	}
	return
}

// func (d *Device) getBrotherDevice(device model.DcimDevice) (brother *model.DcimDevice) {
// 获取某一交换机的一组中的另一台交换机
// return device.BrotherDevice
// }

// func (d *Device) isInRole(role Role) (ok bool) {
// for _, r := range d.Roles {
// if strings.ToUpper(r.Name) == strings.ToUpper(role.Name) {
// return true
// }
// }
// return false
// }

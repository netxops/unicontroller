package selector

import (
	"gin-vue-admin/global"
	"gin-vue-admin/model"
	"gin-vue-admin/service"
	"sort"
	"strings"

	"go.uber.org/zap"
	"gorm.io/gorm/clause"
)

func (s *Selector) SelectCenterRacks() (orderedRacks []*model.DcimRack) {
	//选择符合要求的机柜,并按优先级排序
	levelRackMap, _ := s.getLevelCenterRackMap()
	var levelList []int
	for key := range levelRackMap {
		levelList = append(levelList, key)
	}
	sort.Ints(levelList)
	for _, level := range levelList {
		for _, levelrack := range levelRackMap[level] {
			orderedRacks = append(orderedRacks, levelrack)
		}
	}
	return
}

func (s *Selector) getLevelCenterRackMap() (levelRackMap map[int][]*model.DcimRack, err error) {
	//获取机柜level的Map
	levelRackMap = make(map[int][]*model.DcimRack)
	var rack model.DcimRack
	global.GVA_DB.Where("name = ?", s.Rack).Find(&rack)
	dcimRackTagList, err := service.GetDcimRackTagListByRack(rack)
	if err != nil {
		global.GVA_LOG.Error("GetDcimRackTagListByRack-Error", zap.Any("error:", err))
		return
	}
	for _, tag := range dcimRackTagList {
		if strings.ToUpper(tag.Name) == strings.ToUpper(s.Role) {
			centerRack := tag.DcimCenterRack
			if rack.Name == centerRack.Name && *tag.SelfRack {
				levelRackMap[0] = append(levelRackMap[0], centerRack)
			} else {
				levelRackMap[tag.Level] = append(levelRackMap[tag.Level], centerRack)
			}
		}
	}
	return
}

func (s *Selector) isBrotherDevicePresentTogether(device *model.DcimDevice, uniqDeviceGroup []*model.DcimDevice) bool {
	//判断数组中是否已存在交换机组的其中一个交换机,已存在返回false
	brotherDevice, _ := service.GetBrotherDevice(device)
	if brotherDevice != nil {
		for _, d := range uniqDeviceGroup {
			if d.Name == device.Name || d.Name == brotherDevice.Name {
				return false
			}
		}
	}
	return true
}

func (s *Selector) getUniqDeviceGroup(orderedRacks []*model.DcimRack) (uniqDeviceGroup []*model.DcimDevice) {
	for _, rack := range orderedRacks {
		var deviceList []*model.DcimDevice
		global.GVA_DB.Where("dcim_rack_id = ?", rack.ID).Preload(clause.Associations).Find(&deviceList)
		for _, device := range deviceList {
			if device.IsInFunctionArea(s.Role) {
				if s.isBrotherDevicePresentTogether(device, uniqDeviceGroup) {
					uniqDeviceGroup = append(uniqDeviceGroup, device)
				}
			}
		}
	}
	return
}

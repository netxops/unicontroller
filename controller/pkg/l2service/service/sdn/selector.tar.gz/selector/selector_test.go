package selector

var (
	DEFAULT_CONFIG_FILE = "../example/config.yaml"
	// configRack          = &ConfigRack{}
)

var NewSelectorTest = []struct {
	Priority   bool //是否要求速率优先
	SelfRack   bool //是否要求自身机柜
	Role       Role
	PortNumber int
	Rack       string
	Bandwidth  int
	SystemName string
	want       []string
}{
	{true, true, Role{"DT"}, 10, "rack2", 1, "", []string{"device11", "device13"}},
	{false, true, Role{"DT"}, 10, "rack1", 1, "", []string{"device1", "device11", "device13"}},
	{true, false, Role{"DT"}, 10, "rack1", 1, "", []string{"device11", "device13", "device1"}},
	{true, false, Role{"JY"}, 10, "rack2", 1, "", []string{"device11", "device13"}},
	{false, true, Role{"DT"}, 10, "rack1", 10, "", []string{"device1"}},
	{false, true, Role{"JY"}, 10, "rack1", 10, "", []string{}},
}

// func TestSelectorIsSame(t *testing.T) {
// ConfigViper(DEFAULT_CONFIG_FILE)
// for _, st := range NewSelectorTest {
// sl := Selector{st.Priority, st.SelfRack, WorkOrder{st.Role, st.PortNumber, st.Rack, st.Bandwidth, st.SystemName}}
// devices := sl.SelectDevice(configRack.RackList)
// got := deviceToStrList(devices)
// if !checkInDevice(st.want, devices) {
// t.Errorf("got:%+v, want:%+v", got, st.want)
// }
// }
// }

// func ConfigViper(path string) {
// v := viper.New()
// v.SetConfigFile(path)
//
// err := v.ReadInConfig()
// if err != nil {
// panic(fmt.Errorf("Fatal error config file: %s \n", err))
// }
// v.WatchConfig()
//
// v.OnConfigChange(func(e fsnotify.Event) {
// fmt.Println("config file changed:", e.Name)
// if err := v.Unmarshal(configRack); err != nil {
// fmt.Println(err)
// }
// })
// if err := v.Unmarshal(configRack); err != nil {
// fmt.Println(err)
// }
// }
//
// func deviceToStrList(deviceList []Device) (devices []string) {
// for _, device := range deviceList {
// devices = append(devices, device.Name)
// }
// return
// }
//
// func checkInDevice(deviceNameList []string, deviceList []Device) (ok bool) {
// if len(deviceNameList) == len(deviceList) {
// for i, deviceName := range deviceNameList {
// if strings.ToUpper(deviceName) != strings.ToUpper(deviceList[i].Name) && strings.ToUpper(deviceName) != strings.ToUpper(deviceList[i].Brother) {
// return false
// }
// }
// } else {
// return false
// }
// return true
// }

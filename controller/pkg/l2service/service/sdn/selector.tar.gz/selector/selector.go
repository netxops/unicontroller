package selector

import (
	"fmt"
	"gin-vue-admin/global"
	"gin-vue-admin/model"
	"gin-vue-admin/service"
	"sort"

	"go.uber.org/zap"
)

type Role struct {
	Name string
}

type Selector struct {
	Priority  bool //是否要求速率优先
	SelfRack  bool
	WorkOrder //工单
}

type WorkOrder struct {
	//工单
	Role       string
	PortNumber int
	Rack       string
	Bandwidth  int
	SystemName string
}

func (s *Selector) GetDeviceListByRack() (deviceList []*model.DcimDevice) {
	//通过优先级排序好的中心机柜，获取交换机
	BandwidthConfigViper(BANDWIDTH_CONFIG_FILE)
	var levelMap = make(map[int][]*model.DcimDevice)
	// 获取中心机柜列表，并已经根据优先级完成排序
	orderedRacks := s.SelectCenterRacks()
	uniqDevices := s.getUniqDeviceGroup(orderedRacks)
	for _, device := range uniqDevices {
		var uniqDevice *model.DcimDevice
		if device.MasterOrSlave == 1 {
			uniqDevice = device
		} else {
			var err error
			uniqDevice, err = service.GetBrotherDevice(device)
			if err != nil {
				global.GVA_LOG.Error("GetBrotherDevice-Error", zap.Any("error:", err))
				return
			}
		}
		bandwidthType := bandwidthConfig.selectBandwidth(s.Bandwidth, device.DeviceBandwidth())
		fmt.Println("Bandwidth:==========>", s.Bandwidth, device.DeviceBandwidth(), bandwidthType)
		if s.Priority {
			switch bandwidthType {
			case BESTSELECT:
				levelMap[1] = append(levelMap[1], uniqDevice)
			case SECONDSELECT:
				levelMap[2] = append(levelMap[2], uniqDevice)
			}
		} else {
			if bandwidthType != UNFINDSELECT {
				deviceList = append(deviceList, uniqDevice)
			}
		}
	}
	if s.Priority {
		var levelList []int
		for key := range levelMap {
			levelList = append(levelList, key)
		}
		sort.Ints(levelList)

		for _, i := range levelList {
			for _, device := range levelMap[i] {
				deviceList = append(deviceList, device)
			}
		}
	}
	return
}

func (s *Selector) getFreeDownInterfaces() (interfaceList []model.DcimInterface) {
	devices := s.GetDeviceListByRack()
	for _, device := range devices {
		interfaces := service.GetFreeDownInterfaces(device)
		for _, i := range interfaces {
			interfaceList = append(interfaceList, i)
		}
	}
	return
}

func (s *Selector) SelectDevice() (deviceList []*model.DcimDevice) {
	deviceList = s.GetDeviceListByRack()
	return
}

package selector

import (
	"fmt"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

type BandwidthType int

const (
	_ BandwidthType = iota
	BESTSELECT
	SECONDSELECT
	UNFINDSELECT
)

var (
	BANDWIDTH_CONFIG_FILE = "sdn/bandwidthconfig.yaml"
	bandwidthConfig       = &BandwidthSelect{}
)

type BandwidthSelect struct {
	BandwidthList []BandWidth `yaml:"bandwidth_list" mapstructure:"bandwidth_list"`
}

type BandWidth struct {
	Bandwidth    int `yaml:"bandwidth" mapstructure`
	FirstSelect  int `yaml:"first_select" mapstructure:"first_select"`
	SecondSelect int `yaml:"second_select" mapstructure:"second_select"`
}

func (b *BandwidthSelect) selectBandwidth(bandwidth int, deviceBandwidthList []int) (bandwidthType BandwidthType) {
	for _, bw := range b.BandwidthList {
		if bw.Bandwidth == bandwidth {
			for _, deviceBandwidth := range deviceBandwidthList {
				if bw.FirstSelect == deviceBandwidth {
					return BESTSELECT
				} else if bw.SecondSelect == deviceBandwidth {
					return SECONDSELECT
				} else {
					return UNFINDSELECT
				}
			}
		}
	}
	return UNFINDSELECT
}

func BandwidthConfigViper(path string) {
	v := viper.New()
	v.SetConfigFile(path)

	err := v.ReadInConfig()
	if err != nil {
		panic(fmt.Errorf("Fatal error config file: %s \n", err))
	}
	v.WatchConfig()

	v.OnConfigChange(func(e fsnotify.Event) {
		fmt.Println("config file changed:", e.Name)
		if err := v.Unmarshal(bandwidthConfig); err != nil {
			fmt.Println(err)
		}
	})

	if err := v.Unmarshal(bandwidthConfig); err != nil {
		fmt.Println(err)
	}

}

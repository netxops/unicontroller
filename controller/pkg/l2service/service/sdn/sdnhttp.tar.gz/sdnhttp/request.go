package sdnhttp

type SdnServerType int

const (
	_ SdnServerType = iota
	LOGICSWITCH
	LOGICROUTER
	FABRIC
	DEVICE
	TENANT
	SUBNET
	LOGICPORT
	VPC
	DEVICEGROUP
	DEVICEPORT
)

func RequestToSdn(ctx *RequestContext, serverType SdnServerType) ([]byte, error) {
	init_request := Request{}
	switch serverType {
	case FABRIC:
		init_request = Request{
			method: "GET",
			path:   "/controller/dc/v3/physicalnetwork/fabricresource/fabrics"}
	case VPC:
		init_request = Request{
			method: "GET",
			path:   "/controller/dc/v3/logicnetwork/networks"}
	case LOGICPORT:
		init_request = Request{
			method: "GET",
			path:   "controller/dc/v3/logicnetwork/ports"}
	}

	res, err := ctx.Get(init_request)
	if err != nil {
		return res, err
	}
	return res, nil
}

func (ctx *RequestContext) pdate_huawei_db() {
	init_request_list := []Request{
		{
			method: "GET",
			path:   "/controller/dc/v3/physicalnetwork/fabricresource/fabrics",
		},
		{
			method: "GET",
			path:   "/acdcn/v3/topoapi/dcntopo/device",
		},
		{
			method: "GET",
			path:   "/controller/dc/v3/tenants",
		},
		{
			method: "GET",
			path:   "/controller/dc/v3/logicnetwork/networks",
		},
		{
			method: "GET",
			path:   "/controller/dc/v3/logicnetwork/switchs",
		},
		{
			method: "GET",
			path:   "controller/dc/v3/logicnetwork/ports",
		},
		{
			method: "GET",
			path:   "/controller/dc/v3/logicnetwork/subnets",
		},
		{
			method: "GET",
			path:   "/acdcn/v3/topoapi/dcntopo/devicegroup",
		},
	}

	for _, req := range init_request_list {
		ctx.Get(req)
	}
}

package sdnhttp

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"gin-vue-admin/cmd/sdn/api"
	"gin-vue-admin/global"
	"io/ioutil"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"

	"gorm.io/gorm"
)

var stop bool

type RequestContext struct {
	sync.Mutex
	host   string
	url    *url.URL
	header http.Header
	client *http.Client
	token  string
	expire time.Time
	db     *gorm.DB
}

type Request struct {
	path   string
	method string
	param  string
	body   string
}

func NewHuaWeiRequestContext(host string, port int) (*RequestContext, error) {
	var baseURL = "https://" + host + ":" + strconv.Itoa(port)
	//

	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}

	u, err := url.Parse(baseURL)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}
	ctx := &RequestContext{
		host:   host,
		url:    u,
		header: http.Header{},
		client: &http.Client{Transport: tr},
		db:     global.GVA_DB,
	}

	ctx.header.Add("Accept", "application/json; indent=4;")
	ctx.header.Add("Content-Type", "application/json")
	ctx.tokens()
	go ctx.Loop()
	return ctx, nil
}

func NewPostHuaweiDevicePortsRequest(devices []string) *api.DevicePortsRequest {
	request := api.DevicePortsRequest{
		DeviceIdList: []string{},
		PageIndex:    "1",
		PageSize:     "400000",
	}
	for _, d := range devices {
		request.DeviceIdList = append(request.DeviceIdList, d)
	}
	return &request
}

func PrettyJson(buf []byte) {
	var out bytes.Buffer
	err := json.Indent(&out, buf, "", "\t")
	if err != nil {
		panic(err)
	}
	fmt.Printf("%s\n", out.String())
}

func (ctx *RequestContext) tokens() (string, error) {
	url := fmt.Sprintf("https://%s:18002/controller/v2/tokens", ctx.host)

	auth := api.GetAuthByIp(ctx.host)

	b, err := json.Marshal(auth)
	if err != nil {
		return "", err
	}

	if ctx.header.Get("X-ACCESS-TOKEN") != "" {
		ctx.header.Del("X-ACCESS-TOKEN")
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(b))
	req.Header = ctx.header
	res, err := ctx.client.Do(req)

	if err != nil {
		fmt.Println("error", err)
	}

	if res.StatusCode != 200 {
		return "", fmt.Errorf("response status code: %d, status: %s", res.StatusCode, res.Status)
	}

	// res_map := map[string]interface{}{}
	res_map := &api.HuaweiSDNResponse{}
	data, err := ioutil.ReadAll(res.Body)

	err = json.Unmarshal(data, res_map)
	if err != nil {
		return "", nil
	}

	if res_map.ErrCode != "0" {
		return "", fmt.Errorf("%s", res_map.ErrMsg)
	}

	ctx.Lock()
	ctx.token = res_map.Data.TokenId
	ctx.expire = time.Time(res_map.Data.ExpiredDate)
	fmt.Println("--------------------->", ctx.expire)
	ctx.header.Set("X-ACCESS-TOKEN", ctx.token)
	ctx.Unlock()
	fmt.Println("expire:", ctx.expire, "now:", time.Now())
	return res_map.Data.TokenId, nil
}

func (rc *RequestContext) Loop() {
	// huawei_tokens(, rc)

	for !stop {
		select {
		case <-time.After(10 * time.Second):
			continue

		case <-time.After(rc.expire.Add(-360 * time.Second).Sub(time.Now())):
			rc.tokens()
			break
		}
	}
}

func (ctx *RequestContext) request(method string, url string, body string) ([]byte, error) {
	// req, err := http.NewRequest("GET", url, bytes.NewBuffer(buffer))
	req, err := http.NewRequest(method, url, strings.NewReader(body))
	ctx.Lock()
	req.Header = ctx.header
	ctx.Unlock()
	res, err := ctx.client.Do(req)
	result, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (ctx *RequestContext) Post(path string, body string) {
	if !strings.HasPrefix(path, "/") {
		path = "/" + path
	}

	url := ctx.url.String() + path
	b, err := ctx.request("POST", url, body)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(string(b))
}

func (ctx *RequestContext) Get(req Request) (b []byte, err error) {
	path := req.path
	if !strings.HasPrefix(req.path, "/") {
		path = "/" + req.path
	}

	method := strings.ToUpper(req.method)
	body := ""
	if method == "POST" {
		body = req.body
	}
	url := ctx.url.String() + path
	b, err = ctx.request(method, url, body)
	if err != nil {
		return
	}

	// fmt.Println(b)

	// logicSwitch := &api.LogicSwitchResponse{}
	// logicRouter := &api.LogicRouterResponse{}
	fabric := &api.FabricResponse{}
	devices := &api.DeviceResponse{}
	// tenants := &api.TenantResponse{}
	// subnets := &api.SubnetResponse{}
	ports := &api.LogicPortResponse{}
	vpcs := &api.VPCResponse{}
	// deviceGroups := &api.DeviceGroupResponse{}
	// devicePorts := &api.DevicePortsResponse{}

	switch path {
	case "/controller/dc/v3/logicnetwork/networks":
		json.Unmarshal(b, vpcs)
		// for _, d := range vpcs.Network {
		// ctx.db.FirstOrCreate(&d)
		// }
	case "/acdcn/v3/topoapi/dcntopo/device":
		json.Unmarshal(b, devices)
		fmt.Println("+++++++++++++++++++++++++++++++++++++++++++")
		fmt.Println(len(devices.Device))
	// for _, d := range devices.Devices {
	// ctx.db.FirstOrCreate(&d)
	// }
	// case "/acdcn/v3/topoapi/dcntopo/devicegroup":
	// json.Unmarshal(b, deviceGroups)
	// for _, d := range deviceGroups.DeviceGroups {
	// ctx.db.FirstOrCreate(&d)
	// }
	// case "/controller/dc/v3/tenants":
	// json.Unmarshal(b, tenants)

	case "/controller/dc/v3/physicalnetwork/fabricresource/fabrics":
		json.Unmarshal(b, fabric)
	case "controller/dc/v3/logicnetwork/ports":
		json.Unmarshal(b, ports)
		// for _, d := range fabric.Fabric {
		// ctx.db.FirstOrCreate(&d)
		// }
	}
	return
}

func (ctx *RequestContext) update_huawei_db() {
	init_request_list := []Request{
		{
			method: "GET",
			path:   "/controller/dc/v3/physicalnetwork/fabricresource/fabrics",
		},
		{
			method: "GET",
			path:   "/acdcn/v3/topoapi/dcntopo/device",
		},
		{
			method: "GET",
			path:   "/controller/dc/v3/tenants",
		},
		{
			method: "GET",
			path:   "/controller/dc/v3/logicnetwork/networks",
		},
		{
			method: "GET",
			path:   "/controller/dc/v3/logicnetwork/switchs",
		},
		{
			method: "GET",
			path:   "controller/dc/v3/logicnetwork/ports",
		},
		{
			method: "GET",
			path:   "/controller/dc/v3/logicnetwork/subnets",
		},
		{
			method: "GET",
			path:   "/acdcn/v3/topoapi/dcntopo/devicegroup",
		},
	}

	for _, req := range init_request_list {
		ctx.Get(req)
	}
	//
	// req := Request{
	// method: "POST",
	// path:   "/acdcn/v3/topoapi/dcntopo/getPorts",
	// }
	//
	// devices := []api.Device{}
	// ctx.db.Find(&devices)
	//
	// for _, device := range devices {
	// body := NewPostHuaweiDevicePortsRequest([]string{device.ID})
	// b, err := json.Marshal(body)
	//
	// if err != nil {
	// fmt.Println(err)
	// } else {
	// req.body = string(b)
	// ctx.Get(req)
	// }
	// }
}

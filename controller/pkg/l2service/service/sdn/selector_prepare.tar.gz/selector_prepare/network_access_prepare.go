package selector_prepare

import (
	"gin-vue-admin/cmd/sdn/selector"
	"gin-vue-admin/global"
	"gin-vue-admin/model"
	"gin-vue-admin/service"
	"strings"
)

type Prepare struct {
	TicketAccess model.TicketNetworkAccessItem
}

type TicketAccessDeviceList struct {
	Devices []*TicketAccessDevice
}

type TicketAccessDevice struct {
	Name       string
	Interfaces []*TicketAccessInterface
}

type TicketAccessInterface struct {
	Name   string
	Status bool
}

func (t *TicketAccessDeviceList) checkInDeviceList(deviceName string) (ok bool, ticketDevice *TicketAccessDevice) {
	for _, device := range t.Devices {
		if strings.ToUpper(deviceName) == strings.ToUpper(device.Name) {
			return true, device
		}
	}
	return false, nil
}

func (td *TicketAccessDevice) getFreeInterface() (ok bool, ticketInterface *TicketAccessInterface) {
	for _, port := range td.Interfaces {
		if port.Status == true {
			port.Status = false
			return true, port
		}
	}
	return false, nil
}

func (t *TicketAccessDeviceList) getFreeInterface(deviceName string) (ok bool, ticketInterface *TicketAccessInterface) {
	ok, device := t.checkInDeviceList(deviceName)
	if ok {
		for _, port := range device.Interfaces {
			if port.Status == true {
				port.Status = false
				return true, port
			}
		}
		return false, nil
	} else {
		return false, nil
	}

}

func (p *Prepare) getDeviceInterfaceList() (deviceInterfaceList *TicketAccessDeviceList) {
	//获取工单所用到的设备的所有端口Map
	networkGroup := service.GetStandardNetworkAccessItem(p.TicketAccess)
	for _, network := range networkGroup {
		var s selector.Selector
		s.Rack = network.Rack
		s.Role = network.Role
		s.Bandwidth = network.Bandwidth
		uniqDeviceList := s.GetDeviceListByRack()
		for _, device := range uniqDeviceList {
			ok, _ := deviceInterfaceList.checkInDeviceList(device.Name)
			if ok {
				continue
			}
			var ticketAccessDevice TicketAccessDevice
			ticketAccessDevice.Name = device.Name
			interfaces := service.GetClusterFreeInterfaces(device)
			var interfaceList []*TicketAccessInterface
			for _, freeport := range interfaces {
				var port TicketAccessInterface
				port.Name = freeport
				port.Status = true
				interfaceList = append(interfaceList, &port)
			}
			ticketAccessDevice.Interfaces = interfaceList
			deviceInterfaceList.Devices = append(deviceInterfaceList.Devices, &ticketAccessDevice)
		}
	}
	return
}

func (p *Prepare) getNetworkAccessGroupByNumberIp() (networkAccessGroupMap map[string][]*model.TicketNetworkAccess) {
	//将工单按照number+ip分组
	networkList := service.GetStandardNetworkAccessItem(p.TicketAccess)
	for _, network := range networkList {
		numberIp := network.Number + "_" + network.Ip
		if _, ok := networkAccessGroupMap[numberIp]; ok {
			networkAccessGroupMap[numberIp] = append(networkAccessGroupMap[numberIp], network)
		} else {
			var networkAccessList []*model.TicketNetworkAccess
			networkAccessGroupMap[numberIp] = append(networkAccessList, network)
		}
	}
	return
}

func (p *Prepare) allocateSwitchSource() {
	networkAccessGroupMap := p.getNetworkAccessGroupByNumberIp()
	deviceInterfaceList := p.getDeviceInterfaceList()
	for _, networkAccessList := range networkAccessGroupMap {
		firstNetwork := networkAccessList[0]
		var s selector.Selector
		s.Rack = firstNetwork.Rack
		s.Role = firstNetwork.Role
		s.Bandwidth = firstNetwork.Bandwidth
		uniqDeviceList := s.GetDeviceListByRack()
		for _, device := range uniqDeviceList {
			ok, ticketInterface := deviceInterfaceList.getFreeInterface(device.Name)
			if ok {
				p.setPortNameByNetmodel(device, ticketInterface.Name, networkAccessList)
				break
			}
		}
	}
}

func (p *Prepare) setPortNameByNetmodel(device *model.DcimDevice, port string, networkList []*model.TicketNetworkAccess) {
	var clusterDeviceList []*model.DcimDevice
	masterDevice := device.GetMasterDevice()
	slaveDevice := device.GetSlaveDevice()
	clusterDeviceList = append(clusterDeviceList, masterDevice, slaveDevice)
	for index, network := range networkList {
		network.Port = port
		switch network.Netmodel {
		case 1, 2:
			network.Device = clusterDeviceList[0].Name
		case 3:
			network.Device = clusterDeviceList[1].Name
		default:
			network.Device = clusterDeviceList[index].Name
		}
		global.GVA_DB.Save(network)
	}
}

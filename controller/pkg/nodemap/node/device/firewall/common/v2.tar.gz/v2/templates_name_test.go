package v2

import (
	"strings"
	"testing"

	"github.com/netxops/keys"
	"github.com/netxops/utils/network"
	"github.com/netxops/utils/service"
	"github.com/stretchr/testify/assert"
)

// ==================== network_object_name_template 测试 ====================

// TestNetworkObjectNameTemplate_BasicPlaceholders 测试基础占位符
func TestNetworkObjectNameTemplate_BasicPlaceholders(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		template    string
		expected    string
		description string
	}{
		{
			name:        "单IP地址 - {ip}",
			network:     "192.168.1.1/32",
			template:    "HOST_{ip}",
			expected:    "HOST_192.168.1.1",
			description: "测试 {ip} 占位符用于单IP地址",
		},
		{
			name:        "CIDR网络 - {cidr}",
			network:     "192.168.1.0/24",
			template:    "NET_{cidr}",
			expected:    "NET_192.168.1.0/24",
			description: "测试 {cidr} 占位符用于CIDR网络",
		},
		{
			name:        "IP范围 - {start}_{end}",
			network:     "192.168.1.10-192.168.1.20",
			template:    "RANGE_{start}_{end}",
			expected:    "RANGE_192.168.1.10_192.168.1.20",
			description: "测试 {start} 和 {end} 占位符用于IP范围",
		},
		{
			name:        "子网掩码 - {mask}",
			network:     "192.168.1.0/24",
			template:    "NET_{ip}_{mask}",
			expected:    "NET_192.168.1.0_24",
			description: "测试 {mask} 占位符用于子网掩码",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ng := network.NewNetworkGroupFromStringMust(tt.network)
			metaData := map[string]interface{}{
				"network_object_name_template": tt.template,
			}

			result := generateObjectNameFromTemplate(ng, tt.template, metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s", tt.expected, result)
		})
	}
}

// TestNetworkObjectNameTemplate_ConditionalLogic 测试条件逻辑
func TestNetworkObjectNameTemplate_ConditionalLogic(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		template    string
		expected    string
		description string
	}{
		{
			name:        "条件判断 - 单IP",
			network:     "192.168.1.1/32",
			template:    "{if:type==\"host\"}HOST_{ip}{else}NET_{cidr}{endif}",
			expected:    "HOST_192.168.1.1",
			description: "测试条件判断，单IP应该生成HOST前缀",
		},
		{
			name:        "条件判断 - CIDR网络",
			network:     "192.168.1.0/24",
			template:    "{if:type==\"host\"}HOST_{ip}{else}NET_{cidr}{endif}",
			expected:    "NET_192.168.1.0/24",
			description: "测试条件判断，CIDR网络应该生成NET前缀",
		},
		{
			name:        "条件判断 - IP范围",
			network:     "192.168.1.10-192.168.1.20",
			template:    "{if:type==\"range\"}RANGE_{start}_{end}{else}{cidr}{endif}",
			expected:    "RANGE_192.168.1.10_192.168.1.20",
			description: "测试条件判断，IP范围应该生成RANGE前缀",
		},
		{
			name:        "多条件判断 - else if",
			network:     "192.168.1.0/24",
			template:    "{if:type==\"host\"}HOST_{ip}{else if:type==\"subnet\"}SUBNET_{cidr}{else}RANGE_{start}_{end}{endif}",
			expected:    "SUBNET_192.168.1.0/24",
			description: "测试多条件判断（else if）",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ng := network.NewNetworkGroupFromStringMust(tt.network)
			metaData := map[string]interface{}{
				"network_object_name_template": tt.template,
			}

			result := generateObjectNameFromTemplate(ng, tt.template, metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s", tt.expected, result)
		})
	}
}

// TestNetworkObjectNameTemplate_FormatOptions 测试格式化选项
func TestNetworkObjectNameTemplate_FormatOptions(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		template    string
		expected    string
		description string
	}{
		{
			name:        "压缩IPv6 - {ip:compressed}",
			network:     "2001:0db8:0000:0000:0000:0000:0000:0001/128",
			template:    "IPV6_{ip:compressed}",
			expected:    "IPV6_2001:db8::1",
			description: "测试IPv6压缩格式",
		},
		{
			name:        "不压缩IPv6 - {ip}",
			network:     "2001:0db8::1/128",
			template:    "IPV6_{ip}",
			expected:    "IPV6_2001:db8::1",
			description: "测试IPv6非压缩格式",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ng := network.NewNetworkGroupFromStringMust(tt.network)
			metaData := map[string]interface{}{
				"network_object_name_template": tt.template,
			}

			result := generateObjectNameFromTemplate(ng, tt.template, metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s", tt.expected, result)
		})
	}
}

// TestNetworkObjectNameTemplate_MetaDataVariables 测试元数据变量
func TestNetworkObjectNameTemplate_MetaDataVariables(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		template    string
		metaData    map[string]interface{}
		expected    string
		description string
	}{
		{
			name:     "使用 policy_name",
			network:  "192.168.1.0/24",
			template: "{policy_name}_NET_{cidr}",
			metaData: map[string]interface{}{
				"network_object_name_template": "{policy_name}_NET_{cidr}",
				"policy_name":                  "POLICY_001",
			},
			expected:    "POLICY_001_NET_192.168.1.0/24",
			description: "测试使用 policy_name 变量",
		},
		{
			name:     "使用 is_source",
			network:  "192.168.1.0/24",
			template: "{if:is_source==\"true\"}SRC_{cidr}{else}DST_{cidr}{endif}",
			metaData: map[string]interface{}{
				"network_object_name_template": "{if:is_source==\"true\"}SRC_{cidr}{else}DST_{cidr}{endif}",
				"is_source":                    "true",
			},
			expected:    "SRC_192.168.1.0/24",
			description: "测试使用 is_source 变量区分源/目标地址",
		},
		{
			name:     "组合多个变量",
			network:  "192.168.1.0/24",
			template: "{policy_name}_{if:is_source==\"true\"}SRC{else}DST{endif}_{cidr}",
			metaData: map[string]interface{}{
				"network_object_name_template": "{policy_name}_{if:is_source==\"true\"}SRC{else}DST{endif}_{cidr}",
				"policy_name":                  "POLICY_001",
				"is_source":                    "false",
			},
			expected:    "POLICY_001_DST_192.168.1.0/24",
			description: "测试组合多个元数据变量",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ng := network.NewNetworkGroupFromStringMust(tt.network)
			result := generateObjectNameFromTemplate(ng, tt.template, tt.metaData)
			assert.NotEmpty(t, result, tt.description)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s", tt.expected, result)
		})
	}
}

// TestNetworkObjectNameTemplate_ComplexScenarios 测试复杂场景
func TestNetworkObjectNameTemplate_ComplexScenarios(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		template    string
		metaData    map[string]interface{}
		checkFunc   func(t *testing.T, result string)
		description string
	}{
		{
			name:     "复杂条件判断 - 类型+元数据",
			network:  "192.168.1.1/32",
			template: "{if:type==\"host\"}{if:is_source==\"true\"}SRC_HOST_{ip}{else}DST_HOST_{ip}{endif}{else}NET_{cidr}{endif}",
			metaData: map[string]interface{}{
				"network_object_name_template": "{if:type==\"host\"}{if:is_source==\"true\"}SRC_HOST_{ip}{else}DST_HOST_{ip}{endif}{else}NET_{cidr}{endif}",
				"is_source":                    "true",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "SRC_HOST_192.168.1.1", result,
					"期望: SRC_HOST_192.168.1.1, 实际: %s", result)
			},
			description: "测试嵌套条件判断",
		},
		{
			name:     "条件变量检查 - {if:var!=\"\"}",
			network:  "192.168.1.0/24",
			template: "NET_{cidr}{if:custom_suffix!=\"\"}_{custom_suffix}{endif}",
			metaData: map[string]interface{}{
				"network_object_name_template": "NET_{cidr}{if:custom_suffix!=\"\"}_{custom_suffix}{endif}",
				"custom_suffix":                "CUSTOM",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "NET_192.168.1.0/24_CUSTOM", result,
					"期望: NET_192.168.1.0/24_CUSTOM, 实际: %s", result)
			},
			description: "测试条件变量检查（使用非空检查替代存在性检查）",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ng := network.NewNetworkGroupFromStringMust(tt.network)
			result := generateObjectNameFromTemplate(ng, tt.template, tt.metaData)
			assert.NotEmpty(t, result, tt.description)
			tt.checkFunc(t, result)
		})
	}
}

// ==================== service_object_name_template 测试 ====================

// TestServiceObjectNameTemplate_BasicPlaceholders 测试基础占位符
func TestServiceObjectNameTemplate_BasicPlaceholders(t *testing.T) {
	tests := []struct {
		name        string
		service     string
		template    string
		expected    string
		description string
	}{
		{
			name:        "TCP协议 - {protocol}",
			service:     "tcp:80",
			template:    "SVC_{protocol:upper}",
			expected:    "SVC_TCP",
			description: "测试 {protocol} 占位符用于TCP协议",
		},
		{
			name:        "UDP协议 - {protocol}",
			service:     "udp:53",
			template:    "SVC_{protocol:upper}",
			expected:    "SVC_UDP",
			description: "测试 {protocol} 占位符用于UDP协议",
		},
		{
			name:        "目标端口 - {dst_port}",
			service:     "tcp:80",
			template:    "SVC_{protocol:lower}_{dst_port}",
			expected:    "SVC_tcp_80",
			description: "测试 {dst_port} 占位符",
		},
		{
			name:        "源端口 - {src_port}",
			service:     "tcp:1024-65535|80",
			template:    "SVC_{protocol:lower}_{src_port:compact}_to_{dst_port}",
			expected:    "SVC_tcp_1024-65535_to_80",
			description: "测试 {src_port} 占位符",
		},
		{
			name:        "ICMP协议 - {protocol}",
			service:     "icmp:8|0",
			template:    "ICMP_{protocol:upper}",
			expected:    "ICMP_ICMP",
			description: "测试ICMP协议占位符（注意：ICMP类型和代码在服务对象名称模板中可能不可用）",
		},
		{
			name:        "L3协议 - {protocol}",
			service:     "ip",
			template:    "L3_{protocol:upper}",
			expected:    "L3_IP",
			description: "测试L3协议占位符",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			metaData := map[string]interface{}{
				"service_object_name_template": tt.template,
			}

			result := ct.generateServiceNameFromTemplate(firstEntry, tt.template, metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s", tt.expected, result)
		})
	}
}

// TestServiceObjectNameTemplate_FormatOptions 测试格式化选项
func TestServiceObjectNameTemplate_FormatOptions(t *testing.T) {
	tests := []struct {
		name        string
		service     string
		template    string
		expected    string
		description string
	}{
		{
			name:        "协议大写 - {protocol:upper}",
			service:     "tcp:80",
			template:    "SVC_{protocol:upper}",
			expected:    "SVC_TCP",
			description: "测试协议大写格式",
		},
		{
			name:        "协议小写 - {protocol:lower}",
			service:     "tcp:80",
			template:    "SVC_{protocol:lower}",
			expected:    "SVC_tcp",
			description: "测试协议小写格式",
		},
		{
			name:        "端口紧凑格式 - {dst_port:compact}",
			service:     "tcp:80-90",
			template:    "SVC_{protocol:lower}_{dst_port:compact}",
			expected:    "SVC_tcp_80-90",
			description: "测试端口紧凑格式",
		},
		{
			name:        "端口范围格式 - {dst_port:range}",
			service:     "tcp:80-90",
			template:    "SVC_{protocol:lower}_{dst_port:range}",
			expected:    "SVC_tcp_80-90",
			description: "测试端口范围格式",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			metaData := map[string]interface{}{
				"service_object_name_template": tt.template,
			}

			result := ct.generateServiceNameFromTemplate(firstEntry, tt.template, metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s", tt.expected, result)
		})
	}
}

// TestServiceObjectNameTemplate_ConditionalLogic 测试条件逻辑
func TestServiceObjectNameTemplate_ConditionalLogic(t *testing.T) {
	tests := []struct {
		name        string
		service     string
		template    string
		expected    string
		description string
	}{
		{
			name:        "TCP条件判断",
			service:     "tcp:80",
			template:    "{if:protocol==\"TCP\"}TCP_SVC_{dst_port}{else}OTHER_{protocol}{endif}",
			expected:    "TCP_SVC_80",
			description: "测试TCP协议条件判断",
		},
		{
			name:        "UDP条件判断",
			service:     "udp:53",
			template:    "{if:protocol==\"UDP\"}UDP_SVC_{dst_port}{else}OTHER_{protocol}{endif}",
			expected:    "UDP_SVC_53",
			description: "测试UDP协议条件判断",
		},
		{
			name:        "ICMP条件判断",
			service:     "icmp:8|0",
			template:    "{if:protocol==\"ICMP\"}ICMP_PROTOCOL{else}{protocol}_{dst_port}{endif}",
			expected:    "ICMP_PROTOCOL",
			description: "测试ICMP协议条件判断（注意：ICMP类型和代码在服务对象名称模板中可能不可用）",
		},
		{
			name:        "端口范围条件判断",
			service:     "tcp:80-90",
			template:    "{if:isL4==\"true\"}{protocol:lower}_{dst_port:range}{else}{protocol}{endif}",
			expected:    "tcp_80-90",
			description: "测试端口范围条件判断",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			metaData := map[string]interface{}{
				"service_object_name_template": tt.template,
			}

			result := ct.generateServiceNameFromTemplate(firstEntry, tt.template, metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s", tt.expected, result)
		})
	}
}

// TestServiceObjectNameTemplate_MetaDataVariables 测试元数据变量
func TestServiceObjectNameTemplate_MetaDataVariables(t *testing.T) {
	tests := []struct {
		name        string
		service     string
		template    string
		metaData    map[string]interface{}
		expected    string
		description string
	}{
		{
			name:     "使用 policy_name",
			service:  "tcp:80",
			template: "{policy_name}_{protocol:lower}_{dst_port}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{policy_name}_{protocol:lower}_{dst_port}",
				"policy_name":                  "POLICY_001",
			},
			expected:    "POLICY_001_tcp_80",
			description: "测试使用 policy_name 变量",
		},
		{
			name:     "条件端口处理 - 使用变量",
			service:  "tcp:80",
			template: "{policy_name}_{protocol:lower}{if:compact_port!=\"\"}_{compact_port}{endif}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{policy_name}_{protocol:lower}{if:compact_port!=\"\"}_{compact_port}{endif}",
				"policy_name":                  "POLICY_001",
				"compact_port":                 "80",
			},
			expected:    "POLICY_001_tcp_80",
			description: "测试条件端口处理（使用变量非空检查）",
		},
		{
			name:     "组合多个变量",
			service:  "tcp:80-90",
			template: "{policy_name}_{protocol:upper}_{dst_port:compact}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{policy_name}_{protocol:upper}_{dst_port:compact}",
				"policy_name":                  "POLICY_001",
			},
			expected:    "POLICY_001_TCP_80-90",
			description: "测试组合多个变量和格式化选项",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			result := ct.generateServiceNameFromTemplate(firstEntry, tt.template, tt.metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s", tt.expected, result)
		})
	}
}

// TestServiceObjectNameTemplate_ComplexScenarios 测试复杂场景
func TestServiceObjectNameTemplate_ComplexScenarios(t *testing.T) {
	tests := []struct {
		name        string
		service     string
		template    string
		metaData    map[string]interface{}
		checkFunc   func(t *testing.T, result string)
		description string
	}{
		{
			name:     "嵌套条件判断",
			service:  "tcp:80",
			template: "{if:isL4==\"true\"}{if:protocol==\"TCP\"}TCP_{dst_port}{else}UDP_{dst_port}{endif}{else}{protocol}{endif}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{if:isL4==\"true\"}{if:protocol==\"TCP\"}TCP_{dst_port}{else}UDP_{dst_port}{endif}{else}{protocol}{endif}",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "TCP_80", result,
					"期望: TCP_80, 实际: %s", result)
			},
			description: "测试嵌套条件判断",
		},
		{
			name:     "端口范围处理",
			service:  "tcp:8080-8090",
			template: "{protocol:lower}_{dst_port:range}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{protocol:lower}_{dst_port:range}",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "tcp_8080-8090", result,
					"期望: tcp_8080-8090, 实际: %s", result)
			},
			description: "测试端口范围处理",
		},
		{
			name:     "单服务条目",
			service:  "tcp:80",
			template: "{protocol:upper}_{dst_port:compact}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{protocol:upper}_{dst_port:compact}",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "TCP_80", result,
					"期望: TCP_80, 实际: %s", result)
			},
			description: "测试单服务条目",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			result := ct.generateServiceNameFromTemplate(firstEntry, tt.template, tt.metaData)
			assert.NotEmpty(t, result, tt.description)
			tt.checkFunc(t, result)
		})
	}
}

// TestServiceObjectNameTemplate_EdgeCases 测试边界情况
func TestServiceObjectNameTemplate_EdgeCases(t *testing.T) {
	tests := []struct {
		name        string
		service     string
		template    string
		metaData    map[string]interface{}
		checkFunc   func(t *testing.T, result string)
		description string
	}{
		{
			name:     "空模板",
			service:  "tcp:80",
			template: "",
			metaData: map[string]interface{}{
				"service_object_name_template": "",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Empty(t, result, "空模板应该返回空字符串")
			},
			description: "测试空模板",
		},
		{
			name:     "全端口范围",
			service:  "tcp:0-65535",
			template: "{protocol:lower}_any",
			metaData: map[string]interface{}{
				"service_object_name_template": "{protocol:lower}_any",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "tcp_any", result,
					"期望: tcp_any, 实际: %s", result)
			},
			description: "测试全端口范围处理",
		},
		{
			name:     "L3协议（无端口）",
			service:  "ip",
			template: "{protocol:upper}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{protocol:upper}",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Contains(t, result, "IP")
				// L3协议不应该有端口，只包含协议名称
				assert.Equal(t, "IP", result)
			},
			description: "测试L3协议（无端口）",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			result := ct.generateServiceNameFromTemplate(firstEntry, tt.template, tt.metaData)
			tt.checkFunc(t, result)
		})
	}
}

// ==================== 集成测试：模板函数直接测试 ====================

// TestGenerateObjectNameFromTemplate_Integration 测试 generateObjectNameFromTemplate 函数的集成场景
func TestGenerateObjectNameFromTemplate_Integration(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		template    string
		metaData    map[string]interface{}
		checkFunc   func(t *testing.T, result string)
		description string
	}{
		{
			name:     "完整集成测试 - 策略名称+网络类型",
			network:  "192.168.1.0/24",
			template: "{policy_name}_NET_{cidr}",
			metaData: map[string]interface{}{
				"network_object_name_template": "{policy_name}_NET_{cidr}",
				"policy_name":                  "TEST_POLICY",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "TEST_POLICY_NET_192.168.1.0/24", result,
					"期望: TEST_POLICY_NET_192.168.1.0/24, 实际: %s", result)
			},
			description: "测试完整的模板生成流程",
		},
		{
			name:     "源/目标地址区分",
			network:  "192.168.1.0/24",
			template: "{if:is_source==\"true\"}SRC_{cidr}{else}DST_{cidr}{endif}",
			metaData: map[string]interface{}{
				"network_object_name_template": "{if:is_source==\"true\"}SRC_{cidr}{else}DST_{cidr}{endif}",
				"is_source":                    "false",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "DST_192.168.1.0/24", result,
					"期望: DST_192.168.1.0/24, 实际: %s", result)
			},
			description: "测试源/目标地址区分",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ng := network.NewNetworkGroupFromStringMust(tt.network)
			result := generateObjectNameFromTemplate(ng, tt.template, tt.metaData)
			assert.NotEmpty(t, result, tt.description)
			tt.checkFunc(t, result)
		})
	}
}

// TestGenerateServiceNameFromTemplate_Integration 测试 generateServiceNameFromTemplate 函数的集成场景
func TestGenerateServiceNameFromTemplate_Integration(t *testing.T) {
	tests := []struct {
		name        string
		service     string
		template    string
		metaData    map[string]interface{}
		checkFunc   func(t *testing.T, result string)
		description string
	}{
		{
			name:     "完整集成测试 - 策略名称+协议+端口",
			service:  "tcp:80",
			template: "{policy_name}_{protocol:upper}_{dst_port}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{policy_name}_{protocol:upper}_{dst_port}",
				"policy_name":                  "TEST_POLICY",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "TEST_POLICY_TCP_80", result,
					"期望: TEST_POLICY_TCP_80, 实际: %s", result)
			},
			description: "测试完整的服务模板生成流程",
		},
		{
			name:     "条件端口处理",
			service:  "tcp:80",
			template: "{policy_name}_{protocol:lower}_{dst_port}",
			metaData: map[string]interface{}{
				"service_object_name_template": "{policy_name}_{protocol:lower}_{dst_port}",
				"policy_name":                  "TEST_POLICY",
			},
			checkFunc: func(t *testing.T, result string) {
				assert.Equal(t, "TEST_POLICY_tcp_80", result,
					"期望: TEST_POLICY_tcp_80, 实际: %s", result)
			},
			description: "测试条件端口处理",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			result := ct.generateServiceNameFromTemplate(firstEntry, tt.template, tt.metaData)
			assert.NotEmpty(t, result, tt.description)
			tt.checkFunc(t, result)
		})
	}
}

// TestGetActualOutputs 辅助测试：获取所有测试用例的实际输出（用于更新期望值）
// 注意：此测试默认跳过，仅在需要获取实际输出时使用
func TestGetActualOutputs(t *testing.T) {
	// t.Skip("辅助测试：仅在需要获取实际输出时启用")

	t.Log("=== Network Object Name Template Actual Outputs ===")

	// TestNetworkObjectNameTemplate_BasicPlaceholders
	t.Logf("单IP地址: %q", getNetworkObjectNameActual("192.168.1.1/32", "HOST_{ip}", map[string]interface{}{"network_object_name_template": "HOST_{ip}"}))
	t.Logf("CIDR网络: %q", getNetworkObjectNameActual("192.168.1.0/24", "NET_{cidr}", map[string]interface{}{"network_object_name_template": "NET_{cidr}"}))
	t.Logf("IP范围: %q", getNetworkObjectNameActual("192.168.1.10-192.168.1.20", "RANGE_{start}_{end}", map[string]interface{}{"network_object_name_template": "RANGE_{start}_{end}"}))
	t.Logf("子网掩码: %q", getNetworkObjectNameActual("192.168.1.0/24", "NET_{ip}_{mask}", map[string]interface{}{"network_object_name_template": "NET_{ip}_{mask}"}))

	// TestNetworkObjectNameTemplate_ConditionalLogic
	t.Logf("条件判断-单IP: %q", getNetworkObjectNameActual("192.168.1.1/32", "{if:type==\"host\"}HOST_{ip}{else}NET_{cidr}{endif}", map[string]interface{}{"network_object_name_template": "{if:type==\"host\"}HOST_{ip}{else}NET_{cidr}{endif}"}))
	t.Logf("条件判断-CIDR: %q", getNetworkObjectNameActual("192.168.1.0/24", "{if:type==\"host\"}HOST_{ip}{else}NET_{cidr}{endif}", map[string]interface{}{"network_object_name_template": "{if:type==\"host\"}HOST_{ip}{else}NET_{cidr}{endif}"}))
	t.Logf("条件判断-IP范围: %q", getNetworkObjectNameActual("192.168.1.10-192.168.1.20", "{if:type==\"range\"}RANGE_{start}_{end}{else}{cidr}{endif}", map[string]interface{}{"network_object_name_template": "{if:type==\"range\"}RANGE_{start}_{end}{else}{cidr}{endif}"}))
	t.Logf("多条件判断: %q", getNetworkObjectNameActual("192.168.1.0/24", "{if:type==\"host\"}HOST_{ip}{else if:type==\"subnet\"}SUBNET_{cidr}{else}RANGE_{start}_{end}{endif}", map[string]interface{}{"network_object_name_template": "{if:type==\"host\"}HOST_{ip}{else if:type==\"subnet\"}SUBNET_{cidr}{else}RANGE_{start}_{end}{endif}"}))

	// TestNetworkObjectNameTemplate_FormatOptions
	t.Logf("IPv6压缩: %q", getNetworkObjectNameActual("2001:0db8:0000:0000:0000:0000:0000:0001/128", "IPV6_{ip:compressed}", map[string]interface{}{"network_object_name_template": "IPV6_{ip:compressed}"}))
	t.Logf("IPv6非压缩: %q", getNetworkObjectNameActual("2001:0db8::1/128", "IPV6_{ip}", map[string]interface{}{"network_object_name_template": "IPV6_{ip}"}))

	t.Log("\n=== Service Object Name Template Actual Outputs ===")

	// TestServiceObjectNameTemplate_BasicPlaceholders
	t.Logf("TCP协议: %q", getServiceObjectNameActual("tcp:80", "SVC_{protocol:upper}", map[string]interface{}{"service_object_name_template": "SVC_{protocol:upper}"}))
	t.Logf("UDP协议: %q", getServiceObjectNameActual("udp:53", "SVC_{protocol:upper}", map[string]interface{}{"service_object_name_template": "SVC_{protocol:upper}"}))
	t.Logf("目标端口: %q", getServiceObjectNameActual("tcp:80", "SVC_{protocol:lower}_{dst_port}", map[string]interface{}{"service_object_name_template": "SVC_{protocol:lower}_{dst_port}"}))
	t.Logf("源端口: %q", getServiceObjectNameActual("tcp:1024-65535|80", "SVC_{protocol:lower}_{src_port:compact}_to_{dst_port}", map[string]interface{}{"service_object_name_template": "SVC_{protocol:lower}_{src_port:compact}_to_{dst_port}"}))
	t.Logf("ICMP协议: %q", getServiceObjectNameActual("icmp:8|0", "ICMP_{protocol:upper}", map[string]interface{}{"service_object_name_template": "ICMP_{protocol:upper}"}))
	t.Logf("L3协议: %q", getServiceObjectNameActual("ip", "L3_{protocol:upper}", map[string]interface{}{"service_object_name_template": "L3_{protocol:upper}"}))

	// TestServiceObjectNameTemplate_FormatOptions
	t.Logf("协议大写: %q", getServiceObjectNameActual("tcp:80", "SVC_{protocol:upper}", map[string]interface{}{"service_object_name_template": "SVC_{protocol:upper}"}))
	t.Logf("协议小写: %q", getServiceObjectNameActual("tcp:80", "SVC_{protocol:lower}", map[string]interface{}{"service_object_name_template": "SVC_{protocol:lower}"}))
	t.Logf("端口紧凑格式: %q", getServiceObjectNameActual("tcp:80-90", "SVC_{protocol:lower}_{dst_port:compact}", map[string]interface{}{"service_object_name_template": "SVC_{protocol:lower}_{dst_port:compact}"}))
	t.Logf("端口范围格式: %q", getServiceObjectNameActual("tcp:80-90", "SVC_{protocol:lower}_{dst_port:range}", map[string]interface{}{"service_object_name_template": "SVC_{protocol:lower}_{dst_port:range}"}))

	// TestServiceObjectNameTemplate_ConditionalLogic
	t.Logf("TCP条件判断: %q", getServiceObjectNameActual("tcp:80", "{if:protocol==\"TCP\"}TCP_SVC_{dst_port}{else}OTHER_{protocol}{endif}", map[string]interface{}{"service_object_name_template": "{if:protocol==\"TCP\"}TCP_SVC_{dst_port}{else}OTHER_{protocol}{endif}"}))
	t.Logf("UDP条件判断: %q", getServiceObjectNameActual("udp:53", "{if:protocol==\"UDP\"}UDP_SVC_{dst_port}{else}OTHER_{protocol}{endif}", map[string]interface{}{"service_object_name_template": "{if:protocol==\"UDP\"}UDP_SVC_{dst_port}{else}OTHER_{protocol}{endif}"}))
	t.Logf("ICMP条件判断: %q", getServiceObjectNameActual("icmp:8|0", "{if:protocol==\"ICMP\"}ICMP_PROTOCOL{else}{protocol}_{dst_port}{endif}", map[string]interface{}{"service_object_name_template": "{if:protocol==\"ICMP\"}ICMP_PROTOCOL{else}{protocol}_{dst_port}{endif}"}))
	t.Logf("端口范围条件判断: %q", getServiceObjectNameActual("tcp:80-90", "{if:isL4==\"true\"}{protocol:lower}_{dst_port:range}{else}{protocol}{endif}", map[string]interface{}{"service_object_name_template": "{if:isL4==\"true\"}{protocol:lower}_{dst_port:range}{else}{protocol}{endif}"}))

	// TestServiceObjectNameTemplate_MetaDataVariables
	t.Logf("使用policy_name: %q", getServiceObjectNameActual("tcp:80", "{policy_name}_{protocol:lower}_{dst_port}", map[string]interface{}{"service_object_name_template": "{policy_name}_{protocol:lower}_{dst_port}", "policy_name": "POLICY_001"}))
	t.Logf("条件端口处理: %q", getServiceObjectNameActual("tcp:80", "{policy_name}_{protocol:lower}{if:compact_port!=\"\"}_{compact_port}{endif}", map[string]interface{}{"service_object_name_template": "{policy_name}_{protocol:lower}{if:compact_port!=\"\"}_{compact_port}{endif}", "policy_name": "POLICY_001", "compact_port": "80"}))
	t.Logf("组合多个变量: %q", getServiceObjectNameActual("tcp:80-90", "{policy_name}_{protocol:upper}_{dst_port:compact}", map[string]interface{}{"service_object_name_template": "{policy_name}_{protocol:upper}_{dst_port:compact}", "policy_name": "POLICY_001"}))
}

// 辅助函数：获取网络对象名称的实际输出
func getNetworkObjectNameActual(networkStr, template string, metaData map[string]interface{}) string {
	ng := network.NewNetworkGroupFromStringMust(networkStr)
	return generateObjectNameFromTemplate(ng, template, metaData)
}

// 辅助函数：获取服务对象名称的实际输出
func getServiceObjectNameActual(serviceStr, template string, metaData map[string]interface{}) string {
	svc := service.NewServiceMust(serviceStr)
	var firstEntry service.ServiceEntry
	svc.EachDetailed(func(item service.ServiceEntry) bool {
		firstEntry = item
		return false
	})

	ct := &CommonTemplatesV2{}
	return ct.generateServiceNameFromTemplate(firstEntry, template, metaData)
}

// MockTemplatesV2 用于测试的模拟 TemplatesV2
type MockTemplatesV2 struct{}

func (m *MockTemplatesV2) GetLayout(key keys.Keys) string {
	keyStr := key.String()

	switch {
	case strings.Contains(keyStr, "AddressObject"):
		return "address-object {object_name} {if:is_source==\"true\"}source{else}destination{endif} {if:is_source==\"true\"}{src_network}{else}{dst_network}{endif}"
	case strings.Contains(keyStr, "ServiceObject"):
		return "service-object {object_name} {service}"
	case strings.Contains(keyStr, "AddressGroup"):
		return "address-group {object_name} members {for:obj in member_objects}{obj}{if:!last},{endif}{endfor}"
	case strings.Contains(keyStr, "ServiceGroup"):
		return "service-group {object_name} members {for:obj in member_objects}{obj}{if:!last},{endif}{endfor}"
	default:
		return ""
	}
}

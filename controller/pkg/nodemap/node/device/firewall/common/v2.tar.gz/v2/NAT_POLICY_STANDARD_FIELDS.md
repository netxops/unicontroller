# NAT Policy Layout 标准字段定义

本文档定义了所有NAT Policy Layout使用的标准化字段，确保不同防火墙的layout能够按照预期运行。

## 字段分类

### 1. 基础NAT信息字段

#### nat_type
- **类型**: string
- **值**: "DNAT" 或 "SNAT"
- **来源**: `determineNatType` 函数
- **用途**: 标识NAT类型，用于layout选择不同的渲染逻辑
- **必需**: 是

#### nat_name / nat_rule_name
- **类型**: string
- **来源**: `generateNatPolicyName` 函数
- **用途**: NAT策略的名称
- **必需**: 是

### 2. 源地址相关字段

#### has_source_objects
- **类型**: string ("true" 或 "false")
- **来源**: 当 `objectMode.SourceAddressMode == "object"` 且 `len(result.SourceObjects) > 0` 时设置为 "true"
- **用途**: 标识是否使用源地址对象
- **必需**: 是

#### src_objects / source_objects
- **类型**: []interface{} (字符串数组)
- **来源**: `result.SourceObjects`
- **用途**: 源地址对象名称列表
- **必需**: 当 `has_source_objects == "true"` 时必需

### 3. 目标地址相关字段

#### has_destination_objects
- **类型**: string ("true" 或 "false")
- **来源**: 当 `objectMode.DestinationAddressMode == "object"` 且 `len(result.DestinationObjects) > 0` 时设置为 "true"
- **用途**: 标识是否使用目标地址对象
- **必需**: 是

#### dst_objects / destination_objects
- **类型**: []interface{} (字符串数组)
- **来源**: `result.DestinationObjects`
- **用途**: 目标地址对象名称列表
- **必需**: 当 `has_destination_objects == "true"` 时必需

### 4. 服务相关字段

#### has_service_objects
- **类型**: string ("true" 或 "false")
- **来源**: 当 `objectMode.ServiceMode == "object"` 且 `len(result.ServiceObjects) > 0` 时设置为 "true"
- **用途**: 标识是否使用服务对象
- **必需**: 是

#### service_objects
- **类型**: []interface{} (字符串数组)
- **来源**: `result.ServiceObjects`
- **用途**: 服务对象名称列表
- **必需**: 当 `has_service_objects == "true"` 时必需

### 5. Zone相关字段

#### sourceZones / fromZone
- **类型**: []interface{} (字符串数组) / string
- **来源**: `extractZoneInfo` 函数
- **用途**: 源zone列表或单个源zone
- **必需**: 否（根据防火墙要求）

#### destinationZones / toZone
- **类型**: []interface{} (字符串数组) / string
- **来源**: `extractZoneInfo` 函数
- **用途**: 目标zone列表或单个目标zone
- **必需**: 否（根据防火墙要求）

### 6. 接口相关字段

#### fromPort / toPort
- **类型**: string
- **来源**: `extractInterfaceInfo` 函数
- **用途**: 源接口名称 / 目标接口名称
- **必需**: 否（根据防火墙要求）

#### has_fromPort / has_toPort
- **类型**: string ("true" 或 "false")
- **来源**: 当 `from != nil` 且 `from.Name() != ""` 时设置为 "true"
- **用途**: 标识是否存在源接口 / 目标接口
- **必需**: 否（根据防火墙要求）

### 7. DNAT相关字段

#### has_real_ip
- **类型**: string ("true" 或 "false")
- **来源**: 当 `intent.RealIp != ""` 时设置为 "true"
- **用途**: 标识是否存在real_ip
- **必需**: 当 `nat_type == "DNAT"` 时必需

#### real_ip
- **类型**: string
- **来源**: `intent.RealIp`
- **用途**: DNAT的真实IP地址（inline模式）
- **必需**: 当 `has_real_ip == "true"` 且未使用VIP/MIP对象时必需

#### has_real_port
- **类型**: string ("true" 或 "false")
- **来源**: 当 `intent.RealPort != ""` 时设置为 "true"
- **用途**: 标识是否存在real_port
- **必需**: 当 `nat_type == "DNAT"` 时必需

#### real_port
- **类型**: string
- **来源**: `intent.RealPort`
- **用途**: DNAT的真实端口（inline模式）
- **必需**: 当 `has_real_port == "true"` 且未使用VIP/MIP对象时必需

#### vip_name / mip_name
- **类型**: string
- **来源**: `result.VipMipName`
- **用途**: VIP/MIP对象名称（object模式）
- **必需**: 当使用VIP/MIP对象时必需

#### has_vip_name / has_mip_name
- **类型**: string ("true" 或 "false")
- **来源**: 当 `result.VipMipName != ""` 时设置为 "true"
- **用途**: 标识是否使用VIP/MIP对象
- **必需**: 当使用VIP/MIP对象时必需

#### use_vip
- **类型**: string ("true" 或 "false")
- **来源**: 当VIP layout存在且 `result.VipMipName != ""` 时设置为 "true"
- **用途**: 标识是否使用VIP对象（某些防火墙需要区分VIP和MIP）
- **必需**: 否（根据防火墙要求）

#### mip_object
- **类型**: string
- **来源**: `result.VipMipName`（当MIP作为地址对象时）
- **用途**: MIP作为地址对象的名称（如Sangfor）
- **必需**: 否（根据防火墙要求，如Sangfor）

#### has_mip_object
- **类型**: string ("true" 或 "false")
- **来源**: 当MIP作为地址对象且 `result.VipMipName != ""` 时设置为 "true"
- **用途**: 标识MIP是否作为地址对象
- **必需**: 否（根据防火墙要求，如Sangfor）

### 8. SNAT相关字段

#### has_snat
- **类型**: string ("true" 或 "false")
- **来源**: 当 `intent.Snat != ""` 时设置为 "true"
- **用途**: 标识是否存在snat地址
- **必需**: 当 `nat_type == "SNAT"` 时必需

#### snat
- **类型**: string
- **来源**: `intent.Snat`
- **用途**: SNAT的地址（inline模式）
- **必需**: 当 `has_snat == "true"` 且未使用SNAT_POOL对象时必需

#### has_snat_inline
- **类型**: string ("true" 或 "false")
- **来源**: 当 `objectMode.SnatPoolMode == "inline"` 时设置为 "true"
- **用途**: 标识是否使用inline模式的SNAT
- **必需**: 否（根据防火墙要求）

#### pool_id / pool_name
- **类型**: string
- **来源**: `result.SnatPoolName`
- **用途**: SNAT_POOL对象名称（object模式）
- **必需**: 当使用SNAT_POOL对象时必需

#### has_pool_id / use_pool
- **类型**: string ("true" 或 "false")
- **来源**: 当 `result.SnatPoolName != ""` 时设置为 "true"
- **用途**: 标识是否使用SNAT_POOL对象
- **必需**: 当使用SNAT_POOL对象时必需

#### interface_name
- **类型**: string
- **来源**: 当 `objectMode.SnatPoolMode == "interface"` 时，使用 `to.Name()`
- **用途**: 接口模式的SNAT使用的接口名称
- **必需**: 当使用接口模式SNAT时必需

#### has_interface_name
- **类型**: string ("true" 或 "false")
- **来源**: 当 `objectMode.SnatPoolMode == "interface"` 且 `to != nil` 且 `to.Name() != ""` 时设置为 "true"
- **用途**: 标识是否使用接口模式SNAT
- **必需**: 当使用接口模式SNAT时必需

### 9. 其他字段

#### enable
- **类型**: string ("true" 或 "false")
- **来源**: 从 `metaData["enable"]` 读取，默认为 "true"
- **用途**: 标识NAT策略是否启用
- **必需**: 否（根据防火墙要求）

#### description
- **类型**: string
- **来源**: 从 `metaData["description"]` 读取
- **用途**: NAT策略的描述
- **必需**: 否

## NAT对象生成过程

NAT对象的生成过程遵循以下5个步骤（在 `processDnatObject` 和 `processSnatObject` 中实现）：

### 步骤1: 调用GetReuseNatObject，明确复用还是新建
- **所有模式**（包括inline/interface）都会调用 `GetReuseNatObject`
- 即使是inline模式，也需要调用以确定objectType
- 如果返回 `reused == true`，直接使用复用对象，跳过后续步骤
- 如果返回 `reused == false`，继续后续步骤

### 步骤2: 进行数据整理
- 因为不同防火墙的layout，必定有一些不同的字段需求
- 根据 `objectMode` 和 `metaData` 确定是否需要生成对象
- 如果是inline/interface模式，无需生成对象，直接返回
- 如果是object模式，继续步骤3

### 步骤3: 新建NAT对象（object模式）
- 即使是inline，也无需特别处理（已在步骤2中处理）
- 仅当object模式时，才执行对象生成逻辑
- 调用 `processVipMipObjectLegacy` 或 `processSnatPoolObjectLegacy` 生成对象

### 步骤4: 整合所有数据
- 在对象生成函数中完成数据整合
- 将生成的对象CLI添加到 `result.FlyObject`
- 设置 `result.VipMipName` 或 `result.SnatPoolName`

### 步骤5: 进行NAT Policy Layout渲染
- 在 `renderNatPolicy` 函数中完成
- 使用 `prepareNatPolicyData` 准备模板数据
- 使用 `selectNatPolicyLayout` 选择layout
- 使用 `renderNatPolicyTemplate` 渲染模板

## 字段设置规则

### 复用对象时的字段设置

当NAT对象被复用时（`GetReuseNatObject` 返回 `reused == true`）：
- 设置对应的 `has_*` 标志为 "true"
- 设置对应的对象名称字段（如 `vip_name`、`pool_id`）
- 设置 `result.IsReused = true`
- **不生成**对象定义的CLI（对象已存在）
- **跳过**步骤2-4（数据整理、新建对象、整合数据）

### 新建对象时的字段设置

当NAT对象需要新建时（`GetReuseNatObject` 返回 `reused == false` 且 `objectMode` 为 "object"）：
- 执行步骤2-4（数据整理、新建对象、整合数据）
- 设置对应的 `has_*` 标志为 "true"
- 设置对应的对象名称字段
- **生成**对象定义的CLI（添加到 `result.FlyObject`）

### Inline模式时的字段设置

当使用inline模式时（`objectMode.VipMipMode == "inline"` 或 `objectMode.SnatPoolMode == "inline"`）：
- **仍然调用** `GetReuseNatObject`（步骤1），但会返回 `reused == false`
- 在步骤2中检测到inline模式，直接返回，**跳过**步骤3-4
- 在 `renderNatPolicy` 中设置对应的 `has_*` 标志（如 `has_real_ip`、`has_snat`）
- 在 `renderNatPolicy` 中设置对应的值字段（如 `real_ip`、`snat`）
- **不生成**对象定义的CLI

### Interface模式时的字段设置（仅SNAT）

当使用interface模式时（`objectMode.SnatPoolMode == "interface"`）：
- **仍然调用** `GetReuseNatObject`（步骤1），但会返回 `reused == false`
- 在步骤2中检测到interface模式，直接返回，**跳过**步骤3-4
- 在 `renderNatPolicy` 中设置 `has_interface_name = "true"`
- 在 `renderNatPolicy` 中设置 `interface_name` 为接口名称
- **不生成**对象定义的CLI

## 字段使用示例

### DNAT示例（使用VIP对象）
```go
data["nat_type"] = "DNAT"
data["nat_name"] = "DNAT_POLICY_1"
data["has_vip_name"] = "true"
data["vip_name"] = "WEB_SERVER_VIP"
data["use_vip"] = "true"
```

### DNAT示例（inline模式）
```go
data["nat_type"] = "DNAT"
data["nat_name"] = "DNAT_POLICY_1"
data["has_real_ip"] = "true"
data["real_ip"] = "192.168.1.100"
data["has_real_port"] = "true"
data["real_port"] = "8080"
```

### SNAT示例（使用SNAT_POOL对象）
```go
data["nat_type"] = "SNAT"
data["nat_name"] = "SNAT_POLICY_1"
data["has_pool_id"] = "true"
data["pool_id"] = "SNAT_POOL_1"
data["use_pool"] = "true"
```

### SNAT示例（接口模式）
```go
data["nat_type"] = "SNAT"
data["nat_name"] = "SNAT_POLICY_1"
data["has_interface_name"] = "true"
data["interface_name"] = "GigabitEthernet0/0"
```


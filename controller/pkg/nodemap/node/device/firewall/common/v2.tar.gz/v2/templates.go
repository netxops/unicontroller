package v2

import (
	"fmt"
	"strings"

	"github.com/netxops/keys"
	"github.com/netxops/l2service/pkg/nodemap/api"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall/common"
	"github.com/netxops/utils/dsl"
	"github.com/netxops/utils/network"
	"github.com/netxops/utils/policy"
	"github.com/netxops/utils/service"
)

// CommonTemplatesV2 V2版本的通用模板实现
type CommonTemplatesV2 struct {
	Node                  firewall.FirewallNode
	Templates             TemplatesV2
	om                    *common.ObjectNameManager
	SectionSeparator      string             // 用于分隔多个对象CLI的分隔符
	policyTemplate        *common.IDTemplate // 策略名称模板（支持 {VAR:...} 和 {SEQ:...} 语法）
	currentPolicyTemplate string             // 当前使用的策略名称模板（用于检测模板是否改变）
	natTemplate           *common.IDTemplate // NAT策略名称模板（支持 {VAR:...} 和 {SEQ:...} 语法）
	currentNatTemplate    string             // 当前使用的NAT策略名称模板（用于检测模板是否改变）
}

// NewCommonTemplatesV2 创建新的V2通用模板实例
func NewCommonTemplatesV2(node firewall.FirewallNode, templates TemplatesV2) *CommonTemplatesV2 {
	// 获取分隔符，如果模板中没有定义，使用默认值 "#"
	separator := templates.GetLayout(keys.NewKeyBuilder("SectionSeparator"))
	if separator == "" {
		separator = "#" // 默认使用 "#"
	}

	ct := &CommonTemplatesV2{
		Node:             node,
		Templates:        templates,
		om:               common.NewObjectNameManager(),
		SectionSeparator: separator,
	}

	// 初始化 policyTemplate（如果节点支持迭代器）
	// 注意：policyTemplate 的模板会在 MakePolicyV2 中从 metaData 获取
	// 这里先创建一个默认模板，实际模板会在使用时更新
	defaultTemplate := "Policy_{SEQ:id:5:1:1:MAIN}"
	var getIterator func() firewall.NamerIterator
	if iteratorNode, ok := node.(firewall.IteratorFirewall); ok {
		getIterator = func() firewall.NamerIterator {
			return iteratorNode.PolicyIterator()
		}
	} else {
		// 如果节点不支持迭代器，创建一个空的迭代器
		getIterator = func() firewall.NamerIterator {
			return &emptyNamerIterator{}
		}
	}
	ct.policyTemplate = common.NewPolicyTemplate(defaultTemplate, getIterator).WithMaxRetries(10).Initialize()
	ct.currentPolicyTemplate = defaultTemplate

	return ct
}

// GetSectionSeparator 获取分隔符
func (ct *CommonTemplatesV2) GetSectionSeparator() string {
	return ct.SectionSeparator
}

// MakeAddressObjectV2 生成地址对象或地址组
func (ct *CommonTemplatesV2) MakeAddressObjectV2(intent *policy.Intent, isSource bool, ctx *firewall.PolicyContext, metaData map[string]interface{}) (*AddressObjectResult, error) {
	result := &AddressObjectResult{
		ObjectNames: []string{},
		IsGroup:     false,
		Keys:        []string{},
	}

	sectionSeparator := ct.Templates.GetLayout(keys.NewKeyBuilder("SectionSeparator"))
	if sectionSeparator == "" {
		// 如果模板中没有定义，使用默认值 "#"
		sectionSeparator = "#"
	}

	// 获取命名模板
	networkObjectNameTemplate := getStringFromMeta(metaData, "network_object_name_template", "")
	addressGroupNameTemplate := getStringFromMeta(metaData, "address_group_name_template", "")

	// 获取复用控制参数
	// 支持 securitypolicy.reuse_address_object 和 reuse_address_object 两种格式
	reuseAddressObject := getBoolFromMeta(metaData, "securitypolicy.reuse_address_object", false)
	if !reuseAddressObject {
		reuseAddressObject = getBoolFromMeta(metaData, "reuse_address_object", false)
	}
	// 默认值：如果 securitypolicy.reuse_policy 为 true，则默认复用地址对象
	if !reuseAddressObject {
		reusePolicy := getBoolFromMeta(metaData, "securitypolicy.reuse_policy", false)
		reuseAddressObject = reusePolicy
	}

	// 获取layout
	addressObjectLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("AddressObject", "OneLoop"))
	addressGroupLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("AddressGroup", "OneLoop"))

	// 确定要处理的网络组
	var targetNetworkGroup *network.NetworkGroup
	if isSource {
		targetNetworkGroup = intent.Src()
	} else {
		targetNetworkGroup = intent.Dst()
	}

	// 判断是否需要生成地址组
	// 如果网络组包含多个条目，且设备支持地址组，则生成地址组
	networkCount := 0
	targetNetworkGroup.EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
		networkCount++
		return true
	})

	// 检查设备是否支持地址组（通过检查 AddressGroup layout 是否存在）
	// 如果设备支持地址组且有多个条目，即使 addressGroupNameTemplate 为空，也应该生成地址组
	// 如果 addressGroupNameTemplate 为空，将使用默认命名逻辑（"ADDRESS_GROUP"）
	deviceSupportsAddressGroup := addressGroupLayout != ""
	shouldCreateGroup := networkCount > 1 && deviceSupportsAddressGroup

	// 调试信息：当有多个条目时，打印详细信息
	if networkCount > 1 {
		fmt.Printf("[DEBUG MakeAddressObjectV2] networkCount=%d, addressGroupLayout empty=%v (length=%d), deviceSupportsAddressGroup=%v, shouldCreateGroup=%v\n",
			networkCount, addressGroupLayout == "", len(addressGroupLayout), deviceSupportsAddressGroup, shouldCreateGroup)
		if addressGroupLayout == "" {
			fmt.Printf("[DEBUG MakeAddressObjectV2] WARNING: AddressGroup layout is empty! This may prevent address group generation.\n")
		}
	}

	if shouldCreateGroup {
		// 生成地址组
		// 1. 先为每个成员生成地址对象
		memberObjects := []string{}
		targetNetworkGroup.EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
			// 为每个成员创建网络组
			memberNet := network.NewNetworkGroup()
			memberNet.Add(item)

			var key keys.Keys
			var isNew bool
			var err error

			// 如果启用复用，先尝试通过网络内容查找已有对象
			if reuseAddressObject {
				var existingObj firewall.FirewallNetworkObject
				var foundExisting bool
				// 注意：GetObjectByNetworkGroup 需要 port 参数，这里传 nil（某些设备可能不需要）
				existingObj, foundExisting = ct.Node.GetObjectByNetworkGroup(memberNet, firewall.SEARCH_OBJECT_OR_GROUP, nil)
				if foundExisting {
					// 找到已有对象，复用其名称
					key = keys.NewKeyBuilder(existingObj.Name()).Separator("_")
					isNew = false
				} else {
					// 没有找到已有对象，生成新名称
					// 生成成员对象名称（使用copy后的metaData）
					memberMetaForName := copyMap(metaData)
					// 设置 is_source 供模板使用
					if isSource {
						memberMetaForName["is_source"] = "true"
					} else {
						memberMetaForName["is_source"] = "false"
					}
					memberName := generateObjectNameFromTemplate(memberNet, networkObjectNameTemplate, memberMetaForName)
					if memberName == "" {
						memberName = fmt.Sprintf("MEMBER_%d", len(memberObjects))
					}

					// 检查名称复用
					key = keys.NewKeyBuilder(memberName).Separator("_")
					key, isNew, err = ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(key, 2), memberNet)
					if err != nil {
						return false
					}
				}
			} else {
				// 不复用，直接生成新名称
				// 生成成员对象名称（使用copy后的metaData）
				memberMetaForName := copyMap(metaData)
				// 设置 is_source 供模板使用
				if isSource {
					memberMetaForName["is_source"] = "true"
				} else {
					memberMetaForName["is_source"] = "false"
				}
				memberName := generateObjectNameFromTemplate(memberNet, networkObjectNameTemplate, memberMetaForName)
				if memberName == "" {
					memberName = fmt.Sprintf("MEMBER_%d", len(memberObjects))
				}

				// 检查名称复用
				key = keys.NewKeyBuilder(memberName).Separator("_")
				key, isNew, err = ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(key, 2), memberNet)
				if err != nil {
					return false
				}
			}

			if isNew {
				// 生成成员对象CLI
				// 创建一个新的 intent，只包含 memberNet（单个网络条目），避免模板遍历到不应该包含的条目
				memberIntent := &policy.Intent{
					PolicyEntry: *policy.NewPolicyEntryWithAll(
						func() *network.NetworkGroup {
							if isSource {
								return memberNet
							}
							return network.NewNetworkGroupFromStringMust("0.0.0.0/0")
						}(),
						func() *network.NetworkGroup {
							if isSource {
								return network.NewNetworkGroupFromStringMust("0.0.0.0/0")
							}
							return memberNet
						}(),
						intent.Service(),
					),
				}

				memberMeta := copyMap(metaData)
				memberMeta["object_name"] = key.String()
				if isSource {
					memberMeta["is_source"] = "true"
				} else {
					memberMeta["is_source"] = "false"
				}

				memberCli := dsl.IntentFormat(memberIntent, addressObjectLayout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), memberMeta)
				if memberCli != "" {
					result.CLIString += memberCli + "\n" + sectionSeparator + "\n"
				}
			}

			memberObjects = append(memberObjects, key.String())
			result.Keys = append(result.Keys, key.String())
			return true
		})

		// 2. 生成地址组名称（使用copy后的metaData）
		var groupKey keys.Keys
		var isNew bool
		var err error

		// 如果启用复用，先尝试通过网络内容查找已有地址组
		if reuseAddressObject {
			var existingObj firewall.FirewallNetworkObject
			var foundExisting bool
			existingObj, foundExisting = ct.Node.GetObjectByNetworkGroup(targetNetworkGroup, firewall.SEARCH_GROUP, nil)
			if foundExisting {
				// 找到已有地址组，复用其名称
				groupKey = keys.NewKeyBuilder(existingObj.Name()).Separator("_")
				isNew = false
			} else {
				// 没有找到已有地址组，生成新名称
				groupMetaForName := copyMap(metaData)
				// 设置 is_source 供模板使用（地址组通常不需要区分源/目标，但为了模板兼容性还是设置）
				if isSource {
					groupMetaForName["is_source"] = "true"
				} else {
					groupMetaForName["is_source"] = "false"
				}
				groupName := generateObjectNameFromTemplate(targetNetworkGroup, addressGroupNameTemplate, groupMetaForName)
				if groupName == "" {
					groupName = "ADDRESS_GROUP"
				}

				// 检查地址组名称复用
				groupKey = keys.NewKeyBuilder(groupName).Separator("_")
				groupKey, isNew, err = ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(groupKey, 2), targetNetworkGroup)
				if err != nil {
					return nil, err
				}
			}
		} else {
			// 不复用，直接生成新名称
			groupMetaForName := copyMap(metaData)
			// 设置 is_source 供模板使用（地址组通常不需要区分源/目标，但为了模板兼容性还是设置）
			if isSource {
				groupMetaForName["is_source"] = "true"
			} else {
				groupMetaForName["is_source"] = "false"
			}
			groupName := generateObjectNameFromTemplate(targetNetworkGroup, addressGroupNameTemplate, groupMetaForName)
			if groupName == "" {
				groupName = "ADDRESS_GROUP"
			}

			// 检查地址组名称复用
			groupKey = keys.NewKeyBuilder(groupName).Separator("_")
			groupKey, isNew, err = ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(groupKey, 2), targetNetworkGroup)
			if err != nil {
				return nil, err
			}
		}

		if isNew {
			// 生成地址组CLI
			groupMeta := copyMap(metaData)
			groupMeta["object_name"] = groupKey.String()
			groupMeta["member_objects"] = memberObjects

			groupCli := dsl.IntentFormat(intent, addressGroupLayout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), groupMeta)
			if groupCli != "" {
				result.CLIString += groupCli + "\n"
			}
		}

		result.ObjectNames = append(result.ObjectNames, groupKey.String())
		result.Keys = append(result.Keys, groupKey.String())
		result.IsGroup = true
	} else {
		// 生成单个地址对象
		var key keys.Keys
		var isNew bool
		var err error

		// 如果启用复用，先尝试通过网络内容查找已有对象
		if reuseAddressObject {
			var existingObj firewall.FirewallNetworkObject
			var foundExisting bool
			existingObj, foundExisting = ct.Node.GetObjectByNetworkGroup(targetNetworkGroup, firewall.SEARCH_OBJECT_OR_GROUP, nil)
			if foundExisting {
				// 找到已有对象，复用其名称
				key = keys.NewKeyBuilder(existingObj.Name()).Separator("_")
				isNew = false
			} else {
				// 没有找到已有对象，生成新名称
				// 优先使用metaData中直接指定的object_name
				objectName := getStringFromMeta(metaData, "object_name", "")
				if objectName == "" {
					// 使用copy后的metaData生成对象名称
					objectMetaForName := copyMap(metaData)
					// 设置 is_source 供模板使用
					if isSource {
						objectMetaForName["is_source"] = "true"
					} else {
						objectMetaForName["is_source"] = "false"
					}
					objectName = generateObjectNameFromTemplate(targetNetworkGroup, networkObjectNameTemplate, objectMetaForName)
				}
				if objectName == "" {
					objectName = "ADDRESS_OBJECT"
				}

				// 检查名称复用
				key = keys.NewKeyBuilder(objectName).Separator("_")
				key, isNew, err = ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(key, 2), targetNetworkGroup)
				if err != nil {
					return nil, err
				}
			}
		} else {
			// 不复用，直接生成新名称
			// 优先使用metaData中直接指定的object_name
			objectName := getStringFromMeta(metaData, "object_name", "")
			if objectName == "" {
				// 使用copy后的metaData生成对象名称
				objectMetaForName := copyMap(metaData)
				// 设置 is_source 供模板使用
				if isSource {
					objectMetaForName["is_source"] = "true"
				} else {
					objectMetaForName["is_source"] = "false"
				}
				objectName = generateObjectNameFromTemplate(targetNetworkGroup, networkObjectNameTemplate, objectMetaForName)
			}
			if objectName == "" {
				objectName = "ADDRESS_OBJECT"
			}

			// 检查名称复用
			key = keys.NewKeyBuilder(objectName).Separator("_")
			key, isNew, err = ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(key, 2), targetNetworkGroup)
			if err != nil {
				return nil, err
			}
		}

		if isNew {
			// 生成地址对象CLI
			objectMeta := copyMap(metaData)
			objectMeta["object_name"] = key.String()
			// 使用字符串 "true" 或 "false" 供 DSL 模板判断
			if isSource {
				objectMeta["is_source"] = "true"
			} else {
				objectMeta["is_source"] = "false"
			}

			// 调试信息：打印传递给模板的参数
			if debug := getStringFromMeta(metaData, "debug", ""); debug == "true" {
				fmt.Printf("[DEBUG MakeAddressObjectV2] isSource=%v, is_source=%s, object_name=%s\n", isSource, objectMeta["is_source"], objectMeta["object_name"])
				fmt.Printf("[DEBUG MakeAddressObjectV2] Intent.Src(): %s\n", intent.Src().String())
				fmt.Printf("[DEBUG MakeAddressObjectV2] Intent.Dst(): %s\n", intent.Dst().String())
				fmt.Printf("[DEBUG MakeAddressObjectV2] targetNetworkGroup: %s\n", targetNetworkGroup.String())
			}

			// 创建一个新的 intent，只包含 targetNetworkGroup，避免模板遍历到不应该包含的条目
			// 这样模板就只会遍历 targetNetworkGroup 中的条目，而不是完整的 intent.src 或 intent.dst
			addressIntent := &policy.Intent{
				PolicyEntry: *policy.NewPolicyEntryWithAll(
					func() *network.NetworkGroup {
						if isSource {
							return targetNetworkGroup
						}
						return network.NewNetworkGroupFromStringMust("0.0.0.0/0")
					}(),
					func() *network.NetworkGroup {
						if isSource {
							return network.NewNetworkGroupFromStringMust("0.0.0.0/0")
						}
						return targetNetworkGroup
					}(),
					intent.Service(),
				),
			}

			objectCli := dsl.IntentFormat(addressIntent, addressObjectLayout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), objectMeta)

			// 调试信息：打印生成的CLI
			if debug := getStringFromMeta(metaData, "debug", ""); debug == "true" {
				fmt.Printf("[DEBUG MakeAddressObjectV2] Generated CLI:\n%s\n", objectCli)
			}

			if objectCli != "" {
				result.CLIString = objectCli
			}
		}

		result.ObjectNames = append(result.ObjectNames, key.String())
		result.Keys = append(result.Keys, key.String())
		result.IsGroup = false
	}

	return result, nil
}

// MakeServiceObjectV2 生成服务对象或服务组
func (ct *CommonTemplatesV2) MakeServiceObjectV2(intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}) (*ServiceObjectResult, error) {
	result := &ServiceObjectResult{
		ObjectNames: []string{},
		IsGroup:     false,
		Keys:        []string{},
	}

	// 获取命名模板
	serviceObjectNameTemplate := getStringFromMeta(metaData, "service_object_name_template", "")
	serviceGroupNameTemplate := getStringFromMeta(metaData, "service_group_name_template", "")

	// 获取复用控制参数
	// 支持 securitypolicy.reuse_service_object 和 reuse_service_object 两种格式
	reuseServiceObject := getBoolFromMeta(metaData, "securitypolicy.reuse_service_object", false)
	if !reuseServiceObject {
		reuseServiceObject = getBoolFromMeta(metaData, "reuse_service_object", false)
	}
	// 默认值：如果 securitypolicy.reuse_policy 为 true，则默认复用服务对象
	if !reuseServiceObject {
		reusePolicy := getBoolFromMeta(metaData, "securitypolicy.reuse_policy", false)
		reuseServiceObject = reusePolicy
	}

	// 获取layout
	serviceObjectLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("ServiceObject", "OneLoop"))
	serviceGroupLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("ServiceGroup", "OneLoop"))

	// 判断是否需要生成服务组
	serviceCount := 0
	intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
		serviceCount++
		return true // 继续遍历所有条目以计算总数（true表示继续，false表示停止）
	})

	// 检查设备是否支持服务组（通过检查 ServiceGroup layout 是否存在）
	// 如果设备支持服务组且有多个条目，即使 serviceGroupNameTemplate 为空，也应该生成服务组
	// 如果 serviceGroupNameTemplate 为空，将使用默认命名逻辑（"SERVICE_GROUP"）
	deviceSupportsServiceGroup := serviceGroupLayout != ""
	shouldCreateGroup := serviceCount > 1 && deviceSupportsServiceGroup

	if shouldCreateGroup {
		// 获取各个防火墙特有的 SectionSeparator（从模板中获取）
		sectionSeparator := ct.Templates.GetLayout(keys.NewKeyBuilder("SectionSeparator"))
		if sectionSeparator == "" {
			// 如果模板中没有定义，使用默认值 "#"
			sectionSeparator = "#"
		}

		// 生成服务组
		// 1. 先为每个成员生成服务对象
		memberObjects := []string{}
		intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
			// 为每个成员创建服务
			memberSvc := &service.Service{}
			memberSvc.Add(item)

			var key keys.Keys
			var isNew bool
			var err error

			// 如果启用复用，先尝试通过服务内容查找已有对象
			if reuseServiceObject {
				var existingObj firewall.FirewallServiceObject
				var foundExisting bool
				existingObj, foundExisting = ct.Node.GetObjectByService(memberSvc, firewall.SEARCH_OBJECT_OR_GROUP)
				if foundExisting {
					// 找到已有对象，复用其名称
					key = keys.NewKeyBuilder(existingObj.Name()).Separator("_")
					isNew = false
				} else {
					// 没有找到已有对象，生成新名称
					// 生成成员对象名称（使用copy后的metaData）
					memberMetaForName := copyMap(metaData)
					memberName := ct.generateServiceNameFromTemplate(item, serviceObjectNameTemplate, memberMetaForName)
					if memberName == "" {
						memberName = fmt.Sprintf("MEMBER_%d", len(memberObjects))
					}

					// 检查名称复用
					key = keys.NewKeyBuilder(memberName).Separator("_")
					key, isNew, err = ct.generateUniqueServiceNameV2(keys.NewAutoIncrementKeys(key, 2), memberSvc)
					if err != nil {
						return false
					}
				}
			} else {
				// 不复用，直接生成新名称
				// 生成成员对象名称（使用copy后的metaData）
				memberMetaForName := copyMap(metaData)
				memberName := ct.generateServiceNameFromTemplate(item, serviceObjectNameTemplate, memberMetaForName)
				if memberName == "" {
					memberName = fmt.Sprintf("MEMBER_%d", len(memberObjects))
				}

				// 检查名称复用
				key = keys.NewKeyBuilder(memberName).Separator("_")
				key, isNew, err = ct.generateUniqueServiceNameV2(keys.NewAutoIncrementKeys(key, 2), memberSvc)
				if err != nil {
					return false
				}
			}

			if isNew {
				// 生成成员对象CLI
				memberMeta := copyMap(metaData)
				memberMeta["object_name"] = key.String()

				// 创建临时的intent用于渲染单个服务
				memberIntent := &policy.Intent{}
				memberIntent.SetService(memberSvc)
				if isSource := getBoolFromMeta(metaData, "is_source", false); isSource {
					memberIntent.SetSrc(intent.Src())
				} else {
					memberIntent.SetDst(intent.Dst())
				}

				memberCli := dsl.IntentFormat(memberIntent, serviceObjectLayout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), memberMeta)
				if memberCli != "" {
					// 使用 SectionSeparator 分隔多个 CLI 字符串
					if result.CLIString != "" {
						result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + sectionSeparator + "\n" + strings.TrimLeft(memberCli, "\n\r") + "\n"
					} else {
						result.CLIString = memberCli + "\n" + sectionSeparator + "\n"
					}
				}
			}

			memberObjects = append(memberObjects, key.String())
			result.Keys = append(result.Keys, key.String())
			return true
		})

		// 2. 生成服务组名称（使用copy后的metaData）
		var groupKey keys.Keys
		var isNew bool
		var err error

		// 如果启用复用，先尝试通过服务内容查找已有服务组
		if reuseServiceObject {
			var existingObj firewall.FirewallServiceObject
			var foundExisting bool
			existingObj, foundExisting = ct.Node.GetObjectByService(intent.Service(), firewall.SEARCH_GROUP)
			if foundExisting {
				// 找到已有服务组，复用其名称
				groupKey = keys.NewKeyBuilder(existingObj.Name()).Separator("_")
				isNew = false
			} else {
				// 没有找到已有服务组，生成新名称
				groupMetaForName := copyMap(metaData)
				// 增强：如果模板包含服务相关的占位符，使用 intent.Service() 来生成名称
				groupName := ct.generateServiceGroupNameFromTemplate(intent.Service(), serviceGroupNameTemplate, groupMetaForName)
				if groupName == "" {
					groupName = "SERVICE_GROUP"
				}

				// 检查服务组名称复用（使用完整的服务对象）
				groupKey = keys.NewKeyBuilder(groupName).Separator("_")
				groupKey, isNew, err = ct.generateUniqueServiceNameV2(keys.NewAutoIncrementKeys(groupKey, 2), intent.Service())
				if err != nil {
					return nil, err
				}
			}
		} else {
			// 不复用，直接生成新名称
			groupMetaForName := copyMap(metaData)
			// 增强：如果模板包含服务相关的占位符，使用 intent.Service() 来生成名称
			groupName := ct.generateServiceGroupNameFromTemplate(intent.Service(), serviceGroupNameTemplate, groupMetaForName)
			if groupName == "" {
				groupName = "SERVICE_GROUP"
			}

			// 检查服务组名称复用（使用完整的服务对象）
			groupKey = keys.NewKeyBuilder(groupName).Separator("_")
			groupKey, isNew, err = ct.generateUniqueServiceNameV2(keys.NewAutoIncrementKeys(groupKey, 2), intent.Service())
			if err != nil {
				return nil, err
			}
		}

		if isNew {
			// 生成服务组CLI
			groupMeta := copyMap(metaData)
			groupMeta["object_name"] = groupKey.String()
			groupMeta["member_objects"] = memberObjects

			groupCli := dsl.IntentFormat(intent, serviceGroupLayout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), groupMeta)
			if groupCli != "" {
				// 使用 SectionSeparator 分隔多个 CLI 字符串
				if result.CLIString != "" {
					result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + sectionSeparator + "\n" + strings.TrimLeft(groupCli, "\n\r") + "\n"
				} else {
					result.CLIString = groupCli + "\n" + sectionSeparator + "\n"
				}
			}
		}

		result.ObjectNames = append(result.ObjectNames, groupKey.String())
		result.Keys = append(result.Keys, groupKey.String())
		result.IsGroup = true
	} else {
		// 生成单个服务对象
		var key keys.Keys
		var isNew bool
		var err error

		// 如果启用复用，先尝试通过服务内容查找已有对象
		if reuseServiceObject {
			var existingObj firewall.FirewallServiceObject
			var foundExisting bool
			existingObj, foundExisting = ct.Node.GetObjectByService(intent.Service(), firewall.SEARCH_OBJECT_OR_GROUP)
			if foundExisting {
				// 找到已有对象，复用其名称
				key = keys.NewKeyBuilder(existingObj.Name()).Separator("_")
				isNew = false
			} else {
				// 没有找到已有对象，生成新名称
				// 获取第一个服务条目用于生成名称
				var firstSvcEntry service.ServiceEntry
				intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
					firstSvcEntry = item
					return false // 只取第一个
				})

				// 使用copy后的metaData生成对象名称
				objectMetaForName := copyMap(metaData)
				objectName := ct.generateServiceNameFromTemplate(firstSvcEntry, serviceObjectNameTemplate, objectMetaForName)
				if objectName == "" {
					objectName = "SERVICE_OBJECT"
				}

				// 检查名称复用
				key = keys.NewKeyBuilder(objectName).Separator("_")
				key, isNew, err = ct.generateUniqueServiceNameV2(keys.NewAutoIncrementKeys(key, 2), intent.Service())
				if err != nil {
					return nil, err
				}
			}
		} else {
			// 不复用，直接生成新名称
			// 获取第一个服务条目用于生成名称
			var firstSvcEntry service.ServiceEntry
			intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
				firstSvcEntry = item
				return false // 只取第一个
			})

			// 使用copy后的metaData生成对象名称
			objectMetaForName := copyMap(metaData)
			objectName := ct.generateServiceNameFromTemplate(firstSvcEntry, serviceObjectNameTemplate, objectMetaForName)
			if objectName == "" {
				objectName = "SERVICE_OBJECT"
			}

			// 检查名称复用
			key = keys.NewKeyBuilder(objectName).Separator("_")
			key, isNew, err = ct.generateUniqueServiceNameV2(keys.NewAutoIncrementKeys(key, 2), intent.Service())
			if err != nil {
				return nil, err
			}
		}

		if isNew {
			// 生成服务对象CLI
			objectMeta := copyMap(metaData)
			objectMeta["object_name"] = key.String()

			objectCli := dsl.IntentFormat(intent, serviceObjectLayout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), objectMeta)
			if objectCli != "" {
				result.CLIString = objectCli
			}
		}

		result.ObjectNames = append(result.ObjectNames, key.String())
		result.Keys = append(result.Keys, key.String())
		result.IsGroup = false
	}

	return result, nil
}

// MakeVipOrMipV2 生成VIP或MIP
func (ct *CommonTemplatesV2) MakeVipOrMipV2(intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}) (*VipMipResult, error) {
	result := &VipMipResult{
		Keys: []string{},
	}

	// 从配置读取控制变量
	vipNameTemplate := getStringFromMeta(metaData, "vip_name_template", "")
	mipNameTemplate := getStringFromMeta(metaData, "mip_name_template", "")
	objectName := getStringFromMeta(metaData, "object_name", "")

	// 判断VIP/MIP类型（根据服务类型和real_port）
	svc := intent.Service().Aggregate()
	var objType string
	var nameTemplate string

	// 检查服务类型
	hasL3Protocol := false
	hasL4WithPort := false

	svc.EachDetailed(func(item service.ServiceEntry) bool {
		switch v := item.(type) {
		case *service.L3Protocol:
			hasL3Protocol = true
			return false
		case *service.L4Service:
			if !v.DstPort().IsFull() {
				hasL4WithPort = true
				return false
			}
		case *service.ICMPProto:
			return true
		}
		return true
	})

	// 检查real_port是否存在
	hasRealPort := intent.RealPort != ""

	// 检查VIP layout是否支持
	vipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Vip", "OneLoop"))
	supportsVIP := vipLayout != "" && strings.TrimSpace(vipLayout) != ""

	// 判断对象类型
	if hasL3Protocol {
		objType = "MIP"
		nameTemplate = mipNameTemplate
	} else if hasL4WithPort && hasRealPort {
		if !supportsVIP {
			objType = "MIP"
			if mipNameTemplate == "" {
				nameTemplate = vipNameTemplate
			} else {
				nameTemplate = mipNameTemplate
			}
		} else {
			objType = "VIP"
			nameTemplate = vipNameTemplate
		}
	} else {
		objType = "MIP"
		nameTemplate = mipNameTemplate
	}

	// 选择layout
	var layout string
	if objType == "VIP" {
		layout = ct.Templates.GetLayout(keys.NewKeyBuilder("Vip", "OneLoop"))
		// 如果VIP layout为空，尝试使用MIP layout
		if layout == "" || strings.TrimSpace(layout) == "" {
			objType = "MIP"
			layout = ct.Templates.GetLayout(keys.NewKeyBuilder("Mip", "OneLoop"))
			if nameTemplate == "" {
				nameTemplate = mipNameTemplate
			}
		}
	} else {
		layout = ct.Templates.GetLayout(keys.NewKeyBuilder("Mip", "OneLoop"))
		// 如果MIP layout为空，尝试使用VIP layout（某些防火墙如SRX没有MIP layout）
		if layout == "" || strings.TrimSpace(layout) == "" {
			objType = "VIP"
			layout = ct.Templates.GetLayout(keys.NewKeyBuilder("Vip", "OneLoop"))
			if nameTemplate == "" {
				nameTemplate = vipNameTemplate
			}
		}
	}

	// 生成对象名称
	if objectName == "" && nameTemplate != "" {
		if strings.Contains(nameTemplate, "{dst_network}") || strings.Contains(nameTemplate, "{dst_port}") {
			nameMeta := copyMap(metaData)
			if intent.Dst() != nil {
				intent.Dst().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
					if ipNet, ok := item.(*network.IPNet); ok {
						nameMeta["dst_network"] = ipNet.IP.String()
					} else {
						nameMeta["dst_network"] = item.String()
					}
					return true
				})
			}
			if intent.Service() != nil {
				intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
					if l4, ok := item.(*service.L4Service); ok {
						if !l4.DstPort().IsFull() {
							nameMeta["dst_port"] = l4.DstPort().String()
						}
					}
					return true
				})
			}
			objectName = strings.TrimSpace(dsl.IntentFormat(intent, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), nameMeta))
		} else {
			// 使用copy后的metaData生成对象名称
			nameMetaForTemplate := copyMap(metaData)
			objectName = generateObjectNameFromTemplate(intent.Dst(), nameTemplate, nameMetaForTemplate)
		}
	}
	if objectName == "" {
		objectName = objType + "_OBJECT"
	}

	// 检查对象复用
	key := keys.NewKeyBuilder(objectName).Separator("_")
	key, isNew, err := ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(key, 2), intent.Dst())
	if err != nil {
		return nil, err
	}

	// 准备meta数据
	objectMeta := copyMap(metaData)
	objectMeta["obj_type"] = objType
	objectMeta["object_name"] = key.String()
	if objType == "VIP" {
		objectMeta["pool_name"] = key.String()
	}
	if hasRealPort {
		objectMeta["has_real_port"] = "true"
	}
	// 设置 is_reused 标志（如果对象被复用则为 "true"，否则为 "false"）
	if !isNew {
		objectMeta["is_reused"] = "true"
	} else {
		objectMeta["is_reused"] = "false"
	}
	// 解析real_ip，如果是IP范围，设置real_ip_start和real_ip_end（用于SRX等需要range格式的防火墙）
	if intent.RealIp != "" {
		if strings.Contains(intent.RealIp, "-") {
			parts := strings.Split(intent.RealIp, "-")
			if len(parts) == 2 {
				objectMeta["real_ip_start"] = strings.TrimSpace(parts[0])
				objectMeta["real_ip_end"] = strings.TrimSpace(parts[1])
			}
		}
	}

	// 从ctx获取zone信息
	if ctx != nil {
		if ctx.InPort != nil {
			if zf, ok := ctx.InPort.(firewall.ZoneFirewall); ok {
				objectMeta["fromZone"] = zf.Zone()
			} else {
				objectMeta["fromPort"] = ctx.InPort.Name()
			}
		}
		if ctx.OutPort != nil {
			if zf, ok := ctx.OutPort.(firewall.ZoneFirewall); ok {
				objectMeta["toZone"] = zf.Zone()
			} else {
				objectMeta["toPort"] = ctx.OutPort.Name()
			}
		}
	}

	// 生成CLI（如果layout不为空且对象未被复用）
	if isNew && layout != "" && strings.TrimSpace(layout) != "" {
		objectCli := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), objectMeta)
		if objectCli != "" {
			result.CLIString = objectCli
		}
	}

	result.ObjectName = key.String()
	result.Type = objType
	result.Keys = append(result.Keys, key.String())

	return result, nil
}

// MakeSnatPoolV2 生成SNAT_POOL
// 只处理SNAT_POOL layout，其他类型（ADDRESS_OBJECT、INTERFACE、INLINE）已在调用前处理
func (ct *CommonTemplatesV2) MakeSnatPoolV2(intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}) (*SnatPoolResult, error) {
	result := &SnatPoolResult{
		Keys: []string{},
		Type: "POOL",
	}

	// 从配置读取控制变量
	poolName := getStringFromMeta(metaData, "pool_name", "")
	poolNameTemplate := getStringFromMeta(metaData, "snat_object_name_template", "")

	// 只使用 SnatPool OneLoop layout
	layout := ct.Templates.GetLayout(keys.NewKeyBuilder("SnatPool", "OneLoop"))

	// 生成池名称
	if poolName == "" && poolNameTemplate != "" {
		var snatNg *network.NetworkGroup
		if intent.Snat != "" {
			ng, err := network.NewNetworkGroupFromString(intent.Snat)
			if err == nil {
				snatNg = ng
			}
		}
		if snatNg != nil {
			// 将 snat 添加到 metaData，以便模板中的 {snat} 占位符可以访问
			nameMeta := copyMap(metaData)
			nameMeta["snat"] = intent.Snat
			poolName = generateObjectNameFromTemplate(snatNg, poolNameTemplate, nameMeta)
		}
	}
	if poolName == "" {
		poolName = "SNAT_POOL"
	}

	// 检查池复用
	// 对于 SNAT_POOL，应该使用 intent.Snat 对应的网络组来检查对象是否已存在
	var snatNg *network.NetworkGroup
	if intent.Snat != "" {
		ng, err := network.NewNetworkGroupFromString(intent.Snat)
		if err == nil {
			snatNg = ng
		}
	}
	// 如果无法解析 Snat，使用 intent.Src() 作为 fallback
	if snatNg == nil {
		snatNg = intent.Src()
	}

	key := keys.NewKeyBuilder(poolName).Separator("_")
	key, isNew, err := ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(key, 2), snatNg)
	if err != nil {
		return nil, err
	}

	// 准备meta数据
	poolMeta := copyMap(metaData)
	poolMeta["snat_pool_type"] = "POOL"
	poolMeta["pool_name"] = key.String()

	// 将 snat 添加到 poolMeta，以便 DSL 模板可以直接使用 {snat}
	if intent.Snat != "" {
		poolMeta["snat"] = intent.Snat
		poolMeta["has_snat"] = "true"
	}

	// 对于 USG，需要生成数字 pool_id（用于 nat address-group）
	// 检查 node 是否实现了 PoolIdFirewall 接口
	var poolId string
	if poolIdFirewall, ok := ct.Node.(firewall.PoolIdFirewall); ok {
		// 尝试从 metaData 获取 pool_id，如果没有则使用 NextPoolId 生成
		existingPoolId := getStringFromMeta(metaData, "pool_id", "")
		poolId = poolIdFirewall.NextPoolId(existingPoolId)
		poolMeta["pool_id"] = poolId
	} else {
		poolId = key.String()
		poolMeta["pool_id"] = poolId
	}

	// 设置 is_reused 标志（如果池被复用则为 "true"，否则为 "false"）
	if !isNew {
		poolMeta["is_reused"] = "true"
	} else {
		poolMeta["is_reused"] = "false"
	}

	// 创建临时intent，将snat网络组设置到Src中，以便模板可以使用intent.src
	var poolIntent *policy.Intent
	if intent.Snat != "" {
		snatNg, err := network.NewNetworkGroupFromString(intent.Snat)
		if err == nil {
			// USG 的 nat address-group 格式：第二个数字固定为 0
			poolMeta["section_count"] = "0"

			poolIntent = &policy.Intent{
				PolicyEntry: *policy.NewPolicyEntryWithAll(
					snatNg,
					intent.Dst(),
					intent.Service(),
				),
			}
		}
	}
	if poolIntent == nil {
		poolIntent = intent
	}

	// 生成CLI（如果layout不为空且池未被复用）
	if isNew && layout != "" && strings.TrimSpace(layout) != "" {
		poolCli := dsl.IntentFormat(poolIntent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), poolMeta)
		if poolCli != "" {
			result.CLIString = poolCli
		}
	}

	result.PoolName = key.String()
	result.PoolId = poolId // 使用生成的 poolId，可能与 PoolName 不同（如 USG 的情况）
	result.Keys = append(result.Keys, key.String())

	return result, nil
}

// generateUniqueObjectNameV2 生成唯一的对象名称（复用common包中的逻辑）
func (ct *CommonTemplatesV2) generateUniqueObjectNameV2(auto *keys.AutoIncrementKeys, ng *network.NetworkGroup) (keys.Keys, bool, error) {
	return common.GenerateObjectName(
		auto,
		ng,
		func() firewall.NamerIterator {
			return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
		},
		ct.Node,
		nil, // templates
		common.RetryMethodNext,
		ct.om,
		true, // useBaseFirst
	)
}

// generateUniqueServiceNameV2 生成唯一的服务对象名称（复用common包中的逻辑）
func (ct *CommonTemplatesV2) generateUniqueServiceNameV2(auto *keys.AutoIncrementKeys, svc *service.Service) (keys.Keys, bool, error) {
	return common.GenerateObjectName(
		auto,
		svc,
		func() firewall.NamerIterator {
			return ct.Node.(firewall.IteratorFirewall).ServiceIterator()
		},
		ct.Node,
		nil, // templates
		common.RetryMethodNext,
		ct.om,
		true, // useBaseFirst
	)
}

// 辅助函数

func getStringFromMeta(metaData map[string]interface{}, key, defaultValue string) string {
	if metaData == nil {
		return defaultValue
	}
	if v, ok := metaData[key]; ok {
		if s, ok := v.(string); ok {
			return s
		}
	}
	return defaultValue
}

func getBoolFromMeta(metaData map[string]interface{}, key string, defaultValue bool) bool {
	if metaData == nil {
		return defaultValue
	}
	if v, ok := metaData[key]; ok {
		if b, ok := v.(bool); ok {
			return b
		}
		if s, ok := v.(string); ok {
			return s == "true"
		}
	}
	return defaultValue
}

func copyMap(m map[string]interface{}) map[string]interface{} {
	result := make(map[string]interface{})
	for k, v := range m {
		result[k] = v
	}
	return result
}

func getMapKeys(m map[string]interface{}) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	return keys
}

// emptyNamerIterator 实现一个空的 NamerIterator，用于 IDTemplate
type emptyNamerIterator struct{}

func (e *emptyNamerIterator) HasNext() bool {
	return false
}

func (e *emptyNamerIterator) Next() firewall.Namer {
	return nil
}

func (e *emptyNamerIterator) Reset() {
	// 空实现
}

func generateObjectNameFromTemplate(ng *network.NetworkGroup, template string, metaData map[string]interface{}) string {
	if template == "" || ng == nil {
		return ""
	}

	// 检查模板是否包含 IDTemplate 语法（{SEQ:...} 或 {VAR:...}）
	hasIDTemplateSyntax := strings.Contains(template, "{SEQ:") || strings.Contains(template, "{VAR:")

	// 如果包含 IDTemplate 语法，先处理这些部分
	if hasIDTemplateSyntax {
		// 创建一个临时的 IDTemplate 来处理 {VAR:...} 和 {SEQ:...}
		// 注意：这里不初始化序列号，因为对象名称通常不需要从现有对象中提取序列号
		getIterator := func() firewall.NamerIterator {
			return &emptyNamerIterator{}
		}
		idTemplate := common.NewPolicyTemplate(template, getIterator).Initialize()

		// 将 metaData 转换为 IDTemplate 需要的格式
		idTemplateVars := make(map[string]interface{}, len(metaData))
		for k, v := range metaData {
			idTemplateVars[k] = v
		}

		// 使用 IDTemplate 处理 {VAR:...} 和 {SEQ:...}，得到中间结果
		_, intermediateResult := idTemplate.Generate(idTemplateVars)

		// 如果中间结果还包含 DSL 语法（如 {ip}, {mask}），继续使用 DSL 处理
		// 检查是否还有 DSL 占位符（简单的启发式检查）
		hasDSLSyntax := strings.Contains(intermediateResult, "{ip}") ||
			strings.Contains(intermediateResult, "{mask}") ||
			strings.Contains(intermediateResult, "{start}") ||
			strings.Contains(intermediateResult, "{end}")

		if hasDSLSyntax {
			// 使用 DSL 继续处理剩余部分
			var item network.AbbrNet
			count := 0
			ng.EachDataRangeEntryAsAbbrNet(func(entry network.AbbrNet) bool {
				if count == 0 {
					item = entry
				}
				count++
				return count <= 1
			})

			if count == 1 && item != nil {
				return strings.TrimSpace(dsl.NetworkFormat(item, intermediateResult, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), metaData))
			}
			return strings.TrimSpace(dsl.NetworkGroupFormat(ng, intermediateResult, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), metaData))
		}

		return strings.TrimSpace(intermediateResult)
	}

	// 如果NetworkGroup只包含一个条目，使用NetworkFormat而不是NetworkGroupFormat
	// 这样可以正确提取{ip}, {mask}, {start}, {end}等占位符
	var item network.AbbrNet
	count := 0
	ng.EachDataRangeEntryAsAbbrNet(func(entry network.AbbrNet) bool {
		if count == 0 {
			item = entry
		}
		count++
		return count <= 1 // 只取第一个条目
	})

	if count == 1 && item != nil {
		// 单个条目，使用NetworkFormat
		return strings.TrimSpace(dsl.NetworkFormat(item, template, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), metaData))
	}
	// 多个条目或空，使用NetworkGroupFormat
	return strings.TrimSpace(dsl.NetworkGroupFormat(ng, template, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), metaData))
}

func (ct *CommonTemplatesV2) generateServiceNameFromTemplate(svcEntry service.ServiceEntry, template string, metaData map[string]interface{}) string {
	if template == "" {
		return ""
	}

	// 如果 svcEntry 不为空，将其转换为 Service 并使用 ServiceFormat 处理模板
	if svcEntry != nil {
		// 将 ServiceEntry 转换为 Service
		svc := &service.Service{}
		svc.Add(svcEntry)

		// 使用 ServiceFormat 处理模板，它可以处理 {service.protocol}, {service.compact_port} 等占位符
		// 同时传入 metaData 以处理 {policy_name} 等变量
		result := strings.TrimSpace(dsl.ServiceFormat(svc, template, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), metaData))
		fmt.Printf("[DEBUG generateServiceNameFromTemplate] ServiceFormat 结果=%s\n", result)
		return result
	}

	// 如果没有 svcEntry，使用 MapFormat 处理 metaData 中的变量
	if strings.Contains(template, "{") {
		result := strings.TrimSpace(dsl.MapFormat(metaData, template, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
		fmt.Printf("[DEBUG generateServiceNameFromTemplate] MapFormat 结果=%s\n", result)
		return result
	}

	return ""
}

// generateServiceGroupNameFromTemplate 生成服务组名称（增强版，支持服务信息）
// 如果模板包含服务相关的占位符，使用 ServiceFormat；否则使用 MapFormat
func (ct *CommonTemplatesV2) generateServiceGroupNameFromTemplate(svc *service.Service, template string, metaData map[string]interface{}) string {
	if template == "" {
		return ""
	}

	// 检查模板是否包含服务相关的占位符（如 {service.protocol}, {service.compact_port} 等）
	// 如果包含，使用 ServiceFormat；否则使用 MapFormat
	hasServicePlaceholder := strings.Contains(template, "{service.") ||
		strings.Contains(template, "{protocol}") ||
		strings.Contains(template, "{dst_port}") ||
		strings.Contains(template, "{src_port}") ||
		strings.Contains(template, "{compact_port}")

	if hasServicePlaceholder && svc != nil {
		// 使用 ServiceFormat 处理模板，可以处理服务相关的占位符
		result := strings.TrimSpace(dsl.ServiceFormat(svc, template, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), metaData))
		if result != "" {
			return result
		}
	}

	// 如果没有服务占位符或 ServiceFormat 返回空，使用 MapFormat 处理 metaData 中的变量
	if strings.Contains(template, "{") {
		result := strings.TrimSpace(dsl.MapFormat(metaData, template, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
		return result
	}

	return ""
}

// MakePolicyV2 生成安全策略
func (ct *CommonTemplatesV2) MakePolicyV2(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}) (*PolicyResult, error) {
	result := &PolicyResult{
		SourceObjects:      []string{},
		DestinationObjects: []string{},
		ServiceObjects:     []string{},
		Keys:               []string{},
		FlyObject:          make(map[string]string),
	}

	// 获取zone信息
	fromZone, toZone := "", ""
	// 优先从 from/to 参数获取 zone
	if from != nil {
		if zf, ok := from.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if to != nil {
		if zf, ok := to.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}
	// 如果 from/to 参数没有 zone，尝试从 ctx 中获取
	if fromZone == "" && ctx != nil && ctx.InPort != nil {
		if zf, ok := ctx.InPort.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if toZone == "" && ctx != nil && ctx.OutPort != nil {
		if zf, ok := ctx.OutPort.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}

	// 1. 生成策略名称
	var policyName string
	var policyId string
	var mainID int

	// 优先使用metaData中直接指定的policy_name
	policyName = getStringFromMeta(metaData, "policy_name", "")

	// 如果metaData中没有policy_name，优先调用GetPolicyName（如果实现）
	if policyName == "" {
		if policyNameGetter, ok := ct.Node.(interface {
			GetPolicyName(ctx *firewall.PolicyContext) (string, error)
		}); ok {
			name, err := policyNameGetter.GetPolicyName(ctx)
			if err == nil && name != "" {
				policyName = name
			}
		}
	}

	// 如果GetPolicyName返回空，使用命名模板
	if policyName == "" {
		policyNameTemplate := getStringFromMeta(metaData, "securitypolicy.policy_name_template", "")
		if policyNameTemplate == "" {
			policyNameTemplate = getStringFromMeta(metaData, "policy_name_template", "")
		}
		if policyNameTemplate == "" {
			policyNameTemplate = "POLICY_{SEQ:id:5:1:1:MAIN}" // 默认模板
		}

		// 检查模板是否包含 IDTemplate 语法（{SEQ:...} 或 {VAR:...}）
		hasIDTemplateSyntax := strings.Contains(policyNameTemplate, "{SEQ:") || strings.Contains(policyNameTemplate, "{VAR:")

		if hasIDTemplateSyntax {
			// 如果模板改变了，需要重新创建 IDTemplate
			if ct.currentPolicyTemplate != policyNameTemplate {
				var getIterator func() firewall.NamerIterator
				if iteratorNode, ok := ct.Node.(firewall.IteratorFirewall); ok {
					getIterator = func() firewall.NamerIterator {
						return iteratorNode.PolicyIterator()
					}
				} else {
					getIterator = func() firewall.NamerIterator {
						return &emptyNamerIterator{}
					}
				}
				ct.policyTemplate = common.NewPolicyTemplate(policyNameTemplate, getIterator).WithMaxRetries(10).Initialize()
				ct.currentPolicyTemplate = policyNameTemplate
			}

			// 使用 IDTemplate 生成策略名称
			variables := make(map[string]interface{})
			for k, v := range metaData {
				variables[k] = v
			}
			mainID, policyName = ct.policyTemplate.Generate(variables)

			// 如果 metaData 中没有提供 policy_id，使用 mainID
			if mainID > 0 && getStringFromMeta(metaData, "policy_id", "") == "" {
				metaData["policy_id"] = fmt.Sprintf("%d", mainID)
			}
		} else {
			// 使用dsl.MapFormat生成策略名称（不包含 SEQ/VAR 语法）
			policyName = strings.TrimSpace(dsl.MapFormat(metaData, policyNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
		}
	}

	// 如果还是没有名称，使用默认名称
	if policyName == "" {
		policyName = "POLICY_OBJECT"
	}

	// 将 policyName 设置到 metaData 中，以便后续的对象名称生成可以使用
	metaData["policy_name"] = policyName

	// 生成策略ID（如果需要）
	policyId = getStringFromMeta(metaData, "policy_id", "")
	if policyId == "" && result.IsReused {
		// 如果复用了策略，使用已存在策略的ID
		// policyId已经在上面设置了
	} else if policyId == "" {
		// 如果没有提供policy_id，生成一个默认值（实际应该由节点生成）
		policyId = "1"
	}

	// 2. 策略复用逻辑
	reusePolicy := getBoolFromMeta(metaData, "securitypolicy.reuse_policy", false)
	var matchedPolicy firewall.FirewallPolicy
	if reusePolicy {
		matchConfig := common.MatchConfig{
			MatchSrc:       true,
			MatchDst:       true,
			MatchService:   true,
			MatchThreshold: 2, // 至少两项匹配
		}
		// 从配置中读取空zone列表是否匹配任何zone（默认为true）
		emptyZoneMatchesAny := getBoolFromMeta(metaData, "securitypolicy.empty_zone_matches_any", true)
		matchConfig.EmptyZoneMatchesAny = &emptyZoneMatchesAny
		matchedPolicies := common.FindPolicyByIntent(ct.Node, intent, fromZone, toZone, matchConfig)
		if len(matchedPolicies) > 0 {
			matchedPolicy = matchedPolicies[0]
			result.IsReused = true
			result.ReusedPolicyName = matchedPolicy.Name()
			policyName = matchedPolicy.Name()
			policyId = matchedPolicy.ID()
			// 更新 metaData 中的 policy_name，因为策略名称可能已改变
			metaData["policy_name"] = policyName

			// 计算差异
			diffSrc, diffDst, diffSrv, err := intent.PolicyEntry.SubtractWithTwoSame(matchedPolicy.PolicyEntry())
			if err == nil {
				// 更新intent为差异部分
				needCopy := false
				if diffSrc != nil || diffDst != nil || diffSrv != nil {
					needCopy = true
				}
				if needCopy {
					newIntent := intent.Copy().(*policy.Intent)
					if diffSrc != nil {
						newIntent.SetSrc(diffSrc)
					}
					if diffDst != nil {
						newIntent.SetDst(diffDst)
					}
					if diffSrv != nil {
						newIntent.SetService(diffSrv)
					}
					intent = newIntent
				}
			}
		}
	}

	// 3. 确定地址和服务处理方式
	useAddressObject := false
	useServiceObject := false

	// 检查是否为DPTech防火墙
	_, isDptech := ct.Templates.(*DptechTemplatesV2)

	// 检查address_style配置
	addressStyle := getStringFromMeta(metaData, "securitypolicy.address_style", "")
	if addressStyle == "object" {
		useAddressObject = true
	} else if addressStyle == "inline" {
		useAddressObject = false
	} else {
		// 如果未指定address_style，DPTech默认使用对象风格
		if isDptech {
			useAddressObject = true
		} else {
			// 其他防火墙检查use_address_object配置
			useAddressObject = getBoolFromMeta(metaData, "securitypolicy.use_address_object", false)
		}
	}

	// 检查service_style配置
	serviceStyle := getStringFromMeta(metaData, "securitypolicy.service_style", "")
	if serviceStyle == "object" {
		useServiceObject = true
	} else if serviceStyle == "inline" {
		useServiceObject = false
	} else {
		// 如果未指定service_style，DPTech默认使用对象风格
		if isDptech {
			useServiceObject = true
		} else {
			// 其他防火墙检查use_service_object配置
			useServiceObject = getBoolFromMeta(metaData, "securitypolicy.use_service_object", false)
		}
	}

	// 4. 生成地址和服务对象
	if useAddressObject {
		// 生成源地址对象
		srcResult, err := ct.MakeAddressObjectV2(intent, true, ctx, metaData)
		if err != nil {
			return nil, fmt.Errorf("failed to create source address object: %v", err)
		}
		result.SourceObjects = srcResult.ObjectNames
		result.Keys = append(result.Keys, srcResult.Keys...)
		if srcResult.CLIString != "" {
			// 将源地址对象CLI添加到NETWORK类别，使用分隔符分隔多个对象
			if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
				// 确保 existing 以换行符结尾，srcResult.CLIString 以换行符开头或直接是 config
				existing = strings.TrimRight(existing, "\n\r")
				srcCli := strings.TrimLeft(srcResult.CLIString, "\n\r")
				result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + srcCli
			} else {
				result.FlyObject[common.FlyObjectNetwork] = srcResult.CLIString
			}
			// 使用 SectionSeparator 分隔多个 CLI 字符串
			if result.CLIString != "" {
				result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + ct.SectionSeparator + "\n" + strings.TrimLeft(srcResult.CLIString, "\n\r")
			} else {
				result.CLIString = srcResult.CLIString
			}
		}

		// 生成目标地址对象
		dstResult, err := ct.MakeAddressObjectV2(intent, false, ctx, metaData)
		if err != nil {
			return nil, fmt.Errorf("failed to create destination address object: %v", err)
		}
		result.DestinationObjects = dstResult.ObjectNames
		result.Keys = append(result.Keys, dstResult.Keys...)
		if dstResult.CLIString != "" {
			// 将目标地址对象CLI添加到NETWORK类别，使用分隔符分隔多个对象
			if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
				// 确保 existing 以换行符结尾，dstResult.CLIString 以换行符开头或直接是 config
				existing = strings.TrimRight(existing, "\n\r")
				dstCli := strings.TrimLeft(dstResult.CLIString, "\n\r")
				result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + dstCli
			} else {
				result.FlyObject[common.FlyObjectNetwork] = dstResult.CLIString
			}
			// 使用 SectionSeparator 分隔多个 CLI 字符串
			if result.CLIString != "" {
				result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + ct.SectionSeparator + "\n" + strings.TrimLeft(dstResult.CLIString, "\n\r")
			} else {
				result.CLIString = dstResult.CLIString
			}
		}
	}

	if useServiceObject {
		// 检查 service 是否为 ip 协议，如果是则跳过 service 对象生成（使用 service "any"）
		isIPProtocol := false
		intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
			if l3, ok := item.(*service.L3Protocol); ok && l3.Protocol() == service.IP {
				isIPProtocol = true
				return false // 停止遍历
			}
			return true
		})

		if !isIPProtocol {
			// 生成服务对象
			svcResult, err := ct.MakeServiceObjectV2(intent, ctx, metaData)
			if err != nil {
				return nil, fmt.Errorf("failed to create service object: %v", err)
			}
			result.ServiceObjects = svcResult.ObjectNames
			result.Keys = append(result.Keys, svcResult.Keys...)
			if svcResult.CLIString != "" {
				// 将服务对象CLI添加到SERVICE类别，使用分隔符分隔多个对象
				if existing, exists := result.FlyObject[common.FlyObjectService]; exists && existing != "" {
					// 确保 existing 以换行符结尾，svcResult.CLIString 以换行符开头或直接是 config
					existing = strings.TrimRight(existing, "\n\r")
					svcCli := strings.TrimLeft(svcResult.CLIString, "\n\r")
					result.FlyObject[common.FlyObjectService] = existing + "\n" + ct.SectionSeparator + "\n" + svcCli
				} else {
					result.FlyObject[common.FlyObjectService] = svcResult.CLIString
				}
				// 使用 SectionSeparator 分隔多个 CLI 字符串
				if result.CLIString != "" {
					result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + ct.SectionSeparator + "\n" + strings.TrimLeft(svcResult.CLIString, "\n\r")
				} else {
					result.CLIString = svcResult.CLIString
				}
			}
		}
		// 如果 isIPProtocol 为 true，不生成 service 对象，模板会使用 service "any"
	}

	// 5. 生成策略CLI
	layout := ct.Templates.GetLayout(keys.NewKeyBuilder("Policy", "OneLoop"))
	if layout == "" {
		return nil, fmt.Errorf("Policy.OneLoop layout not found")
	}

	// 准备模板数据
	data := copyMap(metaData)
	data["policy_name"] = policyName
	data["policy_id"] = policyId
	data["fromZone"] = fromZone
	data["toZone"] = toZone
	// 如果策略被复用，去掉源zone和目的zone（设置为空数组）
	if result.IsReused {
		data["sourceZones"] = []interface{}{}
		data["destinationZones"] = []interface{}{}
	} else {
		data["sourceZones"] = []interface{}{fromZone}
		data["destinationZones"] = []interface{}{toZone}
	}
	if from != nil {
		data["fromPort"] = from.Name()
	}
	if to != nil {
		data["toPort"] = to.Name()
	}

	// 设置对象引用
	if len(result.SourceObjects) > 0 {
		data["src_objects"] = result.SourceObjects
		data["sourceObjects"] = result.SourceObjects
		data["has_source_objects"] = "true"
	}
	if len(result.DestinationObjects) > 0 {
		data["dst_objects"] = result.DestinationObjects
		data["destinationObjects"] = result.DestinationObjects
		data["has_destination_objects"] = "true"
	}
	if len(result.ServiceObjects) > 0 {
		data["service_objects"] = result.ServiceObjects
		data["serviceObjects"] = result.ServiceObjects
		data["has_service_objects"] = "true"
	}

	// 设置标志位
	if useAddressObject {
		data["make_source"] = "true"
		data["make_destination"] = "true"
	}
	if useServiceObject {
		data["make_service"] = "true"
	}

	// 策略状态
	enable := getStringFromMeta(metaData, "securitypolicy.enable", "enable")
	data["enable"] = enable

	// 动作
	// 根据防火墙类型设置action格式
	// SecPath和DPTech使用 "pass"/"drop"
	// FortiGate使用 "accept"/"deny"
	// 其他设备（USG、Sangfor、ASA、SRX等）使用 "permit"/"deny"
	_, isSecPath := ct.Templates.(*SecPathTemplatesV2)
	_, isForti := ct.Templates.(*FortiTemplatesV2)
	// isDptech已经在上面定义过了，这里重用
	if isSecPath || isDptech {
		// SecPath和DPTech防火墙解析时期望的是 "pass" 而不是 "permit"
		// 默认值使用 "pass"，将 "permit" 映射为 "pass"，"deny" 映射为 "drop"
		action := getStringFromMeta(metaData, "action", "pass")
		if action == "permit" {
			data["action"] = "pass"
		} else if action == "deny" {
			data["action"] = "drop"
		} else if action == "" {
			data["action"] = "pass"
		} else {
			data["action"] = action
		}
	} else if isForti {
		// FortiGate使用 "accept" 表示允许，"deny" 表示拒绝
		// 默认值使用 "accept"，将 "permit" 映射为 "accept"，"deny" 保持为 "deny"
		action := getStringFromMeta(metaData, "action", "accept")
		if action == "permit" {
			data["action"] = "accept"
		} else if action == "" {
			data["action"] = "accept"
		} else {
			// "deny" 或其他值直接使用
			data["action"] = action
		}
	} else {
		// 其他设备（USG、Sangfor、ASA、SRX等）使用 "permit"/"deny"，默认值为 "permit"
		action := getStringFromMeta(metaData, "action", "permit")
		data["action"] = action
	}

	// 使用dsl.IntentFormat渲染策略模板
	policyCli := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)

	if policyCli != "" {
		// 将策略CLI添加到SECURITY_POLICY类别
		result.FlyObject[common.FlyObjectSecurityPolicy] = policyCli
		result.CLIString += policyCli
	}

	result.PolicyName = policyName
	result.PolicyId = policyId

	return result, nil
}

// MakeNatPolicyV2 生成NAT策略
func (ct *CommonTemplatesV2) MakeNatPolicyV2(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}) (*NatPolicyResult, error) {
	result := &NatPolicyResult{
		SourceObjects:      []string{},
		DestinationObjects: []string{},
		ServiceObjects:     []string{},
		Keys:               []string{},
		FlyObject:          make(map[string]string),
	}

	// 获取zone信息
	fromZone, toZone := "", ""
	if from != nil {
		if zf, ok := from.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if to != nil {
		if zf, ok := to.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}

	// 判断NAT类型
	var natType string
	if intent.RealIp != "" {
		natType = "DNAT"
	} else if intent.Snat != "" {
		natType = "SNAT"
	} else {
		// 检查是否是 interface 模式的 SNAT（不需要 Snat）
		snatPoolType := getStringFromMeta(metaData, "snat_pool_type", "POOL")
		if snatPoolType == "INTERFACE" {
			natType = "SNAT"
		} else {
			return nil, fmt.Errorf("intent must have either RealIp (DNAT) or Snat (SNAT)")
		}
	}
	result.NatType = natType

	// 生成NAT策略名称
	natName := getStringFromMeta(metaData, "nat_name", "")
	if natName == "" {
		if policyNameGetter, ok := ct.Node.(interface {
			GetPolicyName(ctx *firewall.PolicyContext) (string, error)
		}); ok {
			name, err := policyNameGetter.GetPolicyName(ctx)
			if err == nil && name != "" {
				natName = name
			}
		}
	}
	if natName == "" {
		natNameTemplate := getStringFromMeta(metaData, "natpolicy.name_template", "")
		if natNameTemplate != "" {
			if strings.Contains(natNameTemplate, "{dst_network}") || strings.Contains(natNameTemplate, "{src_network}") || strings.Contains(natNameTemplate, "{dst_port}") {
				nameMeta := copyMap(metaData)
				if intent.Dst() != nil {
					intent.Dst().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
						if ipNet, ok := item.(*network.IPNet); ok {
							nameMeta["dst_network"] = ipNet.IP.String()
						} else {
							nameMeta["dst_network"] = item.String()
						}
						return true
					})
				}
				if intent.Src() != nil {
					intent.Src().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
						if ipNet, ok := item.(*network.IPNet); ok {
							nameMeta["src_network"] = ipNet.IP.String()
						} else {
							nameMeta["src_network"] = item.String()
						}
						return true
					})
				}
				if intent.Service() != nil {
					intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
						if l4, ok := item.(*service.L4Service); ok {
							if !l4.DstPort().IsFull() {
								nameMeta["dst_port"] = l4.DstPort().String()
							}
						}
						return true
					})
				}
				natName = strings.TrimSpace(dsl.IntentFormat(intent, natNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), nameMeta))
			} else {
				natName = strings.TrimSpace(dsl.MapFormat(metaData, natNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
			}
		}
	}
	if natName == "" {
		natName = "NAT_POLICY"
	}
	result.NatName = natName

	// 处理DNAT
	if natType == "DNAT" {
		// 配置优先级：
		// 1. natpolicy.dnat.inline_mode = true -> 使用 inline 模式（在 NAT Policy 中直接使用 {real_ip}/{real_port}）
		// 2. 否则生成 VIP/MIP 对象（对象模式）
		// 注意：对于 Sangfor，MIP 实际上是 AddressObject，当 MIP layout 为空时，使用地址对象代替
		inlineMode := getBoolFromMeta(metaData, "natpolicy.dnat.inline_mode", false)
		if !inlineMode {
			// 检查 MIP layout 是否为空（Sangfor 不支持 VIP，MIP 是 AddressObject）
			mipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Mip", "OneLoop"))
			vipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Vip", "OneLoop"))
			isMipAsAddressObject := (mipLayout == "" || strings.TrimSpace(mipLayout) == "") && (vipLayout == "" || strings.TrimSpace(vipLayout) == "")

			if isMipAsAddressObject {
				// Sangfor 的情况：MIP 实际上是 AddressObject
				// 为 real_ip 创建地址对象
				if intent.RealIp != "" {
					realIpNg, _ := network.NewNetworkGroupFromString(intent.RealIp)
					mipMeta := copyMap(metaData)
					// 使用 mip_name_template 或默认模板生成地址对象名称
					mipNameTemplate := getStringFromMeta(metaData, "mip_name_template", "")
					if mipNameTemplate == "" {
						mipNameTemplate = getStringFromMeta(metaData, "vip_name_template", "")
					}
					if mipNameTemplate != "" {
						// 从模板生成名称
						nameMeta := copyMap(metaData)
						if intent.Dst() != nil {
							intent.Dst().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
								if ipNet, ok := item.(*network.IPNet); ok {
									nameMeta["dst_network"] = ipNet.IP.String()
								} else {
									nameMeta["dst_network"] = item.String()
								}
								return true
							})
						}
						if intent.RealPort != "" {
							nameMeta["dst_port"] = intent.RealPort
						}
						objectName := strings.TrimSpace(dsl.MapFormat(nameMeta, mipNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
						if objectName != "" {
							mipMeta["object_name"] = objectName
						}
					}
					if mipMeta["object_name"] == nil || mipMeta["object_name"] == "" {
						// 如果没有模板，使用默认名称
						mipMeta["object_name"] = "MIP_" + strings.ReplaceAll(intent.RealIp, ".", "_")
					}
					mipIntent := &policy.Intent{
						PolicyEntry: *policy.NewPolicyEntryWithAll(
							network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
							realIpNg,
							service.NewServiceMust("ip"),
						),
					}
					mipResult, err := ct.MakeAddressObjectV2(mipIntent, false, ctx, mipMeta)
					if err == nil && mipResult != nil && len(mipResult.ObjectNames) > 0 {
						result.VipMipName = mipResult.ObjectNames[0]
						result.Keys = append(result.Keys, mipResult.Keys...)
						if mipResult.CLIString != "" {
							// 确保分隔符前后有换行符
							if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
								existing = strings.TrimRight(existing, "\n\r")
								mipCli := strings.TrimLeft(mipResult.CLIString, "\n\r")
								result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + mipCli
							} else {
								result.FlyObject[common.FlyObjectNetwork] = mipResult.CLIString
							}
							result.CLIString += mipResult.CLIString + "\n"
						}
					} else if err != nil {
						return nil, fmt.Errorf("failed to create MIP address object: %v", err)
					}
				}
			} else {
				// 其他防火墙：生成VIP/MIP对象
				vipMeta := copyMap(metaData)
				if fromZone != "" {
					vipMeta["fromZone"] = fromZone
				} else if from != nil {
					vipMeta["fromPort"] = from.Name()
				}
				if toZone != "" {
					vipMeta["toZone"] = toZone
				} else if to != nil {
					vipMeta["toPort"] = to.Name()
				}

				vipResult, err := ct.MakeVipOrMipV2(intent, ctx, vipMeta)
				if err != nil {
					return nil, fmt.Errorf("failed to create VIP/MIP: %v", err)
				}
				result.VipMipName = vipResult.ObjectName
				result.Keys = append(result.Keys, vipResult.Keys...)

				// 设置FlyObject
				var flyObjectKey string
				if vipResult.Type == "MIP" {
					flyObjectKey = common.FlyObjectMip
				} else {
					vipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Vip", "OneLoop"))
					if vipLayout == "" {
						flyObjectKey = common.FlyObjectMip
					} else {
						flyObjectKey = common.FlyObjectVip
					}
				}
				if vipResult.CLIString != "" {
					result.FlyObject[flyObjectKey] = vipResult.CLIString
					result.CLIString += vipResult.CLIString + "\n"
				} else {
					result.IsReused = true
				}
			}
		}

		// 处理源地址控制
		sourceStyle := getStringFromMeta(metaData, "natpolicy.dnat.source_style", "none")
		if sourceStyle == "required" || (sourceStyle == "optional" && intent.Src() != nil && !intent.Src().IsAny(true)) {
			srcResult, err := ct.MakeAddressObjectV2(intent, true, ctx, metaData)
			if err != nil {
				return nil, fmt.Errorf("failed to create source address object: %v", err)
			}
			result.SourceObjects = srcResult.ObjectNames
			result.Keys = append(result.Keys, srcResult.Keys...)
			if srcResult.CLIString != "" {
				// 确保分隔符前后有换行符，避免出现 #config 这样的格式
				if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
					// 确保 existing 以换行符结尾，srcResult.CLIString 以换行符开头或直接是 config
					existing = strings.TrimRight(existing, "\n\r")
					srcCli := strings.TrimLeft(srcResult.CLIString, "\n\r")
					result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + srcCli
				} else {
					result.FlyObject[common.FlyObjectNetwork] = srcResult.CLIString
				}
				// 使用 SectionSeparator 分隔多个 CLI 字符串
				if result.CLIString != "" {
					result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + ct.SectionSeparator + "\n" + strings.TrimLeft(srcResult.CLIString, "\n\r")
				} else {
					result.CLIString = srcResult.CLIString
				}
			}
		}
	}

	// 处理SNAT
	if natType == "SNAT" {
		// 配置优先级（完全由配置驱动，无回退机制）：
		// 1. natpolicy.snat.inline_mode = true -> 使用 inline 模式（在 NAT Policy 中直接使用 {snat}）
		// 2. snat_pool_type 配置决定使用哪种类型（POOL/INTERFACE/INLINE/ADDRESS_OBJECT）
		// 3. 如果都没有配置，默认使用 POOL
		inlineMode := getBoolFromMeta(metaData, "natpolicy.snat.inline_mode", false)
		poolType := getStringFromMeta(metaData, "snat_pool_type", "POOL")

		// 如果 inline_mode 为 true，强制使用 INLINE 类型（在 NAT Policy 中处理，不生成 SNAT_POOL 对象）
		if inlineMode {
			poolType = "INLINE"
		}

		// 处理INTERFACE类型：从output接口获取接口名称（如果可用）
		if poolType == "INTERFACE" {
			if to != nil && to.Name() != "" {
				metaData["interface_name"] = to.Name()
			}
			// 注意：即使接口名称不可用，也保持 INTERFACE 类型，由模板根据 interface_name 是否存在来决定如何处理
		}

		// 生成SNAT_POOL对象（如果不是内联模式且不是INLINE类型且不是INTERFACE类型）
		// 注意：INLINE 和 INTERFACE 类型在 NAT Policy 模板中直接处理，不需要生成 SNAT_POOL 对象
		if !inlineMode && poolType != "INLINE" && poolType != "INTERFACE" {
			poolMeta := copyMap(metaData)
			poolMeta["snat_pool_type"] = poolType

			// 检查SNAT_POOL复用
			if iterator, ok := ct.Node.(firewall.IteratorFirewall); ok {
				poolIterator := iterator.NatPoolIterator()
				snatNg, err := network.NewNetworkGroupFromString(intent.Snat)
				if err == nil {
					for poolIterator.HasNext() {
						pool := poolIterator.Next().(firewall.NatPool)
						if pool.MatchNetworkGroup(snatNg) {
							result.SnatPoolName = pool.Name()
							result.IsReused = true
							poolType = ""
							break
						}
					}
				}
			}

			if poolType != "" {
				poolResult, err := ct.MakeSnatPoolV2(intent, ctx, poolMeta)
				if err != nil {
					return nil, fmt.Errorf("failed to create SNAT_POOL: %v", err)
				}
				result.SnatPoolName = poolResult.PoolName
				result.Keys = append(result.Keys, poolResult.Keys...)
				if poolResult.CLIString != "" {
					// POOL 对象也是地址对象，应该合并到 NETWORK 类别，使用分隔符分隔
					// 注意：分隔符前后需要换行符，避免出现 #config 这样的格式
					if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
						// 确保 existing 以换行符结尾，poolResult.CLIString 以换行符开头或直接是 config
						existing = strings.TrimRight(existing, "\n\r")
						poolCli := strings.TrimLeft(poolResult.CLIString, "\n\r")
						result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + poolCli
					} else {
						result.FlyObject[common.FlyObjectNetwork] = poolResult.CLIString
					}
					// 同时保留 POOL 键以便测试代码访问
					result.FlyObject[common.FlyObjectPool] = poolResult.CLIString
					result.CLIString += poolResult.CLIString + "\n"
				}
			}
		}

		// 处理源地址控制（SNAT 至少需要源地址对象）
		sourceStyle := getStringFromMeta(metaData, "natpolicy.snat.source_style", "none")
		if sourceStyle == "required" || (sourceStyle == "optional" && intent.Src() != nil && !intent.Src().IsAny(true)) {
			srcResult, err := ct.MakeAddressObjectV2(intent, true, ctx, metaData)
			if err != nil {
				return nil, fmt.Errorf("failed to create source address object: %v", err)
			}
			result.SourceObjects = srcResult.ObjectNames
			result.Keys = append(result.Keys, srcResult.Keys...)
			if srcResult.CLIString != "" {
				// 确保分隔符前后有换行符，避免出现 #config 这样的格式
				if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
					existing = strings.TrimRight(existing, "\n\r")
					srcCli := strings.TrimLeft(srcResult.CLIString, "\n\r")
					result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + srcCli
				} else {
					result.FlyObject[common.FlyObjectNetwork] = srcResult.CLIString
				}
				result.CLIString += srcResult.CLIString + "\n"
			}
		}

		// 处理目标地址控制
		destinationStyle := getStringFromMeta(metaData, "natpolicy.snat.destination_style", "none")
		if destinationStyle == "required" || (destinationStyle == "optional" && intent.Dst() != nil && !intent.Dst().IsAny(true)) {
			dstResult, err := ct.MakeAddressObjectV2(intent, false, ctx, metaData)
			if err != nil {
				return nil, fmt.Errorf("failed to create destination address object: %v", err)
			}
			result.DestinationObjects = dstResult.ObjectNames
			result.Keys = append(result.Keys, dstResult.Keys...)
			if dstResult.CLIString != "" {
				// 确保分隔符前后有换行符，避免出现 #config 这样的格式
				if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
					// 确保 existing 以换行符结尾，dstResult.CLIString 以换行符开头或直接是 config
					existing = strings.TrimRight(existing, "\n\r")
					dstCli := strings.TrimLeft(dstResult.CLIString, "\n\r")
					result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + dstCli
				} else {
					result.FlyObject[common.FlyObjectNetwork] = dstResult.CLIString
				}
				// 使用 SectionSeparator 分隔多个 CLI 字符串
				if result.CLIString != "" {
					result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + ct.SectionSeparator + "\n" + strings.TrimLeft(dstResult.CLIString, "\n\r")
				} else {
					result.CLIString = dstResult.CLIString
				}
			}
		}
	}

	// 生成服务对象（如果需要）
	useServiceObject := getBoolFromMeta(metaData, "natpolicy.use_service_object", false)
	if useServiceObject {
		// 检查 service 是否为 ip 协议，如果是则跳过 service 对象生成（使用 service "any"）
		isIPProtocol := false
		intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
			if l3, ok := item.(*service.L3Protocol); ok && l3.Protocol() == service.IP {
				isIPProtocol = true
				return false // 停止遍历
			}
			return true
		})

		if !isIPProtocol {
			svcResult, err := ct.MakeServiceObjectV2(intent, ctx, metaData)
			if err != nil {
				return nil, fmt.Errorf("failed to create service object: %v", err)
			}
			result.ServiceObjects = svcResult.ObjectNames
			result.Keys = append(result.Keys, svcResult.Keys...)
			if svcResult.CLIString != "" {
				if existing, exists := result.FlyObject[common.FlyObjectService]; exists && existing != "" {
					// 确保 existing 以换行符结尾，svcResult.CLIString 以换行符开头或直接是 config
					existing = strings.TrimRight(existing, "\n\r")
					svcCli := strings.TrimLeft(svcResult.CLIString, "\n\r")
					result.FlyObject[common.FlyObjectService] = existing + "\n" + ct.SectionSeparator + "\n" + svcCli
				} else {
					result.FlyObject[common.FlyObjectService] = svcResult.CLIString
				}
				// 使用 SectionSeparator 分隔多个 CLI 字符串
				if result.CLIString != "" {
					result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + ct.SectionSeparator + "\n" + strings.TrimLeft(svcResult.CLIString, "\n\r")
				} else {
					result.CLIString = svcResult.CLIString
				}
			}
		}
		// 如果 isIPProtocol 为 true，不生成 service 对象，模板会使用 service "any"
	}

	// 生成NAT策略CLI
	// 检查是否使用 object NAT 格式（通过配置控制）
	natStyle := getStringFromMeta(metaData, "natpolicy.asa.nat_style", "twice")

	// 准备模板数据（提前定义，以便在 object NAT 检查中使用）
	data := copyMap(metaData)

	var layoutKey keys.Keys
	if natStyle == "object" {
		// 使用 Object NAT 格式
		layoutKey = keys.NewKeyBuilder("NatPolicy", "ObjectNat")
		// 确保 object 定义已存在
		if natType == "DNAT" {
			// DNAT: 确保 real_ip_object 已创建（将在后面的代码中创建，这里只检查配置）
			if intent.RealIp == "" {
				return nil, fmt.Errorf("object NAT DNAT requires real_ip to be set")
			}
			// 确保 real_ip_object_style 配置为 required 或 optional
			realIpObjectStyle := getStringFromMeta(metaData, "natpolicy.dnat.real_ip_object_style", "none")
			if realIpObjectStyle == "none" {
				// 如果未配置，设置为 required（object NAT 必需）
				metaData["natpolicy.dnat.real_ip_object_style"] = "required"
				data["natpolicy.dnat.real_ip_object_style"] = "required"
			}
		} else if natType == "SNAT" {
			// SNAT: 确保 src_objects[0] 已创建
			sourceStyle := getStringFromMeta(metaData, "natpolicy.snat.source_style", "none")
			if sourceStyle == "none" && (intent.Src() == nil || intent.Src().IsAny(true)) {
				return nil, fmt.Errorf("object NAT SNAT requires source address object to be created (set natpolicy.snat.source_style to 'required' or 'optional')")
			}
			if len(result.SourceObjects) == 0 {
				// 如果源地址对象不存在，尝试创建
				srcResult, err := ct.MakeAddressObjectV2(intent, true, ctx, metaData)
				if err != nil {
					return nil, fmt.Errorf("failed to create source address object for object NAT (required): %v", err)
				}
				if len(srcResult.ObjectNames) == 0 {
					return nil, fmt.Errorf("object NAT SNAT requires source address object, but creation returned no objects")
				}
				result.SourceObjects = srcResult.ObjectNames
				result.Keys = append(result.Keys, srcResult.Keys...)
				if srcResult.CLIString != "" {
					if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
						existing = strings.TrimRight(existing, "\n\r")
						srcCli := strings.TrimLeft(srcResult.CLIString, "\n\r")
						result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + srcCli
					} else {
						result.FlyObject[common.FlyObjectNetwork] = srcResult.CLIString
					}
					result.CLIString += srcResult.CLIString + "\n"
				}
				// 更新 data 中的 src_objects
				srcObjs := make([]interface{}, len(result.SourceObjects))
				for i, obj := range result.SourceObjects {
					srcObjs[i] = obj
				}
				data["src_objects"] = srcObjs
				data["source_objects"] = srcObjs
				data["has_source_objects"] = "true"
			}
		}
	} else {
		// 使用 twice NAT 格式（默认）
		layoutKey = keys.NewKeyBuilder("NatPolicy", "OneLoop")
	}
	layout := ct.Templates.GetLayout(layoutKey)
	if layout == "" {
		return nil, fmt.Errorf("NAT layout not found for key: %v", layoutKey)
	}
	previewLen := 200
	if len(layout) < previewLen {
		previewLen = len(layout)
	}
	if previewLen > 0 {
		fmt.Printf("DEBUG: layout length=%d, layout preview (first %d chars): %s\n", len(layout), previewLen, layout[:previewLen])
	} else {
		fmt.Printf("DEBUG: layout is empty\n")
	}

	// 继续准备模板数据
	data["nat_type"] = natType
	data["nat_name"] = natName
	data["nat_rule_name"] = natName
	// 处理 enable 字段：如果 metaData 中有 "enable"，则使用它；否则默认为 "true"
	enableValue := getStringFromMeta(metaData, "enable", "true")
	// 将 "enable" 字符串转换为 "true"，"disable" 转换为 "false"
	if enableValue == "enable" {
		data["enable"] = "true"
	} else if enableValue == "disable" {
		data["enable"] = "false"
	} else {
		data["enable"] = enableValue
	}
	// 只有当 zone 非空时才设置，避免生成空的 zone 配置
	if fromZone != "" {
		data["fromZone"] = fromZone
		data["sourceZones"] = []interface{}{fromZone}
	}
	if toZone != "" {
		data["toZone"] = toZone
		data["destinationZones"] = []interface{}{toZone}
	}
	if from != nil {
		data["fromPort"] = from.Name()
		data["has_fromPort"] = "true"
	}
	if to != nil {
		data["toPort"] = to.Name()
		data["has_toPort"] = "true"
	}

	// 设置对象引用（转换为 []interface{} 以便 DSL 可以正确遍历）
	if len(result.SourceObjects) > 0 {
		srcObjs := make([]interface{}, len(result.SourceObjects))
		for i, obj := range result.SourceObjects {
			srcObjs[i] = obj
		}
		data["src_objects"] = srcObjs
		data["source_objects"] = srcObjs
		data["has_source_objects"] = "true"
	}
	if len(result.DestinationObjects) > 0 {
		dstObjs := make([]interface{}, len(result.DestinationObjects))
		for i, obj := range result.DestinationObjects {
			dstObjs[i] = obj
		}
		data["dst_objects"] = dstObjs
		data["destination_objects"] = dstObjs
		data["has_destination_objects"] = "true"
	}
	if len(result.ServiceObjects) > 0 {
		svcObjs := make([]interface{}, len(result.ServiceObjects))
		for i, obj := range result.ServiceObjects {
			svcObjs[i] = obj
		}
		data["service_objects"] = svcObjs
		data["has_service_objects"] = "true"
	}

	// 设置NAT相关变量（real_ip、real_port、snat可以直接在DSL中使用，但需要设置has_*标志）
	if natType == "DNAT" {
		// 设置 DNAT inline_mode 标志，用于模板分支选择
		dnatInlineMode := getBoolFromMeta(metaData, "natpolicy.dnat.inline_mode", false)
		data["dnat_inline_mode"] = fmt.Sprintf("%v", dnatInlineMode)
		if dnatInlineMode {
			data["has_dnat_inline_mode"] = "true"
		}

		if intent.RealIp != "" {
			data["has_real_ip"] = "true"
		}
		if intent.RealPort != "" {
			data["has_real_port"] = "true"
		}
		// 只有在对象模式（非inline模式）下才设置VIP/MIP名称
		if !dnatInlineMode && result.VipMipName != "" {
			data["vip_name"] = result.VipMipName
			data["mip_name"] = result.VipMipName
			data["has_vip_name"] = "true"
			data["has_mip_name"] = "true"
			vipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Vip", "OneLoop"))
			if vipLayout != "" && strings.TrimSpace(vipLayout) != "" {
				data["use_vip"] = "true"
			}
			// 检查 MIP 是否作为地址对象（Sangfor 的情况）
			mipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Mip", "OneLoop"))
			if (mipLayout == "" || strings.TrimSpace(mipLayout) == "") && (vipLayout == "" || strings.TrimSpace(vipLayout) == "") {
				// MIP 作为地址对象
				data["mip_object"] = result.VipMipName
				data["has_mip_object"] = "true"
			}
		}
		// 为real_ip创建地址对象（通过配置控制）
		if intent.RealIp != "" {
			realIpObjectStyle := getStringFromMeta(metaData, "natpolicy.dnat.real_ip_object_style", "none")
			if realIpObjectStyle == "required" || realIpObjectStyle == "optional" {
				realIpNg, _ := network.NewNetworkGroupFromString(intent.RealIp)
				realIpMeta := copyMap(metaData)
				realIpMeta["object_name"] = "REAL_IP_" + strings.ReplaceAll(intent.RealIp, ".", "_")
				realIpIntent := &policy.Intent{
					PolicyEntry: *policy.NewPolicyEntryWithAll(
						network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
						realIpNg,
						service.NewServiceMust("ip"),
					),
				}
				realIpResult, err := ct.MakeAddressObjectV2(realIpIntent, false, ctx, realIpMeta)
				if err == nil && realIpResult != nil && len(realIpResult.ObjectNames) > 0 {
					data["real_ip_object"] = realIpResult.ObjectNames[0]
					data["has_real_ip_object"] = "true"
					if realIpResult.CLIString != "" {
						// 确保分隔符前后有换行符，避免出现 #config 这样的格式
						if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
							existing = strings.TrimRight(existing, "\n\r")
							realIpCli := strings.TrimLeft(realIpResult.CLIString, "\n\r")
							result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + ct.SectionSeparator + "\n" + realIpCli
						} else {
							result.FlyObject[common.FlyObjectNetwork] = realIpResult.CLIString
						}
						result.CLIString += realIpResult.CLIString + "\n"
					}
				} else if realIpObjectStyle == "required" {
					// 如果配置为 required 但创建失败，返回错误
					return nil, fmt.Errorf("failed to create real_ip_object (required but creation failed): %v", err)
				}
			}
		}
	}
	if natType == "SNAT" {
		// 设置 SNAT inline_mode 和 pool_type 标志，用于模板分支选择
		snatInlineMode := getBoolFromMeta(metaData, "natpolicy.snat.inline_mode", false)
		poolType := getStringFromMeta(metaData, "snat_pool_type", "POOL")
		fmt.Printf("DEBUG SNAT: snatInlineMode=%v, poolType=%s, to=%v\n", snatInlineMode, poolType, to)
		if to != nil {
			fmt.Printf("DEBUG SNAT: to.Name()=%s\n", to.Name())
		}
		data["snat_inline_mode"] = fmt.Sprintf("%v", snatInlineMode)
		data["snat_pool_type"] = poolType
		if snatInlineMode {
			data["has_snat_inline_mode"] = "true"
		}

		data["has_snat"] = "true"
		if poolType == "INTERFACE" {
			if to != nil && to.Name() != "" {
				data["interface_name"] = to.Name()
				data["has_interface_name"] = "true"
				fmt.Printf("DEBUG SNAT: Set interface_name=%s, has_interface_name=true\n", to.Name())
			} else {
				fmt.Printf("DEBUG SNAT: INTERFACE mode but to is nil or empty, to=%v\n", to)
			}
		} else if snatInlineMode || poolType == "INLINE" {
			// 内联模式：直接使用 intent.Snat，不需要设置 pool_id
			// layout 会通过 {snat} 从 intent 获取
			data["has_snat_inline"] = "true"
			fmt.Printf("DEBUG SNAT: Set has_snat_inline=true\n")
		} else if result.SnatPoolName != "" {
			// 对象模式：使用 SNAT_POOL 对象
			data["pool_id"] = result.SnatPoolName
			data["pool_name"] = result.SnatPoolName
			data["use_pool"] = "true"
			data["has_pool_id"] = "true"
			fmt.Printf("DEBUG SNAT: Set pool_id=%s, has_pool_id=true\n", result.SnatPoolName)
		} else {
			fmt.Printf("DEBUG SNAT: No pool_id set, result.SnatPoolName=%s\n", result.SnatPoolName)
		}
	}

	// 使用dsl.IntentFormat渲染NAT策略模板
	fmt.Printf("DEBUG generateObjectStyleCli data: nat_type=%v, has_pool_id=%v, has_interface_name=%v, has_snat=%v, pool_id=%v, interface_name=%v, fromPort=%v, toPort=%v, has_fromPort=%v, has_toPort=%v, has_source_objects=%v, src_objects=%v\n",
		data["nat_type"], data["has_pool_id"], data["has_interface_name"], data["has_snat"], data["pool_id"], data["interface_name"], data["fromPort"], data["toPort"], data["has_fromPort"], data["has_toPort"], data["has_source_objects"], data["src_objects"])
	var natCli string
	var panicErr interface{}
	func() {
		defer func() {
			if r := recover(); r != nil {
				panicErr = r
				fmt.Printf("DEBUG: DSL parsing panicked: %v\n", r)
				natCli = ""
			}
		}()
		natCli = dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)
	}()
	if panicErr != nil {
		fmt.Printf("DEBUG: Panic occurred during DSL parsing: %v\n", panicErr)
	}
	fmt.Printf("DEBUG generateObjectStyleCli: natCli=%q, layout length=%d\n", natCli, len(layout))
	if natCli == "" {
		fmt.Printf("DEBUG: natCli is empty, checking layout conditions...\n")
		fmt.Printf("DEBUG: nat_type check: %v == \"SNAT\"? %v\n", data["nat_type"], data["nat_type"] == "SNAT")
		fmt.Printf("DEBUG: has_fromPort check: %v == \"true\"? %v\n", data["has_fromPort"], data["has_fromPort"] == "true")
		fmt.Printf("DEBUG: has_toPort check: %v == \"true\"? %v\n", data["has_toPort"], data["has_toPort"] == "true")
		fmt.Printf("DEBUG: has_interface_name check: %v == \"true\"? %v\n", data["has_interface_name"], data["has_interface_name"] == "true")
		idx := strings.Index(layout, "{else}")
		if idx >= 0 {
			previewLen := 300
			if idx+previewLen > len(layout) {
				previewLen = len(layout) - idx
			}
			fmt.Printf("DEBUG: layout SNAT section:\n%s\n", layout[idx:idx+previewLen])
		}
		fmt.Printf("DEBUG: src_objects type: %T, value: %v, len: %d\n", data["src_objects"], data["src_objects"], len(result.SourceObjects))
		if srcObjs, ok := data["src_objects"].([]interface{}); ok {
			fmt.Printf("DEBUG: src_objects as []interface{}: %v, len: %d\n", srcObjs, len(srcObjs))
		}
	}
	if natCli != "" {
		if natStyle == "object" {
			// Object NAT: 将 nat 行追加到对应的 object network 定义之后
			if natType == "DNAT" && data["has_real_ip_object"] == "true" {
				// DNAT: 追加到 real_ip_object 定义之后
				objectName := data["real_ip_object"].(string)
				// 查找对应的 object network 定义并追加 nat 行
				if networkCli, exists := result.FlyObject[common.FlyObjectNetwork]; exists && networkCli != "" {
					// 查找 object network <object_name> 的位置
					objectPattern := fmt.Sprintf("object network %s", objectName)
					idx := strings.Index(networkCli, objectPattern)
					if idx >= 0 {
						// 找到 object network 定义，查找其结束位置（下一个 object 或文件结束）
						remaining := networkCli[idx:]
						// 查找下一个 object network 或 object-group 的位置
						nextObjectIdx := strings.Index(remaining, "\nobject ")
						if nextObjectIdx < 0 {
							nextObjectIdx = len(remaining)
						}
						// 在 object 定义后追加 nat 行
						objectDefEnd := idx + nextObjectIdx
						beforeNat := networkCli[:objectDefEnd]
						afterNat := networkCli[objectDefEnd:]
						// 确保 beforeNat 以换行符结尾
						beforeNat = strings.TrimRight(beforeNat, "\n\r") + "\n"
						// nat 行需要添加空格缩进（ASA Object NAT 格式要求）
						natCliWithIndent := strings.TrimLeft(natCli, " \t")
						if natCliWithIndent != "" {
							natCliWithIndent = " " + natCliWithIndent
						}
						result.FlyObject[common.FlyObjectNetwork] = beforeNat + natCliWithIndent + afterNat
					} else {
						// 如果找不到，直接追加到末尾
						result.FlyObject[common.FlyObjectNetwork] = networkCli + "\n" + natCli
					}
				} else {
					// 如果没有 NETWORK 定义，创建新的
					result.FlyObject[common.FlyObjectNetwork] = natCli
				}
			} else if natType == "SNAT" && data["has_source_objects"] == "true" {
				// SNAT: 追加到 src_objects[0] 定义之后
				if srcObjs, ok := data["src_objects"].([]interface{}); ok && len(srcObjs) > 0 {
					objectName := srcObjs[0].(string)
					if networkCli, exists := result.FlyObject[common.FlyObjectNetwork]; exists && networkCli != "" {
						objectPattern := fmt.Sprintf("object network %s", objectName)
						idx := strings.Index(networkCli, objectPattern)
						if idx >= 0 {
							remaining := networkCli[idx:]
							nextObjectIdx := strings.Index(remaining, "\nobject ")
							if nextObjectIdx < 0 {
								nextObjectIdx = len(remaining)
							}
							objectDefEnd := idx + nextObjectIdx
							beforeNat := networkCli[:objectDefEnd]
							afterNat := networkCli[objectDefEnd:]
							beforeNat = strings.TrimRight(beforeNat, "\n\r") + "\n"
							// nat 行需要添加空格缩进（ASA Object NAT 格式要求）
							natCliWithIndent := strings.TrimLeft(natCli, " \t")
							if natCliWithIndent != "" {
								natCliWithIndent = " " + natCliWithIndent
							}
							result.FlyObject[common.FlyObjectNetwork] = beforeNat + natCliWithIndent + afterNat
						} else {
							result.FlyObject[common.FlyObjectNetwork] = networkCli + "\n" + natCli
						}
					} else {
						result.FlyObject[common.FlyObjectNetwork] = natCli
					}
				}
			}
			// Object NAT 不需要单独的 NAT 条目
		} else {
			// Twice NAT: 使用独立的 NAT 配置
			result.FlyObject[common.FlyObjectNat] = natCli
			result.CLIString += natCli
		}
	}

	return result, nil
}

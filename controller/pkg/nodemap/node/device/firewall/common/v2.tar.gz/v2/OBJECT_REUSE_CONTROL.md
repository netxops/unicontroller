# 对象复用控制参数说明

## 概述

在生成策略时，可以通过参数控制是否复用已有的地址对象、地址组、服务对象和服务组。这允许您灵活控制对象的生成策略。

## 控制参数

### 地址对象/地址组复用控制

**参数名称：**
- `securitypolicy.reuse_address_object` (推荐)
- `reuse_address_object` (简化格式)

**参数类型：** `boolean` (true/false)

**默认行为：**
- 如果 `securitypolicy.reuse_policy` 为 `true`，则默认启用地址对象复用
- 否则默认不启用复用

**功能说明：**
- 当设置为 `true` 时，系统会先通过网络内容查找已有对象
- 如果找到相同网络的对象（如 `192.168.1.0/24`），会复用该对象的名称
- 如果未找到，则按模板生成新对象名称

### 服务对象/服务组复用控制

**参数名称：**
- `securitypolicy.reuse_service_object` (推荐)
- `reuse_service_object` (简化格式)

**参数类型：** `boolean` (true/false)

**默认行为：**
- 如果 `securitypolicy.reuse_policy` 为 `true`，则默认启用服务对象复用
- 否则默认不启用复用

**功能说明：**
- 当设置为 `true` 时，系统会先通过服务内容查找已有对象
- 如果找到相同服务的对象（如 `tcp:80` 对应 "HTTP"），会复用该对象的名称
- 如果未找到，则按模板生成新对象名称

## 使用示例

### 示例 1：启用地址对象和服务对象复用

```yaml
metadata:
  securitypolicy.reuse_address_object: true
  securitypolicy.reuse_service_object: true
  network_object_name_template: "{policy_name}_{if:is_source==\"true\"}SRC{else}DST{endif}_{if:type==\"range\"}{start}_{end}{else if:type==\"subnet\"}{cidr}{else}{ip}{endif}"
  service_object_name_template: "{policy_name}_{protocol:lower}{if:dst_port!=\"\"}_{dst_port}{endif}"
```

**效果：**
- 如果已有网络对象 `192.168.1.0/24`，会复用该对象，而不是生成新对象
- 如果已有服务对象 "HTTP"（对应 `tcp:80`），会复用该对象，而不是生成 `policy_001_tcp_80`

### 示例 2：仅启用服务对象复用

```yaml
metadata:
  securitypolicy.reuse_service_object: true
  securitypolicy.reuse_address_object: false  # 明确禁用地址对象复用
```

**效果：**
- 服务对象会复用已有对象（如 "HTTP"）
- 地址对象总是按模板生成新名称

### 示例 3：通过 reuse_policy 统一控制

```yaml
metadata:
  securitypolicy.reuse_policy: true  # 统一启用复用
```

**效果：**
- 地址对象和服务对象都会启用复用（默认行为）

### 示例 4：完全禁用复用

```yaml
metadata:
  securitypolicy.reuse_policy: false
  securitypolicy.reuse_address_object: false
  securitypolicy.reuse_service_object: false
```

**效果：**
- 所有对象都按模板生成新名称，不会复用已有对象

## 复用逻辑说明

### 地址对象复用

1. **单个地址对象：**
   - 如果 `reuse_address_object == true`
   - 调用 `GetObjectByNetworkGroup(network, SEARCH_OBJECT_OR_GROUP, nil)`
   - 如果找到相同网络的对象，复用其名称
   - 如果未找到，按模板生成新名称

2. **地址组：**
   - 如果 `reuse_address_object == true`
   - 调用 `GetObjectByNetworkGroup(network, SEARCH_GROUP, nil)`
   - 如果找到相同网络的地址组，复用其名称
   - 如果未找到，按模板生成新名称

3. **地址组中的成员对象：**
   - 每个成员对象也会根据 `reuse_address_object` 参数决定是否复用

### 服务对象复用

1. **单个服务对象：**
   - 如果 `reuse_service_object == true`
   - 调用 `GetObjectByService(service, SEARCH_OBJECT_OR_GROUP)`
   - 如果找到相同服务的对象，复用其名称
   - 如果未找到，按模板生成新名称

2. **服务组：**
   - 如果 `reuse_service_object == true`
   - 调用 `GetObjectByService(service, SEARCH_GROUP)`
   - 如果找到相同服务的服务组，复用其名称
   - 如果未找到，按模板生成新名称

3. **服务组中的成员对象：**
   - 每个成员服务对象也会根据 `reuse_service_object` 参数决定是否复用

## 参数优先级

1. **显式设置：** `securitypolicy.reuse_address_object` 或 `reuse_address_object`
2. **继承策略复用：** 如果未显式设置，则继承 `securitypolicy.reuse_policy` 的值
3. **默认值：** 如果都未设置，默认为 `false`（不复用）

## 注意事项

1. **对象匹配：** 复用基于对象内容（网络或服务）的完全匹配，而不是名称匹配
2. **名称冲突：** 即使启用复用，如果生成的名称与已有对象名称冲突但内容不同，仍会生成新名称（带后缀）
3. **性能考虑：** 启用复用会增加查找开销，但可以减少生成的对象数量
4. **兼容性：** 如果防火墙节点不支持 `GetObjectByNetworkGroup` 或 `GetObjectByService`，复用功能会自动降级为按模板生成

## 实际应用场景

### 场景 1：复用标准服务对象

```yaml
metadata:
  securitypolicy.reuse_service_object: true
```

**场景：** 防火墙已有标准服务对象（如 "HTTP", "HTTPS", "DNS"）
**效果：** 策略生成时会自动复用这些标准对象，而不是生成 `policy_001_tcp_80` 这样的名称

### 场景 2：复用已有网络对象

```yaml
metadata:
  securitypolicy.reuse_address_object: true
```

**场景：** 防火墙已有网络对象（如 "internal_network", "dmz_network"）
**效果：** 策略生成时会自动复用这些网络对象，而不是生成 `policy_001_SRC_192.168.1.0/24` 这样的名称

### 场景 3：完全自定义命名

```yaml
metadata:
  securitypolicy.reuse_address_object: false
  securitypolicy.reuse_service_object: false
  network_object_name_template: "{policy_name}_{if:is_source==\"true\"}SRC{else}DST{endif}_{if:type==\"range\"}{start}_{end}{else if:type==\"subnet\"}{cidr}{else}{ip}{endif}"
  service_object_name_template: "{policy_name}_{protocol:lower}{if:dst_port!=\"\"}_{dst_port}{endif}"
```

**场景：** 希望所有对象都使用策略名作为前缀
**效果：** 所有对象都按模板生成，不会复用已有对象


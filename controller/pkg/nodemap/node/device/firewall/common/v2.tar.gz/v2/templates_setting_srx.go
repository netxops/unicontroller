package v2

import (
	"github.com/netxops/keys"
	"github.com/samber/lo"
)

// SRXTemplatesV2 SRX的V2模板定义
type SRXTemplatesV2 struct {
	ConfigKeys []Entry
}

// GetLayout 获取指定key的layout
func (st *SRXTemplatesV2) GetLayout(key keys.Keys) string {
	var e Entry
	lo.ForEach(st.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})
	return e.Value
}

// NewSRXTemplatesV2 创建SRX的V2模板
func NewSRXTemplatesV2() *SRXTemplatesV2 {
	return &SRXTemplatesV2{
		ConfigKeys: []Entry{
			// 分隔符定义（用于分隔多个对象CLI）
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "#"},

			// 地址对象Layout（使用dsl.IntentFormat）
			// SRX格式：set security zones security-zone {zone} address-book address {name} {ip}/{prefix}
			// 或：set security zones security-zone {zone} address-book address {name} range-address {start} to {end}
			{Key: keys.NewKeyBuilder("AddressObject", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
{if:is_source=="true"}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    set security zones security-zone {zone} address-book address {object_name}
    {if:item:type=="range"} range-address {item:start} to {item:end}
    {else if:item:type=="host"} {item:ip}/32
    {else} {item:ip}/{item:mask:cidr}{endif}
    {newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    set security zones security-zone {zone} address-book address {object_name}
    {if:item:type=="range"} range-address {item:start} to {item:end}
    {else if:item:type=="host"} {item:ip}/32
    {else} {item:ip}/{item:mask:cidr}{endif}
    {newline}
{endfor}
{endif}
{endif}
`},

			// 地址组Layout（成员引用其他地址对象）
			// SRX格式：set security zones security-zone {zone} address-book address-set {name} address {member}
			{Key: keys.NewKeyBuilder("AddressGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
{if:exist:member_objects=="true"}
{for:member in member_objects}
    set security zones security-zone {zone} address-book address-set {object_name} address {member}{newline}
{endfor}
{endif}
{endif}
`},

			// 服务对象Layout（使用dsl.IntentFormat）
			// SRX格式：set applications application {name} protocol {protocol} destination-port {port}
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{set:service.range_format="-"}
{if:exist:object_name=="true"}
{for:item in intent.service.EachDetailed}
    set applications application {object_name}
    {if:item:protocol=="TCP"} protocol tcp{endif}
    {if:item:protocol=="UDP"} protocol udp{endif}
    {if:item:protocol=="ICMP"} protocol icmp{endif}
    {if:item:protocol=="ICMP6"} protocol icmp6{endif}
    {if:item:protocol=="IP"} protocol ip{endif}
    {if:item:protocol=="TCP"}
        {if:item:src_port:isFull=="false"}
            {if:item:src_port:count==1} source-port {item:src_port:compact}{endif}
            {if:item:src_port:count!=1} source-port {item:src_port:range}{endif}
        {endif}
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} destination-port {item:dst_port:compact}{endif}
            {if:item:dst_port:count!=1} destination-port {item:dst_port:range}{endif}
        {endif}
    {endif}
    {if:item:protocol=="UDP"}
        {if:item:src_port:isFull=="false"}
            {if:item:src_port:count==1} source-port {item:src_port:compact}{endif}
            {if:item:src_port:count!=1} source-port {item:src_port:range}{endif}
        {endif}
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} destination-port {item:dst_port:compact}{endif}
            {if:item:dst_port:count!=1} destination-port {item:dst_port:range}{endif}
        {endif}
    {endif}
    {if:item:protocol=="ICMP"}
        {if:item:hasType=="true"} icmp-type {item:type}
            {if:item:hasCode=="true"} icmp-code {item:code}{endif}
        {endif}
    {endif}
    {if:item:protocol=="ICMP6"}
        {if:item:hasType=="true"} icmp6-type {item:type}
            {if:item:hasCode=="true"} icmp6-code {item:code}{endif}
        {endif}
    {endif}
    {newline}
{endfor}
{endif}
`},

			// 服务组Layout（成员引用其他服务对象）
			// SRX格式：set applications application-set {name} application {member}
			{Key: keys.NewKeyBuilder("ServiceGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
{if:exist:member_objects=="true"}
{for:member in member_objects}
    set applications application-set {object_name} application {member}{newline}
{endfor}
{endif}
{endif}
`},

			// VIP Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}和{real_port}直接从intent获取，不需要从meta获取
			// SRX格式：set security nat destination pool {name} address {ip}/{prefix} 或 address {start} to {end}
			// 注意：VIP pool定义的是real_ip（转换后的内部地址），不是外部地址
			// 使用real_ip生成地址池，因为destination pool存储的是映射后的内部地址
			// real_ip可能是单个IP或IP范围（如192.168.1.100-192.168.1.200）
			// 如果real_ip是IP范围，MakeVipOrMipV2会在metaData中设置real_ip_start和real_ip_end
			{Key: keys.NewKeyBuilder("Vip", "OneLoop"), Value: `
{if:exist:pool_name=="true"}
{if:is_reused!="true"}
    {if:exist:real_ip_start=="true"}
    set security nat destination pool {pool_name} address {real_ip_start} to {real_ip_end}{newline}
    {else}
    set security nat destination pool {pool_name} address {real_ip}/32{newline}
    {endif}
    {if:exist:has_real_port=="true"}
    set security nat destination pool {pool_name} address port {real_port}{newline}
    {endif}
{endif}
{endif}
`},

			// MIP Layout - SRX没有MIP
			{Key: keys.NewKeyBuilder("Mip", "OneLoop"), Value: `
`},

			// SNAT_POOL Layout（独立POOL，使用dsl.IntentFormat）
			// 注意：{snat}直接从intent获取，不需要从meta获取
			// SRX格式：set security nat source pool {name} address {ip}/{prefix} 或 address {start} to {end}
			// 注意：使用{item:mask:cidr}生成CIDR格式（/24），确保与parsePool正则表达式兼容
			{Key: keys.NewKeyBuilder("SnatPool", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{if:exist:pool_name=="true"}
{if:is_reused!="true"}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    set security nat source pool {pool_name}
    {if:item:type=="range"} address {item:start} to {item:end}
    {else if:item:type=="host"} address {item:ip}/32
    {else} address {item:ip}/{item:mask:cidr}{endif}
    {newline}
{endfor}
{endif}
{endif}
`},

			// SNAT_POOL Layout（使用interface）
			// 注意：Interface模式不是对象定义，而是NAT命令，应在NAT Policy中处理
			{Key: keys.NewKeyBuilder("SnatPool", "Interface"), Value: `
{comment:SRX的Interface模式SNAT不是对象定义，而是NAT命令，应在NAT Policy中处理}
`},

			// SNAT_POOL Layout（使用指定IP，inline地址形式）
			// SRX不支持inline模式的SNAT，使用pool
			{Key: keys.NewKeyBuilder("SnatPool", "Inline"), Value: `
{comment:SRX不支持inline模式的SNAT，应使用pool}
`},

			// 安全策略Layout（使用dsl.IntentFormat）
			// SRX格式：set security policies from-zone {from} to-zone {to} policy {name} match ... then permit
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format="-"}
{if:exist:description=="true"}
set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} description {description}{newline}
{endif}
{if:exist:has_source_objects=="true"}
{for:item in src_objects}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match source-address-name {item}{newline}
{endfor}
{else}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="host"}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match source-address {item:ip}/32{newline}
    {else if:item:type=="range"}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match source-address {item:start}-{item:end}{newline}
    {else}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match source-address {item:ip}/{item:mask:cidr}{newline}
    {endif}
{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
{for:item in dst_objects}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match destination-address-name {item}{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="host"}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match destination-address {item:ip}/32{newline}
    {else if:item:type=="range"}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match destination-address {item:start}-{item:end}{newline}
    {else}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match destination-address {item:ip}/{item:mask:cidr}{newline}
    {endif}
{endfor}
{endif}
{if:exist:has_service_objects=="true"}
{for:item in service_objects}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match application {item}{newline}
{endfor}
{else}
{for:item in intent.service.EachDetailed}
    {if:item:protocol=="IP"}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match application any{newline}
    {else}
    set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match application {item:protocol:lower}{newline}
    {endif}
{endfor}
{endif}
set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} then {action}{newline}
`},

			// NAT策略Layout（使用dsl.IntentFormat）
			// SRX格式：set security nat source/destination/static rule-set {rule_set} rule {name} ...
			// 注意：使用VIP时应该使用destination，使用MIP时使用static
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{set:service.range_format="-"}
{if:exist:has_real_ip=="true"}
{if:exist:use_vip=="true"}
{if:exist:fromZone=="true"}
set security nat destination rule-set {nat_rule_name} from zone {fromZone}{newline}
{else}
{if:exist:fromPort=="true"}
set security nat destination rule-set {nat_rule_name} from zone {fromPort}{newline}
{endif}
{endif}
{if:exist:toZone=="true"}
set security nat destination rule-set {nat_rule_name} to zone {toZone}{newline}
{else}
{if:exist:toPort=="true"}
set security nat destination rule-set {nat_rule_name} to zone {toPort}{newline}
{endif}
{endif}
set security nat destination rule-set {nat_rule_name} rule {nat_name}{newline}
{if:exist:has_source_objects=="true"}
{for:item in src_objects}
    set security nat destination rule-set {nat_rule_name} rule {nat_name} match source-address-name {item}{newline}
{endfor}
{else}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    set security nat destination rule-set {nat_rule_name} rule {nat_name} match source-address {item:ip}/{item:mask:cidr}{newline}
{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
{for:item in dst_objects}
    set security nat destination rule-set {nat_rule_name} rule {nat_name} match destination-address-name {item}{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    set security nat destination rule-set {nat_rule_name} rule {nat_name} match destination-address {item:ip}/{item:mask:cidr}{newline}
{endfor}
{endif}
{if:exist:has_service_objects=="true"}
{for:item in service_objects}
    set security nat destination rule-set {nat_rule_name} rule {nat_name} match application {item}{newline}
{endfor}
{else}
{for:item in intent.service.EachDetailed}
    {if:item:protocol=="TCP"}
        {if:item:dst_port:isFull=="false"}
            set security nat destination rule-set {nat_rule_name} rule {nat_name} match destination-port {item:dst_port:compact}{newline}
        {endif}
    {else if:item:protocol=="UDP"}
        {if:item:dst_port:isFull=="false"}
            set security nat destination rule-set {nat_rule_name} rule {nat_name} match destination-port {item:dst_port:compact}{newline}
        {endif}
    {endif}
{endfor}
{endif}
set security nat destination rule-set {nat_rule_name} rule {nat_name} then destination-nat pool {vip_name}{newline}
{else}
{if:exist:fromZone=="true"}
set security nat static rule-set {nat_rule_name} from zone {fromZone}{newline}
{else}
{if:exist:fromPort=="true"}
set security nat static rule-set {nat_rule_name} from zone {fromPort}{newline}
{endif}
{endif}
{if:exist:toZone=="true"}
set security nat static rule-set {nat_rule_name} to zone {toZone}{newline}
{else}
{if:exist:toPort=="true"}
set security nat static rule-set {nat_rule_name} to zone {toPort}{newline}
{endif}
{endif}
set security nat static rule-set {nat_rule_name} rule {nat_name}{newline}
{if:exist:has_source_objects=="true"}
{for:item in src_objects}
    set security nat static rule-set {nat_rule_name} rule {nat_name} match source-address-name {item}{newline}
{endfor}
{else}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    set security nat static rule-set {nat_rule_name} rule {nat_name} match source-address {item:ip}/{item:mask:cidr}{newline}
{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
{for:item in dst_objects}
    set security nat static rule-set {nat_rule_name} rule {nat_name} match destination-address-name {item}{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    set security nat static rule-set {nat_rule_name} rule {nat_name} match destination-address {item:ip}/{item:mask:cidr}{newline}
{endfor}
{endif}
{if:exist:has_service_objects=="true"}
{for:item in service_objects}
    set security nat static rule-set {nat_rule_name} rule {nat_name} match application {item}{newline}
{endfor}
{else}
{for:item in intent.service.EachDetailed}
    {if:item:protocol=="TCP"}
        {if:item:dst_port:isFull=="false"}
            set security nat static rule-set {nat_rule_name} rule {nat_name} match destination-port {item:dst_port:compact}{newline}
        {endif}
    {else if:item:protocol=="UDP"}
        {if:item:dst_port:isFull=="false"}
            set security nat static rule-set {nat_rule_name} rule {nat_name} match destination-port {item:dst_port:compact}{newline}
        {endif}
    {endif}
{endfor}
{endif}
{if:exist:has_real_port=="true"}
set security nat static rule-set {nat_rule_name} rule {nat_name} then static-nat prefix {real_ip} mapped-port {real_port}{newline}
{else}
set security nat static rule-set {nat_rule_name} rule {nat_name} then static-nat prefix {real_ip}{newline}
{endif}
{endif}
{else}
{if:exist:fromZone=="true"}
set security nat source rule-set {nat_rule_name} from zone {fromZone}{newline}
{else}
{if:exist:fromPort=="true"}
set security nat source rule-set {nat_rule_name} from zone {fromPort}{newline}
{endif}
{endif}
{if:exist:toZone=="true"}
set security nat source rule-set {nat_rule_name} to zone {toZone}{newline}
{else}
{if:exist:toPort=="true"}
set security nat source rule-set {nat_rule_name} to zone {toPort}{newline}
{endif}
{endif}
{if:exist:has_source_objects=="true"}
{for:item in src_objects}
    set security nat source rule-set {nat_rule_name} rule {nat_name} match source-address-name {item}{newline}
{endfor}
{else}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    set security nat source rule-set {nat_rule_name} rule {nat_name} match source-address {item:ip}/{item:mask:cidr}{newline}
{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
{for:item in dst_objects}
    set security nat source rule-set {nat_rule_name} rule {nat_name} match destination-address-name {item}{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    set security nat source rule-set {nat_rule_name} rule {nat_name} match destination-address {item:ip}/{item:mask:cidr}{newline}
{endfor}
{endif}
{if:exist:has_service_objects=="true"}
{for:item in service_objects}
    set security nat source rule-set {nat_rule_name} rule {nat_name} match application {item}{newline}
{endfor}
{else}
{for:item in intent.service.EachDetailed}
    {if:item:protocol=="TCP"}
        {if:item:dst_port:isFull=="false"}
            set security nat source rule-set {nat_rule_name} rule {nat_name} match destination-port {item:dst_port:compact}{newline}
        {endif}
    {else if:item:protocol=="UDP"}
        {if:item:dst_port:isFull=="false"}
            set security nat source rule-set {nat_rule_name} rule {nat_name} match destination-port {item:dst_port:compact}{newline}
        {endif}
    {endif}
{endfor}
{endif}
{if:exist:interface_name=="true"}
set security nat source rule-set {nat_rule_name} rule {nat_name} then source-nat interface{newline}
{else}
{if:exist:has_pool_id=="true"}
set security nat source rule-set {nat_rule_name} rule {nat_name} then source-nat pool {pool_id}{newline}
{endif}
{endif}
{endif}
`},
		},
	}
}

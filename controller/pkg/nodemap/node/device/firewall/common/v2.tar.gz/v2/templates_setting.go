package v2

import (
	"github.com/netxops/keys"
	"github.com/samber/lo"
)

var _ TemplatesV2 = &SecPathTemplatesV2{}
var _ TemplatesV2 = &SangforTemplatesV2{}
var _ TemplatesV2 = &UsgTemplatesV2{}
var _ TemplatesV2 = &DptechTemplatesV2{}
var _ TemplatesV2 = &AsaTemplatesV2{}
var _ TemplatesV2 = &SRXTemplatesV2{}
var _ TemplatesV2 = &FortiTemplatesV2{}

// SecPathTemplatesV2 SecPath的V2模板定义
type SecPathTemplatesV2 struct {
	ConfigKeys []Entry
}

// SangforTemplatesV2 Sangfor的V2模板定义
type SangforTemplatesV2 struct {
	ConfigKeys []Entry
}

// GetLayout 获取指定key的layout
func (st *SecPathTemplatesV2) GetLayout(key keys.Keys) string {
	var e Entry
	lo.ForEach(st.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})
	return e.Value
}

// NewSecPathTemplatesV2 创建SecPath的V2模板
func NewSecPathTemplatesV2() *SecPathTemplatesV2 {
	return &SecPathTemplatesV2{
		ConfigKeys: []Entry{
			// 分隔符定义（用于分隔多个对象CLI）
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "#"},

			// 地址对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			{Key: keys.NewKeyBuilder("AddressObject", "OneLoop"), Value: `
{if:exist:object_name=="true"}
object-group ip address {object_name}{newline}
{if:is_source=="true"}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    {space:1}network
    {if:item:type=="range"} range {item:start} {item:end}{endif}
    {if:item:type=="host"} host address {item:ip}{endif}
    {if:item:type=="subnet"} subnet {item:ip} {item:mask:dotted}{endif}
    {newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    {space:1}network
    {if:item:type=="range"} range {item:start} {item:end}{endif}
    {if:item:type=="host"} host address {item:ip}{endif}
    {if:item:type=="subnet"} subnet {item:ip} {item:mask:dotted}{endif}
    {newline}
{endfor}
{endif}
{endif}
`},

			// 地址组Layout（成员引用其他地址对象）
			// object-group ip address LY_policy_1231_src_addr01
			//  description LY_policy_1231_source_address
			//  0 network subnet 132.252.41.0 255.255.255.128
			// #

			{Key: keys.NewKeyBuilder("AddressGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
object-group ip address {object_name}{newline}
{if:exist:member_objects=="true"}
	{for:member in member_objects}
		{space:1}network group-object {member}{newline}
	{endfor}
{else}
	{if:is_source=="true"}
		{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
			{space:1}network
			{if:item:type=="range"} range {item:start} {item:end}{endif}
			{if:item:type=="host"} host address {item:ip}{endif}
			{if:item:type=="subnet"} subnet {item:ip} {item:mask:dotted}{endif}
			{newline}
		{endfor}
	{else}
		{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
			{space:1}network
			{if:item:type=="range"} range {item:start} {item:end}{endif}
			{if:item:type=="host"} host address {item:ip}{endif}
			{if:item:type=="subnet"} subnet {item:ip} {item:mask:dotted}{endif}
			{newline}
		{endfor}
	{endif}
{endif}
{endif}
`},

			// 服务对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{set:service.range_format=" "}
{set:service.tcp_format.template="{protocol:lower} from {if:src_port=='0-65535'}any{else}{src_port:range}{endif} to {dst_port:range}"}
{set:service.udp_format.template="{protocol:lower} from {if:src_port=='0-65535'}any{else}{src_port:range}{endif} to {dst_port:compact}"}
{set:service.icmp_format.template="{protocol:lower} type {type} code {code}"}
{if:exist:object_name=="true"}
object-group service {object_name}{newline}
{for:item in intent.service.EachDetailed}
    {space:1}service {item:protocol:lower}
    {if:item:protocol=="TCP"}
        {if:item:src_port=="0-65535"}
        {else} source range {item:src_port:range}{endif}
        {if:item:dst_port:count==1} destination eq {item:dst_port:compact}
        {else} destination range {item:dst_port:range}{endif}
    {else if:item:protocol=="UDP"}
        {if:item:src_port=="0-65535"}
        {else} source range {item:src_port:range}{endif}
        {if:item:dst_port:count==1} destination eq {item:dst_port:compact}
        {else} destination range {item:dst_port:range}{endif}
    {else if:item:protocol=="ICMP"}
        {if:item:hasType=="true"} type {item:type}
            {if:item:hasCode=="true"} code {item:code}{endif}
        {endif}
    {endif}
    {newline}
{endfor}
{endif}
`},

			// 服务组Layout（成员引用其他服务对象）
			{Key: keys.NewKeyBuilder("ServiceGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
object-group service {object_name}{newline}
{if:exist:member_objects=="true"}
{for:member in member_objects}
    {space:1}service group-object {member}{newline}
{endfor}
{endif}
{endif}
`},

			// VIP Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}和{real_port}直接从intent获取，不需要从meta获取
			{Key: keys.NewKeyBuilder("VIP", "OneLoop"), Value: `
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
{if:is_reused!="true"}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
nat server protocol {protocol:lower} global {item:ip} {dst_port:compact} local {real_ip} {real_port}
{endfor}
{endif}
{endif}
`},

			// MIP Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}直接从intent获取，不需要从meta获取
			{Key: keys.NewKeyBuilder("MIP", "OneLoop"), Value: `
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
{if:is_reused!="true"}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
nat server global {item:ip} local {real_ip}
{endfor}
{endif}
{endif}
`},

			// SNAT_POOL Layout（独立POOL，使用dsl.IntentFormat）
			// 注意：{snat}直接从intent获取，不需要从meta获取
			{Key: keys.NewKeyBuilder("SnatPool", "OneLoop"), Value: `
nat address-group {pool_id}{newline}
{space:1}address {snat} {snat}
`},

			// 安全策略Layout（使用dsl.IntentFormat）
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
security-policy ip{newline}
	{space:1}rule {policy_id} name {policy_name}{newline}
	{if:exist:description=="true"}  description {description}{newline}{endif}
	{for:zone in sourceZones}
		{space:2}source-zone {zone}{newline}
	{endfor}
	{for:zone in destinationZones}
		{space:2}destination-zone {zone}{newline}
	{endfor}
{if:exist:has_source_objects=="true"}
	{for:item in src_objects}
		{space:2}source-ip {item}{newline}
	{endfor}
{else}
	{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
		{if:item:type=="host"}  source-ip-host {item:ip}{else if:item:type=="range"}  source-ip-range {item:start} {item:end}{else}  source-ip-subnet {item:ip} {item:mask:dotted}{endif}{newline}
	{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
	{for:item in dst_objects}
		{space:2}destination-ip {item}{newline}
	{endfor}
{else}
	{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
		{if:item:type=="host"}  destination-ip-host {item:ip}{else if:item:type=="range"}  destination-ip-range {item:start} {item:end}{else}  destination-ip-subnet {item:ip} {item:mask:dotted}{endif}{newline}
	{endfor}
{endif}
{if:exist:has_service_objects=="true"}
	{for:item in service_objects}
		{space:2}service {item}{newline}
	{endfor}
{else}
	{for:item in intent.service.EachDetailed}
		{space:2}service-port {item:protocol:lower}
		{if:item:protocol=="ICMP"}
			{if:item:hasType=="true"} {item:type}
				{if:item:hasCode=="true"} {item:code}{endif}
			{endif}
		{endif}
		{if:item:protocol=="TCP"}
			{if:item:src_port=="0-65535"}
			{else}
				{if:item:src_port:count==1} source eq {item:src_port:compact}
				{else} source range {item:src_port:range}{endif}
			{endif}
			{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
			{else} destination range {item:dst_port:range}{endif}
		{endif}
		{if:item:protocol=="UDP"}
			{if:item:src_port=="0-65535"}
			{else}
				{if:item:src_port:count==1} source eq {item:src_port:compact}
				{else} source range {item:src_port:range}{endif}
			{endif}
			{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
			{else} destination range {item:dst_port:range}{endif}
		{endif}
		{newline}
	{endfor}
{endif}
	{space:2}action {action}{newline}
	{if:enable=="true"}
	{else}
		{space:2}disable{newline}
	{endif}
`},

			// NAT策略Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}、{real_port}、{snat}直接从intent获取，不需要从meta获取
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{set:service.range_format=" "}
{if:nat_type=="DNAT"}
nat global-policy{newline}
	{space:1}rule name {nat_name}{newline}
	{if:exist:description=="true"}  description {description}{newline}{endif}
	{for:zone in sourceZones}
		{space:2}source-zone {zone}{newline}
	{endfor}
	{for:zone in destinationZones}
		{space:2}destination-zone {zone}{newline}
	{endfor}
{if:exist:has_source_objects=="true"}
	{for:item in src_objects}
		{space:2}source-ip {item}{newline}
	{endfor}
{else}
	{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
		{if:item:type=="host"}  source-ip-host {item:ip}{else if:item:type=="range"}  source-ip-range {item:start} {item:end}{else}  source-ip-subnet {item:ip} {item:mask:dotted}{endif}{newline}
	{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
	{for:item in dst_objects}
		{space:2}destination-ip {item}{newline}
	{endfor}
{else}
	{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
		{if:item:type=="host"}  destination-ip-host {item:ip}{else if:item:type=="range"}  destination-ip-range {item:start} {item:end}{else}  destination-ip-subnet {item:ip} {item:mask:dotted}{endif}{newline}
	{endfor}
{endif}
{if:exist:has_service_objects=="true"}
	{for:item in service_objects}
		{space:2}service {item}{newline}
	{endfor}
{else}
	{for:item in intent.service.EachDetailed}
		{space:2}service-port {item:protocol:lower}
		{if:item:protocol=="ICMP"}
			{if:item:hasType=="true"} {item:type}
				{if:item:hasCode=="true"} {item:code}{endif}
			{endif}
		{endif}
		{if:item:protocol=="TCP"}
			{if:item:src_port=="0-65535"}
			{else}
				{if:item:src_port:count==1} source eq {item:src_port:compact}
				{else} source range {item:src_port:range}{endif}
			{endif}
			{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
			{else} destination range {item:dst_port:range}{endif}
		{endif}
		{if:item:protocol=="UDP"}
			{if:item:src_port=="0-65535"}
			{else}
				{if:item:src_port:count==1} source eq {item:src_port:compact}
				{else} source range {item:src_port:range}{endif}
			{endif}
			{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
			{else} destination range {item:dst_port:range}{endif}
		{endif}
		{newline}
	{endfor}
{endif}
	{if:vip_name != ""}
		{space:2}action dnat object-group {vip_name}
	{else}
		{space:2}action dnat ip-address {real_ip}
	{endif}
	{if:exist:has_real_port=="true"} local-port {real_port}{endif}
	{newline}
{else}
nat global-policy{newline}
	{space:1}rule name {nat_name}{newline}
	{if:exist:description=="true"}  description {description}{newline}{endif}
	{for:zone in sourceZones}
		{space:2}source-zone {zone}{newline}
	{endfor}
	{for:zone in destinationZones}
		{space:2}destination-zone {zone}{newline}
	{endfor}
{if:exist:has_source_objects=="true"}
	{for:item in src_objects}
		{space:2}source-ip {item}{newline}
	{endfor}
{else}
	{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
		{if:item:type=="host"}  source-ip-host {item:ip}{else if:item:type=="range"}  source-ip-range {item:start} {item:end}{else}  source-ip-subnet {item:ip} {item:mask:dotted}{endif}{newline}
	{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
	{for:item in dst_objects}
		{space:2}destination-ip {item}{newline}
	{endfor}
{else}
	{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
		{if:item:type=="host"}  destination-ip-host {item:ip}{else if:item:type=="range"}  destination-ip-range {item:start} {item:end}{else}  destination-ip-subnet {item:ip} {item:mask:dotted}{endif}{newline}
	{endfor}
{endif}
{if:exist:has_service_objects=="true"}
	{for:item in service_objects}
		{space:2}service {item}{newline}
	{endfor}
{else}
	{for:item in intent.service.EachDetailed}
		{space:2}service-port {item:protocol:lower}
		{if:item:protocol=="ICMP"}
			{if:item:hasType=="true"} {item:type}
				{if:item:hasCode=="true"} {item:code}{endif}
			{endif}
		{endif}
		{if:item:protocol=="TCP"}
			{if:item:src_port=="0-65535"}
			{else}
				{if:item:src_port:count==1} source eq {item:src_port:compact}
				{else} source range {item:src_port:range}{endif}
			{endif}
			{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
			{else} destination range {item:dst_port:range}{endif}
		{endif}
		{if:item:protocol=="UDP"}
			{if:item:src_port=="0-65535"}
			{else}
				{if:item:src_port:count==1} source eq {item:src_port:compact}
				{else} source range {item:src_port:range}{endif}
			{endif}
			{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
			{else} destination range {item:dst_port:range}{endif}
		{endif}
		{newline}
	{endfor}
{endif}
{if:exist:has_pool_id=="true"}
	{space:2}action snat address-group {pool_id}{newline}
{else}
	{if:snat=="interface"}
		{space:2}action snat easy-ip{newline}
	{else}
		{space:2}action snat ip-address {snat}{newline}
	{endif}
{endif}
{endif}
`},
		},
	}
}

// GetLayout 获取指定key的layout
func (st *SangforTemplatesV2) GetLayout(key keys.Keys) string {
	var e Entry
	lo.ForEach(st.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})
	return e.Value
}

// NewSangforTemplatesV2 创建Sangfor的V2模板
func NewSangforTemplatesV2() *SangforTemplatesV2 {
	return &SangforTemplatesV2{
		ConfigKeys: []Entry{
			// 分隔符定义（用于分隔多个对象CLI）
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "\n"},

			// 地址对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// 注意：Sangfor的ipentry使用CIDR格式（/24），不是点分十进制掩码
			{Key: keys.NewKeyBuilder("AddressObject", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
config{newline}
ipgroup "{object_name}" ipv4{newline}
type ip{newline}
importance ordinary{newline}
{if:is_source=="true"}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="range"}ipentry {item:start}-{item:end}
    {else if:item:type=="host"}ipentry {item:ip}
    {else}ipentry {item:ip}/{item:mask:prefix}{endif}
    {newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="range"}ipentry {item:start}-{item:end}
    {else if:item:type=="host"}ipentry {item:ip}
    {else}ipentry {item:ip}/{item:mask:prefix}{endif}
    {newline}
{endfor}
{endif}
end{newline}
{endif}
`},

			// 地址组Layout（成员引用其他地址对象）
			{Key: keys.NewKeyBuilder("AddressGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
config{newline}
ipgroup "{object_name}" ipv4{newline}
type addrgroup{newline}
importance ordinary{newline}
{if:exist:member_objects=="true"}
{for:member in member_objects}
    member "{member}"{newline}
{endfor}
{endif}
end{newline}
{endif}
`},

			// ServiceObject.CompactPorts 模板：用于生成 compact_port（用于对象名称）
			{Key: keys.NewKeyBuilder("ServiceObject", "CompactPorts"), Value: `{set:service.range_format="_"}
{if:src_port:isFull=="false"}
S{src_port:compact}
{if:dst_port:isFull=="false"}
D{dst_port:compact}
{endif}
{else}
{dst_port:compact}
{endif}
`},

			// 服务对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// 支持格式：
			// config
			// service "name"
			// icmp type 6 code 8
			// protocol 55
			// tcp src-port 0-65535 dst-port 80,443,1000-1005
			// udp src-port 0-65535 dst-port 5555
			// end
			// 注意：相同协议且相同src-port的条目会合并为一行，dst-port用逗号分隔
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{set:service.range_format=" "}
{if:exist:object_name=="true"}
config{newline}
service "{object_name}"{newline}
{for:item in intent.service.TcpEach}
    {if:item:src_port:isFull=="true"}
        tcp src-port 0-65535 dst-port {item:dst_port}
    {else}
        tcp src-port {item:src_port:range} dst-port {item:dst_port}
    {endif}
    {newline}
{endfor}
{for:item in intent.service.UdpEach}
    {if:item:src_port:isFull=="true"}
        udp src-port 0-65535 dst-port {item:dst_port}
    {else}
        udp src-port {item:src_port:range} dst-port {item:dst_port}
    {endif}
    {newline}
{endfor}
{for:item in intent.service.IcmpEach}
    {if:item:hasType=="true"}
        icmp type {item:type}{if:item:hasCode=="true"} code {item:code}{endif}
    {else}
        icmp type 255 code 255
    {endif}
    {newline}
{endfor}
{for:item in intent.service.L3Each}
    protocol {item:protocol:number}
    {newline}
{endfor}
end{newline}
{endif}
`},

			// 服务组Layout（成员引用其他服务对象）
			// 支持格式：
			// config
			// servgroup "name"
			// service "service1"
			// service "service2"
			// end
			{Key: keys.NewKeyBuilder("ServiceGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
config{newline}
servgroup "{object_name}"{newline}
{if:exist:member_objects=="true"}
{for:member in member_objects}
    service "{member}"{newline}
{endfor}
{endif}
end{newline}
{endif}
`},

			{Key: keys.NewKeyBuilder("VIP", "OneLoop"), Value: `
`},

			{Key: keys.NewKeyBuilder("MIP", "OneLoop"), Value: `
`},

			// SNAT_POOL Layout（独立POOL，使用dsl.IntentFormat）
			// 	nat address-group 1
			//   address 172.26.120.1 172.26.120.10

			{Key: keys.NewKeyBuilder("SnatPool", "OneLoop"), Value: `
`},

			// 安全策略Layout（使用dsl.IntentFormat）
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
config{newline}
policy "{policy_name}" top{newline}
{if:enable=="true"}enable{newline}{endif}
group "default-policygroup"{newline}
{for:zone in sourceZones}
	{if:zone!=""}
		src-zone "{zone}"{newline}
	{endif}
{endfor}
{for:zone in destinationZones}
	{if:zone!=""}
		dst-zone "{zone}"{newline}
	{endif}
{endfor}
{if:exist:has_source_objects=="true"}
{for:item in src_objects}
    src-ipgroup "{item}"{newline}
{endfor}
{else}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="host"}src-ipgroup "{item:ip}"
    {else if:item:type=="range"}src-ipgroup "{item:start}-{item:end}"
    {else}src-ipgroup "{item:ip}/{item:mask:prefix}"{endif}
    {newline}
{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
{for:item in dst_objects}
    dst-ipgroup "{item}"{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="host"}dst-ipgroup "{item:ip}"
    {else if:item:type=="range"}dst-ipgroup "{item:start}-{item:end}"
    {else}dst-ipgroup "{item:ip}/{item:mask:prefix}"{endif}
    {newline}
{endfor}
{endif}
{if:exist:has_service_objects=="true"}
{for:item in service_objects}
    service "{item}"{newline}
{endfor}
{else}
service "any"{newline}
{endif}
user-group "/"{newline}
application "全部"{newline}
action {action}{newline}
schedule "all-week"{newline}
log session-start disable{newline}
log session-end disable{newline}
end{newline}
`},

			// NAT策略Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}、{real_port}、{snat}直接从intent获取，不需要从meta获取
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{set:service.range_format=" "}
{if:nat_type=="DNAT"}
  config{newline}
  dnat-rule "{nat_name}" top{newline}
{else}
  config{newline}
  snat-rule "{nat_name}" top{newline}
{endif}
{if:enable=="true"}enable{newline}{endif}
{if:exist:fromZone=="true"}
  src-zone "{fromZone}"{newline}
{endif}
schedule "all-week"{newline}
{if:exist:has_source_objects=="true"}
    {for:item in src_objects}
      src-ipgroup "{item}"{newline}
    {endfor}
{else}
    {for:item in intent.src.EachDataRangeEntryAsAbbrNet}
      {if:item:type=="host"}src-ipgroup "{item:ip}"
      {else if:item:type=="range"}src-ipgroup "{item:start}-{item:end}"
      {else}src-ipgroup "{item:ip}/{item:mask:prefix}"{endif}
      {newline}
    {endfor}
{endif}
  {if:nat_type=="DNAT"}
    {for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
      {if:item:type=="host"}dst-ip {item:ip}
      {else if:item:type=="range"}dst-ip {item:start}-{item:end}
      {else}dst-ip {item:ip}/{item:mask:prefix}{endif}
      {newline}
    {endfor}
    {if:exist:toZone=="true"}
      dst-zone {toZone}{newline}
    {endif}
  {else}
    {if:exist:has_destination_objects=="true"}
      {for:item in dst_objects}
        dst-ipgroup "{item}"{newline}
      {endfor}
    {else}
      {for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
        {if:item:type=="host"}dst-ipgroup "{item:ip}"
        {else if:item:type=="range"}dst-ipgroup "{item:start}-{item:end}"
        {else}dst-ipgroup "{item:ip}/{item:mask:prefix}"{endif}
        {newline}
      {endfor}
    {endif}
    {if:exist:toZone=="true"}
      dst-zone {toZone}{newline}
    {endif}
{endif}
{if:exist:has_service_objects=="true"}
  {for:item in service_objects}
    service "{item}"{newline}
  {endfor}
{else}
  service "any"{newline}
{endif}
{if:nat_type=="DNAT"}
  {if:exist:has_mip_object=="true"}
    transfer ipgroup {mip_object}{if:exist:has_real_port=="true"} port {real_port}{endif}{newline}
  {else}
    transfer ip {real_ip}{if:exist:has_real_port=="true"} port {real_port}{endif}{newline}
  {endif}
{else}
  {if:exist:has_pool_id=="true"}
    transfer ipgroup "{pool_id}"{newline}
  {else}
    transfer ip {snat}{newline}
  {endif}
{endif}
end{newline}
`},
		},
	}
}

// UsgTemplatesV2 USG的V2模板定义
type UsgTemplatesV2 struct {
	ConfigKeys []Entry
}

// GetLayout 获取指定key的layout
func (ut *UsgTemplatesV2) GetLayout(key keys.Keys) string {
	var e Entry
	lo.ForEach(ut.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})
	return e.Value
}

// NewUsgTemplatesV2 创建USG的V2模板
func NewUsgTemplatesV2() *UsgTemplatesV2 {
	return &UsgTemplatesV2{
		ConfigKeys: []Entry{
			// 分隔符定义（用于分隔多个对象CLI）
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "#"},

			// 地址对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// USG格式：ip address-set <name> type object
			//          address <ip> mask <mask> 或 address range <start> <end>
			{Key: keys.NewKeyBuilder("AddressObject", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
ip address-set {object_name} type object{newline}
{if:is_source=="true"}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="range"} address range {item:start} {item:end}
    {else if:item:type=="host"} address {item:ip} mask 255.255.255.255
    {else} address {item:ip} mask {item:mask:dotted}{endif}
    {newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="range"} address range {item:start} {item:end}
    {else if:item:type=="host"} address {item:ip} mask 255.255.255.255
    {else} address {item:ip} mask {item:mask:dotted}{endif}
    {newline}
{endfor}
{endif}
{endif}
`},

			// 地址组Layout（成员引用其他地址对象）
			// USG格式：ip address-set <name> type group
			//          address-set <member>
			{Key: keys.NewKeyBuilder("AddressGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
ip address-set {object_name} type group{newline}
{if:exist:member_objects=="true"}
{for:member in member_objects}
    address address-set {member}{newline}
{endfor}
{endif}
{endif}
`},

			// 服务对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// USG格式：ip service-set <name> type object
			//          service protocol <protocol> source-port <port> destination-port <port>
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{set:service.range_format=" to "}
{if:exist:object_name=="true"}
ip service-set {object_name} type object{newline}
{for:item in intent.service.EachDetailed}
    service protocol {item:protocol:lower}
    {if:item:protocol=="TCP"}
        {if:item:src_port=="0-65535"}
        {else} source-port {item:src_port:range}{endif}
        {if:item:dst_port:count==1} destination-port {item:dst_port:compact}
        {else} destination-port {item:dst_port:range}{endif}
    {else if:item:protocol=="UDP"}
        {if:item:src_port=="0-65535"}
        {else} source-port {item:src_port:range}{endif}
        {if:item:dst_port:count==1} destination-port {item:dst_port:compact}
        {else} destination-port {item:dst_port:range}{endif}
    {else if:item:protocol=="ICMP"}
        {if:item:hasType=="true"} icmp-type {item:type}
            {if:item:hasCode=="true"} {item:code}{endif}
        {endif}
    {endif}
    {newline}
{endfor}
{endif}
`},

			// 服务组Layout（成员引用其他服务对象）
			// USG格式：service-group <name>
			//          service-object <service> 或 predefined-service <builtin>
			{Key: keys.NewKeyBuilder("ServiceGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
ip service-set {object_name} type group{newline}
{if:exist:member_objects=="true"}
{for:member in member_objects}
    service service-set {member}{newline}
{endfor}
{endif}
{endif}
`},

			// VIP Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}和{real_port}直接从intent获取，不需要从meta获取
			// USG格式：nat server <name> protocol <protocol> global <ip> <port> inside <ip> <port>
			{Key: keys.NewKeyBuilder("VIP", "OneLoop"), Value: `
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
{if:is_reused!="true"}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
nat server {object_name} protocol {protocol:lower} global {item:ip} {dst_port:compact} inside {real_ip} {real_port}
{endfor}
{endif}
{endif}
`},

			// MIP Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}直接从intent获取，不需要从meta获取
			// USG格式：destination-nat address-group <name> <number>
			//          section <start_ip> <end_ip>
			{Key: keys.NewKeyBuilder("MIP", "OneLoop"), Value: `
{if:exist:object_name=="true"}
{if:is_reused!="true"}
destination-nat address-group {object_name} 0{newline}
section {real_ip} {real_ip}
{endif}
{endif}
`},

			// SNAT_POOL Layout（独立POOL，使用dsl.IntentFormat）
			// 注意：{snat}直接从intent获取，不需要从meta获取
			// USG格式：nat address-group {pool_id} 0
			//          section 0 {snat} {snat}
			{Key: keys.NewKeyBuilder("SnatPool", "OneLoop"), Value: `
{if:exist:pool_id=="true"}
nat address-group {pool_id} {section_count}{newline}
section 0 {snat} {snat}
{endif}
`},

			// SNAT_POOL Layout（使用interface）
			// 注意：Interface模式不是对象定义，而是NAT命令，应在NAT Policy中处理
			{Key: keys.NewKeyBuilder("SnatPool", "Interface"), Value: `
{comment:USG的Interface模式SNAT不是对象定义，而是NAT命令，应在NAT Policy中处理}
`},

			// SNAT_POOL Layout（使用指定IP，inline地址形式）
			// 注意：Inline模式不是对象定义，而是NAT命令，应在NAT Policy中处理
			{Key: keys.NewKeyBuilder("SnatPool", "Inline"), Value: `
{comment:USG的Inline模式SNAT不是对象定义，而是NAT命令，应在NAT Policy中处理}
`},

			// 安全策略Layout（使用dsl.IntentFormat）
			// USG格式：security-policy
			//          rule name <name> (1个空格缩进)
			//          source-zone <zone> (3个空格缩进)
			//          destination-zone <zone> (3个空格缩进)
			//          source-address <address> 或 source-address address-set <name> (3个空格缩进)
			//          destination-address <address> 或 destination-address address-set <name> (3个空格缩进)
			//          service <service> 或 service protocol <protocol> ... (3个空格缩进)
			//          action permit/deny (3个空格缩进)
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
security-policy{newline}
 {space:1}rule name {policy_name}{newline}
{if:exist:description=="true"}{space:2}description {description}{newline}{endif}
{for:zone in sourceZones}
 {space:2}source-zone {zone}{newline}
 {endfor}
 {for:zone in destinationZones}
 {space:2}destination-zone {zone}{newline}
 {endfor}
{if:exist:has_source_objects=="true"}
 {for:item in src_objects}
 {space:2}source-address address-set {item}{newline}
 {endfor}
{else}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
 {if:item:type=="host"}{space:2}source-address {item:ip} mask 255.255.255.255
 {else if:item:type=="range"}{space:2}source-address range {item:start} {item:end}
{else}{space:2}source-address {item:ip} mask {item:mask:dotted}{endif}
{newline}
{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
{for:item in dst_objects}
{space:2}destination-address address-set {item}{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
{if:item:type=="host"}{space:2}destination-address {item:ip} mask 255.255.255.255
{else if:item:type=="range"}{space:2}destination-address range {item:start} {item:end}
{else}{space:2}destination-address {item:ip} mask {item:mask:dotted}{endif}
{newline}
{endfor}
{endif}
{if:exist:has_service_objects=="true"}
{for:item in service_objects}
 {space:2}service {item}{newline}
{endfor}
{else}


{if:is_ip_protocol!="true"}
{for:item in intent.service.EachDetailed}
 {space:2}service protocol {item:protocol:lower}
 {if:item:protocol=="TCP"}
        {if:item:src_port:isFull=="false"}
            {if:item:src_port:count==1} source-port {item:dst_port:compact}
            {else} source-port {item:src_port:range}{endif}
        {endif}
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} destination-port {item:dst_port:compact}
            {else} destination-port {item:dst_port:range}{endif}
        {endif}

{else if:item:protocol=="UDP"}

        {if:item:src_port:isFull=="false"}
            {if:item:src_port:count==1} source-port {item:dst_port:compact}
            {else} source-port {item:src_port:range}{endif}
        {endif}
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} destination-port {item:dst_port:compact}
            {else} destination-port {item:dst_port:range}{endif}
        {endif}

 {else if:item:protocol=="ICMP"}
 {if:item:hasType=="true"} icmp-type{item:type}
 {if:item:hasCode=="true"} {item:code}{endif}
 {endif}
 {endif}
 {newline}
 {endfor}

 {endif}

{endif}
 {space:2}action {action}{newline}
 {if:enable=="true"}
 {else}
 {space:2}disable{newline}
 {endif}
`},

			// NAT策略Layout（使用dsl.IntentFormat）
			// USG格式：nat global-policy
			//          rule name <name>
			//          source-zone <zone>
			//          destination-zone <zone>
			//          source-ip <address> 或 source-ip address-set <name>
			//          destination-ip <address> 或 destination-ip address-set <name>
			//          service-port <protocol> ...
			//          action snat address-group <pool> 或 action dnat ip-address <ip> local-port <port>
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{set:service.range_format=" "}
nat-policy{newline}
    rule name {nat_name}{newline}
    {if:exist:description=="true"} description {description}{newline}{endif}
    {for:zone in sourceZones}
        source-zone {zone}{newline}
    {endfor}
    {for:zone in destinationZones}
        destination-zone {zone}{newline}
    {endfor}
{if:exist:has_source_objects=="true"}
    {for:item in src_objects}
        source-address address-set {item}{newline}
    {endfor}
{else}
    {for:item in intent.src.EachDataRangeEntryAsAbbrNet}
        {if:item:type=="host"} source-address {item:ip} mask 255.255.255.255
        {else if:item:type=="range"} source-address range {item:start} {item:end}
        {else} source-address {item:ip} mask {item:mask:dotted}{endif}
        {newline}
    {endfor}
{endif}
{if:exist:has_destination_objects=="true"}
    {for:item in dst_objects}
        destination-address address-set {item}{newline}
    {endfor}
{else}
    {for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
        {if:item:type=="host"} destination-address {item:ip} mask 255.255.255.255
        {else if:item:type=="range"} destination-address range {item:start} {item:end}
        {else} destination-address {item:ip} mask {item:mask:dotted}{endif}
        {newline}
    {endfor}
{endif}
{if:exist:has_service_objects=="true"}
    {for:item in service_objects}
        service {item}{newline}
    {endfor}
{else}





{if:is_ip_protocol!="true"}


{for:item in intent.service.EachDetailed}
 {space:2}service protocol {item:protocol:lower}
 {if:item:protocol=="TCP"}
        {if:item:src_port:isFull=="false"}
            {if:item:src_port:count==1} source-port {item:dst_port:compact}
            {else} source-port {item:src_port:range}{endif}
        {endif}
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} destination-port {item:dst_port:compact}
            {else} destination-port {item:dst_port:range}{endif}
        {endif}
{else if:item:protocol=="UDP"}
        {if:item:src_port:isFull=="false"}
            {if:item:src_port:count==1} source-port {item:dst_port:compact}
            {else} source-port {item:src_port:range}{endif}
        {endif}
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} destination-port {item:dst_port:compact}
            {else} destination-port {item:dst_port:range}{endif}
        {endif}

 {else if:item:protocol=="ICMP"}
		{if:item:hasType=="true"} icmp-type{item:type}
		{if:item:hasCode=="true"} {item:code}{endif}
 {endif}
 {endif}
 {newline}
 {endfor}
 {endif}





{endif}
{if:nat_type=="DNAT"}
	{if:mip_name != ""}
		{space:2}action destination-nat address-group {mip_name}
	{else}
		{space:2}action destination-nat address {real_ip}
	{endif}
	{if:exist:has_real_port=="true"} {real_port}{endif}
	{newline}
{else}
	{if:exist:has_pool_id=="true"}
    	action source-nat address-group {pool_id}{newline}
    {else}
		action source-nat easy-ip{newline}
	{endif}
{endif}
`},
		},
	}
}

// DptechTemplatesV2 DPTech的V2模板定义
type DptechTemplatesV2 struct {
	ConfigKeys []Entry
}

// GetLayout 获取指定key的layout
func (dt *DptechTemplatesV2) GetLayout(key keys.Keys) string {
	var e Entry
	lo.ForEach(dt.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})
	return e.Value
}

// NewDptechTemplatesV2 创建DPTech的V2模板
func NewDptechTemplatesV2() *DptechTemplatesV2 {
	return &DptechTemplatesV2{
		ConfigKeys: []Entry{
			// 分隔符定义（用于分隔多个对象CLI）
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "!"},

			// 地址对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// DPTech格式：address-object {name} {cidr} 或 address-object {name} range {start} {end}
			{Key: keys.NewKeyBuilder("AddressObject", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
{if:is_source=="true"}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="range"}address-object {object_name} range {item:start} {item:end}
    {else}address-object {object_name} {item:cidr}{endif}
    {newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="range"}address-object {object_name} range {item:start} {item:end}
    {else}address-object {object_name} {item:cidr}{endif}
    {newline}
{endfor}
{endif}
{endif}
`},

			// 地址组Layout（成员引用其他地址对象）
			// DPTech通过多行同名address-object定义地址组，每个引用一个成员对象
			// address-group DMZ_XXB_AddressGroup01 address-object DMZ_192.168.32.18
			// address-group DMZ_XXB_AddressGroup01 address-object DMZ_192.168.32.19
			{Key: keys.NewKeyBuilder("AddressGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
{if:exist:member_objects=="true"}
{for:member in member_objects}
     address-group {object_name} address-object {member}{newline}
{endfor}
{endif}
{endif}
`},

			// 服务对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// DPTech格式：service-object {name} protocol {protocol:lower} src-port {src_port:compact} dst-port {dst_port:compact}
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{set:service.range_format=" to "}
{if:exist:object_name=="true"}
{for:item in intent.service.EachDetailed}
    service-object {object_name} protocol {item:protocol:lower}
    {if:item:protocol=="TCP"}
        {if:item:src_port:isFull=="false"}
            {if:item:src_port:count==1} src-port {item:src_port:compact}
            {else} src-port {item:src_port:range}{endif}
        {endif}
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} dst-port {item:dst_port:compact}
            {else} dst-port {item:dst_port:range}{endif}
        {endif}
    {else if:item:protocol=="UDP"}
        {if:item:src_port:isFull=="false"}
            {if:item:src_port:count==1} src-port {item:src_port:compact}
            {else} src-port {item:src_port:range}{endif}
        {endif}
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} dst-port {item:dst_port:compact}
            {else} dst-port {item:dst_port:range}{endif}
        {endif}
    {else if:item:protocol=="ICMP"}
        {if:item:hasType=="true"}
            type {item:type}
            {if:item:hasCode=="true"} code {item:code}{endif}
        {endif}
    {endif}
    {newline}
{endfor}
{endif}
`},

			// 服务组Layout（成员引用其他服务对象）
			// DPTech通过多行同名service-object定义服务组，每个引用一个成员对象
			{Key: keys.NewKeyBuilder("ServiceGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
{if:exist:member_objects=="true"}
{for:member in member_objects}
    service-group {object_name} service-object {member}{newline}
{endfor}
{endif}
{endif}
`},

			// VIP Layout（使用dsl.IntentFormat）
			// DPTech格式：nat destination-nat {name} interface {interface} global-address {ip} service {protocol} {port} to {port} local-address {ip} to {ip} local-port {port}
			// VIP Layout - DPTech没有VIP，只有MIP
			{Key: keys.NewKeyBuilder("VIP", "OneLoop"), Value: `
`},

			// MIP Layout - DPTech的static nat只使用inline模式地址，不需要address-pool
			// static nat在NatPolicy layout中直接生成：nat static {name} interface {interface} global-address {ip} local-address {ip}
			{Key: keys.NewKeyBuilder("MIP", "OneLoop"), Value: `
			{if:exist:object_name=="true"}
			address-pool {object_name} address {real_ip} to {real_ip}
			{endif}
`},

			// SNAT_POOL Layout（独立POOL，使用dsl.IntentFormat）
			// 注意：{snat}直接从intent获取，不需要从meta获取
			// DPTech格式：address-pool {name} address {start} [to {end}]
			// 注意：根据正则表达式，address-pool格式为：address-pool {name} address {start} [to {end}]
			// 对于host和subnet，不需要"to"，只有range需要"to {end}"
			{Key: keys.NewKeyBuilder("SnatPool", "OneLoop"), Value: `
			{if:exist:pool_name=="true"}
			address-pool {pool_name} address {snat} to {snat}
			{endif}
`},

			// SNAT_POOL Layout（使用interface）
			// 注意：Interface模式不是对象定义，而是NAT命令，应在NAT Policy中处理
			{Key: keys.NewKeyBuilder("SnatPool", "Interface"), Value: `
{comment:DPTech的Interface模式SNAT不是对象定义，而是NAT命令，应在NAT Policy中处理}
`},

			// SNAT_POOL Layout（使用指定IP，inline地址形式）
			// DPTech不支持inline模式的SNAT，使用地址池
			{Key: keys.NewKeyBuilder("SnatPool", "Inline"), Value: `
{comment:DPTech不支持inline模式的SNAT，应使用地址池}
`},

			// 安全策略Layout（使用dsl.IntentFormat）
			// DPTech格式：security-policy {name} src-zone {zone} dst-zone {zone} src-address address-object {obj} ...
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" to "}
{if:exist:has_source_objects=="true"}
{for:item in src_objects}
    security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} src-address address-object {item}{newline}
{endfor}
{else}
{endif}
{if:exist:has_destination_objects=="true"}
{for:item in dst_objects}
    security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} dst-address address-object {item}{newline}
{endfor}
{else}
{endif}
{if:is_ip_protocol=="true"}
security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} service any{newline}
{endif}
{if:exist:has_service_objects=="true"}
{for:item in service_objects}
    security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} service service-object {item}{newline}
{endfor}
{else}
{for:item in intent.service.EachDetailed}
    {if:item:protocol=="TCP"}
    security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} service user-define-service TCP
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} dst-port {item:dst_port:compact}
            {else} dst-port {item:dst_port:range}{endif}
        {endif}
    {newline}
    {else if:item:protocol=="UDP"}
    security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} service user-define-service UDP
        {if:item:dst_port:isFull=="false"}
            {if:item:dst_port:count==1} dst-port {item:dst_port:compact}
            {else} dst-port {item:dst_port:range}{endif}
        {endif}
    {newline}
    {else if:item:protocol=="ICMP"}
    security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} service user-define-service ICMP{newline}
    {endif}
{endfor}
{endif}
security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} action {action}{newline}
{if:exist:description=="true"}
security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} description {description}{newline}
{endif}
`},

			// NAT策略Layout（使用dsl.IntentFormat）
			// DPTech格式：nat source-nat {name} ... 或 nat destination-nat {name} ... 或 nat static {name} ...
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{set:service.range_format=" to "}
{set:intent.dst_template="{ip}"}
{if:exist:has_real_ip=="true"}
{if:exist:has_real_port=="true"}
{if:exist:fromPort=="true"}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
nat destination-nat {nat_name} interface {fromPort} global-address {item:ip} service {protocol:lower} {dst_port:compact} local-address {real_ip} to {real_ip} local-port {real_port}{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
nat destination-nat {nat_name} interface {toPort} global-address {item:ip} service {protocol:lower} {dst_port:compact} local-address {real_ip} to {real_ip} local-port {real_port}{newline}
{endfor}
{endif}
{else}
{if:exist:fromPort=="true"}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
nat static {nat_name} interface {fromPort} global-address {item:ip} local-address {real_ip}{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
nat static {nat_name} interface {toPort} global-address {item:ip} local-address {real_ip}{newline}
{endfor}
{endif}
{endif}
{else}
{if:exist:toPort=="true"}
nat source-nat {nat_name} interface {toPort}{newline}
{endif}
{if:exist:has_source_objects=="true"}
{for:item in src_objects}
    nat source-nat {nat_name} src-address address-object {item}{newline}
{endfor}
{else}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="host"}
    nat source-nat {nat_name} src-address address-object {item:ip}{newline}
    {else if:item:type=="range"}
    nat source-nat {nat_name} src-address address-object {item:start}-{item:end}{newline}
    {else}
    nat source-nat {nat_name} src-address address-object {item:cidr}{newline}
    {endif}
{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
{for:item in dst_objects}
    nat source-nat {nat_name} dst-address address-object {item}{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="host"}
    nat source-nat {nat_name} dst-address address-object {item:ip}{newline}
    {else if:item:type=="range"}
    nat source-nat {nat_name} dst-address address-object {item:start}-{item:end}{newline}
    {else}
    nat source-nat {nat_name} dst-address address-object {item:cidr}{newline}
    {endif}
{endfor}
{endif}
{if:exist:has_service_objects=="true"}
{for:item in service_objects}
    nat source-nat {nat_name} service {item}{newline}
{endfor}
{else}
nat source-nat {nat_name} service any{newline}
{endif}
{if:exist:has_easy_ip=="true"}
nat source-nat {nat_name} action use-interface{newline}
{else}
nat source-nat {nat_name} action address-pool {pool_name}{newline}
{endif}
{if:exist:description=="true"}
nat source-nat {nat_name} description {description}{newline}
{endif}
{endif}
`},
		},
	}
}

// AsaTemplatesV2 ASA的V2模板定义
type AsaTemplatesV2 struct {
	ConfigKeys []Entry
}

// GetLayout 获取指定key的layout
func (at *AsaTemplatesV2) GetLayout(key keys.Keys) string {
	var e Entry
	lo.ForEach(at.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})
	return e.Value
}

// NewAsaTemplatesV2 创建ASA的V2模板
func NewAsaTemplatesV2() *AsaTemplatesV2 {
	return &AsaTemplatesV2{
		ConfigKeys: []Entry{
			// 分隔符定义（用于分隔多个对象CLI）
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "!"},

			// 地址对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// ASA格式：object network <name>
			//          host <ip> 或 subnet <ip> <mask> 或 range <start> <end>
			{Key: keys.NewKeyBuilder("AddressObject", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
object network {object_name}{newline}
{if:is_source=="true"}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
{space:2}{if:item:type=="range"}range {item:start} {item:end}
{else if:item:type=="host"}host {item:ip}
{else}subnet {item:ip} {item:mask:dotted}{endif}
{newline}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
{space:2}{if:item:type=="range"}range {item:start} {item:end}
{else if:item:type=="host"}host {item:ip}
{else}subnet {item:ip} {item:mask:dotted}{endif}
{newline}
{endfor}
{endif}
{endif}
`},

			// 地址组Layout（成员引用其他地址对象）
			// ASA格式：object-group network <name>
			//          network-object host <ip> 或 network-object <ip> <mask> 或 network-object object <name> 或 group-object <name>
			{Key: keys.NewKeyBuilder("AddressGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
object-group network {object_name}{newline}
{if:exist:member_objects=="true"}
{for:member in member_objects}
{space:2}network-object object {member}{newline}
{endfor}
{endif}
{endif}
`},

			// 服务对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// ASA格式：object service <name>
			//          service tcp destination eq <port> 或 service udp destination eq <port> 或 service icmp <type> <code>
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{set:service.range_format=" "}
{if:exist:object_name=="true"}
object service {object_name}{newline}
{for:item in intent.service.EachDetailed}
{space:2}service {item:protocol:lower}
{if:item:protocol=="TCP"}
{if:item:src_port=="0-65535"}
{else}{space:1}source range {item:src_port:range}{endif}
{if:item:dst_port:count==1}{space:1}destination eq {item:dst_port:compact}
{else}{space:1}destination range {item:dst_port:range}{endif}
{else if:item:protocol=="UDP"}
{if:item:src_port=="0-65535"}
{else}{space:1}source range {item:src_port:range}{endif}
{if:item:dst_port:count==1}{space:1}destination eq {item:dst_port:compact}
{else}{space:1}destination range {item:dst_port:range}{endif}
{else if:item:protocol=="ICMP"}
{if:item:hasType=="true"}{space:1}{item:type} {item:code}
{endif}
{endif}
{newline}
{endfor}
{endif}
`},

			// 服务组Layout（成员引用其他服务对象）
			// ASA格式：object-group service <name> [tcp|udp]
			//          port-object eq <port> 或 port-object range <start> <end> 或 service-object object <name> 或 group-object <name>
			{Key: keys.NewKeyBuilder("ServiceGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
object-group service {object_name}{newline}
{if:exist:member_objects=="true"}
{for:member in member_objects}
{space:2}service-object object {member}{newline}
{endfor}
{endif}
{endif}
`},

			// VIP Layout - ASA不支持VIP，只有MIP
			{Key: keys.NewKeyBuilder("VIP", "OneLoop"), Value: `
`},

			// MIP Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}直接从intent获取，不需要从meta获取
			// ASA格式：object network <name> + nat (<real_ifc>,<mapped_ifc>) static <mapped_ip> <real_ip>
			// 注意：ASA中MIP通过object network + nat配置实现，无端口映射（与VIP的区别）
			{Key: keys.NewKeyBuilder("MIP", "OneLoop"), Value: `
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
{if:is_reused!="true"}
object network {object_name}{newline}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
{if:exist:fromPort=="true"}{if:exist:toPort=="true"}
  nat ({fromPort},{toPort}) static {item:ip} {real_ip}
{else}
  nat ({fromPort},any) static {item:ip} {real_ip}
{endif}{else}{if:exist:toPort=="true"}
  nat (any,{toPort}) static {item:ip} {real_ip}
{else}
  nat (any,any) static {item:ip} {real_ip}
{endif}{endif}
{endfor}
{newline}
{endif}
{endif}
`},

			// SNAT_POOL Layout（独立POOL，使用dsl.IntentFormat）
			// 注意：{snat}直接从intent获取，不需要从meta获取
			// ASA格式：object-group network <name> 或 object network <name>
			{Key: keys.NewKeyBuilder("SnatPool", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{if:exist:pool_name=="true"}
{if:is_reused!="true"}
object-group network {pool_name}{newline}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
    {if:item:type=="range"} network-object range {item:start} {item:end}
    {else if:item:type=="host"} network-object host {item:ip}
    {else} network-object {item:ip} {item:mask:dotted}{endif}
    {newline}
{endfor}
{endif}
{endif}
`},

			// SNAT_POOL Layout（使用interface）- ASA不支持interface模式，只支持object格式的POOL
			{Key: keys.NewKeyBuilder("SnatPool", "Interface"), Value: `
`},

			// SNAT_POOL Layout（使用指定IP，inline地址形式）- ASA不支持inline模式，只支持object格式的POOL
			{Key: keys.NewKeyBuilder("SnatPool", "Inline"), Value: `
`},

			// 安全策略Layout（使用dsl.IntentFormat）
			// ASA格式：access-list <name> extended <action> <protocol> <src> <dst> [port]
			// ASA使用ACL作为策略，支持对象组引用
			// 格式1：access-list NAME extended permit|deny PROTOCOL SRC DST [PORT]
			// 格式2：access-list NAME extended permit|deny object-group SERVICE_GROUP SRC DST
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
{for:item in intent}
    access-list {policy_name} extended {action} {if:exist:has_service_objects=="true"}
        {for:svc_obj in service_objects}
            object-group {svc_obj}
            {break}
        {endfor}
    {else}
        {item:service:protocol:lower}
    {endif} 
    {if:exist:has_source_objects=="true"}
        {for:src_obj in src_objects}
            object-group {src_obj}
            {break}
        {endfor}
    {else}
        {if:item:src:isFull=="true"} any
        {else if:item:src:isHost=="true"} host {item:src:ip}
        {else if:item:src:isRange=="true"} range {item:src:start} {item:src:end}
        {else} {item:src:ip} {item:src:mask:dotted}{endif}
    {endif}
    {if:exist:has_service_objects=="false"}
        {if:item:service:protocol=="TCP"}
            {if:item:service:src_port:isFull=="false"}
                {if:item:service:src_port:count==1} eq {item:service:src_port:compact}
                {else} range {item:service:src_port:start} {item:service:src_port:end}{endif}
            {endif}
        {else if:item:service:protocol=="UDP"}
            {if:item:service:src_port:isFull=="false"}
                {if:item:service:src_port:count==1} eq {item:service:src_port:compact}
                {else} range {item:service:src_port:start} {item:service:src_port:end}{endif}
            {endif}
        {endif}
    {endif}
    {if:exist:has_destination_objects=="true"}
        {for:dst_obj in dst_objects}
            object-group {dst_obj}
            {break}
        {endfor}
    {else}
        {if:item:dst:isFull=="true"} any
        {else if:item:dst:isHost=="true"} host {item:dst:ip}
        {else if:item:dst:isRange=="true"} range {item:dst:start} {item:dst:end}
        {else} {item:dst:ip} {item:dst:mask:dotted}{endif}
    {endif}
    {if:exist:has_service_objects=="false"}
        {if:item:service:protocol=="TCP"}
            {if:item:service:dst_port:isFull=="false"}
                {if:item:service:dst_port:count==1} eq {item:service:dst_port:compact}
                {else} range {item:service:dst_port:start} {item:service:dst_port:end}{endif}
            {endif}
        {else if:item:service:protocol=="UDP"}
            {if:item:service:dst_port:isFull=="false"}
                {if:item:service:dst_port:count==1} eq {item:service:dst_port:compact}
                {else} range {item:service:dst_port:start} {item:service:dst_port:end}{endif}
            {endif}
        {else if:item:service:protocol=="ICMP"}
            {if:item:service:hasType=="true"} icmp-type {item:service:type}
                {if:item:service:hasCode=="true"} icmp-code {item:service:code}{endif}
            {endif}
        {endif}
    {endif}
    {newline}
{endfor}
`},

			// Object NAT Layout（使用dsl.IntentFormat）
			// ASA格式：object network <object_name> 已由 MakeAddressObjectV2 生成
			//          nat (<real_ifc>,<mapped_ifc>) <static|dynamic> <mapped> [service <protocol> <real_port> <mapped_port>]
			// 注意：
			// 1. Object NAT 的 layout 只需要生成 nat 行（带缩进），object 定义部分由 MakeAddressObjectV2 生成
			// 2. DNAT Static: object_name = real_ip_object, mapped = dst_network 或 dst_object
			// 3. SNAT Static: object_name = src_object, mapped = mapped_ip|mapped_object|interface
			// 4. SNAT Dynamic: object_name = src_object, mapped = pool_id|interface
			{Key: keys.NewKeyBuilder("NatPolicy", "ObjectNat"), Value: `
{set:intent.dst_template="{ip}"}
{if:nat_type=="DNAT"}
  {if:exist:has_fromPort=="true"}{if:exist:has_toPort=="true"}
    {if:exist:has_real_ip_object=="true"}
      {for:item in intent.service.EachDetailed}
        {for:dst_item in intent.dst.EachDataRangeEntryAsAbbrNet}
 nat ({fromPort},{toPort}) static {if:exist:has_destination_objects=="true"}{dst_objects[0]}{else}{dst_item:ip}{endif}{if:exist:has_service_objects=="true"} service {service_objects[0]} {service_objects[0]}{else}{if:item:protocol=="TCP"} service {item:protocol:lower} {real_port} {item:dst_port:compact}{else if:item:protocol=="UDP"} service {item:protocol:lower} {real_port} {item:dst_port:compact}{endif}{endif}{newline}
        {endfor}
      {endfor}
    {endif}
  {endif}{endif}
{else}
  {if:exist:has_fromPort=="true"}{if:exist:has_toPort=="true"}
    {if:exist:has_source_objects=="true"}
      {if:exist:has_pool_id=="true"}
        {for:src_obj in src_objects}
 nat ({fromPort},{toPort}) dynamic {pool_id}{newline}
        {endfor}
      {else}
        {if:exist:has_interface_name=="true"}
          {for:src_obj in src_objects}
 nat ({fromPort},{toPort}) dynamic interface{newline}
          {endfor}
        {else}
          {if:exist:has_snat=="true"}
            {for:src_obj in src_objects}
              {for:item in intent.service.EachDetailed}
 nat ({fromPort},{toPort}) static {snat}{if:exist:has_service_objects=="true"} service {service_objects[0]} {service_objects[0]}{else}{if:item:protocol=="TCP"} service {item:protocol:lower} {item:src_port:compact} {item:dst_port:compact}{else if:item:protocol=="UDP"} service {item:protocol:lower} {item:src_port:compact} {item:dst_port:compact}{endif}{endif}{newline}
              {endfor}
            {endfor}
          {endif}
        {endif}
      {endif}
    {endif}
  {endif}{endif}
{endif}
`},
			// NAT策略Layout（使用dsl.IntentFormat）- Twice NAT
			// ASA格式：nat (<real_ifc>,<mapped_ifc>) source <type> <real_src> <mapped_src> [destination static <mapped_dest> <real_dest>] [service <real_svc> <mapped_svc>]
			// 注意：
			// 1. ASA的twice NAT不支持inline模式的地址或服务，必须使用object名称（不是object-group）
			// 2. ASA不支持VIP，只支持MIP，destination static的mapped_dest使用mip_name（如果没有destination objects）或dst_obj（如果有destination objects）
			// 3. destination static的real_dest使用real_ip_object（必须通过配置 natpolicy.dnat.real_ip_object_style 创建）
			// 4. 没有源地址对象时，source可以使用any
			// 5. destination static格式：destination static <mapped_dest> <real_dest>，其中mapped_dest是外部地址，real_dest是内部地址
			// 6. 所有地址和服务都使用对象名称，不使用object-group前缀
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{if:nat_type=="DNAT"}
  {if:exist:has_fromPort=="true"}{if:exist:has_toPort=="true"}
    {for:item in intent.service.EachDetailed}
      nat ({fromPort},{toPort}) source static {if:exist:has_source_objects=="true"}{src_objects[0]}{else}any{endif} {if:exist:has_source_objects=="true"}{src_objects[0]}{else}any{endif} destination static {if:exist:has_destination_objects=="true"}{dst_objects[0]}{else}{mip_name}{endif} {if:exist:has_real_ip_object=="true"}{real_ip_object}{endif} {if:exist:has_service_objects=="true"}service {service_objects[0]} {service_objects[0]}{else}{if:item:protocol=="TCP"}service {item:protocol:lower} {item:dst_port:compact} {real_port}{else if:item:protocol=="UDP"}service {item:protocol:lower} {item:dst_port:compact} {real_port}{endif}{endif}{newline}
    {endfor}
  {endif}{endif}
{else}
  {if:exist:has_fromPort=="true"}{if:exist:has_toPort=="true"}
    {if:exist:has_pool_id=="true"}
      {if:exist:has_source_objects=="true"}
        {for:src_obj in src_objects}
          nat ({fromPort},{toPort}) source dynamic {src_obj} pat-pool {pool_id}{newline}
        {endfor}
      {else}
        nat ({fromPort},{toPort}) source dynamic any pat-pool {pool_id}{newline}
      {endif}
    {else}
      {if:exist:has_interface_name=="true"}
        {if:exist:has_source_objects=="true"}
          {for:src_obj in src_objects}
            nat ({fromPort},{toPort}) source dynamic {src_obj} interface{newline}
          {endfor}
        {else}
          nat ({fromPort},{toPort}) source dynamic any interface{newline}
        {endif}
      {else}
        {if:exist:has_snat=="true"}
          {if:exist:has_source_objects=="true"}
            {for:src_obj in src_objects}
              nat ({fromPort},{toPort}) source dynamic {src_obj} {snat}{newline}
            {endfor}
          {else}
            nat ({fromPort},{toPort}) source dynamic any {snat}{newline}
          {endif}
        {endif}
      {endif}
    {endif}
  {endif}{endif}
{endif}
`},
		},
	}
}

// FortiTemplatesV2 FortiGate的V2模板定义
type FortiTemplatesV2 struct {
	ConfigKeys []Entry
}

// GetLayout 获取指定key的layout
func (ft *FortiTemplatesV2) GetLayout(key keys.Keys) string {
	var e Entry
	lo.ForEach(ft.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})
	return e.Value
}

// NewFortiTemplatesV2 创建FortiGate的V2模板
func NewFortiTemplatesV2() *FortiTemplatesV2 {
	return &FortiTemplatesV2{
		ConfigKeys: []Entry{
			// 分隔符定义（用于分隔多个对象CLI）
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "#"},

			// 地址对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// FortiGate格式：config firewall address
			//                edit "{name}"
			//                    set subnet {ip} {mask} 或 set type iprange set start-ip {start} set end-ip {end}
			{Key: keys.NewKeyBuilder("AddressObject", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
config firewall address{newline}
    edit "{object_name}"{newline}
{if:is_source=="true"}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
        {if:item:type=="range"}set type iprange{newline}
            set start-ip {item:start}{newline}
            set end-ip {item:end}{newline}
        {else if:item:type=="host"}set subnet {item:ip} 255.255.255.255{newline}
        {else}set subnet {item:ip} {item:mask:dotted}{newline}
        {endif}
{endfor}
{else}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
        {if:item:type=="range"}set type iprange{newline}
            set start-ip {item:start}{newline}
            set end-ip {item:end}{newline}
        {else if:item:type=="host"}set subnet {item:ip} 255.255.255.255{newline}
        {else}set subnet {item:ip} {item:mask:dotted}{newline}
        {endif}
{endfor}
{endif}
    next{newline}
end{newline}
{endif}
`},

			// 地址组Layout（成员引用其他地址对象）
			// FortiGate格式：config firewall addrgrp
			//                edit "{name}"
			//                    set member "{member1}" "{member2}" ...
			{Key: keys.NewKeyBuilder("AddressGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
config firewall addrgrp{newline}
    edit "{object_name}"{newline}
{if:exist:member_objects=="true"}
        set member {for:member in member_objects}"{member}" {endfor}{newline}
{endif}
    next{newline}
end{newline}
{endif}
`},

			// 服务对象Layout（使用dsl.IntentFormat，根据intent_capabilities.md优化）
			// FortiGate格式：config firewall service custom
			//                edit "{name}"
			//                    set tcp-portrange {port} 或 set udp-portrange {port} 或 set protocol-number {num}
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{set:service.range_format=" "}
{if:exist:object_name=="true"}
config firewall service custom{newline}
    edit "{object_name}"{newline}
{for:item in intent.service.EachDetailed}
        {if:item:protocol=="TCP"}set tcp-portrange {item:dst_port:range}{newline}
        {else if:item:protocol=="UDP"}set udp-portrange {item:dst_port:range}{newline}
        {else if:item:protocol=="ICMP"}
            {if:item:hasType=="true"}set icmptype {item:type}{newline}
                {if:item:hasCode=="true"}set icmpcode {item:code}{newline}
                {endif}
            {endif}
        {else}set protocol-number {item:protocol:number}{newline}
        {endif}
{endfor}
    next{newline}
end{newline}
{endif}
`},

			// 服务组Layout（成员引用其他服务对象）
			// FortiGate格式：config firewall service group
			//                edit "{name}"
			//                    set member "{member1}" "{member2}" ...
			{Key: keys.NewKeyBuilder("ServiceGroup", "OneLoop"), Value: `
{if:exist:object_name=="true"}
config firewall service group{newline}
    edit "{object_name}"{newline}
{if:exist:member_objects=="true"}
        set member {for:member in member_objects}"{member}" {endfor}{newline}
{endif}
    next{newline}
end{newline}
{endif}
`},

			// VIP Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}和{real_port}直接从intent获取，不需要从meta获取
			// FortiGate格式：config firewall vip
			//                edit "{name}"
			//                    set extip {extip_range}
			//                    set mappedip "{real_ip}"
			//                    set extintf "{interface}"
			//                    set portforward enable
			//                    set extport {port}
			//                    set mappedport {real_port}
			{Key: keys.NewKeyBuilder("VIP", "OneLoop"), Value: `
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
{if:is_reused!="true"}
config firewall vip{newline}
    edit "{object_name}"{newline}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
        {if:item:type=="range"}set extip {item:start}-{item:end}{newline}
        {else}set extip {item:ip}{newline}
        {endif}
{endfor}
        set mappedip "{real_ip}"{newline}
{if:exist:toPort=="true"}        set extintf "{toPort}"{newline}{endif}
{if:exist:has_real_port=="true"}        set portforward enable{newline}
        set extport {dst_port:compact}{newline}
        set mappedport {real_port}{newline}
{else}        set portforward disable{newline}
{endif}
    next{newline}
end{newline}
{endif}
{endif}
`},

			// MIP Layout（使用dsl.IntentFormat）
			// 注意：{real_ip}直接从intent获取，不需要从meta获取
			// FortiGate格式：config firewall vip
			//                edit "{name}"
			//                    set extip {extip}
			//                    set mappedip "{real_ip}"
			//                    set portforward disable
			{Key: keys.NewKeyBuilder("MIP", "OneLoop"), Value: `
{set:intent.dst_template="{ip}"}
{if:exist:object_name=="true"}
{if:is_reused!="true"}
config firewall vip{newline}
    edit "{object_name}"{newline}
{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
        set extip {item:ip}{newline}
{endfor}
        set mappedip "{real_ip}"{newline}
        set portforward disable{newline}
    next{newline}
end{newline}
{endif}
{endif}
`},

			// SNAT_POOL Layout（独立POOL，使用dsl.IntentFormat）
			// 注意：{snat}直接从intent获取，不需要从meta获取
			// FortiGate格式：config firewall ippool
			//                edit "{name}"
			//                    set type overload
			//                    set startip {start}
			//                    set endip {end}
			{Key: keys.NewKeyBuilder("SnatPool", "OneLoop"), Value: `
{set:intent.src_template="{ip}"}
{if:exist:pool_name=="true"}
{if:is_reused!="true"}
config firewall ippool{newline}
    edit "{pool_name}"{newline}
        set type overload{newline}
{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
        {if:item:type=="range"}set startip {item:start}{newline}
            set endip {item:end}{newline}
        {else if:item:type=="host"}set startip {item:ip}{newline}
            set endip {item:ip}{newline}
        {else}set startip {item:ip}{newline}
            set endip {item:ip}{newline}
        {endif}
{endfor}
    next{newline}
end{newline}
{endif}
{endif}
`},

			// SNAT_POOL Layout（使用interface）
			// FortiGate不支持interface模式的SNAT，使用ippool
			{Key: keys.NewKeyBuilder("SnatPool", "Interface"), Value: `
{comment:FortiGate不支持interface模式的SNAT，应使用ippool}
`},

			// SNAT_POOL Layout（使用指定IP，inline地址形式）
			// FortiGate不支持inline模式的SNAT，使用ippool
			{Key: keys.NewKeyBuilder("SnatPool", "Inline"), Value: `
{comment:FortiGate不支持inline模式的SNAT，应使用ippool}
`},

			// 安全策略Layout（使用dsl.IntentFormat）
			// FortiGate格式：config firewall policy
			//                edit {policy_id}
			//                    set name "{name}"
			//                    set srcintf "{fromPort}"
			//                    set dstintf "{toPort}"
			//                    set srcaddr "{obj1}" "{obj2}" ... 或 "all"
			//                    set dstaddr "{obj1}" "{obj2}" ... 或 "all"
			//                    set service "{obj1}" "{obj2}" ... 或 "ALL"
			//                    set action {action} (accept表示允许，deny表示拒绝)
			//                    set schedule "always"
			//                    set status enable
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
config firewall policy{newline}
    edit {policy_id}{newline}
        set name "{policy_name}"{newline}
{if:exist:description=="true"}        set comments "{description}"{newline}{endif}
{if:exist:fromPort=="true"}        set srcintf "{fromPort}"{newline}{endif}
{if:exist:toPort=="true"}        set dstintf "{toPort}"{newline}{endif}
{if:exist:has_source_objects=="true"}
        set srcaddr {for:item in src_objects}"{item}" {endfor}{newline}
{else}
        set srcaddr "all"{newline}
{endif}
{if:exist:has_destination_objects=="true"}
        set dstaddr {for:item in dst_objects}"{item}" {endfor}{newline}
{else}
        set dstaddr "all"{newline}
{endif}
{if:exist:has_service_objects=="true"}
        set service {for:item in service_objects}"{item}" {endfor}{newline}
{else}
        set service "ALL"{newline}
{endif}
        set action {action}{newline}
        set schedule "always"{newline}
        set status enable{newline}
    next{newline}
end{newline}
`},

			// NAT策略Layout（使用dsl.IntentFormat）
			// FortiGate格式：config firewall policy
			//                edit {policy_id}
			//                    set name "{name}"
			//                    set srcintf "{fromPort}"
			//                    set dstintf "{toPort}"
			//                    set srcaddr "{obj1}" "{obj2}" ... 或 "all"
			//                    set dstaddr "{obj1}" "{obj2}" ... 或 "all"
			//                    set service "{obj1}" "{obj2}" ... 或 "ALL"
			//                    set action {action} (accept表示允许，deny表示拒绝)
			//                    set nat enable
			//                    set ippool enable (如果使用SNAT pool)
			//                    set poolname "{pool_name}" (如果使用SNAT pool)
			//                    set schedule "always"
			//                    set status enable
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{set:service.range_format=" "}
config firewall policy{newline}
    edit {policy_id}{newline}
        set name "{policy_name}"{newline}
{if:exist:description=="true"}        set comments "{description}"{newline}{endif}
{if:exist:fromPort=="true"}        set srcintf "{fromPort}"{newline}{endif}
{if:exist:toPort=="true"}        set dstintf "{toPort}"{newline}{endif}
{if:exist:has_source_objects=="true"}
        set srcaddr {for:item in src_objects}"{item}" {endfor}{newline}
{else}
        set srcaddr "all"{newline}
{endif}
{if:exist:has_destination_objects=="true"}
        set dstaddr {for:item in dst_objects}"{item}" {endfor}{newline}
{else}
        set dstaddr "all"{newline}
{endif}
{if:exist:has_service_objects=="true"}
        set service {for:item in service_objects}"{item}" {endfor}{newline}
{else}
        set service "ALL"{newline}
{endif}
        set action {action}{newline}
{if:exist:has_real_ip=="true"}
        set nat enable{newline}
{else}
{if:exist:use_pool=="true"}
        set nat enable{newline}
        set ippool enable{newline}
        set poolname "{pool_name}"{newline}
{else}
        set nat disable{newline}
{endif}
{endif}
        set schedule "always"{newline}
        set status enable{newline}
    next{newline}
end{newline}
`},
		},
	}
}

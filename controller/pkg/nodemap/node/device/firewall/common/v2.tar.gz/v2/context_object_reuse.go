package v2

import (
	"fmt"
	"strings"

	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	"github.com/netxops/utils/network"
	"github.com/netxops/utils/service"
)

// ContextObjectInfo 存储在 context 中的对象信息
type ContextObjectInfo struct {
	ObjectName string                // 对象名称
	CLIString  string                // 生成的CLI
	Keys       []string              // 对象键列表
	IsGroup    bool                  // 是否是组对象
	Network    *network.NetworkGroup // 网络组（用于地址对象匹配）
	Service    *service.Service      // 服务（用于服务对象匹配）
	NodeName   string                // 防火墙节点名称（用于确保只复用同一节点的对象）
}

// getNetworkGroupKey 生成 NetworkGroup 的 context key（包含节点名称）
func getNetworkGroupKey(nodeName string, ng *network.NetworkGroup) string {
	if ng == nil {
		return ""
	}
	if nodeName == "" {
		return fmt.Sprintf("network:%s", ng.String())
	}
	return fmt.Sprintf("%s:network:%s", nodeName, ng.String())
}

// getServiceKey 生成 Service 的 context key（包含节点名称）
func getServiceKey(nodeName string, svc *service.Service) string {
	if svc == nil {
		return ""
	}
	if nodeName == "" {
		return fmt.Sprintf("service:%s", svc.String())
	}
	return fmt.Sprintf("%s:service:%s", nodeName, svc.String())
}

// getNodeName 从 PolicyContext 获取防火墙节点名称
func getNodeName(ctx *firewall.PolicyContext) string {
	if ctx == nil || ctx.Node == nil {
		return ""
	}
	// 通过类型断言获取节点名称
	if node, ok := ctx.Node.(interface{ Name() string }); ok {
		return node.Name()
	}
	return ""
}

// getOrCreateContextObjects 获取或创建 context 中的 GeneratedObjects map
func getOrCreateContextObjects(ctx *firewall.PolicyContext) map[string]interface{} {
	if ctx.GeneratedObjects == nil {
		ctx.GeneratedObjects = make(map[string]interface{})
	}
	return ctx.GeneratedObjects
}

// findReusedAddressObject 在 context 中查找可复用的地址对象
// 只查找同一防火墙节点生成的对象
// 返回复用的对象信息，如果未找到则返回 nil
func findReusedAddressObject(ctx *firewall.PolicyContext, ng *network.NetworkGroup) *ContextObjectInfo {
	if ctx == nil || ng == nil {
		return nil
	}

	// 获取当前节点的名称
	currentNodeName := getNodeName(ctx)
	if currentNodeName == "" {
		// 如果无法获取节点名称，不进行复用（安全起见）
		return nil
	}

	objects := getOrCreateContextObjects(ctx)

	// 生成当前节点的 key 前缀
	expectedKeyPrefix := fmt.Sprintf("%s:network:", currentNodeName)

	// 遍历 context 中已生成的所有网络对象，查找匹配的 NetworkGroup
	for key, value := range objects {
		// 只检查当前节点的对象（key 必须以 "节点名:network:" 开头）
		if !strings.HasPrefix(key, expectedKeyPrefix) {
			continue
		}

		// 从存储的值中获取 NetworkGroup 对象
		var storedNG *network.NetworkGroup
		var storedNodeName string
		if objInfo, ok := value.(*ContextObjectInfo); ok {
			// ContextObjectInfo 包含 NetworkGroup 对象和节点名称
			storedNG = objInfo.Network
			storedNodeName = objInfo.NodeName
		} else if objMap, ok := value.(map[string]interface{}); ok {
			// 兼容旧格式：尝试从 map 中获取 NetworkGroup 对象
			if ngObj, ok := objMap["network"].(*network.NetworkGroup); ok {
				storedNG = ngObj
			}
			if nodeName, ok := objMap["nodeName"].(string); ok {
				storedNodeName = nodeName
			}
		}

		// 确保节点名称匹配
		if storedNodeName != "" && storedNodeName != currentNodeName {
			continue
		}

		// 如果没有 NetworkGroup 对象，尝试从 key 解析（作为 fallback）
		if storedNG == nil {
			// 从 key 中提取 network 部分（格式：节点名:network:网络组字符串）
			parts := strings.SplitN(key, ":", 3)
			if len(parts) >= 3 {
				ngStr := parts[2]
				parsedNG, err := network.NewNetworkGroupFromString(ngStr)
				if err != nil {
					continue
				}
				storedNG = parsedNG
			} else {
				// 兼容旧格式（没有节点名前缀）
				ngStr := strings.TrimPrefix(key, "network:")
				parsedNG, err := network.NewNetworkGroupFromString(ngStr)
				if err != nil {
					continue
				}
				storedNG = parsedNG
			}
		}

		// 使用 Same 方法比较 NetworkGroup
		if storedNG != nil && storedNG.Same(ng) {
			// 找到匹配的对象，返回对象信息
			if objInfo, ok := value.(*ContextObjectInfo); ok {
				// 确保节点名称匹配
				if objInfo.NodeName == "" || objInfo.NodeName == currentNodeName {
					return objInfo
				}
			}
			// 兼容旧格式（map[string]interface{}）
			if objMap, ok := value.(map[string]interface{}); ok {
				objInfo := &ContextObjectInfo{}
				if name, ok := objMap["objectName"].(string); ok {
					objInfo.ObjectName = name
				}
				if cli, ok := objMap["cliString"].(string); ok {
					objInfo.CLIString = cli
				}
				if keys, ok := objMap["keys"].([]string); ok {
					objInfo.Keys = keys
				}
				if isGroup, ok := objMap["isGroup"].(bool); ok {
					objInfo.IsGroup = isGroup
				}
				if ngObj, ok := objMap["network"].(*network.NetworkGroup); ok {
					objInfo.Network = ngObj
				}
				if nodeName, ok := objMap["nodeName"].(string); ok {
					objInfo.NodeName = nodeName
				}
				// 确保节点名称匹配
				if objInfo.NodeName == "" || objInfo.NodeName == currentNodeName {
					return objInfo
				}
			}
		}
	}

	return nil
}

// findReusedServiceObject 在 context 中查找可复用的服务对象
// 只查找同一防火墙节点生成的对象
// 返回复用的对象信息，如果未找到则返回 nil
func findReusedServiceObject(ctx *firewall.PolicyContext, svc *service.Service) *ContextObjectInfo {
	if ctx == nil || svc == nil {
		return nil
	}

	// 获取当前节点的名称
	currentNodeName := getNodeName(ctx)
	if currentNodeName == "" {
		// 如果无法获取节点名称，不进行复用（安全起见）
		return nil
	}

	objects := getOrCreateContextObjects(ctx)

	// 生成当前节点的 key 前缀
	expectedKeyPrefix := fmt.Sprintf("%s:service:", currentNodeName)

	// 遍历 context 中已生成的所有服务对象，查找匹配的 Service
	for key, value := range objects {
		// 只检查当前节点的对象（key 必须以 "节点名:service:" 开头）
		if !strings.HasPrefix(key, expectedKeyPrefix) {
			continue
		}

		// 从存储的值中获取 Service 对象
		var storedSvc *service.Service
		var storedNodeName string
		if objInfo, ok := value.(*ContextObjectInfo); ok {
			// ContextObjectInfo 包含 Service 对象和节点名称
			storedSvc = objInfo.Service
			storedNodeName = objInfo.NodeName
		} else if objMap, ok := value.(map[string]interface{}); ok {
			// 兼容旧格式：尝试从 map 中获取 Service 对象
			if svcObj, ok := objMap["service"].(*service.Service); ok {
				storedSvc = svcObj
			}
			if nodeName, ok := objMap["nodeName"].(string); ok {
				storedNodeName = nodeName
			}
		}

		// 确保节点名称匹配
		if storedNodeName != "" && storedNodeName != currentNodeName {
			continue
		}

		// 如果没有 Service 对象，跳过
		if storedSvc == nil {
			continue
		}

		// 使用 Same 方法比较 Service
		if storedSvc.Same(svc) {
			// 找到匹配的对象，返回对象信息
			if objInfo, ok := value.(*ContextObjectInfo); ok {
				// 确保节点名称匹配
				if objInfo.NodeName == "" || objInfo.NodeName == currentNodeName {
					return objInfo
				}
			}
			// 兼容旧格式（map[string]interface{}）
			if objMap, ok := value.(map[string]interface{}); ok {
				objInfo := &ContextObjectInfo{}
				if name, ok := objMap["objectName"].(string); ok {
					objInfo.ObjectName = name
				}
				if cli, ok := objMap["cliString"].(string); ok {
					objInfo.CLIString = cli
				}
				if keys, ok := objMap["keys"].([]string); ok {
					objInfo.Keys = keys
				}
				if isGroup, ok := objMap["isGroup"].(bool); ok {
					objInfo.IsGroup = isGroup
				}
				if svcObj, ok := objMap["service"].(*service.Service); ok {
					objInfo.Service = svcObj
				}
				if nodeName, ok := objMap["nodeName"].(string); ok {
					objInfo.NodeName = nodeName
				}
				// 确保节点名称匹配
				if objInfo.NodeName == "" || objInfo.NodeName == currentNodeName {
					return objInfo
				}
			}
		}
	}

	return nil
}

// storeAddressObjectInContext 将地址对象信息存储到 context 中
// 存储时会包含防火墙节点名称，确保只复用同一节点的对象
func storeAddressObjectInContext(ctx *firewall.PolicyContext, ng *network.NetworkGroup, objInfo *ContextObjectInfo) {
	if ctx == nil || ng == nil || objInfo == nil {
		return
	}

	// 获取当前节点的名称并存储到 objInfo 中
	nodeName := getNodeName(ctx)
	if nodeName != "" {
		objInfo.NodeName = nodeName
	}

	objects := getOrCreateContextObjects(ctx)
	key := getNetworkGroupKey(nodeName, ng)
	objects[key] = objInfo
}

// storeServiceObjectInContext 将服务对象信息存储到 context 中
// 存储时会包含防火墙节点名称，确保只复用同一节点的对象
func storeServiceObjectInContext(ctx *firewall.PolicyContext, svc *service.Service, objInfo *ContextObjectInfo) {
	if ctx == nil || svc == nil || objInfo == nil {
		return
	}

	// 获取当前节点的名称并存储到 objInfo 中
	nodeName := getNodeName(ctx)
	if nodeName != "" {
		objInfo.NodeName = nodeName
	}

	objects := getOrCreateContextObjects(ctx)
	key := getServiceKey(nodeName, svc)
	objects[key] = objInfo
}

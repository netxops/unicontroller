# VIP/MIP/SNAT_POOL机制梳理

## 1. 基本概念

### 1.1 VIP和MIP是同一种对象类型

- **本质**：VIP和MIP都是DNAT映射对象，属于同一种对象类型
- **区别**：仅在于是否有端口转换（`real_port`）
  - **VIP (Virtual IP)**: 有`real_port`，带端口转换
  - **MIP (Mapped IP)**: 无`real_port`，不带端口转换
- **判断标准**: 仅通过 `intent.RealPort != ""` 判断（有real_port=VIP，无real_port=MIP）
- **对象管理**：VIP和MIP对象可以统一管理，复用逻辑相同

### 1.2 两种处理方式

#### 1.2.1 有特殊语法
- **定义**：防火墙有专门的VIP/MIP/SNAT_POOL命令格式，需要使用对应的layout渲染
- **特点**：
  - 使用 `Vip layout`、`Mip layout`、`SnatPool layout` 生成CLI
  - 有专门的对象类型和命名规则
  - 可以通过 `GetObjectByVipMipSnatPool` 检查对象复用
- **示例**：FortiGate的VIP/MIP使用 `config firewall vip`，SNAT_POOL使用 `config firewall ippool`

#### 1.2.2 复用object（没有特殊语法）
- **定义**：防火墙没有特殊语法，直接复用已存在的地址对象
- **特点**：
  - 通过 `GetObjectByNetworkGroup` 查找已存在的地址对象
  - 如果找到：直接使用对象名称，不生成新对象
  - 如果未找到：生成新的地址对象（使用 `MakeAddressObjectV2`）
- **示例**：Sangfor的MIP需要复用地址对象，USG的MIP需要复用address-group

### 1.3 SNAT_POOL

- **定义**：SNAT地址池，用于源地址转换
- **类型判断**：通过 `snat_pool_type` 配置判断
  - `"ADDRESS_OBJECT"`: 复用object模式（没有特殊语法）
  - `"POOL"`: 特殊语法模式（使用SnatPool layout）
  - `"INTERFACE"`: 接口模式（在NAT Policy中处理，不生成对象）
  - `"INLINE"`: 内联模式（在NAT Policy中处理，不生成对象）

## 2. VIP/MIP/SNAT_POOL统一处理流程

```
1. 判断类型
   - VIP/MIP：通过real_port判断（有real_port=VIP，无real_port=MIP）
   - SNAT_POOL：通过snat_pool_type判断

2. 检查是否需要使用网络对象
   - 调用Node提供的接口返回是否需要使用网络对象
   - 接口：Node.ShouldUseNetworkObjectForNat(objectType) -> bool
   - 例如：Sangfor的MIP需要使用网络对象，USG的MIP需要复用address-group

3. 如果复用object（没有特殊语法）：
   - 通过GetObjectByNetworkGroup查找
   - 找到：直接使用对象名称，结束
   - 未找到：生成新的Object（使用MakeAddressObjectV2）

4. 有特殊语法：
   - 选择对应的layout（Vip/Mip/SnatPool）
   - 优先检查VIP/MIP/SNAT_POOL的复用（Node提供接口）
     - 接口：Node.GetObjectByVipMipSnatPool(objectType, intent) -> (object, bool)
   - 对象命名：
     - 如果Node提供自动命名：使用Node的命名接口
     - 如果Node不提供：使用配置的命名模板（vip_name_template/mip_name_template/snat_pool_name_template）
   - 如果未复用：渲染对应的layout（Vip/Mip/SnatPool）生成CLI

5. 通过NatPolicy layout进行渲染
   - 使用准备好的对象名称（VIP/MIP/SNAT_POOL对象名称或复用的地址对象名称）
   - 渲染NatPolicy layout生成最终的NAT策略CLI
```

## 3. Node接口设计

### 3.1 ShouldUseNetworkObjectForNat

- **接口签名**: `ShouldUseNetworkObjectForNat(objectType string) bool`
- **功能**: 判断是否需要使用网络对象（地址对象）
- **参数**:
  - `objectType`: "VIP", "MIP", "SNAT_POOL"
- **返回**: true表示需要使用网络对象，false表示使用特殊语法
- **示例**:
  - Sangfor的MIP: `ShouldUseNetworkObjectForNat("MIP")` -> true
  - USG的MIP: `ShouldUseNetworkObjectForNat("MIP")` -> true
  - FortiGate的VIP: `ShouldUseNetworkObjectForNat("VIP")` -> false

### 3.2 GetObjectByVipMipSnatPool

- **接口签名**: `GetObjectByVipMipSnatPool(objectType string, intent *policy.Intent) (firewall.FirewallObject, bool)`
- **功能**: 检查VIP/MIP/SNAT_POOL对象是否已存在（复用检查）
- **参数**:
  - `objectType`: "VIP", "MIP", "SNAT_POOL"
  - `intent`: 包含real_ip、real_port等信息
- **返回**: (对象, 是否找到)
- **示例**: 检查是否已存在相同real_ip和real_port的VIP对象

### 3.3 GenerateVipMipSnatPoolName（可选）

- **接口签名**: `GenerateVipMipSnatPoolName(objectType string, intent *policy.Intent, metaData map[string]interface{}) string`
- **功能**: 自动生成VIP/MIP/SNAT_POOL对象名称
- **参数**:
  - `objectType`: "VIP", "MIP", "SNAT_POOL"
  - `intent`: 包含real_ip、real_port等信息
  - `metaData`: 包含policy_name等元数据
- **返回**: 生成的对象名称
- **说明**: 如果Node不提供此接口，则使用配置的命名模板

## 4. SNAT_POOL处理流程

### 4.1 SNAT_POOL类型判断

- **ADDRESS_OBJECT类型**（使用网络对象模式）:
  - `snat_pool_type = "ADDRESS_OBJECT"`
  - 通过 `ShouldUseNetworkObjectForNat("SNAT_POOL")` 判断是否需要使用网络对象
  - 如果为true：通过 `GetObjectByNetworkGroup` 查找或生成地址对象
  - 不生成SNAT_POOL layout

- **POOL类型**（特殊语法模式）:
  - `snat_pool_type = "POOL"`
  - 使用 `SnatPool layout` 渲染
  - 通过 `GetObjectByVipMipSnatPool("SNAT_POOL", intent)` 检查对象复用
  - 如果未复用：渲染SnatPool layout生成CLI

- **INTERFACE/INLINE类型**:
  - 在NAT Policy中处理，不生成对象
  - 直接在NatPolicy layout中使用接口或内联地址

### 4.2 SNAT_POOL复用逻辑

1. **地址对象复用**（ADDRESS_OBJECT类型）:
   - 触发条件：`ShouldUseNetworkObjectForNat("SNAT_POOL")` 返回 true
   - 查找方式：`GetObjectByNetworkGroup(snatPoolNg, SEARCH_OBJECT_OR_GROUP)`
   - 匹配标准：网络地址完全匹配
   - 结果：如果找到，直接使用对象名称，不生成新对象

2. **SNAT_POOL对象复用**（POOL类型）:
   - 触发条件：`snat_pool_type = "POOL"` 且 `ShouldUseNetworkObjectForNat("SNAT_POOL")` 返回 false
   - 查找方式：`GetObjectByVipMipSnatPool("SNAT_POOL", intent)`
   - 匹配标准：对象属性匹配（地址池范围等）
   - 结果：如果找到，复用对象名称，不生成CLI

## 5. 各防火墙VIP/MIP/SNAT_POOL支持情况

### 5.1 SecPath

- **VIP/MIP**: 不支持（VIP和MIP是同一种对象类型，但SecPath不支持）
- **SNAT_POOL**: 支持，使用address-group
- **特点**: 只支持SNAT_POOL，使用address-group格式
- **Node接口实现**:
  - `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> true（复用address-group）
  - `ShouldUseNetworkObjectForNat("VIP")` -> false（不支持）
  - `ShouldUseNetworkObjectForNat("MIP")` -> false（不支持）

### 5.2 Sangfor

- **VIP/MIP**: 不支持（VIP和MIP是同一种对象类型，但Sangfor不支持）
- **SNAT_POOL**: 不支持
- **特点**: 不支持VIP/MIP/SNAT_POOL对象，所有NAT配置都在NAT策略中直接使用地址/服务对象
- **Node接口实现**:
  - `ShouldUseNetworkObjectForNat(DNAT, "MIP")` -> true（MIP需要复用地址对象）
  - `ShouldUseNetworkObjectForNat(DNAT, "VIP")` -> false（不支持）
  - `ShouldUseNetworkObjectForNat(SNAT, "SNAT_POOL")` -> false（不支持）

### 5.3 USG

- **VIP/MIP**: 支持MIP，使用destination-nat address-group
- **SNAT_POOL**: 支持，使用address-group
- **特点**: 支持MIP（通过destination-nat address-group）和SNAT_POOL（address-group），不支持VIP对象
- **Node接口实现**:
  - `ShouldUseNetworkObjectForNat("MIP")` -> true（复用address-group）
  - `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> true（复用address-group）
  - `ShouldUseNetworkObjectForNat("VIP")` -> false（不支持）

### 5.4 SRX

- **VIP/MIP**: 支持VIP，使用destination pool
- **DNAT**: 支持，使用pool
- **SNAT_POOL**: 支持，使用pool
- **特点**: 支持VIP（destination pool）、DNAT pool和SNAT_POOL pool
- **Node接口实现**:
  - `ShouldUseNetworkObjectForNat("VIP")` -> false（使用特殊语法pool）
  - `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> false（使用特殊语法pool）
  - `GetObjectByVipMipSnatPool`: 检查pool对象复用

### 5.5 ASA

- **VIP/MIP**: 支持，使用network object
- **SNAT_POOL**: 支持，使用network object
- **特点**: VIP/MIP/SNAT_POOL都使用network object，NAT配置在object network中直接定义
- **Node接口实现**:
  - `ShouldUseNetworkObjectForNat("VIP")` -> true（使用network object）
  - `ShouldUseNetworkObjectForNat("MIP")` -> true（使用network object）
  - `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> true（使用network object）

### 5.6 DPTech

- **VIP/MIP**: 支持MIP，使用address-pool
- **SNAT_POOL**: 支持，使用address-pool
- **特点**: 支持MIP和SNAT_POOL，都使用address-pool格式
- **Node接口实现**:
  - `ShouldUseNetworkObjectForNat("MIP")` -> false（使用特殊语法address-pool）
  - `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> false（使用特殊语法address-pool）
  - `GetObjectByVipMipSnatPool`: 检查address-pool对象复用

### 5.7 FortiGate

- **VIP/MIP**: 支持VIP和MIP，都使用`config firewall vip`（通过portforward区分）
- **SNAT_POOL**: 支持，使用`config firewall ippool`
- **特点**: 支持VIP/MIP对象和SNAT_POOL对象，都有特殊语法
- **Node接口实现**:
  - `ShouldUseNetworkObjectForNat("VIP")` -> false（使用特殊语法vip）
  - `ShouldUseNetworkObjectForNat("MIP")` -> false（使用特殊语法vip）
  - `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> false（使用特殊语法ippool）
  - `GetObjectByVipMipSnatPool`: 检查vip/ippool对象复用

## 6. 统一处理流程对比表

| 对象类型 | 判断标准 | 复用object模式 | 特殊语法模式 |
|---------|---------|--------------|------------|
| **VIP** | `real_port != ""` | 1. `ShouldUseNetworkObjectForNat("VIP")` -> true<br>2. `GetObjectByNetworkGroup` 查找<br>3. 找到：使用对象名称<br>4. 未找到：生成地址对象 | 1. `ShouldUseNetworkObjectForNat("VIP")` -> false<br>2. 选择 `Vip layout`<br>3. `GetObjectByVipMipSnatPool("VIP", intent)` 检查复用<br>4. 生成对象名称（Node接口或模板）<br>5. 渲染 `Vip layout` 生成CLI |
| **MIP** | `real_port == ""` | 1. `ShouldUseNetworkObjectForNat("MIP")` -> true<br>2. `GetObjectByNetworkGroup` 查找<br>3. 找到：使用对象名称<br>4. 未找到：生成地址对象 | 1. `ShouldUseNetworkObjectForNat("MIP")` -> false<br>2. 选择 `Mip layout`<br>3. `GetObjectByVipMipSnatPool("MIP", intent)` 检查复用<br>4. 生成对象名称（Node接口或模板）<br>5. 渲染 `Mip layout` 生成CLI |
| **SNAT_POOL** | `snat_pool_type` | 1. `snat_pool_type = "ADDRESS_OBJECT"`<br>2. `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> true<br>3. `GetObjectByNetworkGroup` 查找<br>4. 找到：使用对象名称<br>5. 未找到：生成地址对象 | 1. `snat_pool_type = "POOL"`<br>2. `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> false<br>3. 选择 `SnatPool layout`<br>4. `GetObjectByVipMipSnatPool("SNAT_POOL", intent)` 检查复用<br>5. 生成对象名称（Node接口或模板）<br>6. 渲染 `SnatPool layout` 生成CLI |

## 7. 配置字段

### 7.1 核心配置

- **注意**: `natpolicy.dnat.mip_as_address_object` 配置已废弃，现在通过 Node 接口 `ShouldUseNetworkObjectForNat` 来判断是否需要使用网络对象
- `snat_pool_type`: SNAT_POOL类型（"ADDRESS_OBJECT"=复用object，其他=特殊语法）
- `vip_name_template`: VIP对象命名模板（Node不提供自动命名时使用）
- `mip_name_template`: MIP对象命名模板（Node不提供自动命名时使用）
- `snat_pool_name_template`: SNAT_POOL对象命名模板（Node不提供自动命名时使用）
- `object_name`: 直接指定的对象名称（优先级最高）

### 7.2 模板变量

- `{VAR:policy_name}`: 策略名称
- `{VAR:dst_network}`: 目标网络（从intent.dst获取）
- `{VAR:src_network}`: 源网络（从intent.src获取）
- `{VAR:dst_port}`: 目标端口（从intent.service或real_port获取）
- `{real_ip}`: 真实IP（从intent.RealIp获取）
- `{real_port}`: 真实端口（从intent.RealPort获取）

## 8. 关键函数

- `determineVipMipType()`: 判断VIP/MIP类型（仅通过real_port）
- `processVipMipObject()`: 处理VIP/MIP对象（统一流程）
- `processSnatPoolObject()`: 处理SNAT_POOL对象（统一流程）
- `ShouldUseNetworkObjectForNat()`: Node接口，判断是否需要使用网络对象
- `GetObjectByNetworkGroup()`: 查找地址对象复用
- `GetObjectByVipMipSnatPool()`: Node接口，检查VIP/MIP/SNAT_POOL对象复用
- `GenerateVipMipSnatPoolName()`: Node接口（可选），自动生成对象名称
- `generateUniqueObjectNameV2()`: 检查VIP/MIP/SNAT_POOL对象复用（通过名称）
- `dsl.IntentFormat()`: 渲染layout生成CLI

## 9. 特殊情况说明

### 9.1 Sangfor（只支持MIP，MIP需要复用地址对象）

- VIP layout为空 → 不支持VIP
- MIP layout存在 → 支持MIP
- `ShouldUseNetworkObjectForNat("MIP")` -> true → MIP先尝试复用地址对象，未复用则用Mip layout渲染为地址对象

### 9.2 FortiGate（同时支持VIP和MIP，都有特殊语法）

- VIP layout存在 → 支持VIP（有real_port时）
- MIP layout存在 → 支持MIP（无real_port时）
- `ShouldUseNetworkObjectForNat("VIP")` -> false → VIP使用标准Vip layout渲染
- `ShouldUseNetworkObjectForNat("MIP")` -> false → MIP使用标准Mip layout渲染

### 9.3 USG（支持MIP，需要复用address-group）

- VIP layout为空 → 不支持VIP
- MIP layout存在 → 支持MIP
- `ShouldUseNetworkObjectForNat("MIP")` -> true → MIP需要复用address-group

### 9.4 SRX（支持VIP，使用特殊语法pool）

- VIP layout存在 → 支持VIP
- `ShouldUseNetworkObjectForNat("VIP")` -> false → VIP使用destination pool

### 9.5 DPTech（支持MIP和SNAT_POOL，使用特殊语法address-pool）

- MIP layout存在 → 支持MIP
- SNAT_POOL layout存在 → 支持SNAT_POOL
- `ShouldUseNetworkObjectForNat("MIP")` -> false → MIP使用address-pool
- `ShouldUseNetworkObjectForNat("SNAT_POOL")` -> false → SNAT_POOL使用address-pool

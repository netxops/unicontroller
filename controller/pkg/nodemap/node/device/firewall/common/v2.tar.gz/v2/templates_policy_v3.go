package v2

import (
	"fmt"
	"strings"

	"github.com/netxops/keys"
	"github.com/netxops/l2service/pkg/nodemap/api"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall/common"
	"github.com/netxops/utils/dsl"
	"github.com/netxops/utils/policy"
	"github.com/netxops/utils/service"
)

// PolicyConfig 策略配置结构体，统一管理所有配置项
type PolicyConfig struct {
	// 策略名称相关
	PolicyName         string
	PolicyNameTemplate string
	PolicyId           string
	MainID             int

	// 对象模式配置
	SourceAddressStyle          string // "object" | "inline" | ""
	DestinationAddressStyle     string // "object" | "inline" | ""
	ServiceStyle                string // "object" | "inline" | ""
	UseSourceAddressObject      bool
	UseDestinationAddressObject bool
	UseServiceObject            bool

	// 策略复用配置
	ReusePolicy         bool
	EmptyZoneMatchesAny bool

	// 策略行为配置
	Action string
	Enable string

	// 其他配置
	Description string
}

// NewPolicyConfigFromMeta 从 metaData 中提取并创建 PolicyConfig
func NewPolicyConfigFromMeta(metaData map[string]interface{}, templates TemplatesV2) *PolicyConfig {
	config := &PolicyConfig{}

	// 策略名称相关
	config.PolicyName = getStringFromMeta(metaData, "policy_name", "")
	config.PolicyNameTemplate = getStringFromMeta(metaData, "securitypolicy.policy_name_template", "")
	if config.PolicyNameTemplate == "" {
		config.PolicyNameTemplate = getStringFromMeta(metaData, "policy_name_template", "")
	}
	if config.PolicyNameTemplate == "" {
		config.PolicyNameTemplate = "POLICY_{SEQ:id:5:1:1:MAIN}" // 默认模板
	}
	config.PolicyId = getStringFromMeta(metaData, "policy_id", "")

	// 对象模式配置
	// 优先检查独立的源地址和目标地址配置
	config.SourceAddressStyle = getStringFromMeta(metaData, "securitypolicy.source_address_style", "")
	config.DestinationAddressStyle = getStringFromMeta(metaData, "securitypolicy.destination_address_style", "")
	config.ServiceStyle = getStringFromMeta(metaData, "securitypolicy.service_style", "")

	// 如果没有独立的源/目标地址配置，使用通用的address_style配置
	if config.SourceAddressStyle == "" && config.DestinationAddressStyle == "" {
		addressStyle := getStringFromMeta(metaData, "securitypolicy.address_style", "")
		config.SourceAddressStyle = addressStyle
		config.DestinationAddressStyle = addressStyle
	}

	// 检查是否为DPTech防火墙
	_, isDptech := templates.(*DptechTemplatesV2)

	// 确定源地址对象模式
	if config.SourceAddressStyle == "object" {
		config.UseSourceAddressObject = true
	} else if config.SourceAddressStyle == "inline" {
		config.UseSourceAddressObject = false
	} else {
		// 如果未指定source_address_style，检查use_source_address_object配置
		// 如果没有，回退到use_address_object配置
		if isDptech {
			config.UseSourceAddressObject = true
		} else {
			useSourceObject := getBoolFromMeta(metaData, "securitypolicy.use_source_address_object", false)
			if !useSourceObject {
				useSourceObject = getBoolFromMeta(metaData, "securitypolicy.use_address_object", false)
			}
			config.UseSourceAddressObject = useSourceObject
		}
	}

	// 确定目标地址对象模式
	if config.DestinationAddressStyle == "object" {
		config.UseDestinationAddressObject = true
	} else if config.DestinationAddressStyle == "inline" {
		config.UseDestinationAddressObject = false
	} else {
		// 如果未指定destination_address_style，检查use_destination_address_object配置
		// 如果没有，回退到use_address_object配置
		if isDptech {
			config.UseDestinationAddressObject = true
		} else {
			useDstObject := getBoolFromMeta(metaData, "securitypolicy.use_destination_address_object", false)
			if !useDstObject {
				useDstObject = getBoolFromMeta(metaData, "securitypolicy.use_address_object", false)
			}
			config.UseDestinationAddressObject = useDstObject
		}
	}

	// 确定服务对象模式
	if config.ServiceStyle == "object" {
		config.UseServiceObject = true
	} else if config.ServiceStyle == "inline" {
		config.UseServiceObject = false
	} else {
		// 如果未指定service_style，DPTech默认使用对象风格
		if isDptech {
			config.UseServiceObject = true
		} else {
			// 其他防火墙检查use_service_object配置
			config.UseServiceObject = getBoolFromMeta(metaData, "securitypolicy.use_service_object", false)
		}
	}

	// 策略复用配置
	config.ReusePolicy = getBoolFromMeta(metaData, "securitypolicy.reuse_policy", false)
	config.EmptyZoneMatchesAny = getBoolFromMeta(metaData, "securitypolicy.empty_zone_matches_any", true)

	// 策略行为配置
	config.Action = getStringFromMeta(metaData, "action", "")
	config.Enable = getStringFromMeta(metaData, "securitypolicy.enable", "true")
	config.Description = getStringFromMeta(metaData, "description", "")

	return config
}

// Validate 验证配置项的有效性
func (config *PolicyConfig) Validate() error {
	// 验证 SourceAddressStyle
	if config.SourceAddressStyle != "" && config.SourceAddressStyle != "object" && config.SourceAddressStyle != "inline" {
		return fmt.Errorf("invalid source_address_style: %s, must be 'object' or 'inline'", config.SourceAddressStyle)
	}

	// 验证 DestinationAddressStyle
	if config.DestinationAddressStyle != "" && config.DestinationAddressStyle != "object" && config.DestinationAddressStyle != "inline" {
		return fmt.Errorf("invalid destination_address_style: %s, must be 'object' or 'inline'", config.DestinationAddressStyle)
	}

	// 验证 ServiceStyle
	if config.ServiceStyle != "" && config.ServiceStyle != "object" && config.ServiceStyle != "inline" {
		return fmt.Errorf("invalid service_style: %s, must be 'object' or 'inline'", config.ServiceStyle)
	}

	return nil
}

// ActionNormalizer 接口，用于处理不同防火墙的 action 差异
type ActionNormalizer interface {
	NormalizeAction(action string) string
}

// DefaultActionNormalizer 默认的 action 标准化器（permit/deny）
type DefaultActionNormalizer struct{}

func (n *DefaultActionNormalizer) NormalizeAction(action string) string {
	if action == "" {
		return "permit"
	}
	return action
}

// SecPathActionNormalizer SecPath和DPTech的 action 标准化器（pass/drop）
type SecPathActionNormalizer struct{}

func (n *SecPathActionNormalizer) NormalizeAction(action string) string {
	if action == "" {
		return "pass"
	}
	if action == "permit" {
		return "pass"
	}
	if action == "deny" {
		return "drop"
	}
	return action
}

// FortiActionNormalizer FortiGate的 action 标准化器（accept/deny）
type FortiActionNormalizer struct{}

func (n *FortiActionNormalizer) NormalizeAction(action string) string {
	if action == "" {
		return "accept"
	}
	if action == "permit" {
		return "accept"
	}
	// "deny" 或其他值直接使用
	return action
}

// GetActionNormalizer 根据模板类型获取对应的 ActionNormalizer
func GetActionNormalizer(templates TemplatesV2) ActionNormalizer {
	_, isSecPath := templates.(*SecPathTemplatesV2)
	_, isDptech := templates.(*DptechTemplatesV2)
	_, isForti := templates.(*FortiTemplatesV2)

	if isSecPath || isDptech {
		return &SecPathActionNormalizer{}
	}
	if isForti {
		return &FortiActionNormalizer{}
	}
	return &DefaultActionNormalizer{}
}

// extractZoneInfoV3 提取 zone 信息
func (ct *CommonTemplatesV2) extractZoneInfoV3(from, to api.Port, ctx *firewall.PolicyContext) (fromZone, toZone string) {
	// 优先从 from/to 参数获取 zone
	if from != nil {
		if zf, ok := from.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if to != nil {
		if zf, ok := to.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}
	// 如果 from/to 参数没有 zone，尝试从 ctx 中获取
	if fromZone == "" && ctx != nil && ctx.InPort != nil {
		if zf, ok := ctx.InPort.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if toZone == "" && ctx != nil && ctx.OutPort != nil {
		if zf, ok := ctx.OutPort.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}
	return fromZone, toZone
}

// generatePolicyNameAndIdV3 生成策略名称和ID
func (ct *CommonTemplatesV2) generatePolicyNameAndIdV3(config *PolicyConfig, ctx *firewall.PolicyContext, metaData map[string]interface{}) (int, string, string, error) {
	var mainID int
	var policyName string
	var policyId string

	// 优先使用metaData中直接指定的policy_name
	policyName = config.PolicyName

	// 如果metaData中没有policy_name，优先调用GetPolicyName（如果实现）
	if policyName == "" {
		if policyNameGetter, ok := ct.Node.(interface {
			GetPolicyName(ctx *firewall.PolicyContext) (string, error)
		}); ok {
			name, err := policyNameGetter.GetPolicyName(ctx)
			if err == nil && name != "" {
				policyName = name
			}
		}
	}

	// 如果GetPolicyName返回空，使用命名模板
	if policyName == "" {
		policyNameTemplate := config.PolicyNameTemplate

		// 检查模板是否包含 IDTemplate 语法（{SEQ:...} 或 {VAR:...}）
		hasIDTemplateSyntax := strings.Contains(policyNameTemplate, "{SEQ:") || strings.Contains(policyNameTemplate, "{VAR:")

		if hasIDTemplateSyntax {
			// 如果模板改变了，需要重新创建 IDTemplate
			if ct.currentPolicyTemplate != policyNameTemplate {
				var getIterator func() firewall.NamerIterator
				if iteratorNode, ok := ct.Node.(firewall.IteratorFirewall); ok {
					getIterator = func() firewall.NamerIterator {
						return iteratorNode.PolicyIterator()
					}
				} else {
					getIterator = func() firewall.NamerIterator {
						return &emptyNamerIterator{}
					}
				}
				ct.policyTemplate = common.NewPolicyTemplate(policyNameTemplate, getIterator).WithMaxRetries(10).Initialize()
				ct.currentPolicyTemplate = policyNameTemplate
			}

			// 使用 IDTemplate 生成策略名称
			variables := make(map[string]interface{})
			for k, v := range metaData {
				variables[k] = v
			}
			mainID, policyName = ct.policyTemplate.Generate(variables)

			// 如果 metaData 中没有提供 policy_id，使用 mainID
			if mainID > 0 && config.PolicyId == "" {
				config.PolicyId = fmt.Sprintf("%d", mainID)
				metaData["policy_id"] = config.PolicyId
			}
		} else {
			// 使用dsl.MapFormat生成策略名称（不包含 SEQ/VAR 语法）
			policyName = strings.TrimSpace(dsl.MapFormat(metaData, policyNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
		}
	}

	// 如果还是没有名称，使用默认名称
	if policyName == "" {
		policyName = "POLICY_OBJECT"
	}

	// 将 policyName 设置到 metaData 中，以便后续的对象名称生成可以使用
	metaData["policy_name"] = policyName

	// 生成策略ID（如果需要）
	policyId = config.PolicyId
	if policyId == "" {
		// 如果没有提供policy_id，生成一个默认值（实际应该由节点生成）
		policyId = "1"
	}

	// 更新配置
	config.PolicyName = policyName
	config.PolicyId = policyId
	config.MainID = mainID

	return mainID, policyName, policyId, nil
}

// ReuseResult 策略复用结果
type ReuseResult struct {
	IsReused         bool
	ReusedPolicyName string
	MatchedPolicy    firewall.FirewallPolicy
	UpdatedIntent    *policy.Intent
}

// handlePolicyReuseV3 处理策略复用逻辑
func (ct *CommonTemplatesV2) handlePolicyReuseV3(intent *policy.Intent, config *PolicyConfig, fromZone, toZone string) (*ReuseResult, error) {
	result := &ReuseResult{
		IsReused: false,
	}

	if !config.ReusePolicy {
		return result, nil
	}

	matchConfig := common.MatchConfig{
		MatchSrc:       true,
		MatchDst:       true,
		MatchService:   true,
		MatchThreshold: 2, // 至少两项匹配
	}
	matchConfig.EmptyZoneMatchesAny = &config.EmptyZoneMatchesAny

	matchedPolicies := common.FindPolicyByIntent(ct.Node, intent, fromZone, toZone, matchConfig)
	if len(matchedPolicies) == 0 {
		return result, nil
	}

	matchedPolicy := matchedPolicies[0]
	result.IsReused = true
	result.ReusedPolicyName = matchedPolicy.Name()
	result.MatchedPolicy = matchedPolicy

	// 计算差异
	diffSrc, diffDst, diffSrv, err := intent.PolicyEntry.SubtractWithTwoSame(matchedPolicy.PolicyEntry())
	if err == nil {
		// 更新intent为差异部分
		needCopy := false
		if diffSrc != nil || diffDst != nil || diffSrv != nil {
			needCopy = true
		}
		if needCopy {
			newIntent := intent.Copy().(*policy.Intent)
			if diffSrc != nil {
				newIntent.SetSrc(diffSrc)
			}
			if diffDst != nil {
				newIntent.SetDst(diffDst)
			}
			if diffSrv != nil {
				newIntent.SetService(diffSrv)
			}
			result.UpdatedIntent = newIntent
		}
	}

	return result, nil
}

// ObjectGenerationResult 对象生成结果
type ObjectGenerationResult struct {
	ObjectNames []string
	Keys        []string
	CLIString   string
}

// mergeObjectCLI 通用的对象CLI合并逻辑（接口版本）
func (ct *CommonTemplatesV2) mergeObjectCLI(result ObjectResultMerger, category string, newCLI string) {
	if newCLI == "" {
		return
	}

	// 获取各个防火墙特有的 SectionSeparator（从模板中获取）
	sectionSeparator := ct.Templates.GetLayout(keys.NewKeyBuilder("SectionSeparator"))
	if sectionSeparator == "" {
		// 如果模板中没有定义，使用默认值 "#"
		sectionSeparator = "#"
	}

	flyObject := result.GetFlyObject()
	if existing, exists := flyObject[category]; exists && existing != "" {
		// 确保 existing 以换行符结尾，newCLI 以换行符开头或直接是 config
		existing = strings.TrimRight(existing, "\n\r")
		newCLI = strings.TrimLeft(newCLI, "\n\r")
		result.SetFlyObject(category, existing+"\n"+sectionSeparator+"\n"+newCLI)
	} else {
		result.SetFlyObject(category, newCLI)
	}

	// 使用 SectionSeparator 分隔多个 CLI 字符串
	currentCLI := result.GetCLIString()
	if currentCLI != "" {
		trimmedCurrentCLI := strings.TrimRight(currentCLI, "\n\r")
		trimmedNewCLI := strings.TrimLeft(newCLI, "\n\r")
		result.AppendCLIString("\n" + sectionSeparator + "\n" + trimmedCurrentCLI + "\n" + trimmedNewCLI + "\n")
	} else {
		result.AppendCLIString(newCLI + "\n")
	}
}

// mergeObjectCLIV3 统一处理对象CLI合并逻辑（向后兼容包装）
func (ct *CommonTemplatesV2) mergeObjectCLIV3(result *PolicyResult, category string, newCLI string) {
	ct.mergeObjectCLI(result, category, newCLI)
}

// generateAddressObjects 通用的地址对象生成函数（接口版本）
// 同时支持 Policy 和 NAT
// 支持从 context 中复用已生成的对象
func (ct *CommonTemplatesV2) generateAddressObjects(
	intent *policy.Intent,
	useSourceObject bool,
	useDestinationObject bool,
	ctx *firewall.PolicyContext,
	metaData map[string]interface{},
	result ObjectResultMerger,
) error {
	// 生成源地址对象
	if useSourceObject {
		srcNG := intent.Src()
		// 先检查 context 中是否已有匹配的对象
		reusedObj := findReusedAddressObject(ctx, srcNG)
		if reusedObj != nil {
			// 复用 context 中的对象
			// 注意：复用的对象已经在之前的 MakeNatPolicyV3 中生成并添加到 FlyObject 中，
			// 这里只需要设置对象名称和 Keys，不需要再次添加到 FlyObject
			result.SetSourceObjects([]string{reusedObj.ObjectName})
			result.AppendKeys(reusedObj.Keys)
			// 不复用对象的 CLI，因为已经在之前的阶段添加到 FlyObject 中了
		} else {
			// 生成新对象
			srcResult, err := ct.MakeAddressObjectV2(intent, true, ctx, metaData)
			if err != nil {
				return fmt.Errorf("failed to create source address object: %v", err)
			}
			result.SetSourceObjects(srcResult.ObjectNames)
			result.AppendKeys(srcResult.Keys)
			if srcResult.CLIString != "" {
				ct.mergeObjectCLI(result, common.FlyObjectNetwork, srcResult.CLIString)
			}
			// 将新生成的对象存储到 context 中
			if len(srcResult.ObjectNames) > 0 {
				objInfo := &ContextObjectInfo{
					ObjectName: srcResult.ObjectNames[0],
					CLIString:  srcResult.CLIString,
					Keys:       srcResult.Keys,
					IsGroup:    srcResult.IsGroup,
					Network:    srcNG,
				}
				storeAddressObjectInContext(ctx, srcNG, objInfo)
			}
		}
	}

	// 生成目标地址对象
	if useDestinationObject {
		dstNG := intent.Dst()
		// 先检查 context 中是否已有匹配的对象
		reusedObj := findReusedAddressObject(ctx, dstNG)
		if reusedObj != nil {
			// 复用 context 中的对象
			// 注意：复用的对象已经在之前的 MakeNatPolicyV3 中生成并添加到 FlyObject 中，
			// 这里只需要设置对象名称和 Keys，不需要再次添加到 FlyObject
			result.SetDestinationObjects([]string{reusedObj.ObjectName})
			result.AppendKeys(reusedObj.Keys)
			// 不复用对象的 CLI，因为已经在之前的阶段添加到 FlyObject 中了
		} else {
			// 生成新对象
			dstResult, err := ct.MakeAddressObjectV2(intent, false, ctx, metaData)
			if err != nil {
				return fmt.Errorf("failed to create destination address object: %v", err)
			}
			result.SetDestinationObjects(dstResult.ObjectNames)
			result.AppendKeys(dstResult.Keys)
			if dstResult.CLIString != "" {
				ct.mergeObjectCLI(result, common.FlyObjectNetwork, dstResult.CLIString)
			}
			// 将新生成的对象存储到 context 中
			if len(dstResult.ObjectNames) > 0 {
				objInfo := &ContextObjectInfo{
					ObjectName: dstResult.ObjectNames[0],
					CLIString:  dstResult.CLIString,
					Keys:       dstResult.Keys,
					IsGroup:    dstResult.IsGroup,
					Network:    dstNG,
				}
				storeAddressObjectInContext(ctx, dstNG, objInfo)
			}
		}
	}

	return nil
}

// generateAddressObjectsV3 生成地址对象（分别处理源地址和目标地址）
func (ct *CommonTemplatesV2) generateAddressObjectsV3(intent *policy.Intent, config *PolicyConfig, ctx *firewall.PolicyContext, metaData map[string]interface{}, result *PolicyResult) error {
	return ct.generateAddressObjects(intent, config.UseSourceAddressObject, config.UseDestinationAddressObject, ctx, metaData, result)
}

// generateServiceObjects 通用的服务对象生成函数（接口版本）
// 支持从 context 中复用已生成的对象
func (ct *CommonTemplatesV2) generateServiceObjects(
	intent *policy.Intent,
	useServiceObject bool,
	ctx *firewall.PolicyContext,
	metaData map[string]interface{},
	result ObjectResultMerger,
) error {
	if !useServiceObject {
		return nil
	}

	// 检查 service 是否为 ip 协议
	isIPProtocol := false
	if intent.Service() != nil {
		intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
			if l3, ok := item.(*service.L3Protocol); ok && l3.Protocol() == service.IP {
				isIPProtocol = true
				return false
			}
			return true
		})
	}

	if isIPProtocol {
		// 如果 isIPProtocol 为 true，不生成 service 对象，模板会使用 service "any"
		return nil
	}

	// 先检查 context 中是否已有匹配的对象
	svc := intent.Service()
	reusedObj := findReusedServiceObject(ctx, svc)
	if reusedObj != nil {
		// 复用 context 中的对象
		// 注意：复用的对象已经在之前的 MakeNatPolicyV3 中生成并添加到 FlyObject 中，
		// 这里只需要设置对象名称和 Keys，不需要再次添加到 FlyObject
		result.SetServiceObjects([]string{reusedObj.ObjectName})
		result.AppendKeys(reusedObj.Keys)
		// 不复用对象的 CLI，因为已经在之前的阶段添加到 FlyObject 中了
	} else {
		// 生成新对象
		svcResult, err := ct.MakeServiceObjectV2(intent, ctx, metaData)
		if err != nil {
			return fmt.Errorf("failed to create service object: %v", err)
		}
		result.SetServiceObjects(svcResult.ObjectNames)
		result.AppendKeys(svcResult.Keys)
		if svcResult.CLIString != "" {
			ct.mergeObjectCLI(result, common.FlyObjectService, svcResult.CLIString)
		}
		// 将新生成的对象存储到 context 中
		if len(svcResult.ObjectNames) > 0 {
			objInfo := &ContextObjectInfo{
				ObjectName: svcResult.ObjectNames[0],
				CLIString:  svcResult.CLIString,
				Keys:       svcResult.Keys,
				IsGroup:    svcResult.IsGroup,
				Service:    svc,
			}
			storeServiceObjectInContext(ctx, svc, objInfo)
		}
	}

	return nil
}

// generateServiceObjectsV3 生成服务对象
func (ct *CommonTemplatesV2) generateServiceObjectsV3(intent *policy.Intent, config *PolicyConfig, ctx *firewall.PolicyContext, metaData map[string]interface{}, result *PolicyResult) error {
	return ct.generateServiceObjects(intent, config.UseServiceObject, ctx, metaData, result)
}

// preparePolicyTemplateDataV3 准备策略模板数据
func (ct *CommonTemplatesV2) preparePolicyTemplateDataV3(intent *policy.Intent, config *PolicyConfig, result *PolicyResult, fromZone, toZone string, from, to api.Port, metaData map[string]interface{}) map[string]interface{} {
	data := copyMap(metaData)

	// 基本策略信息
	data["policy_name"] = config.PolicyName
	data["policy_id"] = config.PolicyId
	data["fromZone"] = fromZone
	data["toZone"] = toZone

	// 如果策略被复用，去掉源zone和目的zone（设置为空数组）
	if result.IsReused {
		data["sourceZones"] = []interface{}{}
		data["destinationZones"] = []interface{}{}
	} else {
		data["sourceZones"] = []interface{}{fromZone}
		data["destinationZones"] = []interface{}{toZone}
	}

	// 接口信息
	if from != nil {
		data["fromPort"] = from.Name()
	}
	if to != nil {
		data["toPort"] = to.Name()
	}

	// 设置对象引用
	if len(result.SourceObjects) > 0 {
		srcObjs := make([]interface{}, len(result.SourceObjects))
		for i, obj := range result.SourceObjects {
			srcObjs[i] = obj
		}
		data["src_objects"] = srcObjs
		data["sourceObjects"] = srcObjs
		data["has_source_objects"] = "true"
	}
	if len(result.DestinationObjects) > 0 {
		dstObjs := make([]interface{}, len(result.DestinationObjects))
		for i, obj := range result.DestinationObjects {
			dstObjs[i] = obj
		}
		data["dst_objects"] = dstObjs
		data["destinationObjects"] = dstObjs
		data["has_destination_objects"] = "true"
	}
	if len(result.ServiceObjects) > 0 {
		svcObjs := make([]interface{}, len(result.ServiceObjects))
		for i, obj := range result.ServiceObjects {
			svcObjs[i] = obj
		}
		data["service_objects"] = svcObjs
		data["serviceObjects"] = svcObjs
		data["has_service_objects"] = "true"
	}

	// 设置标志位
	if config.UseSourceAddressObject {
		data["make_source"] = "true"
	}
	if config.UseDestinationAddressObject {
		data["make_destination"] = "true"
	}
	if config.UseServiceObject {
		data["make_service"] = "true"
	}

	// 策略状态
	data["enable"] = config.Enable

	// 动作 - 使用 ActionNormalizer
	normalizer := GetActionNormalizer(ct.Templates)
	data["action"] = normalizer.NormalizeAction(config.Action)

	// 描述
	if config.Description != "" {
		data["description"] = config.Description
		data["has_description"] = "true"
	}

	return data
}

// MakePolicyV3 生成安全策略（V3版本，重构优化版）
// 该版本通过配置结构体、函数拆分、消除重复代码等方式，改善了代码的可维护性和可读性
func (ct *CommonTemplatesV2) MakePolicyV3(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}) (*PolicyResult, error) {
	// 步骤1: 初始化结果对象
	result := &PolicyResult{
		SourceObjects:      []string{},
		DestinationObjects: []string{},
		ServiceObjects:     []string{},
		Keys:               []string{},
		FlyObject:          make(map[string]string),
	}

	// 步骤2: 创建并验证配置
	config := NewPolicyConfigFromMeta(metaData, ct.Templates)
	if err := config.Validate(); err != nil {
		return nil, fmt.Errorf("invalid policy config: %v", err)
	}

	// 步骤3: 提取 zone 信息
	fromZone, toZone := ct.extractZoneInfoV3(from, to, ctx)

	// 步骤4: 生成策略名称和ID
	mainID, policyName, policyId, err := ct.generatePolicyNameAndIdV3(config, ctx, metaData)
	if err != nil {
		return nil, fmt.Errorf("failed to generate policy name and id: %v", err)
	}
	// 更新配置中的值
	config.PolicyName = policyName
	config.PolicyId = policyId
	config.MainID = mainID

	// 步骤5: 处理策略复用
	reuseResult, err := ct.handlePolicyReuseV3(intent, config, fromZone, toZone)
	if err != nil {
		return nil, fmt.Errorf("failed to handle policy reuse: %v", err)
	}

	if reuseResult.IsReused {
		result.IsReused = true
		result.ReusedPolicyName = reuseResult.ReusedPolicyName
		config.PolicyName = reuseResult.ReusedPolicyName
		config.PolicyId = reuseResult.MatchedPolicy.ID()
		metaData["policy_name"] = config.PolicyName
		metaData["policy_id"] = config.PolicyId

		// 如果 intent 被更新，使用更新后的 intent
		if reuseResult.UpdatedIntent != nil {
			intent = reuseResult.UpdatedIntent
		}
	}

	// 步骤6: 生成地址对象
	if err := ct.generateAddressObjectsV3(intent, config, ctx, metaData, result); err != nil {
		return nil, err
	}

	// 步骤7: 生成服务对象
	if err := ct.generateServiceObjectsV3(intent, config, ctx, metaData, result); err != nil {
		return nil, err
	}

	// 步骤8: 生成策略CLI
	layout := ct.Templates.GetLayout(keys.NewKeyBuilder("Policy", "OneLoop"))
	if layout == "" {
		return nil, fmt.Errorf("Policy.OneLoop layout not found")
	}

	// 准备模板数据
	data := ct.preparePolicyTemplateDataV3(intent, config, result, fromZone, toZone, from, to, metaData)

	// 使用dsl.IntentFormat渲染策略模板
	policyCli := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)

	if policyCli != "" {
		// 将策略CLI添加到SECURITY_POLICY类别
		result.FlyObject[common.FlyObjectSecurityPolicy] = policyCli
		result.CLIString += policyCli
	}

	// 设置结果
	result.PolicyName = config.PolicyName
	result.PolicyId = config.PolicyId

	return result, nil
}

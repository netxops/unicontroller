package v2

import (
	"testing"

	"github.com/netxops/utils/network"
	"github.com/netxops/utils/service"
	"github.com/stretchr/testify/assert"
)

// ==================== 生产环境通用命名模板测试 ====================

// 定义生产环境通用的命名模板
const (
	// ProductionNetworkObjectNameTemplate 生产环境网络对象命名模板
	// 命名规则：
	// - 单IP: {ip}
	// - CIDR网络: {cidr}
	// - IP范围: {start}_{end}
	// - 如果提供policy_name且不为空，则添加前缀: {policy_name}_{if:is_source=="true"}SRC{else}DST{endif}_{network}
	ProductionNetworkObjectNameTemplate = `
	{set:network.separator="/"}
	{if:exist:policy_name=="true"}
		{if:policy_name!=""}
			{policy_name}_{if:is_source=="true"}SRC{else}DST{endif}_
						  {if:type=="range"}{start}_{end}{else if:type=="subnet"}{cidr}{else}{ip}{endif}
		{else}
			{if:type=="range"}{start}_{end}
			{else if:type=="subnet"}{cidr}{else}{ip}
			{endif}
		{endif}
	{else}
		{if:type=="range"}{start}_{end}
		{else if:type=="subnet"}{cidr}
		{else}{ip}
		{endif}
	{endif}`

	// ProductionServiceObjectNameTemplate 生产环境服务对象命名模板
	// 命名规则：
	// - 格式: {policy_name}_{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}
	// - 如果没有policy_name或为空，则使用: {protocol:lower}{if:dst_port!=""}_{dst_port}{endif}
	// - 注意：L3协议（如IP）和ICMP没有端口，所以不会包含端口部分
	ProductionServiceObjectNameTemplate = `
	{set:service.range_format="-"}
	{if:exist:policy_name=="true"}
		{if:policy_name!=""}
			{policy_name}_{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}
		{else}
			{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}
		{endif}
	{else}
		{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}
	{endif}`
)

// TestProductionNetworkObjectNameTemplate 测试生产环境网络对象命名模板
func TestProductionNetworkObjectNameTemplate(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		metaData    map[string]interface{}
		expected    string
		description string
	}{
		// ========== 基础场景：无policy_name ==========
		// {
		// 	name:        "单IP地址-无策略名",
		// 	network:     "192.168.1.1/32",
		// 	metaData:    map[string]interface{}{"network_object_name_template": ProductionNetworkObjectNameTemplate},
		// 	expected:    "192.168.1.1",
		// 	description: "单IP地址，无策略名时直接使用IP",
		// },
		// {
		// 	name:        "CIDR网络-无策略名",
		// 	network:     "192.168.1.0/24",
		// 	metaData:    map[string]interface{}{"network_object_name_template": ProductionNetworkObjectNameTemplate},
		// 	expected:    "192.168.1.0/24",
		// 	description: "CIDR网络，无策略名时直接使用CIDR",
		// },
		{
			name:        "IP范围-无策略名",
			network:     "192.168.1.10-192.168.1.20",
			metaData:    map[string]interface{}{"network_object_name_template": ProductionNetworkObjectNameTemplate},
			expected:    "192.168.1.10_192.168.1.20",
			description: "IP范围，无策略名时使用start_end格式",
		},

		// ========== 带policy_name的场景 ==========
		{
			name:    "单IP地址-源地址-有策略名",
			network: "192.168.1.1/32",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_001",
				"is_source":                    "true",
			},
			expected:    "POLICY_001_SRC_192.168.1.1",
			description: "单IP地址，源地址，有策略名时格式为：策略名_SRC_IP",
		},
		{
			name:    "单IP地址-目标地址-有策略名",
			network: "192.168.1.1/32",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_001",
				"is_source":                    "false",
			},
			expected:    "POLICY_001_DST_192.168.1.1",
			description: "单IP地址，目标地址，有策略名时格式为：策略名_DST_IP",
		},
		{
			name:    "CIDR网络-源地址-有策略名",
			network: "192.168.1.0/24",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_001",
				"is_source":                    "true",
			},
			expected:    "POLICY_001_SRC_192.168.1.0/24",
			description: "CIDR网络，源地址，有策略名时格式为：策略名_SRC_CIDR",
		},
		{
			name:    "CIDR网络-目标地址-有策略名",
			network: "10.0.0.0/8",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_002",
				"is_source":                    "false",
			},
			expected:    "POLICY_002_DST_10.0.0.0/8",
			description: "CIDR网络，目标地址，有策略名时格式为：策略名_DST_CIDR",
		},
		{
			name:    "IP范围-源地址-有策略名",
			network: "192.168.1.10-192.168.1.20",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_001",
				"is_source":                    "true",
			},
			expected:    "POLICY_001_SRC_192.168.1.10_192.168.1.20",
			description: "IP范围，源地址，有策略名时格式为：策略名_SRC_start_end",
		},
		{
			name:    "IP范围-目标地址-有策略名",
			network: "10.1.1.100-10.1.1.200",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_003",
				"is_source":                    "false",
			},
			expected:    "POLICY_003_DST_10.1.1.100_10.1.1.200",
			description: "IP范围，目标地址，有策略名时格式为：策略名_DST_start_end",
		},

		// ========== IPv6场景 ==========
		{
			name:        "IPv6单地址-无策略名",
			network:     "2001:db8::1/128",
			metaData:    map[string]interface{}{"network_object_name_template": ProductionNetworkObjectNameTemplate},
			expected:    "2001:db8::1",
			description: "IPv6单地址，无策略名",
		},
		{
			name:    "IPv6网络-有策略名",
			network: "2001:db8::/32",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_IPV6",
				"is_source":                    "true",
			},
			expected:    "POLICY_IPV6_SRC_2001:db8::/32",
			description: "IPv6网络，有策略名",
		},

		// ========== 边界情况 ==========
		{
			name:    "全0网络",
			network: "0.0.0.0/0",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_ANY",
				"is_source":                    "true",
			},
			expected:    "POLICY_ANY_SRC_0.0.0.0/0",
			description: "全0网络（any）",
		},
		{
			name:    "私有网络-10.0.0.0/8",
			network: "10.0.0.0/8",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_PRIVATE",
				"is_source":                    "false",
			},
			expected:    "POLICY_PRIVATE_DST_10.0.0.0/8",
			description: "大型私有网络",
		},
		{
			name:    "小范围IP段",
			network: "192.168.1.1-192.168.1.2",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "POLICY_SMALL",
				"is_source":                    "true",
			},
			expected:    "POLICY_SMALL_SRC_192.168.1.1_192.168.1.2",
			description: "小范围IP段（仅2个IP）",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ng := network.NewNetworkGroupFromStringMust(tt.network)
			result := generateObjectNameFromTemplate(ng, ProductionNetworkObjectNameTemplate, tt.metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s\n描述: %s", tt.expected, result, tt.description)
		})
	}
}

// TestProductionServiceObjectNameTemplate 测试生产环境服务对象命名模板
func TestProductionServiceObjectNameTemplate(t *testing.T) {
	tests := []struct {
		name        string
		service     string
		metaData    map[string]interface{}
		expected    string
		description string
	}{
		// ========== 基础场景：无policy_name ==========
		{
			name:        "TCP单端口-无策略名",
			service:     "tcp:80",
			metaData:    map[string]interface{}{"service_object_name_template": ProductionServiceObjectNameTemplate},
			expected:    "tcp_80",
			description: "TCP单端口，无策略名时格式为：协议_端口",
		},
		{
			name:        "UDP单端口-无策略名",
			service:     "udp:53",
			metaData:    map[string]interface{}{"service_object_name_template": ProductionServiceObjectNameTemplate},
			expected:    "udp_53",
			description: "UDP单端口，无策略名",
		},
		{
			name:        "TCP端口范围-无策略名",
			service:     "tcp:8080-8090",
			metaData:    map[string]interface{}{"service_object_name_template": ProductionServiceObjectNameTemplate},
			expected:    "tcp_8080-8090",
			description: "TCP端口范围，无策略名",
		},
		{
			name:        "ICMP-无策略名",
			service:     "icmp:8|0",
			metaData:    map[string]interface{}{"service_object_name_template": ProductionServiceObjectNameTemplate},
			expected:    "icmp",
			description: "ICMP协议，无策略名，无端口",
		},
		{
			name:        "L3协议IP-无策略名",
			service:     "ip",
			metaData:    map[string]interface{}{"service_object_name_template": ProductionServiceObjectNameTemplate},
			expected:    "ip",
			description: "L3协议IP，无策略名，无端口",
		},

		// ========== 带policy_name的场景 ==========
		{
			name:    "TCP单端口-有策略名",
			service: "tcp:80",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_001",
			},
			expected:    "POLICY_001_tcp_80",
			description: "TCP单端口，有策略名时格式为：策略名_协议_端口",
		},
		{
			name:    "UDP单端口-有策略名",
			service: "udp:53",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_001",
			},
			expected:    "POLICY_001_udp_53",
			description: "UDP单端口，有策略名",
		},
		{
			name:    "TCP端口范围-有策略名",
			service: "tcp:8080-8090",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_002",
			},
			expected:    "POLICY_002_tcp_8080-8090",
			description: "TCP端口范围，有策略名",
		},
		{
			name:    "TCP多端口-有策略名",
			service: "tcp:80,443,8080",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_003",
			},
			expected:    "POLICY_003_tcp_80",
			description: "TCP多端口，有策略名（使用第一个端口）",
		},
		{
			name:    "ICMP-有策略名",
			service: "icmp:8|0",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_ICMP",
			},
			expected:    "POLICY_ICMP_icmp",
			description: "ICMP协议，有策略名，无端口",
		},
		{
			name:    "L3协议IP-有策略名",
			service: "ip",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_IP",
			},
			expected:    "POLICY_IP_ip",
			description: "L3协议IP，有策略名，无端口",
		},

		// ========== 复杂场景 ==========
		{
			name:    "TCP全端口范围-有策略名",
			service: "tcp:0-65535",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_ALL",
			},
			expected:    "POLICY_ALL_tcp",
			description: "TCP全端口范围（0-65535被视为全范围，不显示端口），有策略名",
		},
		{
			name:    "TCP带源端口-有策略名",
			service: "tcp:1024-65535|80",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_SRC",
			},
			expected:    "POLICY_SRC_tcp_80",
			description: "TCP带源端口限制，有策略名（使用目标端口）",
		},
		{
			name:    "UDP端口范围-有策略名",
			service: "udp:50000-60000",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_UDP_RANGE",
			},
			expected:    "POLICY_UDP_RANGE_udp_50000-60000",
			description: "UDP端口范围，有策略名",
		},

		// ========== 边界情况 ==========
		{
			name:    "TCP端口1-有策略名",
			service: "tcp:1",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_MIN",
			},
			expected:    "POLICY_MIN_tcp_1",
			description: "TCP最小端口1",
		},
		{
			name:    "TCP端口65535-有策略名",
			service: "tcp:65535",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_MAX",
			},
			expected:    "POLICY_MAX_tcp_65535",
			description: "TCP最大端口65535",
		},
		{
			name:    "TCP知名端口HTTP-有策略名",
			service: "tcp:80",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_HTTP",
			},
			expected:    "POLICY_HTTP_tcp_80",
			description: "TCP知名端口HTTP（80）",
		},
		{
			name:    "TCP知名端口HTTPS-有策略名",
			service: "tcp:443",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY_HTTPS",
			},
			expected:    "POLICY_HTTPS_tcp_443",
			description: "TCP知名端口HTTPS（443）",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			result := ct.generateServiceNameFromTemplate(firstEntry, ProductionServiceObjectNameTemplate, tt.metaData)
			assert.Equal(t, tt.expected, result,
				"期望: %s, 实际: %s\n描述: %s", tt.expected, result, tt.description)
		})
	}
}

// TestProductionTemplates_RealWorldScenarios 测试真实世界场景
func TestProductionTemplates_RealWorldScenarios(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		service     string
		metaData    map[string]interface{}
		expectedNet string
		expectedSvc string
		description string
	}{
		{
			name:    "Web服务器访问场景",
			network: "192.168.1.100/32",
			service: "tcp:80,443",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "WEB_SERVER_ACCESS",
				"is_source":                    "false",
			},
			expectedNet: "WEB_SERVER_ACCESS_DST_192.168.1.100",
			expectedSvc: "WEB_SERVER_ACCESS_tcp_80",
			description: "Web服务器访问场景：目标地址+HTTP/HTTPS服务",
		},
		{
			name:    "数据库访问场景",
			network: "10.1.1.0/24",
			service: "tcp:3306",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "DB_ACCESS",
				"is_source":                    "true",
			},
			expectedNet: "DB_ACCESS_SRC_10.1.1.0/24",
			expectedSvc: "DB_ACCESS_tcp_3306",
			description: "数据库访问场景：源网络+MySQL端口",
		},
		{
			name:    "DNS服务场景",
			network: "8.8.8.8/32",
			service: "udp:53",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "DNS_SERVICE",
				"is_source":                    "false",
			},
			expectedNet: "DNS_SERVICE_DST_8.8.8.8",
			expectedSvc: "DNS_SERVICE_udp_53",
			description: "DNS服务场景：目标DNS服务器+UDP53端口",
		},
		{
			name:    "ICMP Ping场景",
			network: "192.168.1.0/24",
			service: "icmp:8|0",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "PING_ALLOW",
				"is_source":                    "true",
			},
			expectedNet: "PING_ALLOW_SRC_192.168.1.0/24",
			expectedSvc: "PING_ALLOW_icmp",
			description: "ICMP Ping场景：允许网络ping",
		},
		{
			name:    "应用服务器端口范围场景",
			network: "10.2.2.50-10.2.2.60",
			service: "tcp:8080-8090",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "APP_SERVER",
				"is_source":                    "false",
			},
			expectedNet: "APP_SERVER_DST_10.2.2.50_10.2.2.60",
			expectedSvc: "APP_SERVER_tcp_8080-8090",
			description: "应用服务器场景：IP范围+端口范围",
		},
		{
			name:    "全网络访问场景",
			network: "0.0.0.0/0",
			service: "ip",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "ALLOW_ALL",
				"is_source":                    "true",
			},
			expectedNet: "ALLOW_ALL_SRC_0.0.0.0/0",
			expectedSvc: "ALLOW_ALL_ip",
			description: "全网络访问场景：允许所有网络和所有协议",
		},
		{
			name:    "私有网络互访场景",
			network: "172.16.0.0/12",
			service: "tcp:22,3389",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "PRIVATE_NET_ACCESS",
				"is_source":                    "false",
			},
			expectedNet: "PRIVATE_NET_ACCESS_DST_172.16.0.0/12",
			expectedSvc: "PRIVATE_NET_ACCESS_tcp_22",
			description: "私有网络互访场景：大型私有网络+管理端口",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// 测试网络对象命名
			ng := network.NewNetworkGroupFromStringMust(tt.network)
			netResult := generateObjectNameFromTemplate(ng, ProductionNetworkObjectNameTemplate, tt.metaData)
			assert.Equal(t, tt.expectedNet, netResult,
				"网络对象命名 - 期望: %s, 实际: %s\n场景: %s", tt.expectedNet, netResult, tt.description)

			// 测试服务对象命名
			svc := service.NewServiceMust(tt.service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			svcResult := ct.generateServiceNameFromTemplate(firstEntry, ProductionServiceObjectNameTemplate, tt.metaData)
			assert.Equal(t, tt.expectedSvc, svcResult,
				"服务对象命名 - 期望: %s, 实际: %s\n场景: %s", tt.expectedSvc, svcResult, tt.description)
		})
	}
}

// TestProductionTemplates_EdgeCases 测试边界情况和异常场景
func TestProductionTemplates_EdgeCases(t *testing.T) {
	tests := []struct {
		name        string
		network     string
		service     string
		metaData    map[string]interface{}
		expectedNet string
		expectedSvc string
		description string
	}{
		{
			name:    "空策略名-网络对象",
			network: "192.168.1.1/32",
			service: "",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"policy_name":                  "",
				"is_source":                    "true",
			},
			expectedNet: "192.168.1.1",
			expectedSvc: "",
			description: "策略名为空时，网络对象应直接使用网络信息",
		},
		{
			name:    "空策略名-服务对象",
			network: "",
			service: "tcp:80",
			metaData: map[string]interface{}{
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "",
			},
			expectedNet: "",
			expectedSvc: "tcp_80",
			description: "策略名为空时，服务对象应直接使用协议和端口",
		},
		{
			name:    "特殊字符策略名",
			network: "192.168.1.1/32",
			service: "tcp:80",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "POLICY-TEST_001",
				"is_source":                    "true",
			},
			expectedNet: "POLICY-TEST_001_SRC_192.168.1.1",
			expectedSvc: "POLICY-TEST_001_tcp_80",
			description: "策略名包含特殊字符（连字符和下划线）",
		},
		{
			name:    "长策略名",
			network: "10.1.1.0/24",
			service: "tcp:443",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "VERY_LONG_POLICY_NAME_FOR_TESTING_PURPOSES",
				"is_source":                    "false",
			},
			expectedNet: "VERY_LONG_POLICY_NAME_FOR_TESTING_PURPOSES_DST_10.1.1.0/24",
			expectedSvc: "VERY_LONG_POLICY_NAME_FOR_TESTING_PURPOSES_tcp_443",
			description: "超长策略名测试",
		},
		{
			name:    "数字策略名",
			network: "192.168.1.1/32",
			service: "udp:53",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "12345",
				"is_source":                    "true",
			},
			expectedNet: "12345_SRC_192.168.1.1",
			expectedSvc: "12345_udp_53",
			description: "纯数字策略名",
		},
		{
			name:    "混合大小写策略名",
			network: "10.1.1.1/32",
			service: "tcp:22",
			metaData: map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"policy_name":                  "PolicyTest_001",
				"is_source":                    "false",
			},
			expectedNet: "PolicyTest_001_DST_10.1.1.1",
			expectedSvc: "PolicyTest_001_tcp_22",
			description: "混合大小写策略名",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.network != "" {
				ng := network.NewNetworkGroupFromStringMust(tt.network)
				netResult := generateObjectNameFromTemplate(ng, ProductionNetworkObjectNameTemplate, tt.metaData)
				assert.Equal(t, tt.expectedNet, netResult,
					"网络对象命名 - 期望: %s, 实际: %s\n场景: %s", tt.expectedNet, netResult, tt.description)
			}

			if tt.service != "" {
				svc := service.NewServiceMust(tt.service)
				var firstEntry service.ServiceEntry
				svc.EachDetailed(func(item service.ServiceEntry) bool {
					firstEntry = item
					return false
				})

				ct := &CommonTemplatesV2{}
				svcResult := ct.generateServiceNameFromTemplate(firstEntry, ProductionServiceObjectNameTemplate, tt.metaData)
				assert.Equal(t, tt.expectedSvc, svcResult,
					"服务对象命名 - 期望: %s, 实际: %s\n场景: %s", tt.expectedSvc, svcResult, tt.description)
			}
		})
	}
}

// TestProductionTemplates_Comprehensive 综合测试：覆盖各种组合场景
func TestProductionTemplates_Comprehensive(t *testing.T) {
	// 定义测试数据矩阵
	networks := []struct {
		name    string
		network string
	}{
		{"单IP", "192.168.1.1/32"},
		{"CIDR网络", "192.168.1.0/24"},
		{"IP范围", "192.168.1.10-192.168.1.20"},
		{"大型网络", "10.0.0.0/8"},
		{"IPv6", "2001:db8::1/128"},
	}

	services := []struct {
		name    string
		service string
	}{
		{"TCP单端口", "tcp:80"},
		{"TCP端口范围", "tcp:8080-8090"},
		{"UDP单端口", "udp:53"},
		{"ICMP", "icmp:8|0"},
		{"L3协议", "ip"},
	}

	policyNames := []string{
		"POLICY_001",
		"WEB_SERVER",
		"DB_ACCESS",
		"",
	}

	// 测试所有组合（部分采样，避免测试过多）
	testCases := []struct {
		netIdx      int
		svcIdx      int
		policyIdx   int
		isSource    bool
		description string
	}{
		{0, 0, 0, true, "单IP+TCP80+策略名+源地址"},
		{1, 1, 1, false, "CIDR网络+TCP端口范围+策略名+目标地址"},
		{2, 2, 2, true, "IP范围+UDP53+策略名+源地址"},
		{3, 3, 3, false, "大型网络+ICMP+无策略名+目标地址"},
		{4, 4, 0, true, "IPv6+L3协议+策略名+源地址"},
	}

	for _, tc := range testCases {
		testName := networks[tc.netIdx].name + "_" + services[tc.svcIdx].name + "_" + policyNames[tc.policyIdx] + "_" + tc.description
		t.Run(testName, func(t *testing.T) {
			metaData := map[string]interface{}{
				"network_object_name_template": ProductionNetworkObjectNameTemplate,
				"service_object_name_template": ProductionServiceObjectNameTemplate,
				"is_source":                    map[bool]string{true: "true", false: "false"}[tc.isSource],
			}
			if policyNames[tc.policyIdx] != "" {
				metaData["policy_name"] = policyNames[tc.policyIdx]
			}

			// 测试网络对象
			ng := network.NewNetworkGroupFromStringMust(networks[tc.netIdx].network)
			netResult := generateObjectNameFromTemplate(ng, ProductionNetworkObjectNameTemplate, metaData)
			assert.NotEmpty(t, netResult, "网络对象名称不应为空")

			// 测试服务对象
			svc := service.NewServiceMust(services[tc.svcIdx].service)
			var firstEntry service.ServiceEntry
			svc.EachDetailed(func(item service.ServiceEntry) bool {
				firstEntry = item
				return false
			})

			ct := &CommonTemplatesV2{}
			svcResult := ct.generateServiceNameFromTemplate(firstEntry, ProductionServiceObjectNameTemplate, metaData)
			assert.NotEmpty(t, svcResult, "服务对象名称不应为空")

			t.Logf("网络对象: %s", netResult)
			t.Logf("服务对象: %s", svcResult)
		})
	}
}

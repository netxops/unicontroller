# 生产环境通用命名模板测试总结

## 概述

本文档总结了为生产环境创建的通用命名模板及其全面的测试验证。

## 1. 通用命名模板定义

### 1.1 网络对象命名模板 (ProductionNetworkObjectNameTemplate)

**模板定义：**
```
{if:exist:policy_name=="true"}{if:policy_name!=""}{policy_name}_{if:is_source=="true"}SRC{else}DST{endif}_{if:type=="range"}{start}_{end}{else if:type=="subnet"}{cidr}{else}{ip}{endif}{else}{if:type=="range"}{start}_{end}{else if:type=="subnet"}{cidr}{else}{ip}{endif}{endif}{else}{if:type=="range"}{start}_{end}{else if:type=="subnet"}{cidr}{else}{ip}{endif}{endif}
```

**命名规则：**
- **无策略名时**：直接使用网络信息
  - 单IP: `192.168.1.1`
  - CIDR网络: `192.168.1.0/24`
  - IP范围: `192.168.1.10_192.168.1.20`
- **有策略名时**：添加策略名和源/目标标识
  - 单IP源地址: `POLICY_001_SRC_192.168.1.1`
  - CIDR网络目标地址: `POLICY_001_DST_192.168.1.0/24`
  - IP范围源地址: `POLICY_001_SRC_192.168.1.10_192.168.1.20`

**特点：**
- 自动识别网络类型（单IP、CIDR、IP范围）
- 支持源/目标地址区分（SRC/DST）
- 支持IPv4和IPv6
- 策略名为空时自动降级为简单格式

### 1.2 服务对象命名模板 (ProductionServiceObjectNameTemplate)

**模板定义：**
```
{if:exist:policy_name=="true"}{if:policy_name!=""}{policy_name}_{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}{else}{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}{endif}{else}{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}{endif}
```

**命名规则：**
- **无策略名时**：直接使用协议和端口
  - TCP单端口: `tcp_80`
  - UDP单端口: `udp_53`
  - TCP端口范围: `tcp_8080-8090`
  - ICMP: `icmp`（无端口）
  - L3协议: `ip`（无端口）
- **有策略名时**：添加策略名前缀
  - TCP单端口: `POLICY_001_tcp_80`
  - UDP单端口: `POLICY_001_udp_53`
  - TCP端口范围: `POLICY_002_tcp_8080-8090`
  - ICMP: `POLICY_ICMP_icmp`
  - L3协议: `POLICY_IP_ip`

**特点：**
- 自动处理端口信息（有端口时显示，无端口时不显示）
- 全端口范围（0-65535）不显示端口部分
- 协议名称统一小写
- 策略名为空时自动降级为简单格式

## 2. 测试覆盖范围

### 2.1 网络对象命名测试 (TestProductionNetworkObjectNameTemplate)

**测试场景：**
1. **基础场景（无策略名）**
   - 单IP地址
   - CIDR网络
   - IP范围

2. **带策略名场景**
   - 单IP地址（源地址/目标地址）
   - CIDR网络（源地址/目标地址）
   - IP范围（源地址/目标地址）

3. **IPv6场景**
   - IPv6单地址（无策略名）
   - IPv6网络（有策略名）

4. **边界情况**
   - 全0网络（0.0.0.0/0）
   - 大型私有网络（10.0.0.0/8）
   - 小范围IP段（仅2个IP）

**测试用例总数：** 14个

### 2.2 服务对象命名测试 (TestProductionServiceObjectNameTemplate)

**测试场景：**
1. **基础场景（无策略名）**
   - TCP单端口
   - UDP单端口
   - TCP端口范围
   - ICMP协议
   - L3协议（IP）

2. **带策略名场景**
   - TCP单端口
   - UDP单端口
   - TCP端口范围
   - TCP多端口
   - ICMP协议
   - L3协议（IP）

3. **复杂场景**
   - TCP全端口范围（0-65535）
   - TCP带源端口限制
   - UDP端口范围

4. **边界情况**
   - TCP端口1（最小端口）
   - TCP端口65535（最大端口）
   - TCP知名端口HTTP（80）
   - TCP知名端口HTTPS（443）

**测试用例总数：** 18个

### 2.3 真实世界场景测试 (TestProductionTemplates_RealWorldScenarios)

**测试场景：**
1. Web服务器访问场景：目标地址 + HTTP/HTTPS服务
2. 数据库访问场景：源网络 + MySQL端口
3. DNS服务场景：目标DNS服务器 + UDP53端口
4. ICMP Ping场景：允许网络ping
5. 应用服务器端口范围场景：IP范围 + 端口范围
6. 全网络访问场景：允许所有网络和所有协议
7. 私有网络互访场景：大型私有网络 + 管理端口

**测试用例总数：** 7个

### 2.4 边界情况和异常场景测试 (TestProductionTemplates_EdgeCases)

**测试场景：**
1. 空策略名处理（网络对象和服务对象）
2. 特殊字符策略名（连字符和下划线）
3. 长策略名测试
4. 数字策略名
5. 混合大小写策略名

**测试用例总数：** 5个

### 2.5 综合测试 (TestProductionTemplates_Comprehensive)

**测试场景：**
- 网络类型矩阵测试（单IP、CIDR、IP范围、大型网络、IPv6）
- 服务类型矩阵测试（TCP单端口、TCP端口范围、UDP、ICMP、L3协议）
- 策略名矩阵测试（有策略名、无策略名）
- 源/目标地址矩阵测试

**测试用例总数：** 5个（采样测试）

## 3. 测试统计

| 测试组 | 测试用例数 | 状态 |
|--------|-----------|------|
| 网络对象命名测试 | 14 | ✅ 全部通过 |
| 服务对象命名测试 | 18 | ✅ 全部通过 |
| 真实世界场景测试 | 7 | ✅ 全部通过 |
| 边界情况测试 | 5 | ✅ 全部通过 |
| 综合测试 | 5 | ✅ 全部通过 |
| **总计** | **49** | **✅ 全部通过** |

## 4. 关键特性验证

### 4.1 网络对象命名特性
- ✅ 自动识别网络类型（单IP、CIDR、IP范围）
- ✅ 支持源/目标地址区分
- ✅ 支持IPv4和IPv6
- ✅ 策略名为空时自动降级
- ✅ 处理边界情况（全0网络、大型网络等）

### 4.2 服务对象命名特性
- ✅ 自动处理端口信息（有/无端口）
- ✅ 全端口范围不显示端口
- ✅ 协议名称统一小写
- ✅ 策略名为空时自动降级
- ✅ 支持L3协议和ICMP协议

### 4.3 模板健壮性
- ✅ 空策略名处理
- ✅ 特殊字符处理
- ✅ 长策略名处理
- ✅ 各种网络和服务类型组合

## 5. 使用建议

### 5.1 适用场景
- 生产环境防火墙策略配置
- 需要清晰区分源/目标地址的场景
- 需要策略名关联的场景
- 需要支持多种网络和服务类型的场景

### 5.2 配置方式
在 `config.yaml` 中配置：

```yaml
metadata:
  network_object_name_template: |
    {if:exist:policy_name=="true"}{if:policy_name!=""}{policy_name}_{if:is_source=="true"}SRC{else}DST{endif}_{if:type=="range"}{start}_{end}{else if:type=="subnet"}{cidr}{else}{ip}{endif}{else}{if:type=="range"}{start}_{end}{else if:type=="subnet"}{cidr}{else}{ip}{endif}{endif}{else}{if:type=="range"}{start}_{end}{else if:type=="subnet"}{cidr}{else}{ip}{endif}{endif}
  
  service_object_name_template: |
    {if:exist:policy_name=="true"}{if:policy_name!=""}{policy_name}_{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}{else}{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}{endif}{else}{protocol:lower}{if:dst_port!=""}_{dst_port}{endif}{endif}
```

### 5.3 命名示例

**网络对象命名示例：**
- `192.168.1.1` - 单IP，无策略名
- `POLICY_001_SRC_192.168.1.1` - 单IP，源地址，有策略名
- `POLICY_001_DST_192.168.1.0/24` - CIDR网络，目标地址，有策略名
- `POLICY_001_SRC_192.168.1.10_192.168.1.20` - IP范围，源地址，有策略名

**服务对象命名示例：**
- `tcp_80` - TCP端口80，无策略名
- `POLICY_001_tcp_80` - TCP端口80，有策略名
- `POLICY_002_tcp_8080-8090` - TCP端口范围，有策略名
- `POLICY_ICMP_icmp` - ICMP协议，有策略名

## 6. 测试文件位置

- **测试文件：** `pkg/nodemap/node/device/firewall/common/v2/templates_name_production_test.go`
- **模板定义：** 在测试文件顶部作为常量定义

## 7. 运行测试

```bash
# 运行所有生产环境模板测试
go test ./pkg/nodemap/node/device/firewall/common/v2 -run TestProduction

# 运行特定测试组
go test ./pkg/nodemap/node/device/firewall/common/v2 -run TestProductionNetworkObjectNameTemplate
go test ./pkg/nodemap/node/device/firewall/common/v2 -run TestProductionServiceObjectNameTemplate
go test ./pkg/nodemap/node/device/firewall/common/v2 -run TestProductionTemplates_RealWorldScenarios
```

## 8. 总结

本通用命名模板经过49个测试用例的全面验证，覆盖了：
- 各种网络类型（单IP、CIDR、IP范围、IPv6）
- 各种服务类型（TCP、UDP、ICMP、L3协议）
- 各种端口场景（单端口、端口范围、全端口、无端口）
- 各种策略名场景（有策略名、无策略名、空策略名）
- 真实世界使用场景
- 边界情况和异常场景

所有测试均通过，模板已准备好用于生产环境。


package v2

import (
	"fmt"
	"strings"

	"github.com/netxops/keys"
	"github.com/netxops/l2service/pkg/nodemap/api"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall/common"
	"github.com/netxops/utils/dsl"
	"github.com/netxops/utils/network"
	"github.com/netxops/utils/policy"
	"github.com/netxops/utils/service"
)

// ObjectModeConfig 对象模式配置
type ObjectModeConfig struct {
	SourceAddressMode      string // "inline" 或 "object"
	DestinationAddressMode string // "inline" 或 "object"
	ServiceMode            string // "inline" 或 "object"
	VipMipMode             string // "inline" 或 "object" (仅DNAT)
	SnatPoolMode           string // "inline", "interface" 或 "object" (仅SNAT)
	// NAT对象类型（用于确定使用哪个layout）
	DnatObjectType firewall.NatObjectType // VIP, MIP, NETWORK_OBJECT, INLINE (仅DNAT)
	SnatObjectType firewall.NatObjectType // SNAT_POOL, NETWORK_OBJECT, INTERFACE, INLINE (仅SNAT)
}

// NatPolicyConfig NAT策略配置结构体，统一管理所有配置项
type NatPolicyConfig struct {
	// NAT策略名称相关
	NatName         string
	NatNameTemplate string
	NatId           string
	PolicyId        string
	MainID          int

	// NAT类型相关
	NatType        string // "DNAT" 或 "SNAT"
	DnatObjectType string // DNAT对象类型：VIP, MIP, NETWORK_OBJECT, INLINE
	SnatPoolType   string // SNAT_POOL类型：POOL, INTERFACE, ADDRESS_OBJECT, INLINE

	// 对象模式配置（通过 determineObjectMode 生成）
	ObjectMode *ObjectModeConfig

	// 策略行为配置
	Enable      string
	Description string

	// NAT风格配置
	NatStyle string // "twice" 或 "object" (仅ASA)
}

// NewNatPolicyConfigFromMeta 从 metaData 中提取并创建 NatPolicyConfig
func NewNatPolicyConfigFromMeta(metaData map[string]interface{}, intent *policy.Intent) *NatPolicyConfig {
	config := &NatPolicyConfig{}

	// NAT策略名称相关
	config.NatName = getStringFromMeta(metaData, "nat_name", "")
	config.NatNameTemplate = getStringFromMeta(metaData, "natpolicy.name_template", "")
	config.NatId = getStringFromMeta(metaData, "nat_id", "")
	config.PolicyId = getStringFromMeta(metaData, "policy_id", "")

	// NAT类型相关
	// 先根据 intent 判断基本类型
	if intent.RealIp != "" {
		config.NatType = "DNAT"
	} else if intent.Snat != "" {
		config.NatType = "SNAT"
	} else {
		// 检查是否是 interface 模式的 SNAT
		snatPoolType := getStringFromMeta(metaData, "snat_pool_type", "POOL")
		if snatPoolType == "INTERFACE" {
			config.NatType = "SNAT"
		}
	}

	config.DnatObjectType = getStringFromMeta(metaData, "dnat_object_type", "")
	config.SnatPoolType = getStringFromMeta(metaData, "snat_pool_type", "POOL")

	// 策略行为配置
	config.Enable = getStringFromMeta(metaData, "enable", "true")
	config.Description = getStringFromMeta(metaData, "description", "")

	// NAT风格配置
	config.NatStyle = getStringFromMeta(metaData, "natpolicy.asa.nat_style", "twice")

	return config
}

// Validate 验证配置项的有效性
func (config *NatPolicyConfig) Validate() error {
	// 验证 NatType
	if config.NatType != "DNAT" && config.NatType != "SNAT" {
		err := fmt.Errorf("invalid nat_type: %s, must be 'DNAT' or 'SNAT'", config.NatType)
		fmt.Printf("[ERROR] NatPolicyConfig.Validate: %v\n", err)
		fmt.Printf("[ERROR] 当前配置: NatType=%s, NatName=%s\n", config.NatType, config.NatName)
		return err
	}

	// 验证 DnatObjectType（如果设置了）
	if config.DnatObjectType != "" && config.DnatObjectType != "VIP" && config.DnatObjectType != "MIP" && config.DnatObjectType != "NETWORK_OBJECT" && config.DnatObjectType != "INLINE" {
		err := fmt.Errorf("invalid dnat_object_type: %s, must be 'VIP', 'MIP', 'NETWORK_OBJECT', or 'INLINE'", config.DnatObjectType)
		fmt.Printf("[ERROR] NatPolicyConfig.Validate: %v\n", err)
		fmt.Printf("[ERROR] 当前配置: NatType=%s, DnatObjectType=%s, NatName=%s\n", config.NatType, config.DnatObjectType, config.NatName)
		return err
	}

	// 验证 SnatPoolType（如果设置了）
	if config.SnatPoolType != "" && config.SnatPoolType != "SNAT_POOL" && config.SnatPoolType != "INTERFACE" && config.SnatPoolType != "NETWORK_OBJECT" && config.SnatPoolType != "INLINE" {
		err := fmt.Errorf("invalid snat_pool_type: %s, must be 'SNAT_POOL', 'INTERFACE', 'NETWORK_OBJECT', or 'INLINE'", config.SnatPoolType)
		fmt.Printf("[ERROR] NatPolicyConfig.Validate: %v\n", err)
		fmt.Printf("[ERROR] 当前配置: NatType=%s, SnatPoolType=%s, NatName=%s\n", config.NatType, config.SnatPoolType, config.NatName)
		return err
	}

	// 验证 NatStyle（如果设置了）
	if config.NatStyle != "" && config.NatStyle != "twice" && config.NatStyle != "object" {
		err := fmt.Errorf("invalid nat_style: %s, must be 'twice' or 'object'", config.NatStyle)
		fmt.Printf("[ERROR] NatPolicyConfig.Validate: %v\n", err)
		fmt.Printf("[ERROR] 当前配置: NatType=%s, NatStyle=%s, NatName=%s\n", config.NatType, config.NatStyle, config.NatName)
		return err
	}

	return nil
}

// MakeNatPolicyV3 生成NAT策略（V3版本，按过程拆分）
// 该版本将 NAT 策略生成过程拆分为多个独立的步骤，便于维护和扩展
// 使用配置结构体统一管理所有配置项
func (ct *CommonTemplatesV2) MakeNatPolicyV3(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}) (*NatPolicyResult, error) {
	// 步骤1: 初始化结果对象
	result, err := ct.initNatPolicyResult()
	if err != nil {
		return nil, fmt.Errorf("failed to initialize NAT policy result: %v", err)
	}

	// 步骤2: 创建并验证配置
	config := NewNatPolicyConfigFromMeta(metaData, intent)
	if err := config.Validate(); err != nil {
		return nil, fmt.Errorf("invalid NAT policy config: %v", err)
	}

	// 步骤3: 获取zone信息
	fromZone, toZone, err := ct.extractZoneInfo(from, to)
	if err != nil {
		return nil, fmt.Errorf("failed to extract zone info: %v", err)
	}

	// 步骤4: 提取接口信息
	fromInterface, toInterface, err := ct.extractInterfaceInfo(from, to)
	if err != nil {
		return nil, fmt.Errorf("failed to extract interface info: %v", err)
	}

	// 步骤5: 判断NAT类型（如果配置中未设置，从intent判断）
	if config.NatType == "" {
		natType, err := ct.determineNatType(intent, metaData)
		if err != nil {
			return nil, fmt.Errorf("failed to determine NAT type: %v", err)
		}
		config.NatType = natType
	}
	result.NatType = config.NatType

	// 步骤6: 生成NAT策略名称
	natMainID, natName, err := ct.generateNatPolicyNameV3(intent, ctx, config, metaData)
	if err != nil {
		return nil, fmt.Errorf("failed to generate NAT policy name: %v", err)
	}
	result.NatName = natName
	config.NatName = natName
	config.MainID = natMainID

	// 如果 metaData 中没有提供 nat_id 或 policy_id，使用 mainID
	if natMainID > 0 {
		if config.NatId == "" {
			config.NatId = fmt.Sprintf("%d", natMainID)
			metaData["nat_id"] = config.NatId
		}
		if config.PolicyId == "" {
			config.PolicyId = fmt.Sprintf("%d", natMainID)
			metaData["policy_id"] = config.PolicyId
		}
	}

	// 步骤7: 判断对象模式
	objectMode, err := ct.determineObjectModeV3(intent, config, metaData)
	if err != nil {
		return nil, fmt.Errorf("failed to determine object mode: %v", err)
	}
	config.ObjectMode = objectMode

	// 步骤7: 生成地址对象和服务对象（使用统一的通用函数）
	useSourceObject := objectMode.SourceAddressMode == "object"
	useDestinationObject := objectMode.DestinationAddressMode == "object"
	useServiceObject := objectMode.ServiceMode == "object"

	// 生成地址对象
	if err := ct.generateAddressObjects(intent, useSourceObject, useDestinationObject, ctx, metaData, result); err != nil {
		return nil, fmt.Errorf("failed to generate address objects: %v", err)
	}

	// 生成服务对象
	if err := ct.generateServiceObjects(intent, useServiceObject, ctx, metaData, result); err != nil {
		return nil, fmt.Errorf("failed to generate service objects: %v", err)
	}

	// 步骤10: 处理NAT对象（VIP/MIP或SNAT_POOL）
	// 注意：即使是inline模式，也需要调用GetReuseNatObject来确定objectType，但不会生成对象
	// processNatObject 内部会根据 natType 参数区分 DNAT 和 SNAT
	err = ct.processNatObject(intent, ctx, metaData, config.NatType, fromZone, toZone, from, to, objectMode, result)
	if err != nil {
		return nil, fmt.Errorf("failed to process NAT object: %v", err)
	}

	// 步骤12: 处理附属信息
	err = ct.processAuxiliaryInfo(intent, ctx, metaData, fromZone, toZone, fromInterface, toInterface, result)
	if err != nil {
		return nil, fmt.Errorf("failed to process auxiliary info: %v", err)
	}

	// 步骤13: 渲染NAT策略（最终阶段）
	err = ct.renderNatPolicyV3(intent, ctx, config, fromZone, toZone, from, to, objectMode, result, metaData)
	if err != nil {
		return nil, fmt.Errorf("failed to render NAT policy: %v", err)
	}

	return result, nil
}

// initNatPolicyResult 初始化NAT策略结果对象
func (ct *CommonTemplatesV2) initNatPolicyResult() (*NatPolicyResult, error) {
	return &NatPolicyResult{
		SourceObjects:      []string{},
		DestinationObjects: []string{},
		ServiceObjects:     []string{},
		Keys:               []string{},
		FlyObject:          make(map[string]string),
	}, nil
}

// extractZoneInfo 从端口对象中提取zone信息
func (ct *CommonTemplatesV2) extractZoneInfo(from, to api.Port) (fromZone, toZone string, err error) {
	if from != nil {
		if zf, ok := from.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if to != nil {
		if zf, ok := to.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}
	return fromZone, toZone, nil
}

// extractInterfaceInfo 从端口对象中提取接口信息
func (ct *CommonTemplatesV2) extractInterfaceInfo(from, to api.Port) (fromInterface, toInterface string, err error) {
	if from != nil {
		fromInterface = from.Name()
	}
	if to != nil {
		toInterface = to.Name()
	}
	return fromInterface, toInterface, nil
}

// determineNatType 判断NAT类型（DNAT或SNAT）
func (ct *CommonTemplatesV2) determineNatType(intent *policy.Intent, metaData map[string]interface{}) (string, error) {
	if intent.RealIp != "" {
		return "DNAT", nil
	}
	if intent.Snat != "" {
		return "SNAT", nil
	}
	// 检查是否是 interface 模式的 SNAT（不需要 Snat）
	snatPoolType := getStringFromMeta(metaData, "snat_pool_type", "POOL")
	if snatPoolType == "INTERFACE" {
		return "SNAT", nil
	}
	return "", fmt.Errorf("intent must have either RealIp (DNAT) or Snat (SNAT)")
}

// generateNatPolicyNameV3 生成NAT策略名称（使用配置结构体）
// 返回 mainID 和 natName，其中 mainID 可以作为 nat_id 或 policy_id 使用
func (ct *CommonTemplatesV2) generateNatPolicyNameV3(intent *policy.Intent, ctx *firewall.PolicyContext, config *NatPolicyConfig, metaData map[string]interface{}) (int, string, error) {
	var mainID int
	natName := config.NatName
	if natName == "" {
		if policyNameGetter, ok := ct.Node.(interface {
			GetPolicyName(ctx *firewall.PolicyContext) (string, error)
		}); ok {
			name, err := policyNameGetter.GetPolicyName(ctx)
			if err == nil && name != "" {
				natName = name
			}
		}
	}
	if natName == "" {
		natNameTemplate := config.NatNameTemplate
		if natNameTemplate == "" {
			natNameTemplate = getStringFromMeta(metaData, "natpolicy.name_template", "")
		}
		if natNameTemplate != "" {
			// 检查模板是否包含 IDTemplate 语法（{SEQ:...} 或 {VAR:...}）
			hasIDTemplateSyntax := strings.Contains(natNameTemplate, "{SEQ:") || strings.Contains(natNameTemplate, "{VAR:")

			if hasIDTemplateSyntax {
				// 如果模板改变了，需要重新创建 IDTemplate
				if ct.currentNatTemplate != natNameTemplate {
					var getIterator func() firewall.NamerIterator
					if iteratorNode, ok := ct.Node.(firewall.IteratorFirewall); ok {
						// 优先使用 NatIterator，如果没有则使用 PolicyIterator
						if natIteratorNode, ok := iteratorNode.(interface {
							NatIterator(opts ...firewall.IteratorOption) firewall.NamerIterator
						}); ok {
							getIterator = func() firewall.NamerIterator {
								return natIteratorNode.NatIterator()
							}
						} else {
							getIterator = func() firewall.NamerIterator {
								return iteratorNode.PolicyIterator()
							}
						}
					} else {
						getIterator = func() firewall.NamerIterator {
							return &emptyNamerIterator{}
						}
					}
					ct.natTemplate = common.NewPolicyTemplate(natNameTemplate, getIterator).WithMaxRetries(10).Initialize()
					ct.currentNatTemplate = natNameTemplate
				}

				// 准备变量数据
				variables := make(map[string]interface{})
				for k, v := range metaData {
					variables[k] = v
				}
				// 添加 intent 相关的变量
				if intent.Dst() != nil {
					intent.Dst().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
						if ipNet, ok := item.(*network.IPNet); ok {
							variables["dst_network"] = ipNet.IP.String()
						} else {
							variables["dst_network"] = item.String()
						}
						return true
					})
				}
				if intent.Src() != nil {
					intent.Src().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
						if ipNet, ok := item.(*network.IPNet); ok {
							variables["src_network"] = ipNet.IP.String()
						} else {
							variables["src_network"] = item.String()
						}
						return true
					})
				}
				if intent.Service() != nil {
					intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
						if l4, ok := item.(*service.L4Service); ok {
							if !l4.DstPort().IsFull() {
								variables["dst_port"] = l4.DstPort().String()
							}
						}
						return true
					})
				}

				// 使用 IDTemplate 生成 NAT 策略名称
				mainID, natName = ct.natTemplate.Generate(variables)
				natName = strings.TrimSpace(natName)

				// 如果 metaData 中没有提供 nat_id 或 policy_id，使用 mainID
				if getStringFromMeta(metaData, "nat_id", "") == "" && getStringFromMeta(metaData, "policy_id", "") == "" {
					metaData["nat_id"] = fmt.Sprintf("%d", mainID)
					metaData["policy_id"] = fmt.Sprintf("%d", mainID)
				}
			} else if strings.Contains(natNameTemplate, "{dst_network}") || strings.Contains(natNameTemplate, "{src_network}") || strings.Contains(natNameTemplate, "{dst_port}") {
				// 使用 dsl.IntentFormat 处理包含 intent 字段的模板
				nameMeta := copyMap(metaData)
				if intent.Dst() != nil {
					intent.Dst().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
						if ipNet, ok := item.(*network.IPNet); ok {
							nameMeta["dst_network"] = ipNet.IP.String()
						} else {
							nameMeta["dst_network"] = item.String()
						}
						return true
					})
				}
				if intent.Src() != nil {
					intent.Src().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
						if ipNet, ok := item.(*network.IPNet); ok {
							nameMeta["src_network"] = ipNet.IP.String()
						} else {
							nameMeta["src_network"] = item.String()
						}
						return true
					})
				}
				if intent.Service() != nil {
					intent.Service().EachDetailed(func(item service.ServiceEntry) bool {
						if l4, ok := item.(*service.L4Service); ok {
							if !l4.DstPort().IsFull() {
								nameMeta["dst_port"] = l4.DstPort().String()
							}
						}
						return true
					})
				}
				natName = strings.TrimSpace(dsl.IntentFormat(intent, natNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), nameMeta))
			} else {
				// 使用 dsl.MapFormat 处理普通模板
				natName = strings.TrimSpace(dsl.MapFormat(metaData, natNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
			}
		}
	}
	if natName == "" {
		natName = "NAT_POLICY"
		mainID = 0 // 使用默认名称时，mainID 为 0
	}
	return mainID, natName, nil
}

// determineObjectModeV3 判断是否使用object模式（使用配置结构体）
// 统一使用 securitypolicy.* 配置变量，如果没有则回退到 natpolicy.*（向后兼容）
func (ct *CommonTemplatesV2) determineObjectModeV3(intent *policy.Intent, config *NatPolicyConfig, metaData map[string]interface{}) (*ObjectModeConfig, error) {
	objectMode := &ObjectModeConfig{}

	// 判断源地址模式
	// 优先使用 securitypolicy.source_address_style，如果没有则使用 securitypolicy.address_style
	// 最后回退到 natpolicy.* 配置（向后兼容）
	sourceStyle := getStringFromMeta(metaData, "securitypolicy.source_address_style", "")
	if sourceStyle == "" {
		sourceStyle = getStringFromMeta(metaData, "securitypolicy.address_style", "")
	}
	if sourceStyle == "" {
		// 向后兼容：读取 natpolicy 配置
		sourceStyle = getStringFromMeta(metaData, "natpolicy.dnat.source_style", "none")
		if config.NatType == "SNAT" {
			sourceStyle = getStringFromMeta(metaData, "natpolicy.snat.source_style", "none")
		}
		// 处理 required/optional 逻辑
		if sourceStyle == "required" || (sourceStyle == "optional" && intent.Src() != nil && !intent.Src().IsAny(true)) {
			objectMode.SourceAddressMode = "object"
		} else {
			objectMode.SourceAddressMode = "inline"
		}
	} else {
		// 使用 securitypolicy 配置（object/inline）
		if sourceStyle == "object" {
			objectMode.SourceAddressMode = "object"
		} else {
			objectMode.SourceAddressMode = "inline"
		}
	}

	// 判断目标地址模式
	// 优先使用 securitypolicy.destination_address_style，如果没有则使用 securitypolicy.address_style
	// 最后回退到 natpolicy.* 配置（向后兼容）
	destinationStyle := getStringFromMeta(metaData, "securitypolicy.destination_address_style", "")
	if destinationStyle == "" {
		destinationStyle = getStringFromMeta(metaData, "securitypolicy.address_style", "")
	}
	if destinationStyle == "" {
		// 向后兼容：读取 natpolicy 配置
		destinationStyle = getStringFromMeta(metaData, "natpolicy.dnat.destination_style", "none")
		if config.NatType == "SNAT" {
			destinationStyle = getStringFromMeta(metaData, "natpolicy.snat.destination_style", "none")
		}
		// 处理 required/optional 逻辑
		if destinationStyle == "required" || (destinationStyle == "optional" && intent.Dst() != nil && !intent.Dst().IsAny(true)) {
			objectMode.DestinationAddressMode = "object"
		} else {
			objectMode.DestinationAddressMode = "inline"
		}
	} else {
		// 使用 securitypolicy 配置（object/inline）
		if destinationStyle == "object" {
			objectMode.DestinationAddressMode = "object"
		} else {
			objectMode.DestinationAddressMode = "inline"
		}
	}

	// 判断服务模式
	// 优先使用 securitypolicy.service_style，如果没有则检查 securitypolicy.use_service_object
	// 最后回退到 natpolicy.use_service_object（向后兼容）
	serviceStyle := getStringFromMeta(metaData, "securitypolicy.service_style", "")
	if serviceStyle != "" {
		if serviceStyle == "object" {
			objectMode.ServiceMode = "object"
		} else {
			objectMode.ServiceMode = "inline"
		}
	} else {
		// 检查布尔配置
		useServiceObject := getBoolFromMeta(metaData, "securitypolicy.use_service_object", false)
		if !useServiceObject {
			// 向后兼容：读取 natpolicy 配置
			useServiceObject = getBoolFromMeta(metaData, "natpolicy.use_service_object", false)
		}
		if useServiceObject {
			objectMode.ServiceMode = "object"
		} else {
			objectMode.ServiceMode = "inline"
		}
	}

	// 判断VIP/MIP模式（仅DNAT）
	// 使用 DetermineNatObjectType 来确定NAT对象类型，并根据类型获取对应的layout
	if config.NatType == "DNAT" {
		natObjectType, ok := ct.Node.DetermineNatObjectType("DNAT", metaData)
		if !ok {
			// DetermineNatObjectType 返回 false 表示配置存在错误
			return nil, fmt.Errorf("invalid DNAT configuration")
		}
		// 保存对象类型，用于后续获取对应的layout
		objectMode.DnatObjectType = natObjectType
		switch natObjectType {
		case firewall.INLINE:
			objectMode.VipMipMode = "inline"
		case firewall.VIP, firewall.MIP, firewall.NETWORK_OBJECT:
			// VIP、MIP、NETWORK_OBJECT 都使用object模式
			// 具体使用哪个layout（Vip、Mip、AddressObject/AddressGroup）由对象类型决定
			objectMode.VipMipMode = "object"
		default:
			// 其他未支持的类型
			return nil, fmt.Errorf("unsupported DNAT object type: %v", natObjectType)
		}
	}

	// 判断SNAT_POOL模式（仅SNAT）
	// 使用 DetermineNatObjectType 来确定NAT对象类型，并根据类型获取对应的layout
	if config.NatType == "SNAT" {
		natObjectType, ok := ct.Node.DetermineNatObjectType("SNAT", metaData)
		if !ok {
			// DetermineNatObjectType 返回 false 表示配置存在错误
			return nil, fmt.Errorf("invalid SNAT configuration")
		}
		// 保存对象类型，用于后续获取对应的layout
		objectMode.SnatObjectType = natObjectType
		switch natObjectType {
		case firewall.INLINE:
			objectMode.SnatPoolMode = "inline"
		case firewall.INTERFACE:
			objectMode.SnatPoolMode = "interface"
		case firewall.SNAT_POOL, firewall.NETWORK_OBJECT:
			// SNAT_POOL、NETWORK_OBJECT 都使用object模式
			// 具体使用哪个layout（SnatPool、AddressObject/AddressGroup）由对象类型决定
			objectMode.SnatPoolMode = "object"
		default:
			// 其他未支持的类型
			return nil, fmt.Errorf("unsupported SNAT object type: %v", natObjectType)
		}
	}

	return objectMode, nil
}

// processNatObject 处理NAT对象（VIP/MIP或SNAT_POOL）
// 流程：
// 1. 调用GetReuseNatObject，明确复用还是新建
// 2. 如果是INLINE或INTERFACE模式，直接返回（不生成对象）
// 3. 根据objectMode中的对象类型生成对象（VIP/MIP/SNAT_POOL/NETWORK_OBJECT）
// 4. 整合所有数据（设置result中的字段）
func (ct *CommonTemplatesV2) processNatObject(intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}, natType, fromZone, toZone string, from, to api.Port, objectMode *ObjectModeConfig, result *NatPolicyResult) error {
	// 步骤1: 调用GetReuseNatObject，明确复用还是新建
	reusedName, reused := ct.Node.GetReuseNatObject(natType, intent, metaData)
	if reused {
		// 找到复用对象，设置对象名称
		if natType == "DNAT" {
			result.VipMipName = reusedName
		} else if natType == "SNAT" {
			result.SnatPoolName = reusedName
		}
		result.IsReused = true
		return nil
	}

	// 步骤2: 检查是否是INLINE或INTERFACE模式（不生成对象）
	if natType == "DNAT" {
		if objectMode.DnatObjectType == firewall.INLINE {
			// inline模式：不生成对象，real_ip和real_port会在renderNatPolicy中直接使用
			return nil
		}
		// 步骤3: 根据objectMode.DnatObjectType生成对象
		return ct.processVipMipObjectLegacy(intent, ctx, metaData, fromZone, toZone, from, to, objectMode, result)
	} else if natType == "SNAT" {
		if objectMode.SnatObjectType == firewall.INLINE || objectMode.SnatObjectType == firewall.INTERFACE {
			// inline或interface模式：不生成对象
			return nil
		}
		// 步骤3: 根据objectMode.SnatObjectType生成对象
		return ct.processSnatPoolObjectLegacy(intent, ctx, metaData, fromZone, toZone, from, to, objectMode, result)
	}
	return fmt.Errorf("unsupported NAT type: %s", natType)
}

// processVipMipObjectLegacy 处理VIP/MIP对象（简化设计）
// 根据objectMode.DnatObjectType确定使用哪个layout（VIP layout、MIP layout 或 address object layout），然后直接利用layout生成命令行
// 注意：前序processNatObject已经进行过reuse检查和INLINE模式检查，这里不需要重复检查
func (ct *CommonTemplatesV2) processVipMipObjectLegacy(intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}, fromZone, toZone string, from, to api.Port, objectMode *ObjectModeConfig, result *NatPolicyResult) error {
	// 步骤1: 根据objectMode.DnatObjectType判断需要使用哪个layout
	// determineObjectModeV3已经处理过对象类型判断，这里直接使用
	var layoutType string // "VIP", "MIP", 或 "NETWORK_OBJECT"
	var layoutKey keys.Keys

	// 只根据objectMode.DnatObjectType来判断使用哪个layout，不需要fallback
	switch objectMode.DnatObjectType {
	case firewall.NETWORK_OBJECT:
		// 使用address object layout
		layoutType = "NETWORK_OBJECT"
	case firewall.VIP:
		// 使用VIP layout
		layoutType = "VIP"
		layoutKey = keys.NewKeyBuilder("Vip", "OneLoop")
	case firewall.MIP:
		// 使用MIP layout
		layoutType = "MIP"
		layoutKey = keys.NewKeyBuilder("Mip", "OneLoop")
	default:
		return fmt.Errorf("unsupported DNAT object type: %v", objectMode.DnatObjectType)
	}

	// 步骤2: 如果是NETWORK_OBJECT，使用MakeAddressObjectV2生成地址对象
	if layoutType == "NETWORK_OBJECT" {
		if intent.RealIp == "" {
			return fmt.Errorf("failed to create address object: RealIp is empty")
		}

		// 前序已经检查过复用，这里直接生成新对象
		realIpNg, _ := network.NewNetworkGroupFromString(intent.RealIp)
		addressIntent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				realIpNg,
				service.NewServiceMust("ip"),
			),
			RealIp:   intent.RealIp,
			RealPort: intent.RealPort,
		}
		addressResult, err := ct.MakeAddressObjectV2(addressIntent, false, ctx, metaData)
		if err != nil {
			return fmt.Errorf("failed to create address object: %v", err)
		}
		if len(addressResult.ObjectNames) > 0 {
			result.VipMipName = addressResult.ObjectNames[0]
			result.Keys = append(result.Keys, addressResult.Keys...)
			if addressResult.CLIString != "" {
				// 获取各个防火墙特有的 SectionSeparator（从模板中获取）
				sectionSeparator := ct.Templates.GetLayout(keys.NewKeyBuilder("SectionSeparator"))
				if sectionSeparator == "" {
					// 如果模板中没有定义，使用默认值 "#"
					sectionSeparator = "#"
				}

				if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
					existing = strings.TrimRight(existing, "\n\r")
					addressCli := strings.TrimLeft(addressResult.CLIString, "\n\r")
					result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + sectionSeparator + "\n" + addressCli
				} else {
					result.FlyObject[common.FlyObjectNetwork] = addressResult.CLIString
				}
				// 使用 SectionSeparator 分隔多个 CLI 字符串
				if result.CLIString != "" {
					result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + sectionSeparator + "\n" + strings.TrimLeft(addressResult.CLIString, "\n\r")
				} else {
					result.CLIString = addressResult.CLIString
				}
			}
			return nil
		}
		return fmt.Errorf("failed to create address object: no object names returned")
	}

	// 步骤3: 如果是VIP或MIP，检查layout是否存在，然后直接渲染
	layout := ct.Templates.GetLayout(layoutKey)
	if layout == "" || strings.TrimSpace(layout) == "" {
		return fmt.Errorf("%s layout is empty, cannot render %s object", layoutType, layoutType)
	}

	// 步骤4: 数据整理 - 准备用于渲染的meta数据
	renderIntent := intent
	vipMipMeta := ct.prepareVipMipMetaData(intent, metaData, layoutType, fromZone, toZone, from, to)

	// 步骤5: 对象命名
	objectName := ct.generateVipMipObjectName(intent, metaData, layoutType, renderIntent)

	// 检查对象复用（通过名称）
	key := keys.NewKeyBuilder(objectName).Separator("_")
	key, isNew, err := ct.generateUniqueObjectNameV2(keys.NewAutoIncrementKeys(key, 2), renderIntent.Dst())
	if err != nil {
		return fmt.Errorf("failed to generate unique object name: %v", err)
	}

	// 更新meta数据中的对象名称
	vipMipMeta["object_name"] = key.String()
	if !isNew {
		vipMipMeta["is_reused"] = "true"
		result.IsReused = true
	} else {
		vipMipMeta["is_reused"] = "false"
	}

	// 步骤6: 如果未复用，渲染对应的layout生成CLI
	if isNew {
		vipMipCli := dsl.IntentFormat(renderIntent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), vipMipMeta)
		if vipMipCli != "" {
			// 设置FlyObject
			var flyObjectKey string
			switch layoutType {
			case "VIP":
				flyObjectKey = common.FlyObjectVip
			case "MIP":
				flyObjectKey = common.FlyObjectMip
			default:
				flyObjectKey = layoutType
			}
			result.FlyObject[flyObjectKey] = vipMipCli
			result.CLIString += vipMipCli + "\n"
		}
	}

	// 设置对象名称
	result.VipMipName = key.String()
	result.Keys = append(result.Keys, key.String())

	return nil
}

// prepareVipMipMetaData 准备VIP/MIP渲染所需的meta数据
func (ct *CommonTemplatesV2) prepareVipMipMetaData(intent *policy.Intent, metaData map[string]interface{}, layoutType, fromZone, toZone string, from, to api.Port) map[string]interface{} {
	vipMipMeta := copyMap(metaData)
	vipMipMeta["obj_type"] = layoutType

	if intent.RealPort != "" {
		vipMipMeta["has_real_port"] = "true"
		vipMipMeta["real_port"] = intent.RealPort
	}

	// 解析real_ip
	if intent.RealIp != "" {
		vipMipMeta["real_ip"] = intent.RealIp
		if strings.Contains(intent.RealIp, "-") {
			parts := strings.Split(intent.RealIp, "-")
			if len(parts) == 2 {
				vipMipMeta["real_ip_start"] = strings.TrimSpace(parts[0])
				vipMipMeta["real_ip_end"] = strings.TrimSpace(parts[1])
			}
		}
	}

	// 设置zone信息
	if fromZone != "" {
		vipMipMeta["fromZone"] = fromZone
	} else if from != nil {
		vipMipMeta["fromPort"] = from.Name()
	}
	if toZone != "" {
		vipMipMeta["toZone"] = toZone
	} else if to != nil {
		vipMipMeta["toPort"] = to.Name()
	}

	return vipMipMeta
}

// generateVipMipObjectName 生成VIP/MIP对象名称
func (ct *CommonTemplatesV2) generateVipMipObjectName(intent *policy.Intent, metaData map[string]interface{}, layoutType string, renderIntent *policy.Intent) string {
	// 优先使用直接指定的对象名称
	objectName := getStringFromMeta(metaData, "object_name", "")
	if objectName != "" {
		return objectName
	}

	// 尝试使用Node的自动命名接口
	if nameGenerator, ok := ct.Node.(interface {
		GenerateVipMipSnatPoolName(objectType string, intent *policy.Intent, metaData map[string]interface{}) string
	}); ok {
		objectName = nameGenerator.GenerateVipMipSnatPoolName(layoutType, intent, metaData)
		if objectName != "" {
			return objectName
		}
	}

	// 使用配置的命名模板
	nameTemplate := getStringFromMeta(metaData, layoutType+"_name_template", "")
	if nameTemplate == "" {
		if layoutType == "VIP" {
			nameTemplate = getStringFromMeta(metaData, "vip_name_template", "")
		} else {
			nameTemplate = getStringFromMeta(metaData, "mip_name_template", "")
		}
	}

	if nameTemplate != "" {
		// 从模板生成名称
		nameMeta := copyMap(metaData)
		if renderIntent.Dst() != nil {
			renderIntent.Dst().EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
				if ipNet, ok := item.(*network.IPNet); ok {
					nameMeta["dst_network"] = ipNet.IP.String()
				} else {
					nameMeta["dst_network"] = item.String()
				}
				return true
			})
		}
		if renderIntent.RealPort != "" {
			nameMeta["dst_port"] = renderIntent.RealPort
		} else if renderIntent.Service() != nil {
			renderIntent.Service().EachDetailed(func(item service.ServiceEntry) bool {
				if l4, ok := item.(*service.L4Service); ok {
					if !l4.DstPort().IsFull() {
						nameMeta["dst_port"] = l4.DstPort().String()
					}
				}
				return true
			})
		}
		objectName = strings.TrimSpace(dsl.IntentFormat(renderIntent, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), nameMeta))
		if objectName != "" {
			return objectName
		}
	}

	// 如果仍然为空，使用默认名称
	if intent.RealIp != "" {
		return layoutType + "_" + strings.ReplaceAll(intent.RealIp, ".", "_")
	}
	return layoutType + "_OBJECT"
}

// determineVipMipType 判断VIP/MIP类型（通过real_port判断）
func (ct *CommonTemplatesV2) determineVipMipType(intent *policy.Intent, metaData map[string]interface{}) (string, error) {
	hasRealPort := intent.RealPort != ""
	if hasRealPort {
		return "VIP", nil
	}
	return "MIP", nil
}

// processSnatPoolObjectLegacy 处理SNAT_POOL对象
// 根据objectMode.SnatObjectType确定使用哪个layout（SnatPool layout 或 address object layout），然后直接利用layout生成命令行
func (ct *CommonTemplatesV2) processSnatPoolObjectLegacy(intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}, fromZone, toZone string, from, to api.Port, objectMode *ObjectModeConfig, result *NatPolicyResult) error {
	// 步骤1: 根据objectMode.SnatObjectType判断需要使用哪个layout
	// determineObjectModeV3已经处理过对象类型判断，这里直接使用
	selectedType := objectMode.SnatObjectType

	// 步骤2: 如果使用网络对象（没有特殊语法）
	if selectedType == firewall.NETWORK_OBJECT {
		if intent.Snat != "" {
			snatNg, err := network.NewNetworkGroupFromString(intent.Snat)
			if err != nil {
				return fmt.Errorf("failed to parse SNAT network: %v", err)
			}
			existingObj, foundExisting := ct.Node.GetObjectByNetworkGroup(snatNg, firewall.SEARCH_OBJECT_OR_GROUP, nil)

			if foundExisting {
				// 找到复用对象，使用复用的对象名称
				result.SnatPoolName = existingObj.Name()
				result.IsReused = true
				return nil
			}
			// 未找到：生成新的Object（使用MakeAddressObjectV2）
			addressIntent := &policy.Intent{
				PolicyEntry: *policy.NewPolicyEntryWithAll(
					snatNg,
					network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
					service.NewServiceMust("ip"),
				),
				Snat: intent.Snat,
			}
			addressResult, err := ct.MakeAddressObjectV2(addressIntent, true, ctx, metaData)
			if err != nil {
				return fmt.Errorf("failed to create address object for SNAT_POOL: %v", err)
			}
			if len(addressResult.ObjectNames) > 0 {
				result.SnatPoolName = addressResult.ObjectNames[0]
				result.Keys = append(result.Keys, addressResult.Keys...)
				if addressResult.CLIString != "" {
					// 获取各个防火墙特有的 SectionSeparator（从模板中获取）
					sectionSeparator := ct.Templates.GetLayout(keys.NewKeyBuilder("SectionSeparator"))
					if sectionSeparator == "" {
						// 如果模板中没有定义，使用默认值 "#"
						sectionSeparator = "#"
					}

					if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
						existing = strings.TrimRight(existing, "\n\r")
						addressCli := strings.TrimLeft(addressResult.CLIString, "\n\r")
						result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + sectionSeparator + "\n" + addressCli
					} else {
						result.FlyObject[common.FlyObjectNetwork] = addressResult.CLIString
					}
					// 使用 SectionSeparator 分隔多个 CLI 字符串
					if result.CLIString != "" {
						result.CLIString = strings.TrimRight(result.CLIString, "\n\r") + "\n" + sectionSeparator + "\n" + strings.TrimLeft(addressResult.CLIString, "\n\r")
					} else {
						result.CLIString = addressResult.CLIString
					}
				}
				return nil
			}
		}
		return fmt.Errorf("failed to create address object for SNAT_POOL")
	}

	// 步骤3: 有特殊语法（SNAT_POOL）
	// 检查是否选择了特殊语法类型
	if selectedType != firewall.SNAT_POOL {
		return fmt.Errorf("unsupported SNAT object type: %v", selectedType)
	}

	// 选择对应的layout（SnatPool）
	layout, err := ct.selectSnatPoolLayout(metaData)
	if err != nil {
		return fmt.Errorf("failed to select SNAT_POOL layout: %v", err)
	}
	if layout == "" || strings.TrimSpace(layout) == "" {
		return fmt.Errorf("SNAT_POOL layout is empty, cannot render SNAT_POOL object")
	}

	// 注意：复用检查已经在 processNatObject 中通过 GetReuseNatObject 处理过了
	// 这里直接生成新的SNAT_POOL对象
	poolMeta := copyMap(metaData)
	// 根据对象类型设置poolType字符串（用于MakeSnatPoolV2）
	if selectedType == firewall.SNAT_POOL {
		poolMeta["snat_pool_type"] = "POOL"
	} else if selectedType == firewall.NETWORK_OBJECT {
		poolMeta["snat_pool_type"] = "ADDRESS_OBJECT"
	} else {
		poolMeta["snat_pool_type"] = "POOL" // 默认值
	}
	poolResult, err := ct.MakeSnatPoolV2(intent, ctx, poolMeta)
	if err != nil {
		return fmt.Errorf("failed to create SNAT_POOL: %v", err)
	}
	result.SnatPoolName = poolResult.PoolName
	// 保存 PoolId（可能与 PoolName 不同，如 USG 的情况）
	// 如果 PoolId 为空，使用 PoolName 作为 fallback
	if poolResult.PoolId != "" {
		result.SnatPoolId = poolResult.PoolId
	} else {
		result.SnatPoolId = poolResult.PoolName
	}
	result.Keys = append(result.Keys, poolResult.Keys...)
	if poolResult.CLIString != "" {
		// 获取各个防火墙特有的 SectionSeparator（从模板中获取）
		sectionSeparator := ct.Templates.GetLayout(keys.NewKeyBuilder("SectionSeparator"))
		if sectionSeparator == "" {
			// 如果模板中没有定义，使用默认值 "#"
			sectionSeparator = "#"
		}

		// // POOL 对象也是地址对象，应该合并到 NETWORK 类别，使用分隔符分隔
		// if existing, exists := result.FlyObject[common.FlyObjectNetwork]; exists && existing != "" {
		// 	existing = strings.TrimRight(existing, "\n\r")
		// 	poolCli := strings.TrimLeft(poolResult.CLIString, "\n\r")
		// 	result.FlyObject[common.FlyObjectNetwork] = existing + "\n" + sectionSeparator + "\n" + poolCli
		// } else {
		// 	result.FlyObject[common.FlyObjectNetwork] = poolResult.CLIString
		// }
		// 同时保留 POOL 键以便测试代码访问
		result.FlyObject[common.FlyObjectPool] = poolResult.CLIString
		result.CLIString += poolResult.CLIString + "\n"
	}

	return nil
}

// selectSnatPoolLayout 选择SNAT_POOL layout
func (ct *CommonTemplatesV2) selectSnatPoolLayout(metaData map[string]interface{}) (string, error) {
	// poolType := getStringFromMeta(metaData, "snat_pool_type", "POOL")
	// layout := ct.Templates.GetLayout(keys.NewKeyBuilder("SnatPool", poolType))
	// if layout == "" {
	// 	// 回退到默认的OneLoop layout
	layout := ct.Templates.GetLayout(keys.NewKeyBuilder("SnatPool", "OneLoop"))
	// }
	return layout, nil
}

// processAuxiliaryInfo 处理附属信息
func (ct *CommonTemplatesV2) processAuxiliaryInfo(intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}, fromZone, toZone, fromInterface, toInterface string, result *NatPolicyResult) error {
	// 附属信息（区域、接口、描述、开启关闭、log）将在renderNatPolicy中处理
	// 这里可以预留处理逻辑
	return nil
}

// renderNatPolicyV3 渲染NAT策略（最终阶段，使用配置结构体）
func (ct *CommonTemplatesV2) renderNatPolicyV3(intent *policy.Intent, ctx *firewall.PolicyContext, config *NatPolicyConfig, fromZone, toZone string, from, to api.Port, objectMode *ObjectModeConfig, result *NatPolicyResult, metaData map[string]interface{}) error {
	// 准备NAT策略模板数据
	data, err := ct.prepareNatPolicyDataV3(intent, ctx, config, fromZone, toZone, from, to, objectMode, result, metaData)
	if err != nil {
		return fmt.Errorf("failed to prepare NAT policy data: %v", err)
	}

	// 选择NAT策略layout
	layout, err := ct.selectNatPolicyLayout(metaData)
	if err != nil {
		return fmt.Errorf("failed to select NAT policy layout: %v", err)
	}

	// 渲染NAT策略模板
	natCli, err := ct.renderNatPolicyTemplate(intent, layout, data)
	if err != nil {
		return fmt.Errorf("failed to render NAT policy template: %v", err)
	}

	// 处理Object NAT特殊情况（追加到object定义后）
	if config.NatStyle == "object" {
		err = ct.handleObjectNatSpecialCase(config.NatType, natCli, data, result)
		if err != nil {
			return fmt.Errorf("failed to handle Object NAT special case: %v", err)
		}
	} else {
		// Twice NAT: 使用独立的 NAT 配置
		result.FlyObject[common.FlyObjectNat] = natCli
		result.CLIString += natCli
	}

	return nil
}

// prepareNatPolicyDataV3 准备NAT策略模板数据（使用配置结构体）
func (ct *CommonTemplatesV2) prepareNatPolicyDataV3(intent *policy.Intent, ctx *firewall.PolicyContext, config *NatPolicyConfig, fromZone, toZone string, from, to api.Port, objectMode *ObjectModeConfig, result *NatPolicyResult, metaData map[string]interface{}) (map[string]interface{}, error) {
	data := copyMap(metaData)

	// 基本NAT信息
	data["nat_type"] = config.NatType
	data["nat_name"] = config.NatName
	data["nat_rule_name"] = config.NatName

	// 处理 enable 字段
	enableValue := config.Enable
	if enableValue == "enable" {
		data["enable"] = "true"
	} else if enableValue == "disable" {
		data["enable"] = "false"
	} else {
		data["enable"] = enableValue
	}

	// Zone信息
	if fromZone != "" {
		data["fromZone"] = fromZone
		data["sourceZones"] = []interface{}{fromZone}
	}
	if toZone != "" {
		data["toZone"] = toZone
		data["destinationZones"] = []interface{}{toZone}
	}

	// 接口信息
	if from != nil {
		data["fromPort"] = from.Name()
		data["has_fromPort"] = "true"
	}
	if to != nil {
		data["toPort"] = to.Name()
		data["has_toPort"] = "true"
	}

	// 源地址：inline模式使用intent.src，object模式使用源地址对象名称
	if objectMode.SourceAddressMode == "object" && len(result.SourceObjects) > 0 {
		srcObjs := make([]interface{}, len(result.SourceObjects))
		for i, obj := range result.SourceObjects {
			srcObjs[i] = obj
		}
		data["src_objects"] = srcObjs
		data["sourceObjects"] = srcObjs
		data["source_objects"] = srcObjs
		data["has_source_objects"] = "true"
	}

	// 目标地址：inline模式使用intent.dst，object模式使用目标地址对象名称
	if objectMode.DestinationAddressMode == "object" && len(result.DestinationObjects) > 0 {
		dstObjs := make([]interface{}, len(result.DestinationObjects))
		for i, obj := range result.DestinationObjects {
			dstObjs[i] = obj
		}
		data["dst_objects"] = dstObjs
		data["destinationObjects"] = dstObjs
		data["destination_objects"] = dstObjs
		data["has_destination_objects"] = "true"
	}

	// 服务：inline模式使用intent.service，object模式使用服务对象名称
	if objectMode.ServiceMode == "object" && len(result.ServiceObjects) > 0 {
		svcObjs := make([]interface{}, len(result.ServiceObjects))
		for i, obj := range result.ServiceObjects {
			svcObjs[i] = obj
		}
		data["service_objects"] = svcObjs
		data["serviceObjects"] = svcObjs
		data["has_service_objects"] = "true"
	}

	// VIP/MIP（DNAT）：inline模式使用real_ip/real_port，object模式使用VIP/MIP对象名称
	if config.NatType == "DNAT" {
		if intent.RealIp != "" {
			data["has_real_ip"] = "true"
		}
		if intent.RealPort != "" {
			data["has_real_port"] = "true"
		}
		if objectMode.VipMipMode == "object" && result.VipMipName != "" {
			data["vip_name"] = result.VipMipName
			data["mip_name"] = result.VipMipName
			data["has_vip_name"] = "true"
			data["has_mip_name"] = "true"
			vipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Vip", "OneLoop"))
			if vipLayout != "" && strings.TrimSpace(vipLayout) != "" {
				data["use_vip"] = "true"
			}
			// 检查 MIP 是否作为地址对象（Sangfor 的情况）
			mipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Mip", "OneLoop"))
			if (mipLayout == "" || strings.TrimSpace(mipLayout) == "") && (vipLayout == "" || strings.TrimSpace(vipLayout) == "") {
				// MIP 作为地址对象
				data["mip_object"] = result.VipMipName
				data["has_mip_object"] = "true"
			}
		}
	}

	// SNAT_POOL（SNAT）：inline模式使用snat，interface模式使用接口名称，object模式使用SNAT_POOL对象名称
	if config.NatType == "SNAT" {
		data["has_snat"] = "true"
		if objectMode.SnatPoolMode == "interface" {
			if to != nil && to.Name() != "" {
				data["interface_name"] = to.Name()
				data["has_interface_name"] = "true"
			}
		} else if objectMode.SnatPoolMode == "inline" {
			data["has_snat_inline"] = "true"
		} else if objectMode.SnatPoolMode == "object" && result.SnatPoolName != "" {
			// 使用 SnatPoolId 作为 pool_id（如果存在），否则使用 SnatPoolName
			// 某些防火墙（如 USG）的 pool_id 可能与 pool_name 不同
			poolId := result.SnatPoolId
			if poolId == "" {
				poolId = result.SnatPoolName
			}
			data["pool_id"] = poolId
			data["pool_name"] = result.SnatPoolName
			data["use_pool"] = "true"
			data["has_pool_id"] = "true"
		}
	}

	// 描述
	if config.Description != "" {
		data["description"] = config.Description
		data["has_description"] = "true"
	}

	return data, nil
}

// prepareNatPolicyData 准备NAT策略模板数据
func (ct *CommonTemplatesV2) prepareNatPolicyData(intent *policy.Intent, ctx *firewall.PolicyContext, metaData map[string]interface{}, natType, natName, fromZone, toZone string, from, to api.Port, objectMode *ObjectModeConfig, result *NatPolicyResult) (map[string]interface{}, error) {
	data := copyMap(metaData)

	// 基本NAT信息
	data["nat_type"] = natType
	data["nat_name"] = natName
	data["nat_rule_name"] = natName

	// 处理 enable 字段
	enableValue := getStringFromMeta(metaData, "enable", "true")
	if enableValue == "enable" {
		data["enable"] = "true"
	} else if enableValue == "disable" {
		data["enable"] = "false"
	} else {
		data["enable"] = enableValue
	}

	// Zone信息
	if fromZone != "" {
		data["fromZone"] = fromZone
		data["sourceZones"] = []interface{}{fromZone}
	}
	if toZone != "" {
		data["toZone"] = toZone
		data["destinationZones"] = []interface{}{toZone}
	}

	// 接口信息
	if from != nil {
		data["fromPort"] = from.Name()
		data["has_fromPort"] = "true"
	}
	if to != nil {
		data["toPort"] = to.Name()
		data["has_toPort"] = "true"
	}

	// 源地址：inline模式使用intent.src，object模式使用源地址对象名称
	if objectMode.SourceAddressMode == "object" && len(result.SourceObjects) > 0 {
		srcObjs := make([]interface{}, len(result.SourceObjects))
		for i, obj := range result.SourceObjects {
			srcObjs[i] = obj
		}
		data["src_objects"] = srcObjs
		data["sourceObjects"] = srcObjs
		data["source_objects"] = srcObjs
		data["has_source_objects"] = "true"
	}

	// 目标地址：inline模式使用intent.dst，object模式使用目标地址对象名称
	if objectMode.DestinationAddressMode == "object" && len(result.DestinationObjects) > 0 {
		dstObjs := make([]interface{}, len(result.DestinationObjects))
		for i, obj := range result.DestinationObjects {
			dstObjs[i] = obj
		}
		data["dst_objects"] = dstObjs
		data["destinationObjects"] = dstObjs
		data["destination_objects"] = dstObjs
		data["has_destination_objects"] = "true"
	}

	// 服务：inline模式使用intent.service，object模式使用服务对象名称
	if objectMode.ServiceMode == "object" && len(result.ServiceObjects) > 0 {
		svcObjs := make([]interface{}, len(result.ServiceObjects))
		for i, obj := range result.ServiceObjects {
			svcObjs[i] = obj
		}
		data["service_objects"] = svcObjs
		data["serviceObjects"] = svcObjs
		data["has_service_objects"] = "true"
	}

	// VIP/MIP（DNAT）：inline模式使用real_ip/real_port，object模式使用VIP/MIP对象名称
	if natType == "DNAT" {
		if intent.RealIp != "" {
			data["has_real_ip"] = "true"
		}
		if intent.RealPort != "" {
			data["has_real_port"] = "true"
		}
		if objectMode.VipMipMode == "object" && result.VipMipName != "" {
			data["vip_name"] = result.VipMipName
			data["mip_name"] = result.VipMipName
			data["has_vip_name"] = "true"
			data["has_mip_name"] = "true"
			vipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Vip", "OneLoop"))
			if vipLayout != "" && strings.TrimSpace(vipLayout) != "" {
				data["use_vip"] = "true"
			}
			// 检查 MIP 是否作为地址对象（Sangfor 的情况）
			mipLayout := ct.Templates.GetLayout(keys.NewKeyBuilder("Mip", "OneLoop"))
			if (mipLayout == "" || strings.TrimSpace(mipLayout) == "") && (vipLayout == "" || strings.TrimSpace(vipLayout) == "") {
				// MIP 作为地址对象
				data["mip_object"] = result.VipMipName
				data["has_mip_object"] = "true"
			}
		}
	}

	// SNAT_POOL（SNAT）：inline模式使用snat，interface模式使用接口名称，object模式使用SNAT_POOL对象名称
	if natType == "SNAT" {
		data["has_snat"] = "true"
		if objectMode.SnatPoolMode == "interface" {
			if to != nil && to.Name() != "" {
				data["interface_name"] = to.Name()
				data["has_interface_name"] = "true"
			}
		} else if objectMode.SnatPoolMode == "inline" {
			data["has_snat_inline"] = "true"
		} else if objectMode.SnatPoolMode == "object" && result.SnatPoolName != "" {
			// 使用 SnatPoolId 作为 pool_id（如果存在），否则使用 SnatPoolName
			// 某些防火墙（如 USG）的 pool_id 可能与 pool_name 不同
			poolId := result.SnatPoolId
			if poolId == "" {
				poolId = result.SnatPoolName
			}
			data["pool_id"] = poolId
			data["pool_name"] = result.SnatPoolName
			data["use_pool"] = "true"
			data["has_pool_id"] = "true"
		}
	}

	return data, nil
}

// selectNatPolicyLayout 选择NAT策略layout
func (ct *CommonTemplatesV2) selectNatPolicyLayout(metaData map[string]interface{}) (keys.Keys, error) {
	natStyle := getStringFromMeta(metaData, "natpolicy.asa.nat_style", "twice")
	if natStyle == "object" {
		return keys.NewKeyBuilder("NatPolicy", "ObjectNat"), nil
	}
	return keys.NewKeyBuilder("NatPolicy", "OneLoop"), nil
}

// renderNatPolicyTemplate 渲染NAT策略模板
func (ct *CommonTemplatesV2) renderNatPolicyTemplate(intent *policy.Intent, layoutKey keys.Keys, data map[string]interface{}) (string, error) {
	layout := ct.Templates.GetLayout(layoutKey)
	if layout == "" {
		return "", fmt.Errorf("NAT layout not found for key: %v", layoutKey)
	}

	natCli := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)
	return natCli, nil
}

// handleObjectNatSpecialCase 处理Object NAT特殊情况（追加到object定义后）
func (ct *CommonTemplatesV2) handleObjectNatSpecialCase(natType, natCli string, data map[string]interface{}, result *NatPolicyResult) error {
	if natType == "DNAT" && data["has_real_ip_object"] == "true" {
		// DNAT: 追加到 real_ip_object 定义之后
		objectName := data["real_ip_object"].(string)
		if networkCli, exists := result.FlyObject[common.FlyObjectNetwork]; exists && networkCli != "" {
			objectPattern := fmt.Sprintf("object network %s", objectName)
			idx := strings.Index(networkCli, objectPattern)
			if idx >= 0 {
				remaining := networkCli[idx:]
				nextObjectIdx := strings.Index(remaining, "\nobject ")
				if nextObjectIdx < 0 {
					nextObjectIdx = len(remaining)
				}
				objectDefEnd := idx + nextObjectIdx
				beforeNat := networkCli[:objectDefEnd]
				afterNat := networkCli[objectDefEnd:]
				beforeNat = strings.TrimRight(beforeNat, "\n\r") + "\n"
				natCliWithIndent := strings.TrimLeft(natCli, " \t")
				if natCliWithIndent != "" {
					natCliWithIndent = " " + natCliWithIndent
				}
				result.FlyObject[common.FlyObjectNetwork] = beforeNat + natCliWithIndent + afterNat
			} else {
				result.FlyObject[common.FlyObjectNetwork] = networkCli + "\n" + natCli
			}
		} else {
			result.FlyObject[common.FlyObjectNetwork] = natCli
		}
	} else if natType == "SNAT" && data["has_source_objects"] == "true" {
		// SNAT: 追加到 src_objects[0] 定义之后
		if srcObjs, ok := data["src_objects"].([]interface{}); ok && len(srcObjs) > 0 {
			objectName := srcObjs[0].(string)
			if networkCli, exists := result.FlyObject[common.FlyObjectNetwork]; exists && networkCli != "" {
				objectPattern := fmt.Sprintf("object network %s", objectName)
				idx := strings.Index(networkCli, objectPattern)
				if idx >= 0 {
					remaining := networkCli[idx:]
					nextObjectIdx := strings.Index(remaining, "\nobject ")
					if nextObjectIdx < 0 {
						nextObjectIdx = len(remaining)
					}
					objectDefEnd := idx + nextObjectIdx
					beforeNat := networkCli[:objectDefEnd]
					afterNat := networkCli[objectDefEnd:]
					beforeNat = strings.TrimRight(beforeNat, "\n\r") + "\n"
					natCliWithIndent := strings.TrimLeft(natCli, " \t")
					if natCliWithIndent != "" {
						natCliWithIndent = " " + natCliWithIndent
					}
					result.FlyObject["NETWORK"] = beforeNat + natCliWithIndent + afterNat
				} else {
					result.FlyObject["NETWORK"] = networkCli + "\n" + natCli
				}
			} else {
				result.FlyObject["NETWORK"] = natCli
			}
		}
	}
	return nil
}

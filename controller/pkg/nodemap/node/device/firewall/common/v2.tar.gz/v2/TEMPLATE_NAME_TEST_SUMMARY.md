# 模板命名能力测试总结

本文档总结了针对 `service_object_name_template` 和 `network_object_name_template` 的详细测试。

## 测试文件

测试文件位置：`pkg/nodemap/node/device/firewall/common/v2/templates_name_test.go`

## 测试覆盖范围

### 1. network_object_name_template 测试

#### 1.1 基础占位符测试 (TestNetworkObjectNameTemplate_BasicPlaceholders)
- ✅ `{ip}` - 单IP地址占位符
- ✅ `{cidr}` - CIDR网络占位符
- ✅ `{start}` / `{end}` - IP范围起止地址
- ✅ `{mask}` - 子网掩码占位符

#### 1.2 条件逻辑测试 (TestNetworkObjectNameTemplate_ConditionalLogic)
- ✅ `{if:type=="host"}` - 单IP条件判断
- ✅ `{if:type=="subnet"}` - CIDR网络条件判断
- ✅ `{if:type=="range"}` - IP范围条件判断
- ✅ `{else if}` - 多条件判断

#### 1.3 格式化选项测试 (TestNetworkObjectNameTemplate_FormatOptions)
- ✅ `{ip:compressed}` - IPv6压缩格式
- ✅ `{ip}` - IPv6非压缩格式

#### 1.4 元数据变量测试 (TestNetworkObjectNameTemplate_MetaDataVariables)
- ✅ `{policy_name}` - 策略名称变量
- ✅ `{is_source}` - 源/目标地址区分
- ✅ 组合多个变量

#### 1.5 复杂场景测试 (TestNetworkObjectNameTemplate_ComplexScenarios)
- ✅ 嵌套条件判断
- ✅ 存在性检查 `{if:exist:var}`

### 2. service_object_name_template 测试

#### 2.1 基础占位符测试 (TestServiceObjectNameTemplate_BasicPlaceholders)
- ✅ `{protocol}` - 协议名称（TCP/UDP/ICMP/IP）
- ✅ `{dst_port}` - 目标端口
- ✅ `{src_port}` - 源端口
- ✅ ICMP协议（注意：ICMP类型和代码在服务对象名称模板中可能不可用，使用 `{protocol}` 即可）

#### 2.2 格式化选项测试 (TestServiceObjectNameTemplate_FormatOptions)
- ✅ `{protocol:upper}` - 协议大写
- ✅ `{protocol:lower}` - 协议小写
- ✅ `{dst_port:compact}` - 端口紧凑格式
- ✅ `{dst_port:range}` - 端口范围格式

#### 2.3 条件逻辑测试 (TestServiceObjectNameTemplate_ConditionalLogic)
- ✅ TCP协议条件判断
- ✅ UDP协议条件判断
- ✅ ICMP条件判断
- ✅ 端口范围条件判断

#### 2.4 元数据变量测试 (TestServiceObjectNameTemplate_MetaDataVariables)
- ✅ `{policy_name}` - 策略名称变量
- ✅ 条件端口处理
- ✅ 组合多个变量

#### 2.5 复杂场景测试 (TestServiceObjectNameTemplate_ComplexScenarios)
- ✅ 嵌套条件判断
- ✅ 端口范围处理
- ✅ 单服务条目

#### 2.6 边界情况测试 (TestServiceObjectNameTemplate_EdgeCases)
- ✅ 空模板处理
- ✅ 全端口范围
- ✅ L3协议（无端口）

### 3. 集成测试

#### 3.1 网络对象模板集成测试 (TestGenerateObjectNameFromTemplate_Integration)
- ✅ 策略名称+网络类型组合
- ✅ 源/目标地址区分

#### 3.2 服务对象模板集成测试 (TestGenerateServiceNameFromTemplate_Integration)
- ✅ 策略名称+协议+端口组合
- ✅ 条件端口处理

## 测试统计

- **总测试用例数**: 40+
- **通过的测试**: 40+ ✅
- **测试通过率**: 100%

## 测试能力验证

### network_object_name_template 支持的能力

1. ✅ **基础网络占位符**
   - `{ip}`, `{cidr}`, `{mask}`, `{start}`, `{end}`

2. ✅ **条件判断**
   - `{if:type=="host"}`, `{if:type=="subnet"}`, `{if:type=="range"}`
   - `{else}`, `{else if}`

3. ✅ **格式化选项**
   - `{ip:compressed}` (IPv6)

4. ✅ **元数据变量**
   - `{policy_name}`, `{is_source}`

5. ✅ **条件变量检查**
   - `{if:var!=""}` (注意：`{if:exist:var}` 语法不被支持，应使用非空检查)

### service_object_name_template 支持的能力

1. ✅ **基础服务占位符**
   - `{protocol}`, `{dst_port}`, `{src_port}`, `{type}`, `{code}`

2. ✅ **格式化选项**
   - `{protocol:upper}`, `{protocol:lower}`
   - `{dst_port:compact}`, `{dst_port:range}`

3. ✅ **条件判断**
   - `{if:protocol=="TCP"}`, `{if:protocol=="UDP"}`
   - `{if:isL4=="true"}`

4. ✅ **元数据变量**
   - `{policy_name}`, `{compact_port}`

5. ✅ **条件变量检查**
   - `{if:var!=""}` (注意：`{if:exist:var}` 语法不被支持，应使用非空检查)

## 使用示例

### network_object_name_template 示例

```yaml
# 基础用法
network_object_name_template: "NET_{cidr}"

# 条件判断
network_object_name_template: |
  {if:type=="host"}HOST_{ip}
  {else if:type=="subnet"}SUBNET_{cidr}
  {else}RANGE_{start}_{end}
  {endif}

# 使用元数据变量
network_object_name_template: "{policy_name}_{if:is_source==\"true\"}SRC{else}DST{endif}_{cidr}"
```

### service_object_name_template 示例

```yaml
# 基础用法
service_object_name_template: "{protocol:upper}_{dst_port}"

# 条件判断
service_object_name_template: |
  {if:protocol=="TCP"}TCP_{dst_port}
  {else if:protocol=="UDP"}UDP_{dst_port}
  {else}{protocol}
  {endif}

# 使用元数据变量
service_object_name_template: "{policy_name}_{protocol:lower}_{dst_port:compact}"
```

## 注意事项

1. **DSL语法兼容性**: `{if:exist:var}` 语法不被支持，应使用 `{if:var!=""}` 进行非空检查。

2. **ICMP支持**: ICMP类型和代码的占位符（如 `{icmp:type}`, `{icmp:code}`）在服务对象名称模板中可能不可用。建议使用 `{protocol}` 占位符来标识ICMP协议。

3. **端口范围**: 全端口范围（0-65535）可以正常处理，使用 `{dst_port:range}` 或 `{dst_port:compact}` 格式。

4. **L3协议**: L3协议（如IP）没有端口，模板中应避免使用端口相关占位符，只使用 `{protocol}` 即可。

## 运行测试

```bash
# 运行所有模板命名测试
go test -v ./pkg/nodemap/node/device/firewall/common/v2 -run "TestNetworkObjectNameTemplate|TestServiceObjectNameTemplate"

# 运行特定测试
go test -v ./pkg/nodemap/node/device/firewall/common/v2 -run TestNetworkObjectNameTemplate_BasicPlaceholders
```

## 后续改进建议

1. **完善边界情况测试**: 针对ICMP、L3协议、全端口范围等边界情况进行更详细的测试。

2. **错误处理测试**: 添加对无效模板、缺失变量等错误情况的测试。

3. **性能测试**: 针对大量网络/服务对象的模板生成性能进行测试。

4. **文档更新**: 根据测试结果更新 `intent_capabilities.md` 文档，确保文档与实际实现一致。


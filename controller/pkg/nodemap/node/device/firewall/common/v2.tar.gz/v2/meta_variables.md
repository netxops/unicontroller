# V2版本防火墙NAT相关Meta变量定义

本文档定义了v2版本防火墙NAT相关功能使用的标准化meta变量，明确每个变量的含义、来源、类型和使用场景。

## 变量命名规范

- 所有变量名使用小写字母和下划线（snake_case）
- 布尔标志使用`has_`前缀（如`has_real_port`）
- 对象名称使用`_name`后缀（如`object_name`、`pool_name`）
- 类型变量使用`_type`后缀（如`obj_type`、`snat_pool_type`）

## VIP/MIP相关Meta变量

### obj_type
- **类型**: string
- **值**: "VIP" 或 "MIP"
- **来源**: 由MakeVipOrMipV2根据服务类型和real_port判断后设置
- **用途**: 标识对象类型，用于layout模板选择不同的生成逻辑
- **示例**: `obj_type = "VIP"`

### object_name
- **类型**: string
- **来源**: 
  - 优先使用配置中的`object_name`
  - 如果为空，从配置的`vip_name_template`或`mip_name_template`生成
  - 如果仍为空，使用默认值（如"VIP_OBJECT"或"MIP_OBJECT"）
- **用途**: VIP/MIP对象的名称，用于生成CLI命令
- **示例**: `object_name = "WEB_SERVER_VIP"`

### pool_name
- **类型**: string
- **来源**: 通常与object_name相同（SRX等使用pool的设备）
- **用途**: 池名称，用于SRX等设备的pool配置
- **示例**: `pool_name = "WEB_SERVER_VIP"`

### is_reused
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeVipOrMipV2在检查对象复用时设置
- **用途**: 标识对象是否复用已存在的对象，用于layout判断是否生成CLI
- **示例**: `is_reused = "true"`

### has_real_port
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeVipOrMipV2根据intent.RealPort是否存在设置
- **用途**: 用于layout判断是否生成端口映射配置
- **示例**: `has_real_port = "true"`

## SNAT_POOL相关Meta变量

### snat_pool_type
- **类型**: string
- **值**: "POOL"、"INTERFACE"、"INLINE"、"ADDRESS_OBJECT"
- **来源**: 从配置的`snat_pool_type`读取，默认为"POOL"
- **用途**: 标识SNAT池的实现方式，用于选择不同的layout
- **示例**: `snat_pool_type = "POOL"`

### pool_name
- **类型**: string
- **来源**: 
  - 优先使用配置中的`pool_name`
  - 如果为空，从配置的`snat_object_name_template`生成
  - 如果仍为空，使用默认值"SNAT_POOL"
- **用途**: SNAT池的名称，用于生成CLI命令
- **示例**: `pool_name = "SNAT_POOL_1"`

### pool_id
- **类型**: string
- **来源**: 通常与pool_name相同（某些设备使用ID）
- **用途**: 池ID，用于某些设备的pool引用
- **示例**: `pool_id = "SNAT_POOL_1"`

### is_reused
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeSnatPoolV2在检查池复用时设置
- **用途**: 标识池是否复用已存在的池，用于layout判断是否生成CLI
- **示例**: `is_reused = "true"`

### interface_name
- **类型**: string
- **来源**: 
  - INTERFACE类型时，从ctx.OutPort获取
  - 或从配置的`interface_name`读取
- **用途**: 接口名称，用于INTERFACE类型的SNAT配置
- **示例**: `interface_name = "GigabitEthernet0/0"`

### snat_ip
- **类型**: string
- **来源**: 从intent.Snat提取（INLINE类型时）
- **用途**: 内联IP地址，用于INLINE类型的SNAT配置
- **注意**: 此变量仅在INLINE类型时使用，通常不需要设置到meta，layout可直接使用`{snat}`从intent获取
- **示例**: `snat_ip = "203.0.113.100"`

## NAT Policy相关Meta变量

### nat_type
- **类型**: string
- **值**: "DNAT" 或 "SNAT"
- **来源**: 由MakeNatPolicyV2根据intent.RealIp或intent.Snat判断后设置
- **用途**: 标识NAT类型，用于layout选择不同的生成逻辑
- **示例**: `nat_type = "DNAT"`

### nat_name
- **类型**: string
- **来源**: 
  - 优先调用节点的GetPolicyName方法
  - 如果为空，从配置的`natpolicy.name_template`生成
  - 如果仍为空，使用默认值"NAT_POLICY"
- **用途**: NAT策略名称，用于生成CLI命令
- **示例**: `nat_name = "DNAT_WEB_SERVER"`

### nat_rule_name
- **类型**: string
- **来源**: 通常与nat_name相同（某些设备使用规则名称）
- **用途**: NAT规则名称，用于某些设备的规则配置
- **示例**: `nat_rule_name = "DNAT_WEB_SERVER"`

### vip_name
- **类型**: string
- **来源**: 由MakeVipOrMipV2返回后设置（DNAT时）
- **用途**: VIP对象名称，用于NAT策略引用VIP对象
- **示例**: `vip_name = "WEB_SERVER_VIP"`

### mip_name
- **类型**: string
- **来源**: 由MakeVipOrMipV2返回后设置（DNAT时）
- **用途**: MIP对象名称，用于NAT策略引用MIP对象
- **示例**: `mip_name = "WEB_SERVER_MIP"`

### has_vip_name
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeNatPolicyV2在设置vip_name后设置
- **用途**: 用于layout判断是否存在VIP名称
- **示例**: `has_vip_name = "true"`

### has_mip_name
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeNatPolicyV2在设置mip_name后设置
- **用途**: 用于layout判断是否存在MIP名称
- **示例**: `has_mip_name = "true"`

### use_vip
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeNatPolicyV2根据设备是否支持VIP设置（SRX等设备）
- **用途**: 用于layout判断是否使用VIP（而非MIP）
- **示例**: `use_vip = "true"`

### pool_id
- **类型**: string
- **来源**: 由MakeSnatPoolV2返回后设置（SNAT时）
- **用途**: SNAT池ID，用于NAT策略引用SNAT池
- **示例**: `pool_id = "SNAT_POOL_1"`

### pool_name
- **类型**: string
- **来源**: 由MakeSnatPoolV2返回后设置（SNAT时）
- **用途**: SNAT池名称，用于NAT策略引用SNAT池
- **示例**: `pool_name = "SNAT_POOL_1"`

### has_pool_id
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeNatPolicyV2在设置pool_id后设置
- **用途**: 用于layout判断是否存在SNAT池ID
- **示例**: `has_pool_id = "true"`

### use_pool
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeNatPolicyV2在设置pool_id后设置
- **用途**: 用于layout判断是否使用SNAT池
- **示例**: `use_pool = "true"`

### source_style
- **类型**: string
- **值**: "none"、"optional"、"required"
- **来源**: 从配置的`natpolicy.dnat.source_style`或`natpolicy.snat.source_style`读取，默认为"none"
- **用途**: 控制源地址对象的生成方式
  - "none": 不生成源地址对象
  - "optional": 如果intent中有源地址，则生成源地址对象
  - "required": 必须生成源地址对象
- **示例**: `source_style = "optional"`

### destination_style
- **类型**: string
- **值**: "none"、"optional"、"required"
- **来源**: 从配置的`natpolicy.snat.destination_style`读取，默认为"none"
- **用途**: 控制目标地址对象的生成方式（SNAT时）
- **示例**: `destination_style = "none"`

### has_source_objects
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeNatPolicyV2在生成源地址对象后设置
- **用途**: 用于layout判断是否存在源地址对象
- **示例**: `has_source_objects = "true"`

### has_destination_objects
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeNatPolicyV2在生成目标地址对象后设置
- **用途**: 用于layout判断是否存在目标地址对象
- **示例**: `has_destination_objects = "true"`

### has_service_objects
- **类型**: string ("true" 或 "false")
- **来源**: 由MakeNatPolicyV2在生成服务对象后设置
- **用途**: 用于layout判断是否存在服务对象
- **示例**: `has_service_objects = "true"`

### src_objects
- **类型**: []string
- **来源**: 由MakeNatPolicyV2在生成源地址对象后设置
- **用途**: 源地址对象名称列表，用于layout引用源地址对象
- **示例**: `src_objects = ["SRC_OBJ_1", "SRC_OBJ_2"]`

### dst_objects
- **类型**: []string
- **来源**: 由MakeNatPolicyV2在生成目标地址对象后设置
- **用途**: 目标地址对象名称列表，用于layout引用目标地址对象
- **示例**: `dst_objects = ["DST_OBJ_1"]`

### service_objects
- **类型**: []string
- **来源**: 由MakeNatPolicyV2在生成服务对象后设置
- **用途**: 服务对象名称列表，用于layout引用服务对象
- **示例**: `service_objects = ["HTTP_SERVICE"]`

## 对象复用控制Meta变量

### securitypolicy.reuse_address_object / reuse_address_object
- **类型**: boolean (true/false)
- **来源**: 从配置读取
- **默认值**: 
  - 如果 `securitypolicy.reuse_policy` 为 `true`，则默认为 `true`
  - 否则默认为 `false`
- **用途**: 控制是否复用已有的地址对象或地址组
  - `true`: 在生成地址对象前，先通过网络内容查找已有对象，如果找到相同网络的对象则复用其名称
  - `false`: 总是按模板生成新的地址对象名称
- **支持格式**: 
  - `securitypolicy.reuse_address_object` (推荐)
  - `reuse_address_object` (简化格式)
- **示例**: `securitypolicy.reuse_address_object = true`

### securitypolicy.reuse_service_object / reuse_service_object
- **类型**: boolean (true/false)
- **来源**: 从配置读取
- **默认值**: 
  - 如果 `securitypolicy.reuse_policy` 为 `true`，则默认为 `true`
  - 否则默认为 `false`
- **用途**: 控制是否复用已有的服务对象或服务组
  - `true`: 在生成服务对象前，先通过服务内容查找已有对象，如果找到相同服务的对象（如 `tcp:80` 对应 "HTTP"）则复用其名称
  - `false`: 总是按模板生成新的服务对象名称
- **支持格式**: 
  - `securitypolicy.reuse_service_object` (推荐)
  - `reuse_service_object` (简化格式)
- **示例**: `securitypolicy.reuse_service_object = true`

### securitypolicy.reuse_policy
- **类型**: boolean (true/false)
- **来源**: 从配置读取
- **默认值**: `false`
- **用途**: 统一控制策略相关的复用行为
  - `true`: 默认启用地址对象和服务对象的复用
  - `false`: 默认不启用复用（除非显式设置 `reuse_address_object` 或 `reuse_service_object`）
- **注意**: 此参数作为默认值，可以被 `reuse_address_object` 和 `reuse_service_object` 显式覆盖
- **示例**: `securitypolicy.reuse_policy = true`

## 通用Meta变量

### fromZone / toZone
- **类型**: string
- **来源**: 从ctx获取（通过ZoneFirewall接口）
- **用途**: 源/目标区域名称，用于生成zone相关的CLI命令
- **示例**: `fromZone = "trust"`, `toZone = "untrust"`

### fromPort / toPort
- **类型**: string
- **来源**: 从ctx获取（如果zone不存在，使用port名称）
- **用途**: 源/目标端口名称，用于生成接口相关的CLI命令
- **示例**: `fromPort = "GigabitEthernet0/0"`, `toPort = "GigabitEthernet0/1"`

### description
- **类型**: string
- **来源**: 从配置读取
- **用途**: 描述信息，用于生成CLI命令中的description字段
- **示例**: `description = "Web server NAT rule"`

### enable
- **类型**: string
- **值**: "enable" 或 "disable"
- **来源**: 从配置读取，默认为"enable"
- **用途**: 控制策略是否启用
- **示例**: `enable = "enable"`

### action
- **类型**: string
- **值**: "permit"/"deny" 或 "pass"/"drop"（根据防火墙类型）
- **来源**: 从配置读取，默认为"permit"或"pass"
- **用途**: 策略动作，用于生成CLI命令中的action字段
- **示例**: `action = "permit"`

## Intent属性（不需要设置到meta）

以下属性可以直接从intent获取，不需要设置到meta中：

### real_ip
- **类型**: string
- **来源**: intent.RealIp
- **DSL使用**: `{real_ip}`
- **用途**: 真实IP地址（DNAT时）

### real_port
- **类型**: string
- **来源**: intent.RealPort
- **DSL使用**: `{real_port}`
- **用途**: 真实端口（DNAT时）

### snat
- **类型**: string
- **来源**: intent.Snat
- **DSL使用**: `{snat}`
- **用途**: SNAT地址（SNAT时）

## 变量来源说明

### 配置来源
从metaData参数传入，通常来自配置文件：
- `vip_name_template`、`mip_name_template`
- `snat_pool_type`、`snat_object_name_template`
- `natpolicy.*`配置项
- `securitypolicy.reuse_policy`、`securitypolicy.reuse_address_object`、`securitypolicy.reuse_service_object`
- `description`、`enable`、`action`等

### 运行时生成
由MakeXXX函数根据intent和配置生成：
- `obj_type`、`nat_type`、`snat_pool_type`
- `object_name`、`pool_name`、`nat_name`
- `is_reused`、`has_*`标志
- `vip_name`、`mip_name`、`pool_id`等

### 对象复用逻辑
由MakeAddressObjectV2和MakeServiceObjectV2根据复用控制参数执行：
- 如果 `reuse_address_object == true`，调用 `GetObjectByNetworkGroup()` 查找已有地址对象
- 如果 `reuse_service_object == true`，调用 `GetObjectByService()` 查找已有服务对象
- 如果找到相同内容的对象，复用其名称；否则按模板生成新名称

### Intent属性
real_ip、real_port、snat等直接从intent获取，不需要设置到meta，DSL模板可直接使用`{real_ip}`、`{real_port}`、`{snat}`占位符。

## 使用示例

### Layout模板中使用meta变量

```dsl
{if:exist:obj_type=="VIP"}
    # VIP配置
    {if:exist:has_real_port=="true"}
        # 端口映射
        nat server protocol {protocol:lower} global {dst_network} {dst_port} local {real_ip} {real_port}
    {endif}
{else}
    # MIP配置
    nat server global {dst_network} local {real_ip}
{endif}
```

### MakeXXX函数中设置meta变量

```go
meta := copyMap(metaData)
meta["obj_type"] = "VIP"
meta["object_name"] = "WEB_SERVER_VIP"
if intent.RealPort != "" {
    meta["has_real_port"] = "true"
}
// 注意：不需要设置real_ip和real_port到meta
// layout可以直接使用{real_ip}和{real_port}从intent获取
```

### 对象复用控制示例

```go
// 启用地址对象和服务对象复用
metaData := map[string]interface{}{
    "securitypolicy.reuse_address_object": true,
    "securitypolicy.reuse_service_object": true,
    "network_object_name_template": "{policy_name}_{if:is_source==\"true\"}SRC{else}DST{endif}_{if:type==\"range\"}{start}_{end}{else if:type==\"subnet\"}{cidr}{else}{ip}{endif}",
    "service_object_name_template": "{policy_name}_{protocol:lower}{if:dst_port!=\"\"}_{dst_port}{endif}",
}

// 或者通过统一参数控制
metaData := map[string]interface{}{
    "securitypolicy.reuse_policy": true,  // 统一启用复用
}
```


package common

import (
	"github.com/netxops/keys"
	"github.com/samber/lo"
)

var _ Templates = &SecPathTemplates{}

type Entry struct {
	Key   keys.Keys
	Value string
}

type SecPathTemplates struct {
	Config     map[string]string
	ConfigKeys []Entry
}

func (st *SecPathTemplates) GetTemplatesEntries(key keys.Keys) (es []Entry) {
	lo.ForEach(st.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.HasPrefix(key) {
			es = append(es, entry)
		}
	})

	return es
}

func (st *SecPathTemplates) GetTemplatesByKey(key keys.Keys) string {
	var e Entry
	lo.ForEach(st.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})

	return e.Value
}

func NewSecPathTemplates() *SecPathTemplates {
	spt := &SecPathTemplates{
		ConfigKeys: []Entry{
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "#"},

			// Network Object
			// object-group ip address 103.7.30.0/25
			//  0 network subnet 103.7.30.0 255.255.255.128
			{Key: keys.NewKeyBuilder("NetworkObject", "OneLoop"), Value: `
{if:exist:object_name=="true"}
object-group ip address {object_name}{newline}
{for:net in networkgroup}
    {space:1}network
	{if:net:type=="range"} range {net:start} {net:end}
    {else if:net:type=="host"} host address {net:ip}
    {else} subnet {net:ip} {net:mask:dotted}{endif}
    {newline}
{endfor}
{endif}`},

			// 	object-group service JiS_DMZ_498_policy_port_group01
			// 	1 service tcp destination eq 48080
			// 	2 service tcp destination eq 13421
			// 	3 service tcp destination eq 40005
			//    #
			//    object-group service tcp
			// 	description TCP ALL Port
			// 	0 service tcp
			//    #
			//    object-group service TCP_10000-10100
			// 	0 service tcp destination range 10000 10100
			//    #
			{Key: keys.NewKeyBuilder("ServiceObject", "CompactPorts"), Value: `{set:service.range_format="_"}
			{if:src_port:isFull!="true"}
				S{src_port:compact}
				{if:dst_port:isFull!="true"}
				    D{dst_port:compact}
				{endif}
			{else}
				{dst_port:compact}
			{endif}
			`,
			},
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `{set:service.range_format=" "}
object-group service {object_name}{newline}
{for:item in service.EachDetailed}
  service {item:protocol:lower}
  {if:item:protocol=="TCP"}
    {if:item:src_port:isFull!="true"} source range {item:src_port:range}{endif}
    {if:item:dst_port:count==1} destination eq {item:dst_port:compact}
    {else} destination range {item:dst_port:range}
    {endif}
  {else}
    {if:item:protocol=="UDP"}
      {if:item:src_port:isFull!="true"} source range {item:src_port:range}{endif}
      {if:item:dst_port:count==1} destination eq {item:dst_port:compact}
      {else} destination range {item:dst_port:range}
      {endif}
    {else}
      {if:item:protocol=="ICMP"}
        {if:item:hasType=="true"} type {item:type}
          {if:item:hasCode=="true"} code {item:code}{endif}
        {endif}
      {endif}
    {endif}
  {endif}
  {newline}
{endfor}
`},

			// 	acl advanced 3111
			// 	description For_Snat-DMZ_Financial-access-ICBC
			// 	rule 10 permit ip source 192.168.22.17 0 destination 108.6.13.116 0
			// 	rule 20 permit ip source 192.168.22.17 0 destination 108.6.13.118 0
			// 	rule 30 permit ip source 192.168.22.17 0 destination 108.2.2.82 0
			// 	rule 40 permit ip source 192.168.22.17 0 destination 108.2.2.120 0
			// 	rule 50 permit ip source 192.168.22.17 0 destination 108.2.2.62 0
			// 	rule 60 permit ip source 192.168.22.17 0 destination 108.6.13.127 0
			// 	rule 70 permit ip source 192.168.22.17 0 destination 108.2.114.82 0
			//    #
			//    acl advanced 3112
			// 	description SNAT DMZ_MSS_SDFQ access ShuiJuLeQiFuWu
			// 	rule 0 permit tcp source 192.168.22.109 0 destination 36.112.115.69 0 destination-port eq 8443
			// 	rule 5 permit tcp source 192.168.22.110 0 destination 36.112.115.69 0 destination-port eq 8443
			//    #

			// [H3C-acl-ipv4-adv-3111]rule permit tcp source ?
			//   X.X.X.X       Source address
			//   any           Any source address
			//   object-group  Specify object group configuration information
			{Key: keys.NewKeyBuilder("ACL", "OneLoop"), Value: `{set:service.range_format=" "}
acl advanced
	{if:exist:acl_id=="true"} {acl_id}{endif}
	{if:exist:acl_name=="true"} name {acl_name}{endif}
{newline}
{if:exist:objectStyle=="true"}
    {for:svc in intent.service}
		rule permit {svc:protocol:lower} source object-group {sourceAddressObject} destination object-group {destinationAddressObject}
        {if:svc:protocol=="TCP"}
            {if:svc:src_port:isFull!="true"} source-port range {svc:src_port:range} {endif}
            {if:svc:dst_port:isFull!="true"} destination-port range {svc:dst_port:range}{endif}
        {else if:svc:protocol=="UDP"}
            {if:svc:src_port:isFull!="true"} source-port range {svc:src_port:range} {endif}
            {if:svc:dst_port:isFull!="true"} destination-port range {svc:dst_port:range}{endif}
        {else}
            {if:svc:protocol=="ICMP"}
                {if:svc:hasType=="true"}icmp-type {svc:type}
                    {if:svc:hasCode=="true"} icmp-code {svc:code}{endif}
                {endif}
            {endif}
        {endif}{newline}
    {endfor}
{else}
    {for:item in intent}
        {space:1}rule permit {item:service:protocol:lower}
        {if:item:src:isFull=="false"} source {item:src:ip} {item:src:mask:wildcard}{endif}
        {if:item:dst:isFull=="false"} destination {item:dst:ip} {item:dst:mask:wildcard}{endif}
        {if:item:service:protocol=="TCP"}
			{if:item:service:isL4=="true"}
				{if:item:service:src_port:isFull=="false"} source-port range {item:service:src_port:range}{endif}
				{if:item:service:dst_port:isFull=="false"} destination-port range {item:service:dst_port:range}{endif}
			{endif}
		{else if:item:service:protocol=="UDP"}
			{if:item:service:isL4=="true"}
				{if:item:service:src_port:isFull=="false"} source-port range {item:service:src_port:range}{endif}
				{if:item:service:dst_port:isFull=="false"} destination-port range {item:service:dst_port:range}{endif}
			{endif}
        {else}
            {if:item:service:protocol=="ICMP"}
                {if:item:service:hasType=="true"} icmp-type {item:service:type}
                    {if:item:service:hasCode=="true"} icmp-code {item:service:code}{endif}
                {endif}
            {endif}
        {endif}{newline}
    {endfor}
{endif}
`},

			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
security-policy ip{newline}
	{space:1}rule {policy_id} name {policy_name}{newline}
	{if:exist:description=="true"}  description {description}{newline}{endif}
	{for:zone in sourceZones}
		{space:2}source-zone {zone}{newline}
	{endfor}
	{for:zone in destinationZones}
		{space:2}destination-zone {zone}{newline}
	{endfor}
{if:exist:objectStyle=="true"}
	{if:exist:make_source=="true"}
		{for:item in sourceObjects}
			{space:2}source-ip {item}{newline}
		{endfor}
	{endif}
	{if:exist:make_destination=="true"}
		{for:item in destinationObjects}
			{space:2}destination-ip {item}{newline}
		{endfor}
	{endif}
	{if:exist:make_service=="true"}
		{for:item in serviceObjects}
			{space:2}service {item}{newline}
		{endfor}
	{endif}
{else}
	{for:item in intent}
		{if:exist:make_source=="true"}
			{if:item:src:isHost=="true"}  source-ip-host {item:src:ip}{else if:item:src:isRange=="true"}  source-ip-range {item:src:start} {item:src:end}{else}  source-ip-subnet {item:src:ip} {item:src:mask:dotted}{endif}{newline}
		{endif}
		{if:exist:make_destination=="true"}
			{if:item:dst:isHost=="true"}  destination-ip-host {item:dst:ip}{else if:item:dst:isRange=="true"}  destination-ip-range {item:dst:start} {item:dst:end}{else}  destination-ip-subnet {item:dst:ip} {item:dst:mask:dotted}{endif}{newline}
		{endif}
		{if:exist:make_service=="true"}
			{space:2}service-port {item:service:protocol:lower}
			{if:item:service:protocol=="ICMP"}
				{if:item:service:hasType=="true"} {item:service:type}
					{if:item:service:hasCode=="true"} {item:service:code}{endif}
				{endif}
			{endif}
			{if:item:service:protocol=="TCP"}
				{if:item:service:src_port:isFull !="true"}
					{if:item:service:src_port:count==1}
						{space:1}source eq {item:service:src_port:compact}
					{else}
						{space:1}source range {item:service:src_port:range}
					{endif}
				{endif}
				{if:item:service:dst_port:isFull !="true"}
					{if:item:service:dst_port:count==1}
						{space:1}destination eq {item:service:dst_port:compact}
					{else}
						{space:1}destination range {item:service:dst_port:range}
					{endif}
				{endif}
			{endif}
			{if:item:service:protocol=="UDP"}
				{if:item:service:src_port:isFull !="true"}
					{if:item:service:src_port:count==1}
						{space:1}source eq {item:service:src_port:compact}
					{else}
						{space:1}source range {item:service:src_port:range}
					{endif}
				{endif}
				{if:item:service:dst_port:isFull !="true"}
					{if:item:service:dst_port:count==1}
						{space:1}destination eq {item:service:dst_port:compact}
					{else}
						{space:1}destination range {item:service:dst_port:range}
					{endif}
				{endif}
			{endif}
		{endif}
		{newline}
	{endfor}
{endif}
  {space:2}action pass{newline}
`},

			{Key: keys.NewKeyBuilder("Nat", "Dynamic", "OneLoop"), Value: `
interface {toPort}{newline}
{space:1}nat outbound {acl_id} address-group {pool_id}
{if:exist:nat_rule_name=="true"} rule {nat_rule_name}{endif}
{if:exist:description=="true"} description {description}{endif}
{newline}
`,
			},
			{Key: keys.NewKeyBuilder("Pool", "OneLoop"), Value: `nat address-group {pool_id}{if:exist:pool_name=="true"} name {pool_name}{endif}{newline} address {start} {end}{newline}`},
			{Key: keys.NewKeyBuilder("Nat", "Static", "OneLoop"), Value: `
			{set:intent.dst_template="{ip}"}
			{if:direction=="Outbound"}
				{for:item in intent.src}
					nat static outbound {item:ip} {snat}
					{if:exist:vpn_instance=="true"} vpn-instance {vpn_instance}{endif}
					{if:exist:acl_id=="true"} acl {acl_id}{endif}
					{if:exist:nat_rule_name=="true"} rule {nat_rule_name}{endif}
					{if:exist:description=="true"} description {description}{endif}
					{newline}
				{endfor}
			{endif}
			{if:direction=="Inbound"}
				{for:item in intent.dst}
					nat static inbound {item:ip} {real_ip}
					{if:exist:vpn_instance=="true"} vpn-instance {vpn_instance}{endif}
					{if:exist:acl_id=="true"} acl {acl_id}{endif}
					{if:exist:nat_rule_name=="true"} rule {nat_rule_name}{endif}
					{if:exist:description=="true"} description {description}{endif}
				{endfor}
			{endif}
			{if:direction=="InOut"}
				interface {fromPort}{newline}
					{space:1}nat server protocol {protocol:lower} global {dst_network}
					{if:isL4=="true"}
						{if:dst_port:count==1} {dst_port}{endif}
					{endif}
					{space:1}local {real_ip}
					{if:isL4=="true"}
						{if:dst_port:count==1} {real_port}{endif}
					{endif}
					{if:exist:nat_rule_name=="true"} rule {nat_rule_name}{endif}
					{if:exist:description=="true"} description {description}{endif}
				{newline}
			{endif}
		`,
			},

			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{set:service.range_format=" "}
nat global-policy{newline}
	{space:1}rule name {policy_name}{newline}
	{if:exist:description=="true"}  description {description}{newline}{endif}
	{for:zone in sourceZones}
		{space:2}source-zone {zone}{newline}
	{endfor}
	{for:zone in destinationZones}
		{space:2}destination-zone {zone}{newline}
	{endfor}
{if:exist:sourceObjects=="true"}
	{for:item in sourceObjects}
      {space:2}source-ip {item}{newline}
	{endfor}
{endif}
{if:exist:destinationObjects=="true"}
	{for:item in destinationObjects}
		{space:2}destination-ip {item}{newline}
	{endfor}
{endif}
{for:item in intent}
	{if:exist:sourceObjects=="false"}
		{if:item:src:isHost=="true"}  source-ip host {item:src:ip}{else}  source-ip subnet {item:src:ip} {item:src:mask:dotted}{endif}{newline}
	{endif}
	{if:exist:destinationObjects=="false"}
		{if:item:dst:isHost=="true"}  destination-ip host {item:dst:ip}{else}  destination-ip subnet {item:dst:ip} {item:dst:mask:dotted}{endif}{newline}
	{endif}
{endfor}

{for:item in serviceObjects}
	{space:2}service {item}{newline}
{endfor}
{if:exist:description=="true"}  description {description}{endif}
{if:exist:pool_id=="true"}  action snat address-group {pool_id}{endif}
{if:exist:real_ip=="true"}
    {if:vip_name!=""}
        {space:2}action dnat object-group {vip_name}
    {else}
    	{space:2}action dnat ip-address {real_ip}
    {endif}
	{if:real_port!=""} local-port {real_port}{endif}
{endif}
{newline}
`},
		},
	}

	return spt
}

func (spt *SecPathTemplates) GetTemplates(key string) string {
	return spt.Config[key]
}

type DptechTemplates struct {
	Config     map[string]string
	ConfigKeys []Entry
}

func (dt *DptechTemplates) GetTemplates(key string) string {
	return dt.Config[key]
}

func (dt *DptechTemplates) GetTemplatesEntries(key keys.Keys) (es []Entry) {
	lo.ForEach(dt.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.HasPrefix(key) {
			es = append(es, entry)
		}
	})

	return es
}

func (dt *DptechTemplates) GetTemplatesByKey(key keys.Keys) string {
	var e Entry
	lo.ForEach(dt.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})

	return e.Value
}

func NewDptechTemplates() *DptechTemplates {
	spt := &DptechTemplates{
		ConfigKeys: []Entry{
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "!"},
			// address-object DCN_EDA_bama_bak01_policy02_addr01 132.239.6.231/32
			// address-object DCN_EDA_bama_bak01_policy02_addr01 132.239.7.19/32
			// service-object TCP_8081 protocol tcp src-port 0 to 65535 dst-port 8081 to 8081
			// service-object TCP_6081 protocol tcp src-port 0 to 65535 dst-port 6081 to 6081
			{Key: keys.NewKeyBuilder("ServiceObject", "CompactPorts"), Value: `{set:service.range_format="_"}
			{if:src_port:isFull!="true"}
				S{src_port:compact}
				{if:dst_port:isFull!="true"}
				    D{dst_port:compact}
				{endif}
			{else}
				{dst_port:compact}
			{endif}
			`,
			},
			// service-object TCP_30220 protocol tcp src-port 0 to 65535 dst-port 30220
			// service-object TCP_30240 protocol tcp src-port 0 to 65535 dst-port 30240
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
			{set:service.range_format=" to "}
			{for:item in service}
				service-object {object_name} protocol {item:protocol:lower}
				{if:item:protocol=="TCP"}
			  		{space:1}src-port {item:src_port:compact} dst-port {item:dst_port:compact}{newline}
				{endif}
			  	{if:item:protocol=="UDP"}
			  		{space:1}src-port {item:src_port:compact} dst-port {item:dst_port:compact}{newline}
			  	{endif}
			  	{if:item:protocol=="ICMP"}
					{if:item:hasType=="true"}
				   		{space:1}type {item:type}
			       		{if:item:hasCode=="true"} 
				   			{space:1}code {item:code}
				   		{endif}
					{endif}
			  	{endif}
				{newline}
			{endfor}`,
			},
			// address-object iboc_ManagePlat_access_YiZ_policy01_src_addr01 132.228.47.188/32
			// address-object iboc_ManagePlat_access_YiZ_policy01_src_addr01 132.252.206.50/32
			{Key: keys.NewKeyBuilder("NetworkObject", "OneLoop"), Value: `
			{for:item in networkgroup}
			  address-object {object_name} {if:item:isRange=="true"}range {item:start} {item:end}{else}{item:cidr}{endif}{newline}
			{endfor}`,
			},

			{Key: keys.NewKeyBuilder("Pool", "OneLoop"), Value: `address-pool {pool_name} address {start} to {end}{newline}address-pool {pool_name} blackhole-route enable{newline}`},
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
				{if:exist:toPort=="true"}
				  nat source-nat {policy_name} interface {toPort}{newline}
				{endif}
				{for:item in sourceObjects}
				  nat source-nat {policy_name} src-address address-object {item}{newline}
				{endfor}
				{for:item in destinationObjects}
				  nat source-nat {policy_name} dst-address address-object {item}{newline}
				{endfor}
				{for:item in serviceObjects}
				  nat source-nat {policy_name} service {item}{newline}
				{endfor}
				{if:exist:pool_name=="true"}
				  nat source-nat {policy_name} action address-pool {pool_name}{newline}
				{endif}
				{if:exist:description=="true"} 
				  nat source-nat {policy_name}description {description}{newline}
				{endif}
				`,
			},
			{Key: keys.NewKeyBuilder("Nat", "Static", "OneLoop"), Value: `{set:intent.dst_template="{ip}"}{set:service.range_format=" to "}
			{if:direction=="Inbound"}
				nat destination-nat {nat_rule_name} interface {fromPort}
				{space:1}global-address {dst_network}
				{if:exist:real_port=="true"} service {protocol:lower} {dst_port:compact}{endif}
				{space:1}local-address {real_ip}
				{if:exist:real_port=="true"} local-port {real_port}{endif} 
				{if:exist:description=="true"} description {description}{endif}
			{endif}
			{if:direction=="InOut"}
				nat static {nat_rule_name} interface {fromPort} global-address {dst_network} local-address {real_ip}
			{endif}
			{newline}
		`,
			},

			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
			    {if:exist:make_source=="true"}
					{for:item in sourceObjects}
						security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} src-address address-object {item}{newline}
					{endfor}
				{endif}
				{if:exist:make_destination=="true"}
					{for:item in destinationObjects}
						security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} dst-address address-object {item}{newline}
					{endfor}
				{endif}
				{if:exist:make_service=="true"}
					{for:item in serviceObjects}
						security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} service service-object {item}{newline}
					{endfor}
						security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} action permit{newline}
					{if:exist:description=="true"}security-policy {policy_name} src-zone {fromZone} dst-zone {toZone} description {description}{endif}
				{endif}
				{newline}`,
			},
		},
	}

	return spt
}

// address-object DCN_132.254.24.34 132.254.24.34/32
// address-object DCN_132.252.36.153 132.252.36.153/32
// address-object DCN_132.254.6.20 132.254.6.20/32
// address-object DCN_132.254.30.15 132.254.30.15/32
// address-object DCN_132.252.35.16 132.252.35.16/32
// address-object DCN_132.254.30.23 132.254.30.23/32

// assert.Contains(t, result, "nat static")
// assert.Contains(t, result, "interface eth1")
// assert.Contains(t, result, "global-address 192.168.1.100")
// assert.Contains(t, result, "local-address 10.0.0.100")
// // assert.Contains(t, result, "description NETACC_TICKET123_SUB456")

// security-policy DCN_BSS_TongyiAPP_policy01 src-zone DCN dst-zone DMZ src-address address-object DCN_BSS_TongyiAPP_policy01_addr01
// security-policy DCN_BSS_TongyiAPP_policy01 src-zone DCN dst-zone DMZ dst-address address-object DMZ_192.168.32.101
// security-policy DCN_BSS_TongyiAPP_policy01 src-zone DCN dst-zone DMZ dst-address address-object DMZ_192.168.32.102
// security-policy DCN_BSS_TongyiAPP_policy01 src-zone DCN dst-zone DMZ service service-object TCP_2197
// security-policy DCN_BSS_TongyiAPP_policy01 src-zone DCN dst-zone DMZ service service-object TCP_2080
// security-policy DCN_BSS_TongyiAPP_policy01 src-zone DCN dst-zone DMZ action permit

// assert.Contains(t, result, "nat destination-nat")
// assert.Contains(t, result, "interface eth1")
// assert.Contains(t, result, "global-address 192.168.1.100")
// assert.Contains(t, result, "local-address 10.0.0.100")
// assert.Contains(t, result, "service tcp")
// assert.Contains(t, result, "global-port 80")
// assert.Contains(t, result, "local-port 80")
// assert.Contains(t, result, "description NETACC_TICKET123_SUB456")

// nat source-nat NAT_DCN-to-DMZ_dynamic interface bond11
// nat source-nat NAT_DCN-to-DMZ_dynamic src-address address-object 192.168.0.0/16
// nat source-nat NAT_DCN-to-DMZ_dynamic dst-address address-object DCN_132.224.0.0/11
// nat source-nat NAT_DCN-to-DMZ_dynamic dst-address address-object DCN_10.0.0.0/8
// nat source-nat NAT_DCN-to-DMZ_dynamic service any
// nat source-nat NAT_DCN-to-DMZ_dynamic action address-pool Dynamic-PAT-DMZ-IN-DCN-Address-Pool
// nat source-nat NAT_DCN-to-DMZ_dynamic port 1500 to 65535

// address-pool Dynamic-PAT-DMZ-IN-DCN-Address-Pool address 132.252.45.245 to 132.252.45.254
// address-pool Dynamic-PAT-DMZ-IN-DCN-Address-Pool blackhole-route enable
// !

type BaseTemplates struct {
	Config     map[string]string
	ConfigKeys []Entry
}

func (dt *BaseTemplates) GetTemplates(key string) string {
	return dt.Config[key]
}

func (dt *BaseTemplates) GetTemplatesEntries(key keys.Keys) (es []Entry) {
	lo.ForEach(dt.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.HasPrefix(key) {
			es = append(es, entry)
		}
	})

	return es
}

func (dt *BaseTemplates) GetTemplatesByKey(key keys.Keys) string {
	var e Entry
	lo.ForEach(dt.ConfigKeys, func(entry Entry, _ int) {
		if entry.Key.Equal(key) {
			e = entry
		}
	})

	return e.Value
}

type UsgTemplates struct {
	BaseTemplates
}

func NewUsgTemplates() *UsgTemplates {
	spt := &BaseTemplates{
		ConfigKeys: []Entry{
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "#"},
			{Key: keys.NewKeyBuilder("ServiceObject", "CompactPorts"), Value: `{set:service.range_format="_"}
			{if:src_port:isFull!="true"}
				S{src_port:compact}
				{if:dst_port:isFull!="true"}
				    D{dst_port:compact}
				{endif}
			{else}
				{dst_port:compact}
			{endif}
			`,
			},
			{Key: keys.NewKeyBuilder("NetworkObject", "OneLoop"), Value: `
ip address-set {object_name}{if:exist:vrf=="true"} vpn-instance {vrf}{endif} type {type}{newline}
{for:item in networkgroup}
	{if:item:type=="range"} address range {item:start} {item:end}{else} address {item:ip} {item:mask:wildcard}{endif}{newline}
{endfor}
`,
			},
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{set:service.range_format=" to "}
ip service-set {object_name} type {type}{newline}
{for:item in service}
    {space:1}service protocol {item:protocol:lower}
	{if:item:isL4=="true"}
		{if:item:protocol=="TCP"}
			{space:1}source-port {item:src_port:compact} destination-port {item:dst_port:compact}
		{endif}
		{if:item:protocol=="UDP"}
			{space:1}source-port {item:src_port:compact} destination-port {item:dst_port:compact}
		{endif}
	{endif}
	{if:item:protocol=="ICMP"}
		{if:item:hasType=="true"}
			{space:1}icmp-type {item:type}
			{if:item:hasCode=="true"}
				{space:1}{item:code}
			{endif}
		{endif}
	{endif}
	{newline}
{endfor}
`,
			},
			{Key: keys.NewKeyBuilder("Nat", "Static", "OneLoop"), Value: `{set:intent.dst_template="{ip}"}{set:service.range_format=" to "}
			{if:direction=="Inbound"}
				nat destination-nat {nat_rule_name} interface {fromPort}
				{space:1}global-address {dst_network}
				{if:exist:real_port=="true"} service {protocol:lower} {dst_port:compact}{endif}
				{space:1}local-address {real_ip}
				{if:exist:real_port=="true"} local-port {real_port}{endif} 
				{if:exist:description=="true"} description {description}{endif}
			{else if:direction=="InOut"}
			nat server {nat_rule_name}
				{if:exist:fromZone=="true"} zone {fromZone}{endif}
				{space:1}protocol {protocol:lower}
				{space:1}global {dst_network}
				{if:isL4=="true"}
					{if:dst_port:count==1} {dst_port}{endif}
				{endif}
				{space:1}inside {real_ip}
				{if:isL4=="true"}
					{if:dst_port:count==1} {real_port}{endif}
				{endif}
			{else}
				nat source-nat {nat_rule_name} interface {fromPort}
				global-address {dst_network}
				{if:exist:real_port=="true"} service {protocol:lower} {dst_port:compact}{endif}
				local-address {real_ip}
				{if:exist:real_port=="true"} local-port {real_port}{endif}
				{if:exist:description=="true"} description {description}{endif}
			{endif}
			{newline}
			`,
			},

			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
nat-policy{newline}
	{space:1}rule name {policy_name}{newline}
	{if:exist:description=="true"}  description {description}{newline}{endif}
	{for:item in sourceZones}
		{space:2}source-zone {item}{newline}
	{endfor}

	{for:item in destinationZones}
		{space:2}destination-zone {item}{newline}
	{endfor}
	
	{if:exist:sourceObjects=="true"}
		{for:item in sourceObjects}
			{space:2}source-address address-set {item}{newline}
		{endfor}
	{endif}
	{if:exist:destinationObjects=="true"}
		{for:item in destinationObjects}
			{space:2}destination-address address-set {item}{newline}
		{endfor}
	{endif}
	{if:exist:serviceObjects=="true"}
		{for:item in serviceObjects}
			{space:2}service {item}{newline}
		{endfor}
	{endif}
	{if:exist:sourceObjects=="false"}
		{for:src in intent.src.EachDataRangeEntryAsAbbrNet}
			{space:2}source-address {if:src:type=="range"}range {src:start} {src:end}{else}{src:ip} {src:mask:wildcard}{endif}{newline}
		{endfor}
	{endif}
	{if:exist:destinationObjects=="false"}
		{for:dst in intent.dst.EachDataRangeEntryAsAbbrNet}
			{space:2}destination-address {if:dst:type=="range"}range {dst:start} {dst:end}{else}{dst:ip} {dst:mask:wildcard}{endif}{newline}
		{endfor}
	{endif}

	{if:exist:serviceObjects=="false"}
		{for:item in intent.service}
			{space:2}service protocol {item:protocol:lower}
			{if:item:protocol=="TCP"}
				{space:1}{if:item:src_port:isFull!="true"}source-port {item:src_port:compact} {endif}{if:item:dst_port:isFull!="true"}destination-port {item:dst_port:compact}{endif}
			{endif}
			{if:item:protocol=="UDP"}
				{space:1}{if:item:src_port:isFull!="true"}source-port {item:src_port:compact} {endif}{if:item:dst_port:isFull!="true"}destination-port {item:dst_port:compact}{endif}
			{endif}
			{if:item:protocol=="ICMP"}
				{if:item:hasType=="true"}
					{space:1}icmp-type {item:type}
					{if:item:hasCode=="true"}
						{space:1}{item:code}
					{endif}
				{endif}
			{endif}
			{newline}
		{endfor}
	{endif}
{if:exist:pool_id=="true"}  action source-nat address-group {pool_id}{newline}{endif}
{if:exist:real_ip=="true"}
    {space:2}action destination-nat static address-to-address address {real_ip}
	{if:real_port!=""} {real_port}{endif}
	{newline}
{endif}
`,
			},

			{Key: keys.NewKeyBuilder("Pool", "OneLoop"), Value: `
nat address-group {pool_id} 0{newline}
{if:exist:snat_mode=="true"} mode {snat_mode}{endif}{newline}
{space:1}section 0 {start} {end}{newline}
`,
			},

			// 	rule name Network_admin05
			// 	description WLZTBJ
			// 	source-zone QXDCN
			// 	destination-zone QXGUANKONG
			// 	suroce-address 132.224.69.0 mask 255.255.255.0
			// 	source-address 132.228.47.178 0.0.0.0
			// 	source-address 132.228.47.188 0.0.0.0
			// 	destination-address 132.252.206.50 0.0.0.0
			// 	action permit
			//    rule name policy_Deny_DCN_Attack_Source
			// 	description This policy used to deny DCN access JiS_subnet
			// 	source-zone QXDCN
			// 	source-address address-set Deny_DCN_Attack_address_group01
			// 	source-address address-set Deny_DCN_Attack_address_group02
			// 	source-address address-set Deny_DCN_Attack_address_group03
			// 	source-address 1.1.1.1 0.0.0.0
			// 	source-address 8.8.8.8 0.0.0.0

			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `{set:service.range_format=" to "}
security-policy{newline}
	{space:1}rule name {policy_name}{newline}
	{if:exist:description=="true"}{space:2}description {description}{newline}{endif}
	{for:item in sourceZones}
		{space:2}source-zone {item}{newline}
	{endfor}

	{for:item in destinationZones}
		{space:2}destination-zone {item}{newline}
	{endfor}
	{if:exist:make_source=="true"}
		{if:exist:sourceObjects=="true"}
			{for:item in sourceObjects}
				{space:2}source-address address-set {item}{newline}
			{endfor}
		{endif}
	{endif}
	{if:exist:make_destination=="true"}
		{if:exist:destinationObjects=="true"}
			{for:item in destinationObjects}
				{space:2}destination-address address-set {item}{newline}
			{endfor}
		{endif}
	{endif}
	{if:exist:make_service=="true"}
		{if:exist:serviceObjects=="true"}
			{for:item in serviceObjects}
				{space:2}service {item}{newline}
			{endfor}
		{endif}
	{endif}
	{if:exist:make_source=="true"}
		{if:exist:sourceObjects=="false"}
			{for:src in intent.src.EachDataRangeEntryAsAbbrNet}
				{space:2}source-address {if:src:type=="range"}range {src:start} {src:end}{else if:src:type=="subnet"}{src:ip} mask {src:mask}{else}{src:ip} {src:mask:wildcard}{endif}{newline}
			{endfor}
		{endif}
	{endif}
	{if:exist:make_destination=="true"}
		{if:exist:destinationObjects=="false"}
			{for:dst in intent.dst.EachDataRangeEntryAsAbbrNet}
				{space:2}destination-address {if:dst:type=="range"}range {dst:start} {dst:end}{else if:dst:type=="subnet"}{dst:ip} mask {dst:mask}{else}{dst:ip} {dst:mask:wildcard}{endif}{newline}
			{endfor}
		{endif}
	{endif}
	
	{if:exist:make_service=="true"}
		{if:exist:serviceObjects=="false"}
			{for:item in intent.service}
				{space:2}service protocol {item:protocol:lower}
				{if:item:protocol=="TCP"}
					{space:1}{if:item:src_port:isFull!="true"}source-port {item:src_port:compact} {endif}{if:item:dst_port:isFull!="true"}destination-port {item:dst_port:compact}{endif}
				{endif}
				{if:item:protocol=="UDP"}
					{space:1}{if:item:src_port:isFull!="true"}source-port {item:src_port:compact} {endif}{if:item:dst_port:isFull!="true"}destination-port {item:dst_port:compact}{endif}
				{endif}
				{if:item:protocol=="ICMP"}
					{if:item:hasType=="true"}
						{space:1}icmp-type {item:type}
						{if:item:hasCode=="true"}
							{space:1}{item:code}
						{endif}
					{endif}
				{endif}
				{newline}
			{endfor}
		{endif}
	{endif}
  {space:2}action permit{newline}
`,
			},
		},
	}

	return &UsgTemplates{
		BaseTemplates: *spt,
	}
}

type ASATemplates struct {
	BaseTemplates
}

func NewASATemplates() *ASATemplates {
	spt := &BaseTemplates{
		ConfigKeys: []Entry{
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "!"},
			// hostname(config)# object network email-server
			// Add an address to the object using one of the following commands. Use the no form of the command to remove the object.
			// 	host {IPv4_address | IPv6_address}—The IPv4 or IPv6 address of a single host. For example, 10.1.1.1 or 2001:DB8::0DB8:800:200C:417A.
			// 	subnet {IPv4_address IPv4_mask | IPv6_address/IPv6_prefix}—The address of a network. For IPv4 subnets, include the mask after a space, for example, 10.0.0.0 255.0.0.0. For IPv6, include the address and prefix as a single unit (no spaces), such as 2001:DB8:0:CD30::/60.
			// 	range start_address end_address—A range of addresses. You can specify IPv4 or IPv6 ranges. Do not include masks or prefixes.
			// 	fqdn [v4 | v6] fully_qualified_domain_name—A fully-qualified domain name, that is, the name of a host, such as www.example.com. Specify v4 to limit the address to IPv4, and v6 for IPv6. If you do not specify an address type, IPv4 is assumed.

			// hostname(config)# object-group network admin
			// Add objects and addresses to the network object group using one or more of the following commands. Use the no form of the command to remove an object.
			// 	network-object host {IPv4_address | IPv6_address}—The IPv4 or IPv6 address of a single host. For example, 10.1.1.1 or 2001:DB8::0DB8:800:200C:417A.
			// 	network-object {IPv4_address IPv4_mask | IPv6_address/IPv6_prefix}—The address of a network or host. For IPv4 subnets, include the mask after a space, for example, 10.0.0.0 255.0.0.0. For IPv6, include the address and prefix as a single unit (no spaces), such as 2001:DB8:0:CD30::/60.
			//	network-object object object_name—The name of an existing network object.
			// 	group-object object_group_name—The name of an existing network object group.
			{Key: keys.NewKeyBuilder("NetworkObject", "OneLoop"), Value: `
{if:exist:object_name=="true"}
	{if:make_vip=="true"}
		object network {object_name}{newline}
		{space:1}host {real_ip}{newline}
	{else if:isSingle=="true"}
		object network {object_name}{newline}
		{for:item in networkgroup}
			{if:item:type=="range"} range {item:start} {item:end}
			{else if:item:type=="host"} host {item:ip}
			{else} subnet {item:ip} {item:mask:dotted}{endif}
			{newline}
		{endfor}
	{else}
		object-group network {object_name}{newline}
		{for:item in networkgroup}
			{space:1}network-object
			{if:item:type=="range"} range {item:start} {item:end}
			{else if:item:type=="host"} host {item:ip}
			{else} {item:ip} {item:mask:dotted}{endif}
			{newline}
		{endfor}
	{endif}
{endif}`},

			{Key: keys.NewKeyBuilder("ServiceObject", "CompactPorts"), Value: `{set:service.range_format="_"}
{if:src_port:isFull!="true"}
	S{src_port:compact}
	{if:dst_port:isFull!="true"
		D{dst_port:compact}
	{endif}
{else}
	{dst_port:compact}
{endif}
`},
			// hostname(config)# object service web
			// Add a service to the object using one of the following commands. Use the no form of the command to remove an object.
			// 	service protocol —The name or number (0-255) of an IP protocol. Specify ip to apply to all protocols.
			// xxxxxxx kkk
			// 	service {icmp | icmp6} [icmp-type [icmp_code]] —For ICMP or ICMP version 6 messages. You can optionally specify the ICMP type by name or number (0-255) to limit the object to that message type. If you specify a type, you can optionally specify an ICMP code for that type (1-255). If you do not specify the code, then all codes are used.
			// 	service {tcp | udp | sctp} [source operator port] [destination operator port] —For TCP, UDP or SCTP. You can optionally specify ports for the source, destination, or both. You can specify the port by name or number. The operator can be one of the following:
			// 		lt—less than.
			// 		gt—greater than.
			// 		eq—equal to.
			// 		neq—not equal to.
			// 		range—an inclusive range of values. When you use this operator, specify two port numbers, for example, range 100 200.
			// hostname(config)# object-group service general-services
			// Add objects and services to the service object group using one or more of the following commands. Use the no form of the command to remove an object.
			// 	service-object protocol —The name or number (0-255) of an IP protocol. Specify ip to apply to all protocols.
			// 	service-object {icmp | icmp6} [icmp-type [icmp_code]] —For ICMP or ICMP version 6 messages. You can optionally specify the ICMP type by name or number (0-255) to limit the object to that message type. If you specify a type, you can optionally specify an ICMP code for that type (1-255). If you do not specify the code, then all codes are used.
			// 	service-object {tcp | udp | tcp-udp | sctp} [source operator port] [destination operator port] —For TCP, UDP, or both, or for SCTP. You can optionally specify ports for the source, destination, or both. You can specify the port by name or number. The operator can be one of the following:
			// 		lt—less than.
			// 		gt—greater than.
			// 		eq—equal to.
			// 		neq—not equal to.
			// 		range—an inclusive range of values. When you use this operator, specify two port numbers, for example, range 100 200.
			// 		service-object object object_name—The name of an existing service object.
			// 	group-object object_group_name—The name of an existing service object group.

			// Service Object - ASA uses "object service" or "object-group service"
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `{set:service.range_format=" "}
{if:exist:object_name=="true"}
{if:isSignle=="true"}
object service {object_name}{newline}
{for:item in service.EachDetailed}
    service {if:item:protocol=="TCP"}
				tcp{if:item:src_port:isFull=="false"} source range {item:src_port:range}{endif}
				{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
				{else if:item:dst_port:isFull=="false"} destination range {item:dst_port:range}{endif}
			{else if:item:protocol=="UDP"}
				udp{if:item:src_port:isFull=="false"} source range {item:src_port:range}{endif}
				{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
				{else if:item:dst_port:isFull=="false"} destination range {item:dst_port:range}{endif}
			{else if:item:protocol=="ICMP"}
				icmp{if:item:hasType=="true"} {item:type}{if:item:hasCode=="true"} {item:code}{else} 0{endif}{endif}
			{else}{item:protocol:lower}
			{endif}
{newline}
{endfor}
{else}
object-group service {object_name}{newline}
{for:item in service.EachDetailed}
    {space:1}service-object {if:item:protocol=="TCP"}
				tcp{if:item:src_port:isFull=="false"} source range {item:src_port:range}{endif}
				{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
				{else if:item:dst_port:isFull=="false"} destination range {item:dst_port:range}{endif}
			{else if:item:protocol=="UDP"}
				udp{if:item:src_port:isFull=="false"} source range {item:src_port:range}{endif}
				{if:item:dst_port:count==1} destination eq {item:dst_port:compact}
				{else if:item:dst_port:isFull=="false"} destination range {item:dst_port:range}{endif}
			{else if:item:protocol=="ICMP"}
				icmp{if:item:hasType=="true"} {item:type}{if:item:hasCode=="true"} {item:code}{else} 0{endif}{endif}
			{else}{item:protocol:lower}
			{endif}
{newline}
{endfor}
{endif}
{endif}
`},

			// hostname(config)# access-list ACL_IN extended permit ip any any
			// hostname(config)# access-list ACL_IN extended permit object service-obj-http any any

			// The options are:
			// access_list_name—The name of the new or existing ACL.
			// 		Line number—The line line_number option specifies the line number at which insert the ACE; otherwise, the ACE is added to the end of the ACL.
			// 		Permit or Deny—The deny keyword denies or exempts a packet if the conditions are matched. The permit keyword permits or includes a packet if the conditions are matched.
			// 		Protocol—The protocol_argument specifies the IP protocol.
			// 			name or number—Specifies the protocol name or number. Specify ip to apply to all protocols.
			// 			object-group protocol_grp_id—Specifies a protocol object group created using the object-group protocol command.
			// 			object service_obj_id—Specifies a service object created using the object service command. The object can include port or ICMP type and code specifications if desired.
			// 			object-group service_grp_id—Specifies a service object group created using the object-group service command.
			//		Source Address, Destination Address—The source_address_argument specifies the IP address or FQDN from which the packet is being sent, and the dest_address_argument specifies the IP address or FQDN to which the packet is being sent:
			//			host ip_address—Specifies an IPv4 host address.
			//			ip_address mask—Specifies an IPv4 network address and subnet mask, such as 10.100.10.0 255.255.255.0.
			// 			ipv6-address/prefix-length—Specifies an IPv6 host or network address and prefix.
			// 			any, any4, and any6—any specifies both IPv4 and IPv6 traffic; any4 specifies IPv4 traffic only; and any6 specifies IPv6 traffic only.
			// 			interface interface_name—Specifies the name of an ASA interface. Use the interface name rather than IP address to match traffic based on which interface is the source or destination of the traffic.
			// 			object nw_obj_id—Specifies a network object created using the object network command.
			// 			object-group nw_grp_id—Specifies a network object group created using the object-group network command.
			//		Logging—log arguments set logging options when an ACE matches a connection for network access (an ACL applied with the access-group command). If you enter the log option without any arguments, you enable syslog message 106100 at the default level (6) and for the default interval (300 seconds). Log options are:
			// 			level—A severity level between 0 and 7. The default is 6 (informational). If you change this level for an active ACE, the new level applies to new connections; existing connections continue to be logged at the previous level.
			// 			interval secs—The time interval in seconds between syslog messages, from 1 to 600. The default is 300. This value is also used as the timeout value for deleting an inactive flow from the cache used to collect drop statistics.
			// 			disable—Disables all ACE logging.
			// 			default—Enables logging to message 106023 for denied packets. This setting is the same as not including the log option.
			// 		Time Range—The time-range time_range_name option specifies a time range object, which determines the times of day and days of the week in which the ACE is active. If you do not include a time range, the ACE is always active.
			// 			Activation—Use the inactive option to disable the ACE without deleting it. To reenable it, enter the entire ACE without the inactive keyword.

			// ACL - ASA uses "access-list"
			{Key: keys.NewKeyBuilder("ACL", "OneLoop"), Value: `
{for:item in intent.EachDataRangeEntryAsAbbrNet.EachDataRangeEntryAsAbbrNet.EachDetailed}
    access-list {acl_name} extended permit {item:service:protocol:lower}
    {if:item:src:isFull=="false"}{if:item:src:isHost==true} host {item:src:ip}{else if:item:src:isRange==true} range {item:src:start} {item:src:end}{else} {item:src:ip} {item:src:mask:dotted}{endif}{else} any{endif}
    {if:item:service:protocol=="TCP"}
        {if:item:service:src_port:isFull=="false"}
            {if:item:service:src_port:count=="1"}
                {space:1}eq {item:service:src_port:compact}
            {else}
                {space:1}range {item:service:src_port:start} {item:service:src_port:end}
            {endif}
        {endif}
    {else if:item:service:protocol=="UDP"}
        {if:item:service:src_port:isFull=="false"}
            {if:item:service:src_port:count=="1"}
                {space:1}eq {item:service:src_port:compact}
            {else}
                {space:1}range {item:service:src_port:start} {item:service:src_port:end}
            {endif}
        {endif}
    {endif}
    {if:item:dst:isFull=="false"}{if:item:dst:isHost==true} host {item:dst:ip}{else if:item:dst:isRange==true} range {item:dst:start} {item:dst:end}{else} {item:dst:ip} {item:dst:mask:dotted}{endif}{else} any{endif}
    {if:item:service:protocol=="TCP"}
        {if:item:service:dst_port:isFull=="false"}
            {if:item:service:dst_port:count=="1"}
                {space:1}eq {item:service:dst_port:compact}
            {else}
                {space:1}range {item:service:dst_port:start} {item:service:dst_port:end}
            {endif}
        {endif}
    {else if:item:service:protocol=="UDP"}
        {if:item:service:dst_port:isFull=="false"}
            {if:item:service:dst_port:count=="1"}
                {space:1}eq {item:service:dst_port:compact}
            {else}
                {space:1}range {item:service:dst_port:start} {item:service:dst_port:end}
            {endif}
        {endif}
    {else if:item:service:protocol=="ICMP"}
        {if:item:service:hasType=="true"} icmp-type {item:service:type}{endif}
        {if:item:service:hasCode=="true"} icmp-code {item:service:code}{endif}
    {else}
        {item:service:protocol:lower}
    {endif}
    {newline}
{endfor}
`},

			// Policy - ASA doesn't have a separate policy command, it uses ACL applied to interfaces
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
{comment:ASA uses ACL for security policy, this is a placeholder}
{comment:access-group {acl_name} in interface {fromPort}}
{comment:access-group {acl_name} out interface {toPort}}
`},

			// Static NAT - ASA uses "nat" command
			// Format: nat (real_ifc,mapped_ifc) source static real_src mapped_src [destination static mapped_dest real_dest] [service real_svc mapped_svc]
			// For static NAT: real_src is real_ip (internal IP), mapped_src is dst_network (external IP)
			// Use object names if available, otherwise use direct IP addresses
			{Key: keys.NewKeyBuilder("Nat", "Static", "OneLoop"), Value: `{set:intent.dst_template="{ip}"}{set:service.range_format=" "}
{if:direction=="Inbound"}
    nat ({toPort},{fromPort}) source static {if:exist:real_src_obj=="true"}{real_src_obj}{else}{real_ip}{endif} {if:exist:mapped_src_obj=="true"}{mapped_src_obj}{else}{dst_network}{endif}
    {if:exist:real_port=="true"} service {protocol:lower} {dst_port:compact} {real_port:compact}{endif}
{else if:direction=="InOut"}
    nat ({fromPort},{toPort}) source static {if:exist:real_src_obj=="true"}{real_src_obj}{else}{real_ip}{endif} {if:exist:mapped_src_obj=="true"}{mapped_src_obj}{else}{dst_network}{endif}
    {if:exist:real_port=="true"} service {protocol:lower} {dst_port:compact} {real_port:compact}{endif}
{else}
    nat ({fromPort},{toPort}) source static {if:exist:real_src_obj=="true"}{real_src_obj}{else}{real_ip}{endif} {if:exist:mapped_src_obj=="true"}{mapped_src_obj}{else}{dst_network}{endif}
    {if:exist:real_port=="true"} service {protocol:lower} {dst_port:compact} {real_port:compact}{endif}
{endif}
{newline}
`},

			// Dynamic NAT
			{Key: keys.NewKeyBuilder("Nat", "Dynamic", "OneLoop"), Value: `
nat ({fromPort},{toPort}) source dynamic {src_network} {pool_name}
{newline}
`},
			// nat (inside,outside) source dynamic INSIDE_NW MAPPED_1 destination static SERVERS_1 SERVERS_1
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `{set:intent.dst_template="{ip}"}{set:service.range_format=" "}
				{if:real_ip!=""}
					{if:inbound_nat=="twice"}
						nat ({fromPort},{toPort}) source static {sourceObjects[0]} {sourceObjects[0]} destination static {realIpObjects} {destinationObjects[0]}{if:real_port!=""} service {serviceObjects[0]} {realServiceObjects}{endif}
					{else}
						object network {realIpObjects}{newline}
						{space:1}nat ({fromPort},{toPort}) static {if:exist:destinationObjects=="true"}{destinationObjects}{else}{dst_network}{endif}
						{if:real_port!=""} service {protocol:lower} {real_port} {dst_port:compact}{endif}
					{endif}
					{newline}
				{else}
					{if:outbound_nat=="twice"}
					nat ({fromPort},{toPort}) source dynamic {sourceObjects[0]} {pool_name} destination static {destinationObjects[0]} {destinationObjects[0]}{if:real_port!=""} service {serviceObjects[0]} {serviceObjects[0]}{endif}
					{else}
					    object network {realIpObjects}{newline}
						{space:1}nat ({fromPort},{toPort}) dynamic {pool_name}
					{endif}
					{newline}
				{endif}`},

			// Pool - ASA doesn't use pool in the same way, but we define it for compatibility
			{Key: keys.NewKeyBuilder("Pool", "OneLoop"), Value: `
{if:exist:object_name=="true"}
{if:isSignle=="true"}
object network {object_name}{newline}
{for:item in networkgroup}
    {if:item:type=="range"} range {item:start} {item:end}
    {else if:item:type=="host"} host {item:ip}
    {else} subnet {item:ip} {item:mask:dotted}{endif}
    {newline}
{endfor}
{else}
object-group network {object_name}{newline}
{for:item in networkgroup}
    {space:1}network-object
    {if:item:type=="range"} range {item:start} {item:end}
    {else if:item:type=="host"} host {item:ip}
    {else} {item:ip} {item:mask:dotted}{endif}
    {newline}
{endfor}
{endif}
{endif}`},

			// Policy Command Permit
			{Key: keys.NewKeyBuilder("Policy", "Command", "Permit"), Value: "permit"},
		},
	}

	return &ASATemplates{
		BaseTemplates: *spt,
	}
}

type SRXTemplates struct {
	BaseTemplates
}

func NewSRXTemplates() *SRXTemplates {
	spt := &BaseTemplates{
		ConfigKeys: []Entry{
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "#"},

			// Network Object - SRX uses "set security zones security-zone {zone} address-book address {objectName}"
			{Key: keys.NewKeyBuilder("NetworkObject", "OneLoop"), Value: `
{if:exist:object_name=="true"}
set security zones security-zone {zone} address-book address {object_name}
{if:item:type=="range"} {item:start} to {item:end}
{else if:item:type=="host"} {item:ip}/32
{else} {item:ip}/{item:mask:prefix}{endif}
{newline}
{endif}`},

			// Service Object - SRX uses service objects
			{Key: keys.NewKeyBuilder("ServiceObject", "CompactPorts"), Value: `{set:service.range_format="_"}
{if:src_port:isFull!="true"}
	S{src_port:compact}
	{if:dst_port:isFull!="true"}
		D{dst_port:compact}
	{endif}
{else}
	{dst_port:compact}
{endif}
`},

			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{if:exist:object_name=="true"}
set applications application {object_name}
{for:item in service.EachDetailed}
    {if:item:protocol=="TCP"}
        protocol tcp
        {if:item:dst_port:count==1} destination-port {item:dst_port:compact}
        {else if:item:dst_port:isFull!="false"} destination-port {item:dst_port:range}
        {endif}
        {if:item:src_port:isFull!="false"} source-port {item:src_port:range}{endif}
    {else if:item:protocol=="UDP"}
        protocol udp
        {if:item:dst_port:count==1} destination-port {item:dst_port:compact}
        {else if:item:dst_port:isFull!="false"} destination-port {item:dst_port:range}
        {endif}
        {if:item:src_port:isFull!="false"} source-port {item:src_port:range}{endif}
    {else if:item:protocol=="ICMP"}
        protocol icmp
        {if:item:hasType=="true"} icmp-type {item:type}
            {if:item:hasCode=="true"} code {item:code}{endif}
        {endif}
    {else}
        protocol {item:protocol:lower}
    {endif}
    {newline}
{endfor}
{endif}
`},

			// ACL - SRX doesn't use traditional ACL, uses policies
			{Key: keys.NewKeyBuilder("ACL", "OneLoop"), Value: `
{comment:SRX uses security policies instead of ACL}
{comment:set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name}}
`},

			// Policy - SRX uses "set security policies"
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name}{newline}
{if:exist:description=="true"}set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} description {description}{newline}{endif}
{if:exist:make_source=="true"}
	{if:exist:sourceObjects=="true"}
		{for:item in sourceObjects}
			set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match source-address {item}{newline}
		{endfor}
	{endif}
{endif}
{if:exist:make_destination=="true"}
	{if:exist:destinationObjects=="true"}
		{for:item in destinationObjects}
			set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match destination-address {item}{newline}
		{endfor}
	{endif}
{endif}
{if:exist:make_service=="true"}
	{if:exist:serviceObjects=="true"}
		{for:item in serviceObjects}
			set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match application {item}{newline}
		{endfor}
	{endif}
{endif}
{if:exist:make_source=="true"}
	{if:exist:sourceObjects=="false"}
		{for:src in intent.src.EachDataRangeEntryAsAbbrNet}
			set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match source-address {if:src:type=="range"}{src:start}-{src:end}{else}{src:ip}/{src:mask:prefix}{endif}{newline}
		{endfor}
	{endif}
{endif}
{if:exist:make_destination=="true"}
	{if:exist:destinationObjects=="false"}
		{for:dst in intent.dst.EachDataRangeEntryAsAbbrNet}
			set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match destination-address {if:dst:type=="range"}{dst:start}-{dst:end}{else}{dst:ip}/{dst:mask:prefix}{endif}{newline}
		{endfor}
	{endif}
{endif}
{if:exist:make_service=="true"}
	{if:exist:serviceObjects=="false"}
		{for:item in intent.service}
			set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} match application {item:protocol:lower}
			{if:item:protocol=="TCP"}
				{if:item:dst_port:isFull!="false"} destination-port {item:dst_port:range}{endif}
				{if:item:src_port:isFull!="false"} source-port {item:src_port:range}{endif}
			{endif}
			{if:item:protocol=="UDP"}
				{if:item:dst_port:isFull!="false"} destination-port {item:dst_port:range}{endif}
				{if:item:src_port:isFull!="false"} source-port {item:src_port:range}{endif}
			{endif}
			{newline}
		{endfor}
	{endif}
{endif}
set security policies from-zone {fromZone} to-zone {toZone} policy {policy_name} then permit{newline}
`},

			// Static NAT - SRX uses "set security nat static"
			{Key: keys.NewKeyBuilder("Nat", "Static", "OneLoop"), Value: `
{if:direction=="Inbound"}
    set security nat static rule-set {nat_rule_name} rule {policy_name} match destination-address {dst_network}
    set security nat static rule-set {nat_rule_name} rule {policy_name} then static-nat prefix {real_ip}
{else if:direction=="InOut"}
    set security nat static rule-set {nat_rule_name} rule {policy_name} match source-address {src_network}
    set security nat static rule-set {nat_rule_name} rule {policy_name} match destination-address {dst_network}
    set security nat static rule-set {nat_rule_name} rule {policy_name} then static-nat prefix {real_ip}
{else}
    set security nat static rule-set {nat_rule_name} rule {policy_name} match source-address {src_network}
    set security nat static rule-set {nat_rule_name} rule {policy_name} then static-nat prefix {real_ip}
{endif}
{newline}
`},

			// Dynamic NAT - SRX uses "set security nat source"
			{Key: keys.NewKeyBuilder("Nat", "Dynamic", "OneLoop"), Value: `
set security nat source rule-set {nat_rule_name} rule {policy_name} match source-address {src_network}
set security nat source rule-set {nat_rule_name} rule {policy_name} then source-nat pool {pool_name}
{newline}
`},

			// NAT Policy
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{comment:SRX uses separate nat configurations, not nat policy}
`},

			// Pool - SRX uses "set security nat source pool"
			{Key: keys.NewKeyBuilder("Pool", "OneLoop"), Value: `
set security nat source pool {pool_name} address
{for:item in networkgroup}
    {if:item:type=="range"} {item:start} to {item:end}
    {else if:item:type=="host"} {item:ip}/32
    {else} {item:ip}/{item:mask:prefix}{endif}
{endfor}
{newline}
`},

			// Policy Command Permit
			{Key: keys.NewKeyBuilder("Policy", "Command", "Permit"), Value: "permit"},
		},
	}

	return &SRXTemplates{
		BaseTemplates: *spt,
	}
}

type FortiTemplates struct {
	BaseTemplates
}

func NewFortiTemplates() *FortiTemplates {
	spt := &BaseTemplates{
		ConfigKeys: []Entry{
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: ""},

			// Network Object - FortiGate uses "config firewall address"
			{Key: keys.NewKeyBuilder("NetworkObject", "OneLoop"), Value: `
{if:make_vip=="true"}
    config firewall vip{newline}
        edit "{object_name}"{newline}
            set extip {dst.first}-{dst.last}{newline}
            set mappedip "{real_ip}"{newline}
            set extintf "{toPort}"{newline}
            {if:real_port!=""}set portforward enable{newline}
            set extport {service.dst_port:compact}{newline}
            set mappedport {real_port}{newline}
			{else}
			set portforward disable{newline}
			{endif}
        next{newline}
    end{newline}
{else if:make_snat="true"}
config firewall ippool{newline}
    edit "{pool_name}"{newline}
        set type overload{newline}
        set startip {first}{newline}
        set endip {last}{newline}
    next{newline}
end{newline}
{else}
	{if:exist:object_name=="true"}
		{if:isSingle=="true"}
		config firewall address{newline}
			edit "{object_name}"{newline}
				{for:item in networkgroup.EachDataRangeEntryAsAbbrNet}
				{if:item:type=="range"} set type iprange{newline}
					set start-ip {item:start}{newline}
					set end-ip {item:end}{newline}
				{else if:item:type=="host"} set subnet {item:ip} 255.255.255.255{newline}
				{else} set subnet {item:ip} {item:mask:dotted}{newline}
				{endif}
				{endfor}
			next{newline}
		end
		{else}
		config firewall addrgrp{newline}
			edit "{object_name}"{newline}
				set member{for:item in objectNames} "{item}"{endfor}{newline}
			next{newline}
		end
		{endif}
	{endif}
{endif}
`},

			// Service Object - FortiGate uses "config firewall service"
			{Key: keys.NewKeyBuilder("ServiceObject", "CompactPorts"), Value: `{set:service.range_format="_"}
{if:src_port:isFull!="true"}
	S{src_port:compact}
	{if:dst_port:isFull!="true"}
		D{dst_port:compact}
	{endif}
{else}
	{dst_port:compact}
{endif}
`},

			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{if:exist:object_name=="true"}
config firewall service custom{newline}
    edit "{object_name}"{newline}
        {for:item in service.EachDetailed}
        {if:item:protocol=="TCP"} set tcp-portrange {item:dst_port:range}{newline}
        {else if:item:protocol=="UDP"} set udp-portrange {item:dst_port:range}{newline}
        {else if:item:protocol=="ICMP"} set icmptype {item:type}{newline}
            {if:item:hasCode=="true"} set icmpcode {item:code}{newline}
            {endif}
        {else} set protocol-number {item:protocol:number}{newline}
        {endif}
        {endfor}
    next{newline}
end
{endif}
`},

			// ACL - FortiGate uses policies, not separate ACL
			{Key: keys.NewKeyBuilder("ACL", "OneLoop"), Value: `
{comment:FortiGate uses firewall policies instead of ACL}
`},

			// Policy - FortiGate uses "config firewall policy"
			// According to FortiGate CLI documentation: https://docs.fortinet.com/document/fortigate/7.2.3/cli-reference/323620/config-firewall-policy
			// Format: set srcaddr "object1" "object2" "object3" (all objects on one line, space-separated, quoted)
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
{set:service.range_format=" "}
config firewall policy{newline}
    edit {policy_id}{newline}
        set name "{policy_name}"{newline}
        {if:exist:description=="true"}        set comments "{description}"{newline}{endif}
        set srcintf "{fromPort}"{newline}
        set dstintf "{toPort}"{newline}
        {if:exist:make_source=="true"}
            {if:exist:sourceObjects=="true"}        set srcaddr {for:item in sourceObjects}"{item}" {endfor}{newline}
            {endif}
        {endif}
        {if:exist:make_destination=="true"}
            {if:exist:destinationObjects=="true"}        set dstaddr {for:item in destinationObjects}"{item}" {endfor}{newline}
            {endif}
        {endif}
        {if:exist:make_service=="true"}
            {if:exist:serviceObjects=="true"}        set service {for:item in serviceObjects}"{item}" {endfor}{newline}
            {endif}
        {endif}
        set action accept{newline}
        set schedule "always"{newline}
        set status enable{newline}
    next{newline}
end
`},

			// Static NAT - FortiGate uses "config firewall vip"
			// VIP name format: "extip mappedip name" (e.g., "200.0.0.10 10.1.0.10 web")
			{Key: keys.NewKeyBuilder("Nat", "Static", "OneLoop"), Value: `
`},

			// Dynamic NAT - FortiGate uses "config firewall ippool"
			{Key: keys.NewKeyBuilder("Nat", "Dynamic", "OneLoop"), Value: `
config firewall ippool{newline}
    edit "{pool_name}"{newline}
        set type overload{newline}
        set startip {pool_start}{newline}
        set endip {pool_end}{newline}
    next{newline}
end{newline}
{newline}
`},

			// NAT Policy - FortiGate handles NAT in policy configuration
			// According to FortiGate CLI documentation: https://docs.fortinet.com/document/fortigate/7.0.0/cli-reference/323620/config-firewall-policy
			// When using VIP (DNAT): set nat enable
			// When using IP Pool (SNAT): set nat enable, set ippool enable, set poolname "pool_name"
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{set:service.range_format=" "}
config firewall policy{newline}
    edit "{policy_name}"{newline}
        set name "{policy_name}"{newline}
        {if:exist:description=="true"}        set comments "{description}"{newline}{endif}
        set srcintf "{fromPort}"{newline}
        set dstintf "{toPort}"{newline}
        {if:exist:make_source=="true"}
            {if:exist:sourceObjects=="true"}        set srcaddr {for:item in sourceObjects}"{item}" {endfor}{newline}
            {endif}
        {endif}
        {if:exist:make_destination=="true"}
            {if:exist:destinationObjects=="true"}        set dstaddr {for:item in destinationObjects}"{item}" {endfor}{newline}
            {endif}
        {endif}
        {if:exist:make_service=="true"}
            {if:exist:serviceObjects=="true"}        set service {for:item in serviceObjects}"{item}" {endfor}{newline}
            {endif}
        {endif}
        set action accept{newline}
        set schedule "always"{newline}
        set status enable{newline}
        {if:exist:use_vip=="true"}
        set nat enable{newline}
        {else if:exist:use_pool=="true"}
        set nat enable{newline}
        set ippool enable{newline}
        set poolname "{pool_name}"{newline}
        {endif}
    next{newline}
end
`},

			// Pool - FortiGate uses "config firewall ippool"
			// According to FortiGate CLI documentation: https://docs.fortinet.com/document/fortigate/7.2.3/cli-reference/298620/config-firewall-ippool
			// Format: config firewall ippool edit "pool_name" set type overload set startip {startip} set endip {endip} next end
			// Pool name is generated from snat_object_name_template if provided
			{Key: keys.NewKeyBuilder("Pool", "OneLoop"), Value: `
config firewall ippool{newline}
    edit "{pool_name}"{newline}
        set type overload{newline}
        set startip {first}{newline}
        set endip {last}{newline}
    next{newline}
end{newline}
`},

			// Policy Command Permit
			{Key: keys.NewKeyBuilder("Policy", "Command", "Permit"), Value: "accept"},
		},
	}

	return &FortiTemplates{
		BaseTemplates: *spt,
	}
}

type SangforTemplates struct {
	BaseTemplates
}

func NewSangforTemplates() *SangforTemplates {
	spt := &BaseTemplates{
		ConfigKeys: []Entry{
			{Key: keys.NewKeyBuilder("SectionSeparator"), Value: "\n"},
			// Sangfor 网络对象模板
			// 格式: config\nipgroup "name" ipv4\ntype ip\nimportance ordinary\nipentry ...\nend
			{Key: keys.NewKeyBuilder("NetworkObject", "OneLoop"), Value: `
{if:exist:object_name=="true"}
config{newline}
ipgroup "{object_name}" ipv4{newline}
type ip{newline}
importance ordinary{newline}
{for:item in networkgroup}
	{if:item:type=="range"}ipentry {item:start}-{item:end}
	{else if:item:type=="host"}ipentry {item:ip}
	{else}ipentry {item:ip}/{item:mask:prefix}{endif}
	{newline}
{endfor}
end{newline}
{endif}
`},
			// Sangfor 服务对象模板 - CompactPorts 布局（用于生成对象名称中的端口部分）
			// 格式: 用于生成紧凑的端口表示，如 "80", "80-8080", "S80D443" 等
			{Key: keys.NewKeyBuilder("ServiceObject", "CompactPorts"), Value: `{set:service.range_format="_"}
{if:src_port:isFull!="true"}
	S{src_port:compact}
	{if:dst_port:isFull!="true"}
		D{dst_port:compact}
	{endif}
{else}
	{dst_port:compact}
{endif}
`},
			// Sangfor 服务对象模板 - OneLoop 布局（用于生成完整的服务对象配置）
			// 格式: config\nservice "name"\n...\nend
			{Key: keys.NewKeyBuilder("ServiceObject", "OneLoop"), Value: `
{if:exist:object_name=="true"}
config{newline}
service "{object_name}"{newline}
{for:item in service.EachDetailed}
	{if:item:protocol=="TCP"}
		{if:item:dst_port:isFull!="true"}
			{if:item:dst_port:count==1}tcp-entry destination-port {item:dst_port:compact}
			{else}tcp-entry destination-port {item:dst_port:range}{endif}
		{else}
			tcp-entry{endif}
		{newline}
	{else if:item:protocol=="UDP"}
		{if:item:dst_port:isFull!="true"}
			{if:item:dst_port:count==1}udp-entry destination-port {item:dst_port:compact}
			{else}udp-entry destination-port {item:dst_port:range}{endif}
		{else}
			udp-entry{endif}
		{newline}
	{else if:item:protocol=="ICMP"}
		icmp-entry{newline}
	{else if:item:protocol=="ICMP6"}
		icmpv6-entry{newline}
	{else}
		other-entry protocol {item:protocol:lower}{newline}
	{endif}
{endfor}
end{newline}
{endif}
`},
			// Sangfor 策略模板
			// 格式: config\npolicy "name" bottom\nenable\n...\naction permit\nend
			{Key: keys.NewKeyBuilder("Policy", "OneLoop"), Value: `
config{newline}
policy "{policy_name}" bottom{newline}
{if:enable=="true"}enable{newline}{endif}
group "default-policygroup"{newline}
{for:zone in sourceZones}
	{if:zone!=""}
		src-zone "{zone}"{newline}
	{endif}
{endfor}
{for:zone in destinationZones}
	{if:zone!=""}
		dst-zone "{zone}"{newline}
	{endif}
{endfor}
{if:exist:src_objects=="true"}
	{for:src_obj in src_objects}
		src-ipgroup "{src_obj}"{newline}
	{endfor}
{else if:exist:source_network=="true"}
	src-ipgroup "{source_network}"{newline}
{endif}
user-group "/"{newline}
{if:exist:dst_objects=="true"}
	{for:dst_obj in dst_objects}
		dst-ipgroup "{dst_obj}"{newline}
	{endfor}
{else if:exist:destination_network=="true"}
	dst-ipgroup "{destination_network}"{newline}
{endif}
{if:exist:service_objects=="true"}
	{for:svc_obj in service_objects}
		service "{svc_obj}"{newline}
	{endfor}
{else}
	service "any"{newline}
{endif}
application "全部"{newline}
action {action}{newline}
schedule "all-week"{newline}
log session-start disable{newline}
log session-end disable{newline}
end{newline}
`},
			{Key: keys.NewKeyBuilder("Policy", "Command", "Permit"), Value: "permit"},
			{Key: keys.NewKeyBuilder("Policy", "Command", "Deny"), Value: "deny"},
			// NAT 模板 - 使用 Nat.Static.OneLoop 和 Nat.Dynamic.OneLoop 键名（与代码中使用的键名一致）
			// 静态 NAT (DNAT) - 使用 Nat.Static.OneLoop 键名
			{Key: keys.NewKeyBuilder("Nat", "Static", "OneLoop"), Value: `
config{newline}
dnat-rule "{nat_name}" bottom{newline}
{if:enable=="true"}enable{newline}{endif}
{if:exist:src_zones=="true"}
	{for:zone in src_zones}
		src-zone "{zone}"{newline}
	{endfor}
{endif}
schedule "all-week"{newline}
{if:exist:src_objects=="true"}
	{for:src_obj in src_objects}
		src-ipgroup "{src_obj}"{newline}
	{endfor}
{endif}
{if:exist:dst_ip=="true"}
	dst-ip {dst_ip}{newline}
{endif}
ignore-acl enable{newline}
log bypass-acl disable{newline}
{if:exist:service_objects=="true"}
	{for:svc_obj in service_objects}
		service {svc_obj}{newline}
	{endfor}
{else}
	service any{newline}
{endif}
{if:exist:transfer_type=="true"}
	{if:transfer_type=="IP"}
		transfer ip {transfer_ip}{if:exist:transfer_port=="true"} port {transfer_port}{endif}{newline}
	{else if:transfer_type=="IP_RANGE"}
		transfer iprange {transfer_start}-{transfer_end}{if:exist:transfer_mode=="true"} {transfer_mode}{endif}{newline}
	{else if:transfer_type=="IPGROUP"}
		transfer ipgroup {transfer_ipgroup}{newline}
	{endif}
{endif}
transfer load-balance disable{newline}
end{newline}
`},
			// 动态 NAT (SNAT) - 使用 Nat.Dynamic.OneLoop 键名
			{Key: keys.NewKeyBuilder("Nat", "Dynamic", "OneLoop"), Value: `
config{newline}
snat-rule "{nat_name}" bottom{newline}
{if:enable=="true"}enable{newline}{endif}
{if:exist:src_zones=="true"}
	{for:zone in src_zones}
		src-zone "{zone}"{newline}
	{endfor}
{endif}
schedule "all-week"{newline}
{if:exist:src_objects=="true"}
	{for:src_obj in src_objects}
		src-ipgroup "{src_obj}"{newline}
	{endfor}
{endif}
{if:exist:dst_zones=="true"}
	{for:zone in dst_zones}
		dst-zone {zone}{newline}
	{endfor}
{endif}
{if:exist:dst_objects=="true"}
	{for:dst_obj in dst_objects}
		dst-ipgroup "{dst_obj}"{newline}
	{endfor}
{endif}
{if:exist:service_objects=="true"}
	{for:svc_obj in service_objects}
		service {svc_obj}{newline}
	{endfor}
{else}
	service any{newline}
{endif}
{if:exist:transfer_type=="true"}
	{if:transfer_type=="IP"}
		transfer ip {transfer_ip}{newline}
	{else if:transfer_type=="IP_RANGE"}
		transfer iprange {transfer_start}-{transfer_end}{if:exist:transfer_mode=="true"} {transfer_mode}{endif}{newline}
	{else if:transfer_type=="IPGROUP"}
		transfer ipgroup {transfer_ipgroup}{newline}
	{endif}
{endif}
end{newline}
`},
			// NAT Policy - 用于基于策略的 NAT（PolicyBasedNat 模式）
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
{comment:Sangfor uses separate dnat-rule and snat-rule configurations, not nat policy}
{comment:This template is a placeholder for PolicyBasedNat mode}
`},
			// Pool - Sangfor 使用 ipgroup 对象作为 NAT 地址池
			// 格式: config\nipgroup "name" ipv4\ntype ip\nimportance ordinary\nipentry ...\nend
			{Key: keys.NewKeyBuilder("Pool", "OneLoop"), Value: `
{if:exist:pool_name=="true"}
config{newline}
ipgroup "{pool_name}" ipv4{newline}
type ip{newline}
importance ordinary{newline}
{for:item in networkgroup}
	{if:item:type=="range"}ipentry {item:start}-{item:end}
	{else if:item:type=="host"}ipentry {item:ip}
	{else}ipentry {item:ip}/{item:mask:prefix}{endif}
	{newline}
{endfor}
end{newline}
{endif}
`},
			// ACL - Sangfor 使用策略（policy）而不是独立的 ACL
			{Key: keys.NewKeyBuilder("ACL", "OneLoop"), Value: `
{comment:Sangfor uses firewall policies instead of ACL}
{comment:This template is a placeholder for ACL mode}
`},
			// NAT 模板 - 保留 StaticNat 和 DynamicNat 键名以保持兼容性
			{Key: keys.NewKeyBuilder("StaticNat", "OneLoop"), Value: `
config{newline}
dnat-rule "{nat_name}" bottom{newline}
{if:enable=="true"}enable{newline}{endif}
{if:exist:src_zones}
	{for:zone in src_zones}
		src-zone "{zone}"{newline}
	{endfor}
{endif}
schedule "all-week"{newline}
{if:exist:src_objects}
	{for:src_obj in src_objects}
		src-ipgroup "{src_obj}"{newline}
	{endfor}
{endif}
{if:exist:dst_ip}
	dst-ip {dst_ip}{newline}
{endif}
ignore-acl enable{newline}
log bypass-acl disable{newline}
{if:exist:service_objects}
	{for:svc_obj in service_objects}
		service {svc_obj}{newline}
	{endfor}
{else}
	service any{newline}
{endif}
{if:exist:transfer_type}
	{if:transfer_type=="IP"}
		transfer ip {transfer_ip}{if:exist:transfer_port} port {transfer_port}{endif}{newline}
	{else if:transfer_type=="IP_RANGE"}
		transfer iprange {transfer_start}-{transfer_end}{if:exist:transfer_mode} {transfer_mode}{endif}{newline}
	{else if:transfer_type=="IPGROUP"}
		transfer ipgroup {transfer_ipgroup}{newline}
	{endif}
{endif}
transfer load-balance disable{newline}
end{newline}
`},
			{Key: keys.NewKeyBuilder("NatPolicy", "OneLoop"), Value: `
config{newline}
{if:exist:real_ip=="true"}
dnat-rule "{policy_name}" bottom{newline}
{else}
snat-rule "{policy_name}" bottom{newline}
{endif}
{if:enable=="true"}enable{newline}{endif}
{for:zone in sourceZones}
		src-zone "{zone}"{newline}
	{endfor}
schedule "all-week"{newline}
{if:exist:has_source_objects=="true"}
	{for:src_obj in sourceObjects}
		src-ipgroup "{src_obj}"{newline}
	{endfor}
{else}
	{for:item in intent.src.EachDataRangeEntryAsAbbrNet}
		{if:item:isHost=="true"}src-ip {item:ip}{else}src-ip {item:ip}/{item:mask:prefix}{endif}{newline}
	{endfor}
{endif}
{if:exist:has_destination_objects=="true"}
	{for:dst_obj in destinationObjects}
		dst-ipgroup "{dst_obj}"{newline}
	{endfor}
{else}
	{for:item in intent.dst.EachDataRangeEntryAsAbbrNet}
		{if:item:isHost=="true"}dst-ip {item:ip}{else}dst-ip {item:ip}/{item:mask:prefix}{endif}{newline}
	{endfor}
{endif}
{if:exist:has_real_ip=="true"}
ignore-acl enable{newline}
log bypass-acl disable{newline}
{endif}
{for:zone in destinationZones}
	dst-zone {zone}{newline}
{endfor}
{if:exist:has_service_objects=="true"}
	{for:svc_obj in serviceObjects}
		service {svc_obj}{newline}
	{endfor}
{else}
	service any{newline}
{endif}
{if:exist:has_real_ip=="true"}
	transfer ip {real_ip}{if:exist:has_real_port=="true"} port {real_port}{endif}{newline}
{else}
	{if:exist:has_pool_id=="true"}
		transfer ipgroup {pool_id}{newline}
	{else}
		{if:exist:has_snat=="true"}
			transfer ip {snat}{newline}
	{endif}
	{endif}
{endif}
{if:exist:has_real_ip=="true"}
transfer load-balance disable{newline}
{endif}
end{newline}
`},
		},
	}

	return &SangforTemplates{
		BaseTemplates: *spt,
	}
}

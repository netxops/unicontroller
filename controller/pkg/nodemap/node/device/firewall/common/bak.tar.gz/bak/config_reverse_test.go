package common

import (
	"fmt"
	"os"
	"strings"
	"testing"
)

// 测试用的配置片段
var testConfigSnippet = `
ip address-set JiS_policy_2246_addr01 type object
 description JiS_policy_2246_source_address
 address 0 132.254.98.0 mask 24
#
ip address-set JiS_policy_1967_src_addr01 type object
 description JiS_policy_1967_source_address
 address 0 132.252.33.169 0.0.0.0
 address 1 132.252.33.170 0.0.0.0
#
ip address-set JiS_policy_1628_addr01 type object
 description JiS_policy_1628_destination_address
 address 0 132.254.90.58 0.0.0.0
 address 1 132.254.90.60 0.0.0.0
#
ip address-set DCN_BSS_address_group type object
 address 23 132.228.175.128 0.0.0.63 description EC6F_CRM_DB_VLAN103
 address 24 132.228.208.0 0.0.0.31 description EC6F_BILLING_APP_VLAN202
#
object-group service JiS_DMZ_498_policy_port_group01
 1 service tcp destination eq 48080
 2 service tcp destination eq 13421
 3 service tcp destination eq 40005
#
object-group service TCP_80
 description TCP Port 80
 0 service tcp destination eq 80
#
security-policy
 rule name JiS_policy_2524
  description NETACC_20241223_496013
  source-zone QXEDA
  destination-zone QXDCN
  source-address range 132.252.33.169 132.252.33.171
  source-address range 132.252.33.181 132.252.33.188
  source-address range 132.252.33.215 132.252.33.248
  destination-address 10.149.16.24 0.0.0.0
  destination-address 132.252.102.230 0.0.0.0
  service protocol tcp destination-port 8921
  action permit
 rule name JiS_policy_1967
  description NETACC_20241223_496014
  source-zone QXEDA
  destination-zone QXDCN
  source-address address-set JiS_policy_1967_src_addr01
  destination-address 132.254.90.58 0.0.0.0
  service protocol tcp destination-port 80
  action permit
 rule name JiS_policy_1628
  description NETACC_20241223_496015
  source-zone QXEDA
  destination-zone QXDCN
  source-address 132.252.33.169 0.0.0.0
  destination-address address-set JiS_policy_1628_addr01
  service protocol tcp destination-port 443
  action permit
#
`

// USG配置示例（用于帮助大模型理解配置格式）
var usgConfigExample = `
ip address-set example_addr01 type object
 description Example address set
 address 0 192.168.1.0 mask 24
#
object-group service example_service
 description Example service
 0 service tcp destination eq 80
#
security-policy
 rule name example_policy_001
  description Example policy
  source-zone Trust
  destination-zone Untrust
  source-address address-set example_addr01
  service example_service
  action permit
#
`

func TestExtractNetworkObjects(t *testing.T) {
	// 跳过需要大模型的测试（需要Ollama服务）
	if testing.Short() {
		t.Skip("Skipping test that requires Ollama")
	}

	client := NewOllamaClient("http://localhost:11434", "qwen3-coder:30b")
	extractor := NewLLMExtractor(client)
	snippets, err := ExtractConfigSnippets(testConfigSnippet, "usg", usgConfigExample, extractor)
	if err != nil {
		t.Fatalf("Failed to extract config snippets: %v", err)
	}

	if snippets.NetworkObjectSnippet == "" {
		t.Fatal("NetworkObjectSnippet should not be empty")
	}

	// 验证是否包含预期的对象
	expectedObjects := []string{
		"JiS_policy_2246_addr01",
		"JiS_policy_1967_src_addr01",
		"JiS_policy_1628_addr01",
		"DCN_BSS_address_group",
	}

	for _, objName := range expectedObjects {
		if !strings.Contains(snippets.NetworkObjectSnippet, objName) {
			t.Errorf("NetworkObjectSnippet should contain %s", objName)
		}
	}

	t.Logf("NetworkObjectSnippet length: %d", len(snippets.NetworkObjectSnippet))
	t.Logf("NetworkObjectSnippet preview:\n%s", snippets.NetworkObjectSnippet[:min(500, len(snippets.NetworkObjectSnippet))])
}

func TestExtractServiceObjects(t *testing.T) {
	// 跳过需要大模型的测试（需要Ollama服务）
	if testing.Short() {
		t.Skip("Skipping test that requires Ollama")
	}

	client := NewOllamaClient("http://localhost:11434", "qwen3-coder:30b")
	extractor := NewLLMExtractor(client)
	snippets, err := ExtractConfigSnippets(testConfigSnippet, "usg", usgConfigExample, extractor)
	if err != nil {
		t.Fatalf("Failed to extract config snippets: %v", err)
	}

	if snippets.ServiceObjectSnippet == "" {
		t.Fatal("ServiceObjectSnippet should not be empty")
	}

	// 验证是否包含预期的服务对象
	expectedObjects := []string{
		"JiS_DMZ_498_policy_port_group01",
		"TCP_80",
	}

	for _, objName := range expectedObjects {
		if !strings.Contains(snippets.ServiceObjectSnippet, objName) {
			t.Errorf("ServiceObjectSnippet should contain %s", objName)
		}
	}

	t.Logf("ServiceObjectSnippet length: %d", len(snippets.ServiceObjectSnippet))
	t.Logf("ServiceObjectSnippet preview:\n%s", snippets.ServiceObjectSnippet[:min(500, len(snippets.ServiceObjectSnippet))])
}

func TestExtractPolicies(t *testing.T) {
	// 跳过需要大模型的测试（需要Ollama服务）
	if testing.Short() {
		t.Skip("Skipping test that requires Ollama")
	}

	client := NewOllamaClient("http://localhost:11434", "qwen3-coder:30b")
	extractor := NewLLMExtractor(client)
	snippets, err := ExtractConfigSnippets(testConfigSnippet, "usg", usgConfigExample, extractor)
	if err != nil {
		t.Fatalf("Failed to extract config snippets: %v", err)
	}

	if snippets.PolicySnippet == "" {
		t.Fatal("PolicySnippet should not be empty")
	}

	// 验证是否包含预期的策略
	expectedPolicies := []string{
		"JiS_policy_2524",
		"JiS_policy_1967",
		"JiS_policy_1628",
	}

	for _, policyName := range expectedPolicies {
		if !strings.Contains(snippets.PolicySnippet, policyName) {
			t.Errorf("PolicySnippet should contain %s", policyName)
		}
	}

	// 验证策略内容
	if !strings.Contains(snippets.PolicySnippet, "source-address address-set") {
		t.Log("PolicySnippet contains object-style source-address")
	}
	if !strings.Contains(snippets.PolicySnippet, "destination-address address-set") {
		t.Log("PolicySnippet contains object-style destination-address")
	}
	if !strings.Contains(snippets.PolicySnippet, "source-address range") {
		t.Log("PolicySnippet contains non-object-style source-address")
	}

	t.Logf("PolicySnippet length: %d", len(snippets.PolicySnippet))
	t.Logf("PolicySnippet preview:\n%s", snippets.PolicySnippet[:min(500, len(snippets.PolicySnippet))])
}

func TestExtractPolicyExamples(t *testing.T) {
	// 跳过需要大模型的测试（需要Ollama服务）
	if testing.Short() {
		t.Skip("Skipping test that requires Ollama")
	}

	client := NewOllamaClient("http://localhost:11434", "qwen3-coder:30b")
	extractor := NewLLMExtractor(client)
	snippets, err := ExtractConfigSnippets(testConfigSnippet, "usg", usgConfigExample, extractor)
	if err != nil {
		t.Fatalf("Failed to extract config snippets: %v", err)
	}
	examples := extractPolicyExamples(snippets.PolicySnippet)

	if len(examples) == 0 {
		t.Fatal("extractPolicyExamples should return at least one example")
	}

	expectedPolicies := []string{
		"JiS_policy_2524",
		"JiS_policy_1967",
		"JiS_policy_1628",
	}

	for _, expected := range expectedPolicies {
		found := false
		for _, example := range examples {
			if example == expected {
				found = true
				break
			}
		}
		if !found {
			t.Errorf("Expected policy %s not found in examples", expected)
		}
	}

	t.Logf("Policy examples: %v", examples)
}

func TestExtractNetworkObjectExamples(t *testing.T) {
	// 跳过需要大模型的测试（需要Ollama服务）
	if testing.Short() {
		t.Skip("Skipping test that requires Ollama")
	}

	client := NewOllamaClient("http://localhost:11434", "qwen3-coder:30b")
	extractor := NewLLMExtractor(client)
	snippets, err := ExtractConfigSnippets(testConfigSnippet, "usg", usgConfigExample, extractor)
	if err != nil {
		t.Fatalf("Failed to extract config snippets: %v", err)
	}
	examples := extractNetworkObjectExamples(snippets.NetworkObjectSnippet)

	if len(examples) == 0 {
		t.Fatal("extractNetworkObjectExamples should return at least one example")
	}

	expectedObjects := []string{
		"JiS_policy_2246_addr01",
		"JiS_policy_1967_src_addr01",
		"JiS_policy_1628_addr01",
		"DCN_BSS_address_group",
	}

	for _, expected := range expectedObjects {
		found := false
		for _, example := range examples {
			if example == expected {
				found = true
				break
			}
		}
		if !found {
			t.Errorf("Expected object %s not found in examples", expected)
		}
	}

	t.Logf("Network object examples: %v", examples)
}

func TestExtractServiceObjectExamples(t *testing.T) {
	// 跳过需要大模型的测试（需要Ollama服务）
	if testing.Short() {
		t.Skip("Skipping test that requires Ollama")
	}

	client := NewOllamaClient("http://localhost:11434", "qwen3-coder:30b")
	extractor := NewLLMExtractor(client)
	snippets, err := ExtractConfigSnippets(testConfigSnippet, "usg", usgConfigExample, extractor)
	if err != nil {
		t.Fatalf("Failed to extract config snippets: %v", err)
	}
	examples := extractServiceObjectExamples(snippets.ServiceObjectSnippet)

	if len(examples) == 0 {
		t.Fatal("extractServiceObjectExamples should return at least one example")
	}

	expectedObjects := []string{
		"JiS_DMZ_498_policy_port_group01",
		"TCP_80",
	}

	for _, expected := range expectedObjects {
		found := false
		for _, example := range examples {
			if example == expected {
				found = true
				break
			}
		}
		if !found {
			t.Errorf("Expected service object %s not found in examples", expected)
		}
	}

	t.Logf("Service object examples: %v", examples)
}

func TestBuildPromptForNetworkObject(t *testing.T) {
	snippet := `
ip address-set JiS_policy_1967_src_addr01 type object
 description JiS_policy_1967_source_address
 address 0 132.252.33.169 0.0.0.0
#
ip address-set JiS_policy_1628_addr01 type object
 description JiS_policy_1628_destination_address
 address 0 132.254.90.58 0.0.0.0
#
`

	prompt := BuildPromptForNetworkObject(snippet, "usg", usgConfigExample, getTemplateHint())

	if prompt == "" {
		t.Fatal("BuildPromptForNetworkObject should not return empty string")
	}

	// 验证提示词包含关键信息
	if !strings.Contains(prompt, snippet) {
		t.Error("Prompt should contain the snippet")
	}
	if !strings.Contains(prompt, "usg") {
		t.Error("Prompt should contain firewall type")
	}
	if !strings.Contains(prompt, "network_object_name_template") {
		t.Error("Prompt should contain template hint")
	}

	t.Logf("Prompt length: %d", len(prompt))
	t.Logf("Prompt preview:\n%s", prompt[:min(500, len(prompt))])
}

func TestBuildPromptForPolicy(t *testing.T) {
	snippet := `
 rule name JiS_policy_2524
  description NETACC_20241223_496013
  source-zone QXEDA
  destination-zone QXDCN
  source-address range 132.252.33.169 132.252.33.171
  action permit
 rule name JiS_policy_1967
  description NETACC_20241223_496014
  source-zone QXEDA
  source-address address-set JiS_policy_1967_src_addr01
  action permit
#
`

	prompt := BuildPromptForPolicy(snippet, "usg", usgConfigExample, getTemplateHint())

	if prompt == "" {
		t.Fatal("BuildPromptForPolicy should not return empty string")
	}

	// 验证提示词包含关键信息
	if !strings.Contains(prompt, snippet) {
		t.Error("Prompt should contain the snippet")
	}
	if !strings.Contains(prompt, "usg") {
		t.Error("Prompt should contain firewall type")
	}
	if !strings.Contains(prompt, "policy_name_template") {
		t.Error("Prompt should contain template hint")
	}

	t.Logf("Prompt length: %d", len(prompt))
	t.Logf("Prompt preview:\n%s", prompt[:min(500, len(prompt))])
}

func TestBuildPromptForObjectStyle(t *testing.T) {
	snippet := `
 rule name JiS_policy_2524
  source-address range 132.252.33.169 132.252.33.171
  destination-address 10.149.16.24 0.0.0.0
  action permit
 rule name JiS_policy_1967
  source-address address-set JiS_policy_1967_src_addr01
  destination-address address-set JiS_policy_1628_addr01
  action permit
#
`

	prompt := BuildPromptForObjectStyle(snippet)

	if prompt == "" {
		t.Fatal("BuildPromptForObjectStyle should not return empty string")
	}

	// 验证提示词包含关键信息
	if !strings.Contains(prompt, snippet) {
		t.Error("Prompt should contain the snippet")
	}
	if !strings.Contains(prompt, "object_style") {
		t.Error("Prompt should contain object style analysis requirement")
	}

	t.Logf("Prompt length: %d", len(prompt))
	t.Logf("Prompt preview:\n%s", prompt[:min(500, len(prompt))])
}

func TestGenerateConfigYAML(t *testing.T) {
	inference := &ConfigInference{
		PolicyNameTemplate:        "JiS_policy_{SEQ:id:4:1:1:MAIN}",
		PolicyNameExamples:        []string{"JiS_policy_2524", "JiS_policy_1967", "JiS_policy_1628"},
		NetworkObjectNameTemplate: "{policy_name}{if:exist:is_source==\"true\"}_src_addr{else}_addr{endif}",
		NetworkObjectExamples:     []string{"JiS_policy_1967_src_addr01", "JiS_policy_1628_addr01"},
		ServiceObjectNameTemplate: "{policy_name}_{protocol}{if:exist:compact_port==\"true\"}_{compact_port}{endif}",
		ServiceObjectExamples:     []string{"JiS_DMZ_498_policy_port_group01", "TCP_80"},
		ObjectStyle: ObjectStyleConfig{
			ObjectStyle:       true,
			SourceObject:      true,
			DestinationObject: true,
			ServiceObject:     true,
		},
	}

	yamlConfig := GenerateConfigYAML(inference)

	if yamlConfig == "" {
		t.Fatal("GenerateConfigYAML should not return empty string")
	}

	// 验证YAML包含关键配置
	if !strings.Contains(yamlConfig, "policy_name_template") {
		t.Error("YAML should contain policy_name_template")
	}
	if !strings.Contains(yamlConfig, "network_object_name_template") {
		t.Error("YAML should contain network_object_name_template")
	}
	if !strings.Contains(yamlConfig, "service_object_name_template") {
		t.Error("YAML should contain service_object_name_template")
	}
	if !strings.Contains(yamlConfig, "securitypolicy.object_style") {
		t.Error("YAML should contain securitypolicy.object_style")
	}

	t.Logf("Generated YAML:\n%s", yamlConfig)
}

// TestOllamaInference 测试真实调用Ollama进行推理
func TestOllamaInference(t *testing.T) {
	// 跳过需要大模型的测试（需要Ollama服务）
	if testing.Short() {
		t.Skip("Skipping test that requires Ollama")
	}

	// 检查Ollama是否可用
	client := NewOllamaClient("http://localhost:11434", "qwen3-coder:30b")

	// 使用测试配置片段
	extractor := NewLLMExtractor(client)
	snippets, err := ExtractConfigSnippets(testConfigSnippet, "usg", usgConfigExample, extractor)
	if err != nil {
		t.Fatalf("Failed to extract config snippets: %v", err)
	}

	// 测试策略命名模板推断
	if snippets.PolicySnippet != "" {
		t.Log("Testing policy template inference...")
		t.Logf("Policy snippet length: %d", len(snippets.PolicySnippet))
		policyTemplate, err := client.InferPolicyTemplate(snippets.PolicySnippet, "usg", usgConfigExample)
		if err != nil {
			t.Fatalf("Ollama inference error: %v", err)
		}
		t.Logf("Inferred policy template: %s", policyTemplate)
		if policyTemplate == "" {
			t.Error("Policy template should not be empty")
		}
	}

	// 测试网络对象命名模板推断
	if snippets.NetworkObjectSnippet != "" {
		t.Log("Testing network object template inference...")
		t.Logf("Network object snippet length: %d", len(snippets.NetworkObjectSnippet))
		networkTemplate, err := client.InferNetworkObjectTemplate(snippets.NetworkObjectSnippet, "usg", usgConfigExample)
		if err != nil {
			t.Fatalf("Ollama inference error: %v", err)
		}
		t.Logf("Inferred network object template: %s", networkTemplate)
		if networkTemplate == "" {
			t.Error("Network object template should not be empty")
		}
	}

	// 测试服务对象命名模板推断
	if snippets.ServiceObjectSnippet != "" {
		t.Log("Testing service object template inference...")
		t.Logf("Service object snippet length: %d", len(snippets.ServiceObjectSnippet))
		serviceTemplate, err := client.InferServiceObjectTemplate(snippets.ServiceObjectSnippet, "usg", usgConfigExample)
		if err != nil {
			t.Fatalf("Ollama inference error: %v", err)
		}
		t.Logf("Inferred service object template: %s", serviceTemplate)
		if serviceTemplate == "" {
			t.Error("Service object template should not be empty")
		}
	}

	// 测试对象样式分析
	if snippets.PolicySnippet != "" {
		t.Log("Testing object style analysis...")
		objectStyle, err := client.AnalyzeObjectStyle(snippets.PolicySnippet)
		if err != nil {
			t.Fatalf("Ollama inference error: %v", err)
		}
		t.Logf("Analyzed object style: %+v", objectStyle)
	}
}

// TestReverseEngineerConfig 测试完整的反向工程流程
func TestReverseEngineerConfig(t *testing.T) {
	// 跳过需要大模型的测试（需要Ollama服务）
	if testing.Short() {
		t.Skip("Skipping test that requires Ollama")
	}

	// 创建临时配置文件
	tmpFile := "/tmp/test_firewall_config.txt"
	err := os.WriteFile(tmpFile, []byte(testConfigSnippet), 0644)
	if err != nil {
		t.Fatalf("Failed to create temp file: %v", err)
	}
	defer os.Remove(tmpFile)

	// 执行反向工程
	inference, err := ReverseEngineerConfig(tmpFile, "usg", usgConfigExample, "http://localhost:11434", "qwen3-coder:30b")
	if err != nil {
		t.Fatalf("Reverse engineering error: %v", err)
	}

	// 生成YAML配置
	yamlConfig := GenerateConfigYAML(inference)
	t.Logf("Generated config:\n%s", yamlConfig)
	fmt.Printf("Generated config:\n%s", yamlConfig)

	// 验证结果
	if inference.PolicyNameTemplate == "" {
		t.Error("PolicyNameTemplate should not be empty")
	}
	if inference.NetworkObjectNameTemplate == "" {
		t.Error("NetworkObjectNameTemplate should not be empty")
	}

}

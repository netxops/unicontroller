package common

import (
	"fmt"
	"strings"
)

// LLMExtractor 基于大模型的通用配置提取器
type LLMExtractor struct {
	client *OllamaClient
}

// NewLLMExtractor 创建新的LLM提取器
func NewLLMExtractor(client *OllamaClient) *LLMExtractor {
	return &LLMExtractor{
		client: client,
	}
}

// ExtractNetworkObjects 使用大模型提取网络对象配置
func (e *LLMExtractor) ExtractNetworkObjects(config, firewallType, configExample string) (string, error) {
	prompt := BuildPromptForNetworkObjectExtraction(config, firewallType, configExample)
	response, err := e.client.callOllama(prompt)
	if err != nil {
		return "", fmt.Errorf("failed to extract network objects: %w", err)
	}
	return extractExtractionResult(response), nil
}

// ExtractServiceObjects 使用大模型提取服务对象配置
func (e *LLMExtractor) ExtractServiceObjects(config, firewallType, configExample string) (string, error) {
	prompt := BuildPromptForServiceObjectExtraction(config, firewallType, configExample)
	response, err := e.client.callOllama(prompt)
	if err != nil {
		return "", fmt.Errorf("failed to extract service objects: %w", err)
	}
	return extractExtractionResult(response), nil
}

// ExtractPolicies 使用大模型提取策略配置
func (e *LLMExtractor) ExtractPolicies(config, firewallType, configExample string) (string, error) {
	prompt := BuildPromptForPolicyExtraction(config, firewallType, configExample)
	response, err := e.client.callOllama(prompt)
	if err != nil {
		return "", fmt.Errorf("failed to extract policies: %w", err)
	}
	return extractExtractionResult(response), nil
}

// ExtractNatRules 使用大模型提取NAT规则配置
func (e *LLMExtractor) ExtractNatRules(config, firewallType, configExample string) (string, error) {
	prompt := BuildPromptForNatExtraction(config, firewallType, configExample)
	response, err := e.client.callOllama(prompt)
	if err != nil {
		return "", fmt.Errorf("failed to extract NAT rules: %w", err)
	}
	return extractExtractionResult(response), nil
}

// ExtractAclRules 使用大模型提取ACL配置
func (e *LLMExtractor) ExtractAclRules(config, firewallType, configExample string) (string, error) {
	prompt := BuildPromptForAclExtraction(config, firewallType, configExample)
	response, err := e.client.callOllama(prompt)
	if err != nil {
		return "", fmt.Errorf("failed to extract ACL rules: %w", err)
	}
	return extractExtractionResult(response), nil
}

// ExtractWithCustomPrompt 使用自定义提示词提取配置
func (e *LLMExtractor) ExtractWithCustomPrompt(prompt string) (string, error) {
	response, err := e.client.callOllama(prompt)
	if err != nil {
		return "", fmt.Errorf("failed to extract with custom prompt: %w", err)
	}
	return extractExtractionResult(response), nil
}

// extractExtractionResult 从大模型响应中提取配置内容
func extractExtractionResult(response string) string {
	response = strings.TrimSpace(response)

	// 移除可能的代码块标记
	response = strings.TrimPrefix(response, "```")
	response = strings.TrimPrefix(response, "yaml")
	response = strings.TrimSuffix(response, "```")

	return strings.TrimSpace(response)
}

// BuildPromptForNetworkObjectExtraction 构建网络对象提取提示词
func BuildPromptForNetworkObjectExtraction(config, firewallType, configExample string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请从以下配置文件中提取所有网络对象（Network Object）的完整配置块。

防火墙类型：%s

配置示例（帮助理解格式）：
%s

完整配置文件：
%s

请提取所有网络对象的完整配置块，包括：
- 对象定义语句
- 所有相关的地址、子网、范围等配置
- 描述信息
- 完整的配置块（包括开始和结束标记）

只输出提取的配置块，不要输出其他内容。如果配置文件中没有网络对象，输出空字符串。`, firewallType, configExample, config)
}

// BuildPromptForServiceObjectExtraction 构建服务对象提取提示词
func BuildPromptForServiceObjectExtraction(config, firewallType, configExample string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请从以下配置文件中提取所有服务对象（Service Object）的完整配置块。

防火墙类型：%s

配置示例（帮助理解格式）：
%s

完整配置文件：
%s

请提取所有服务对象的完整配置块，包括：
- 对象定义语句
- 所有相关的协议、端口配置
- 描述信息
- 完整的配置块（包括开始和结束标记）

只输出提取的配置块，不要输出其他内容。如果配置文件中没有服务对象，输出空字符串。`, firewallType, configExample, config)
}

// BuildPromptForPolicyExtraction 构建策略提取提示词
func BuildPromptForPolicyExtraction(config, firewallType, configExample string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请从以下配置文件中提取所有安全策略（Security Policy）的完整配置块。

防火墙类型：%s

配置示例（帮助理解格式）：
%s

完整配置文件：
%s

请提取所有安全策略的完整配置块，包括：
- 策略定义语句（如 rule name）
- 源区域、目标区域
- 源地址、目标地址
- 服务配置
- 动作（permit/deny）
- 描述信息
- 完整的配置块（包括开始和结束标记）

只输出提取的配置块，不要输出其他内容。如果配置文件中没有安全策略，输出空字符串。`, firewallType, configExample, config)
}

// BuildPromptForNatExtraction 构建NAT规则提取提示词
func BuildPromptForNatExtraction(config, firewallType, configExample string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请从以下配置文件中提取所有NAT规则的完整配置块。

防火墙类型：%s

配置示例（帮助理解格式）：
%s

完整配置文件：
%s

请提取所有NAT规则的完整配置块，包括：
- NAT规则定义语句
- 源地址、目标地址
- 转换地址
- 接口配置
- 描述信息
- 完整的配置块（包括开始和结束标记）

只输出提取的配置块，不要输出其他内容。如果配置文件中没有NAT规则，输出空字符串。`, firewallType, configExample, config)
}

// BuildPromptForAclExtraction 构建ACL提取提示词
func BuildPromptForAclExtraction(config, firewallType, configExample string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请从以下配置文件中提取所有ACL（访问控制列表）的完整配置块。

防火墙类型：%s

配置示例（帮助理解格式）：
%s

完整配置文件：
%s

请提取所有ACL的完整配置块，包括：
- ACL定义语句
- 所有规则条目
- 源地址、目标地址
- 服务配置
- 动作配置
- 描述信息
- 完整的配置块（包括开始和结束标记）

只输出提取的配置块，不要输出其他内容。如果配置文件中没有ACL，输出空字符串。`, firewallType, configExample, config)
}

package common

import (
	"github.com/netxops/l2service/pkg/nodemap/api"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	"github.com/netxops/l2service/pkg/nodemap/session/command"
	"github.com/netxops/utils/policy"
	"github.com/netxops/utils/tools"
)

func MakeNatCli(from, out api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, node firewall.FirewallNode, firewallType string, isInputNat bool) (result *PolicyResult, cmdList command.CmdList) {
	metaData := node.(api.Node).GetDeviceConfig().MetaData
	// 创建 CommonTemplates 实例
	var templates *CommonTemplates
	switch firewallType {
	case "SecPath":
		templates = NewCommonTemplates(node, ctx, NewSecPathTemplates(), metaData)
	case "Dptech":
		templates = NewCommonTemplates(node, ctx, NewDptechTemplates(), metaData)
	case "Usg":
		templates = NewCommonTemplates(node, ctx, NewUsgTemplates(), metaData)
	case "ASA":
		templates = NewCommonTemplates(node, ctx, NewASATemplates(), metaData)
	case "SRX":
		templates = NewCommonTemplates(node, ctx, NewSRXTemplates(), metaData)
	case "FortiGate", "Forti":
		templates = NewCommonTemplates(node, ctx, NewFortiTemplates(), metaData)
	case "Sangfor":
		templates = NewCommonTemplates(node, ctx, NewSangforTemplates(), metaData)
	default:
		// 如果没有匹配的防火墙类型，返回错误
		return nil, nil
	}

	metaData["ticket_number"] = intent.TicketNumber
	metaData["sub_ticket"] = intent.SubTicket

	// 准备数据
	data := map[string]interface{}{
		"interface_name":   from.Name(),
		"description":      tools.MaybeOk(ctx.GetStringValue("description")),
		"nat_rule_name":    tools.MaybeOk(ctx.GetStringValue("nat_rule_name")),
		"make_source":      "true",
		"make_destination": "true",
		"make_service":     "true",
	}

	opts := []PolicyOption{}

	if isInputNat {
		switch metaData["input.nat"] {
		case "natpolicy.dnat", "":
			opts = append(opts, WithNatProcessMode(PolicyBasedNat), WithNatType(firewall.DESTINATION_NAT))
		case "nat.static.inbound":
			opts = append(opts, WithNatProcessMode(StaticNat), WithNatDirection(InboundNat))
		case "nat.static.inout":
			opts = append(opts, WithNatProcessMode(StaticNat), WithNatDirection(InOut))
		}
	} else {
		switch metaData["output.nat"] {
		case "natpolicy.snat", "":
			opts = append(opts, WithNatProcessMode(PolicyBasedNat), WithNatType(firewall.DYNAMIC_NAT))
		case "nat.static.outbound":
			opts = append(opts, WithNatProcessMode(StaticNat), WithNatDirection(OutboundNat))
		case "nat.dynamic.outbound":
			opts = append(opts, WithNatProcessMode(DynamicNat), WithNatDirection(OutboundNat))
		}
	}

	if metaData["nat.enableAclGeneration"] == "true" {
		opts = append(opts, WithAclGeneration(true))
	}

	if isInputNat {
		if objectStyle := metaData["natpolicy.dnat.object_style"]; objectStyle == "true" {
			opts = append(opts, WithObjectStyle(true))
			opts = append(opts, WithSourceObjects(metaData["natpolicy.dnat.source_object"] == "true"))
			opts = append(opts, WithDestinationObjects(metaData["natpolicy.dnat.destination_object"] == "true"))
			opts = append(opts, WithServiceObjects(metaData["natpolicy.dnat.service_object"] == "true"))

		}
	} else {
		if objectStyle := metaData["natpolicy.snat.object_style"]; objectStyle == "true" {
			opts = append(opts, WithObjectStyle(true))
			opts = append(opts, WithSourceObjects(metaData["natpolicy.snat.source_object"] == "true"))
			opts = append(opts, WithDestinationObjects(metaData["natpolicy.snat.destination_object"] == "true"))
			opts = append(opts, WithServiceObjects(metaData["natpolicy.snat.service_object"] == "true"))
		}
	}

	// 调用 MakeNatCli 方法
	result = templates.MakeNatCli(from, out, intent, ctx, data, opts...)

	// 处理结果
	if !result.IsValid() {
		// 处理错误情况
		return nil, nil
	}

	// 创建命令列表
	cmdList = command.NewCliCmdList(node.(api.Node).CmdIp(), true)
	for _, cli := range result.CLIs {
		cmdList.AddCmd(command.NewCliCmd(cli, "", 1, true))
	}

	return result, cmdList
}

// func MakeInputPolicyCli(from, out api.Port, intent *policy.Intent, node firewall.FirewallNode, firewallType string, ctx *firewall.PolicyContext) (result *PolicyResult, cmdList command.CmdList, moveRule []string) {
// 	// 获取设备特定的元数据
// 	metaData := node.(api.Node).GetDeviceConfig().MetaData
// 	var templates *CommonTemplates
// 	switch firewallType {
// 	case "SecPath":
// 		templates = NewCommonTemplates(node, ctx, NewSecPathTemplates(), metaData)
// 	case "Dptech":
// 		templates = NewCommonTemplates(node, ctx, NewDptechTemplates(), metaData)
// 	case "Usg":
// 		templates = NewCommonTemplates(node, ctx, NewUsgTemplates(), metaData)
// 	default:
// 		// 如果没有匹配的防火墙类型，返回错误
// 		return nil, nil, nil
// 	}

// 	opts := &PolicyOptions{}

// 	if objectStyle := metaData["securitypolicy.object_style"]; objectStyle == "true" {
// 		WithObjectStyle(true)(opts)
// 		WithSourceObjects(metaData["securitypolicy.source_object"] == "true")(opts)
// 		WithDestinationObjects(metaData["securitypolicy.destination_object"] == "true")(opts)
// 		WithServiceObjects(metaData["securitypolicy.service_object"] == "true")(opts)
// 	}

// 	// 调用 MakePolicyRuleCli 方法
// 	result = templates.MakePolicyRuleCli(from, out, intent, ctx, opts, metaData)

// 	// 处理结果
// 	if !result.IsValid() {
// 		return nil, nil, nil
// 	}

// 	// 创建命令列表
// 	cmdList = command.NewCliCmdList(node.(api.Node).CmdIp(), true)
// 	for _, cli := range result.CLIs {
// 		cmdList.AddCmd(command.NewCliCmd(cli, "", 1, true))
// 	}

// 	// 处理移动规则
// 	// moveRule = result.MoveRules

// 	return result, cmdList, moveRule
// }

func MakeInputPolicyCli(from, out api.Port, intent *policy.Intent, node firewall.FirewallNode, firewallType string, ctx *firewall.PolicyContext) (result *PolicyResult, cmdList command.CmdList, moveRule []string) {
	// 获取设备特定的元数据
	// metaData := node.(api.Node).GetDeviceConfig().MetaData
	metaData := map[string]interface{}{}
	for k := range node.(api.Node).GetDeviceConfig().MetaData {
		metaData[k] = node.(api.Node).GetDeviceConfig().MetaData[k]
	}
	var templates *CommonTemplates
	switch firewallType {
	case "SecPath":
		templates = NewCommonTemplates(node, ctx, NewSecPathTemplates(), metaData)
	case "Dptech":
		templates = NewCommonTemplates(node, ctx, NewDptechTemplates(), metaData)
	case "Usg":
		templates = NewCommonTemplates(node, ctx, NewUsgTemplates(), metaData)
	case "ASA":
		templates = NewCommonTemplates(node, ctx, NewASATemplates(), metaData)
	case "SRX":
		templates = NewCommonTemplates(node, ctx, NewSRXTemplates(), metaData)
	case "FortiGate", "Forti":
		templates = NewCommonTemplates(node, ctx, NewFortiTemplates(), metaData)
	case "Sangfor":
		templates = NewCommonTemplates(node, ctx, NewSangforTemplates(), metaData)
	default:
		// 如果没有匹配的防火墙类型，返回错误
		return nil, nil, nil
	}

	metaData["ticket_number"] = intent.TicketNumber
	metaData["sub_ticket"] = intent.SubTicket

	opts := &PolicyOptions{}

	if objectStyle := metaData["securitypolicy.object_style"]; objectStyle == "true" {
		WithObjectStyle(true)(opts)
		WithSourceObjects(metaData["securitypolicy.source_object"] == "true")(opts)
		WithDestinationObjects(metaData["securitypolicy.destination_object"] == "true")(opts)
		WithServiceObjects(metaData["securitypolicy.service_object"] == "true")(opts)
	}

	var matchedPolicies []firewall.FirewallPolicy
	if metaData["reuse_policy"] == "true" {
		// 使用 FindPolicyByIntent 查找匹配的策略
		matchConfig := MatchConfig{
			MatchSrc:       true,
			MatchDst:       true,
			MatchService:   true,
			MatchThreshold: 2, // 设置为2，表示至少两项匹配
		}
		// 从配置中读取空zone列表是否匹配任何zone（默认为true）
		emptyZoneMatchesAny := true
		if v, ok := metaData["securitypolicy.empty_zone_matches_any"]; ok {
			if b, ok := v.(bool); ok {
				emptyZoneMatchesAny = b
			} else if s, ok := v.(string); ok {
				emptyZoneMatchesAny = s == "true"
			}
		}
		matchConfig.EmptyZoneMatchesAny = &emptyZoneMatchesAny
		// 注意：Sangfor 等防火墙的接口和 zone 没有关联，Port 可能不实现 ZoneFirewall 接口
		fromZone, toZone := "", ""
		if from != nil {
			if zf, ok := from.(firewall.ZoneFirewall); ok {
				fromZone = zf.Zone()
			}
		}
		if out != nil {
			if zf, ok := out.(firewall.ZoneFirewall); ok {
				toZone = zf.Zone()
			}
		}
		matchedPolicies = FindPolicyByIntent(node, intent, fromZone, toZone, matchConfig)
	}
	var newIntent *policy.Intent
	if len(matchedPolicies) > 0 {
		// 使用第一个匹配的策略
		matchedPolicy := matchedPolicies[0]
		diffSrc, diffDst, diffSrv, err := intent.PolicyEntry.SubtractWithTwoSame(matchedPolicy.PolicyEntry())
		if err != nil {
			// 处理错误
			return nil, nil, nil
		}

		newIntent = intent.Copy().(*policy.Intent)
		if diffSrc != nil {
			newIntent.SetSrc(diffSrc)
			metaData["make_source"] = "true"
		}
		if diffDst != nil {
			newIntent.SetDst(diffDst)
			metaData["make_destination"] = "true"
		}
		if diffSrv != nil {
			newIntent.SetService(diffSrv)
			metaData["make_service"] = "true"
		}

		metaData["policy_name"] = matchedPolicy.Name()
		metaData["policy_id"] = matchedPolicy.ID()

	} else {
		// 如果没有匹配的策略，使用原始的 intent
		newIntent = intent
		metaData["make_source"] = "true"
		metaData["make_destination"] = "true"
		metaData["make_service"] = "true"
	}

	// 调用 MakePolicyRuleCli 方法，使用新的 intent
	result = templates.MakePolicyRuleCli(from, out, newIntent, ctx, opts, metaData)

	// 处理结果
	if !result.IsValid() {
		return nil, nil, nil
	}

	// 创建命令列表
	cmdList = command.NewCliCmdList(node.(api.Node).CmdIp(), true)
	for _, cli := range result.CLIs {
		cmdList.AddCmd(command.NewCliCmd(cli, "", 1, true))
	}

	// 处理移动规则
	// moveRule = result.MoveRules

	return result, cmdList, moveRule
}

package common

import (
	"strings"
	"time"

	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
)

// NamingDimensions 定义所有可用的命名维度
type NamingDimensions struct {
	// 业务维度
	System      string `yaml:"system"`      // 系统名称
	Application string `yaml:"application"` // 应用名称
	Service     string `yaml:"service"`     // 服务名称
	Project     string `yaml:"project"`     // 项目代码

	// 网络维度
	SrcZone    string `yaml:"src_zone"`    // 源区域
	DstZone    string `yaml:"dst_zone"`    // 目标区域
	SrcVlan    string `yaml:"src_vlan"`    // 源VLAN
	DstVlan    string `yaml:"dst_vlan"`    // 目标VLAN
	SrcSegment string `yaml:"src_segment"` // 源网段标识
	DstSegment string `yaml:"dst_segment"` // 目标网段标识

	// 技术维度
	Protocol    string `yaml:"protocol"`     // 协议
	Port        string `yaml:"port"`         // 端口
	ServiceType string `yaml:"service_type"` // 服务类型

	// 管理维度
	Environment string `yaml:"environment"` // 环境(prod/test/dev)
	Site        string `yaml:"site"`        // 站点
	Datacenter  string `yaml:"datacenter"`  // 机房
	Owner       string `yaml:"owner"`       // 责任人
	Department  string `yaml:"department"`  // 部门

	// 时间维度
	Date    string `yaml:"date"`    // 日期
	Version string `yaml:"version"` // 版本号

	// 功能维度
	Purpose  string `yaml:"purpose"`  // 用途(access/publish/mgmt)
	Duration string `yaml:"duration"` // 临时/永久(temp/perm)
	Priority string `yaml:"priority"` // 优先级
}

// NamingConfig 设备命名配置
type NamingConfig struct {
	DeviceID string `yaml:"device_id"`

	// 命名模板
	PolicyTemplate string `yaml:"policy_template"` // 策略命名模板
	AclTemplate    string `yaml:"acl_template"`    // ACL命名模板
	NatTemplate    string `yaml:"nat_template"`    // NAT命名模板
	ObjectTemplate string `yaml:"object_template"` // 对象命名模板

	// 默认维度值
	Defaults NamingDimensions `yaml:"defaults"`

	// 分隔符配置
	Separator string `yaml:"separator"` // 默认分隔符
}

// NamingManager 命名管理器
type NamingManager struct {
	config *NamingConfig
}

// NewNamingManager 创建命名管理器
func NewNamingManager(config *NamingConfig) *NamingManager {
	if config.Separator == "" {
		config.Separator = "_"
	}
	return &NamingManager{config: config}
}

// GenerateName 生成名称
func (nm *NamingManager) GenerateName(template string, dimensions *NamingDimensions, ctx *firewall.PolicyContext) string {
	// 合并默认值和传入的维度
	merged := nm.mergeDimensions(dimensions, ctx)

	// 替换模板中的占位符
	result := template

	// 使用反射或手动替换所有可能的占位符
	replacements := map[string]string{
		"{system}":       merged.System,
		"{application}":  merged.Application,
		"{service}":      merged.Service,
		"{project}":      merged.Project,
		"{src_zone}":     merged.SrcZone,
		"{dst_zone}":     merged.DstZone,
		"{src_vlan}":     merged.SrcVlan,
		"{dst_vlan}":     merged.DstVlan,
		"{src_segment}":  merged.SrcSegment,
		"{dst_segment}":  merged.DstSegment,
		"{protocol}":     merged.Protocol,
		"{port}":         merged.Port,
		"{service_type}": merged.ServiceType,
		"{environment}":  merged.Environment,
		"{site}":         merged.Site,
		"{datacenter}":   merged.Datacenter,
		"{owner}":        merged.Owner,
		"{department}":   merged.Department,
		"{date}":         merged.Date,
		"{version}":      merged.Version,
		"{purpose}":      merged.Purpose,
		"{duration}":     merged.Duration,
		"{priority}":     merged.Priority,
		"{separator}":    nm.config.Separator,
	}

	for placeholder, value := range replacements {
		if value != "" {
			result = strings.ReplaceAll(result, placeholder, value)
		}
	}

	// 清理多余的分隔符
	result = nm.cleanupSeparators(result)

	return result
}

// mergeDimensions 合并维度数据
func (nm *NamingManager) mergeDimensions(input *NamingDimensions, ctx *firewall.PolicyContext) *NamingDimensions {
	merged := nm.config.Defaults // 从默认值开始

	if input != nil {
		// 覆盖非空值
		if input.System != "" {
			merged.System = input.System
		}
		if input.Application != "" {
			merged.Application = input.Application
		}
		if input.Service != "" {
			merged.Service = input.Service
		}
		if input.Project != "" {
			merged.Project = input.Project
		}
		if input.SrcZone != "" {
			merged.SrcZone = input.SrcZone
		}
		if input.DstZone != "" {
			merged.DstZone = input.DstZone
		}
		if input.Protocol != "" {
			merged.Protocol = input.Protocol
		}
		if input.Port != "" {
			merged.Port = input.Port
		}
		if input.Environment != "" {
			merged.Environment = input.Environment
		}
		if input.Site != "" {
			merged.Site = input.Site
		}
		if input.Purpose != "" {
			merged.Purpose = input.Purpose
		}
		// ... 其他字段类似处理
	}

	// 从上下文中获取动态值
	if ctx != nil {
		if site, ok := ctx.GetStringValue("site"); ok && merged.Site == "" {
			merged.Site = site
		}
		if env, ok := ctx.GetStringValue("environment"); ok && merged.Environment == "" {
			merged.Environment = env
		}
		// 自动填充日期
		if merged.Date == "" {
			merged.Date = time.Now().Format("20060102")
		}
	}

	return &merged
}

// cleanupSeparators 清理多余的分隔符
func (nm *NamingManager) cleanupSeparators(name string) string {
	sep := nm.config.Separator

	// 移除连续的分隔符
	for strings.Contains(name, sep+sep) {
		name = strings.ReplaceAll(name, sep+sep, sep)
	}

	// 移除开头和结尾的分隔符
	name = strings.Trim(name, sep)

	return name
}

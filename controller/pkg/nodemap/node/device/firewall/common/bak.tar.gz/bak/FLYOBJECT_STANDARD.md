# FlyObject 标准字段定义

## 概述

本文档定义了 FlyObject 的标准字段，用于统一各防火墙的配置解析。FlyObject 是一个 `map[string]string` 类型，用于存储按类别分离的 CLI 配置字符串。

## 核心标准字段

所有防火墙都应该支持以下核心字段：

| 字段名 | 常量名 | 说明 | 数据格式 |
|--------|--------|------|----------|
| NETWORK | `FlyObjectNetwork` | 网络对象（地址对象、地址组）的CLI字符串 | `string` |
| SERVICE | `FlyObjectService` | 服务对象（服务对象、服务组）的CLI字符串 | `string` |
| NAT | `FlyObjectNat` | NAT规则的CLI字符串（统一字段） | `string` |
| POOL | `FlyObjectPool` | SNAT池对象的CLI字符串 | `string` |
| SECURITY_POLICY | `FlyObjectSecurityPolicy` | 安全策略的CLI字符串 | `string` |

## 扩展字段

部分防火墙使用的扩展字段：

| 字段名 | 常量名 | 说明 | 使用防火墙 | 数据格式 |
|--------|--------|------|-----------|----------|
| ACL | `FlyObjectAcl` | ACL规则的CLI字符串 | SecPath, Common V2 | `string` |
| VIP | `FlyObjectVip` | VIP对象的CLI字符串 | Common V2 | `string` |
| MIP | `FlyObjectMip` | MIP对象的CLI字符串 | Common V2 | `string` |
| STATIC_NAT | `FlyObjectStaticNat` | 静态NAT规则 | Sangfor, FortiGate | `string` 或 `[]interface{}` |
| DYNAMIC_NAT | `FlyObjectDynamicNat` | 动态NAT规则 | Sangfor, FortiGate | `string` 或 `[]interface{}` |

## FortiGate特定扩展字段

| 字段名 | 常量名 | 说明 | 数据格式 |
|--------|--------|------|----------|
| NETWORK_OBJECT_GROUP | `FlyObjectNetworkObjectGroup` | 网络对象组 | `[]interface{}` |
| SERVICE_GROUP | `FlyObjectServiceGroup` | 服务对象组 | `[]interface{}` |
| CLIS | `FlyObjectClis` | CLI命令列表 | `[]interface{}` |

## SecPath特定扩展字段（XML格式）

| 字段名 | 常量名 | 说明 | 数据格式 |
|--------|--------|------|----------|
| NETWORK_IPv4_OBJECT | `FlyObjectNetworkIPv4Object` | IPv4网络对象 | `[]interface{}` |
| NETWORK_IPv6_OBJECT | `FlyObjectNetworkIPv6Object` | IPv6网络对象 | `[]interface{}` |
| NETWORK_IPv4_GROUP | `FlyObjectNetworkIPv4Group` | IPv4网络组 | `[]interface{}` |
| NETWORK_IPv6_GROUP | `FlyObjectNetworkIPv6Group` | IPv6网络组 | `[]interface{}` |
| SERVER_ON_INTERFACE | `FlyObjectServerOnInterface` | 接口上的服务器 | `[]interface{}` |
| NAT_POLICY | `FlyObjectNatPolicy` | NAT策略 | `[]interface{}` |

## 各防火墙字段映射表

### Sangfor
- ✅ NETWORK → `FlyObjectNetwork`
- ✅ SERVICE → `FlyObjectService`
- ✅ POOL → `FlyObjectPool`
- ✅ STATIC_NAT → `FlyObjectStaticNat`
- ✅ DYNAMIC_NAT → `FlyObjectDynamicNat`
- ✅ SECURITY_POLICY → `FlyObjectSecurityPolicy`

### SecPath
- ✅ NETWORK → `FlyObjectNetwork`
- ✅ SERVICE → `FlyObjectService`
- ✅ POOL → `FlyObjectPool`
- ✅ NAT → `FlyObjectNat`
- ✅ ACL → `FlyObjectAcl`
- ✅ SECURITY_POLICY → `FlyObjectSecurityPolicy`
- ✅ NETWORK_IPv4_OBJECT → `FlyObjectNetworkIPv4Object` (XML格式)
- ✅ NETWORK_IPv6_OBJECT → `FlyObjectNetworkIPv6Object` (XML格式)
- ✅ NETWORK_IPv4_GROUP → `FlyObjectNetworkIPv4Group` (XML格式)
- ✅ NETWORK_IPv6_GROUP → `FlyObjectNetworkIPv6Group` (XML格式)
- ✅ SERVER_ON_INTERFACE → `FlyObjectServerOnInterface` (XML格式)
- ✅ NAT_POLICY → `FlyObjectNatPolicy` (XML格式)

### FortiGate
- ✅ NETWORK → `FlyObjectNetwork`
- ✅ NETWORK_OBJECT_GROUP → `FlyObjectNetworkObjectGroup`
- ✅ SERVICE → `FlyObjectService`
- ✅ SERVICE_GROUP → `FlyObjectServiceGroup`
- ✅ STATIC_NAT → `FlyObjectStaticNat`
- ✅ POOL → `FlyObjectPool`
- ✅ SECURITY_POLICY → `FlyObjectSecurityPolicy`
- ✅ CLIS → `FlyObjectClis`

### USG
- ✅ 使用字符串格式，直接解析整个CLI字符串

### ASA
- ✅ 使用字符串格式，直接解析整个CLI字符串

### SRX
- ✅ 使用字符串格式，直接解析整个CLI字符串

### Dptech
- ✅ 使用字符串格式，直接解析整个CLI字符串

### Common V2
- ✅ NETWORK → `FlyObjectNetwork`
- ✅ SERVICE → `FlyObjectService`
- ✅ NAT → `FlyObjectNat`
- ✅ POOL → `FlyObjectPool`
- ✅ VIP → `FlyObjectVip`
- ✅ MIP → `FlyObjectMip`
- ✅ SECURITY_POLICY → `FlyObjectSecurityPolicy`

## 使用规范

1. **优先使用标准字段**：所有防火墙实现应优先使用核心标准字段
2. **使用常量而非硬编码**：在代码中使用 `common.FlyObjectNetwork` 等常量，而不是硬编码字符串 `"NETWORK"`
3. **保持向后兼容**：对于特定防火墙的扩展字段，保留但标注为扩展字段
4. **数据格式说明**：在 FlyConfig 方法中明确说明支持的数据格式（string 或 []interface{}）

## 示例

```go
import "github.com/netxops/l2service/pkg/nodemap/node/device/firewall/common"

// 设置 FlyObject
result.FlyObject[common.FlyObjectNetwork] = networkCli
result.FlyObject[common.FlyObjectService] = serviceCli
result.FlyObject[common.FlyObjectNat] = natCli

// 读取 FlyObject
if networkCli, exists := flyObjectMap[common.FlyObjectNetwork]; exists {
    // 处理网络对象
}
```



package common

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/netxops/keys"
	"github.com/netxops/l2service/pkg/nodemap/api"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"

	"github.com/netxops/utils/dsl"
	"github.com/netxops/utils/network"
	"github.com/netxops/utils/policy"
	"github.com/netxops/utils/service"
	"github.com/netxops/utils/tools"
)

// 定义NAT处理方式
type NatProcessMode int

const (
	PolicyBasedNat NatProcessMode = iota
	AclBasedNat
	StaticNat
	InterfaceNat
	DynamicNat
)

// 定义NAT方向
type NatDirection int

const (
	InboundNat NatDirection = iota
	OutboundNat
	InOut
)

func (d NatDirection) String() string {
	return []string{"Inbound", "Outbound", "InOut"}[d]
}

// 定义NAT实现风格
type NatStyle int

const (
	PolicyIntegratedStyle NatStyle = iota
	StandaloneStyle
)

// 定义所有 map key 常量，避免拼写错误并提高可维护性
const (
	// 模板相关
	KeyPolicyNameTemplate        = "policy_name_template"
	KeyAclNameTemplate           = "acl_name_template"
	KeyServiceObjectNameTemplate = "service_object_name_template"
	KeyNetworkObjectNameTemplate = "network_object_name_template"

	// 对象名称相关
	KeyObjectName = "object_name"
	KeyPolicyName = "policy_name"
	KeyAclName    = "acl_name"
	KeyAclId      = "acl_id"

	// 网络对象相关
	KeyIsSource           = "is_source"
	KeySingleRule         = "single_rule"
	KeySourceObjects      = "sourceObjects"
	KeyDestinationObjects = "destinationObjects"
	KeyServiceObjects     = "serviceObjects"

	// NAT相关
	KeyNatRuleName          = "nat_rule_name"
	KeyDescription          = "description"
	KeyInterfaceName        = "interface_name"
	KeySnat                 = "snat"
	KeyRealIp               = "real_ip"
	KeyRealPort             = "real_port"
	KeyDirection            = "direction"
	KeyPoolId               = "pool_id"
	KeyPoolName             = "pool_name"
	KeyStaticNatRule        = "static_nat_rule"
	KeyStaticNatDescription = "static_nat_description"

	// 端口和区域相关
	KeyFromPort         = "fromPort"
	KeyToPort           = "toPort"
	KeyFromZone         = "fromZone"
	KeyToZone           = "toZone"
	KeySourceZones      = "sourceZones"
	KeyDestinationZones = "destinationZones"

	// 对象样式相关
	KeyObjectStyle              = "objectStyle"
	KeySourceAddressObject      = "sourceAddressObject"
	KeyDestinationAddressObject = "destinationAddressObject"

	// 生成控制标志
	KeyMakeSource      = "make_source"
	KeyMakeDestination = "make_destination"
	KeyMakeService     = "make_service"

	// 策略相关
	KeyPolicyId   = "policy_id"
	KeyAction     = "action"
	KeyPolicyType = "policyType"

	// 服务相关
	KeyCompactPort = "compact_port"

	// NAT类型
	KeyNatType = "natType"
)

// SafeDataMap 提供类型安全的 map[string]interface{} 访问
type SafeDataMap struct {
	data map[string]interface{}
}

// NewSafeDataMap 创建一个新的 SafeDataMap
func NewSafeDataMap(data map[string]interface{}) *SafeDataMap {
	if data == nil {
		data = make(map[string]interface{})
	}
	return &SafeDataMap{data: data}
}

// GetString 安全获取字符串值，如果不存在或类型不匹配返回空字符串和 false
func (sdm *SafeDataMap) GetString(key string) (string, bool) {
	if sdm.data == nil {
		return "", false
	}
	val, exists := sdm.data[key]
	if !exists {
		return "", false
	}
	if str, ok := val.(string); ok {
		return str, true
	}
	return fmt.Sprintf("%v", val), true
}

// GetStringOrDefault 安全获取字符串值，如果不存在返回默认值
func (sdm *SafeDataMap) GetStringOrDefault(key, defaultValue string) string {
	if val, ok := sdm.GetString(key); ok {
		return val
	}
	return defaultValue
}

// SetString 安全设置字符串值
func (sdm *SafeDataMap) SetString(key, value string) {
	if sdm.data == nil {
		sdm.data = make(map[string]interface{})
	}
	sdm.data[key] = value
}

// GetInt 安全获取整数值
func (sdm *SafeDataMap) GetInt(key string) (int, bool) {
	if sdm.data == nil {
		return 0, false
	}
	val, exists := sdm.data[key]
	if !exists {
		return 0, false
	}
	switch v := val.(type) {
	case int:
		return v, true
	case int32:
		return int(v), true
	case int64:
		return int(v), true
	case float64:
		return int(v), true
	}
	return 0, false
}

// GetIntOrDefault 安全获取整数值，如果不存在返回默认值
func (sdm *SafeDataMap) GetIntOrDefault(key string, defaultValue int) int {
	if val, ok := sdm.GetInt(key); ok {
		return val
	}
	return defaultValue
}

// SetInt 安全设置整数值
func (sdm *SafeDataMap) SetInt(key string, value int) {
	if sdm.data == nil {
		sdm.data = make(map[string]interface{})
	}
	sdm.data[key] = value
}

// GetBool 安全获取布尔值
func (sdm *SafeDataMap) GetBool(key string) (bool, bool) {
	if sdm.data == nil {
		return false, false
	}
	val, exists := sdm.data[key]
	if !exists {
		return false, false
	}
	if b, ok := val.(bool); ok {
		return b, true
	}
	if str, ok := val.(string); ok {
		return str == "true", true
	}
	return false, false
}

// GetBoolOrDefault 安全获取布尔值，如果不存在返回默认值
func (sdm *SafeDataMap) GetBoolOrDefault(key string, defaultValue bool) bool {
	if val, ok := sdm.GetBool(key); ok {
		return val
	}
	return defaultValue
}

// SetBool 安全设置布尔值
func (sdm *SafeDataMap) SetBool(key string, value bool) {
	if sdm.data == nil {
		sdm.data = make(map[string]interface{})
	}
	sdm.data[key] = value
}

// GetStringSlice 安全获取字符串切片
func (sdm *SafeDataMap) GetStringSlice(key string) ([]string, bool) {
	if sdm.data == nil {
		return nil, false
	}
	val, exists := sdm.data[key]
	if !exists {
		return nil, false
	}
	if slice, ok := val.([]string); ok {
		return slice, true
	}
	if slice, ok := val.([]interface{}); ok {
		result := make([]string, 0, len(slice))
		for _, v := range slice {
			if str, ok := v.(string); ok {
				result = append(result, str)
			}
		}
		return result, true
	}
	return nil, false
}

// SetStringSlice 安全设置字符串切片
func (sdm *SafeDataMap) SetStringSlice(key string, value []string) {
	if sdm.data == nil {
		sdm.data = make(map[string]interface{})
	}
	sdm.data[key] = value
}

// Get 获取原始值
func (sdm *SafeDataMap) Get(key string) (interface{}, bool) {
	if sdm.data == nil {
		return nil, false
	}
	val, exists := sdm.data[key]
	return val, exists
}

// Set 设置原始值
func (sdm *SafeDataMap) Set(key string, value interface{}) {
	if sdm.data == nil {
		sdm.data = make(map[string]interface{})
	}
	sdm.data[key] = value
}

// Has 检查键是否存在
func (sdm *SafeDataMap) Has(key string) bool {
	if sdm.data == nil {
		return false
	}
	_, exists := sdm.Data()[key]
	return exists
}

// Data 获取底层 map
func (sdm *SafeDataMap) Data() map[string]interface{} {
	if sdm.data == nil {
		sdm.data = make(map[string]interface{})
	}
	return sdm.data
}

// Merge 合并另一个 map 到当前 map
func (sdm *SafeDataMap) Merge(other map[string]interface{}) {
	if sdm.data == nil {
		sdm.data = make(map[string]interface{})
	}
	for k, v := range other {
		sdm.data[k] = v
	}
}

// Copy 创建当前 map 的副本
func (sdm *SafeDataMap) Copy() *SafeDataMap {
	newData := make(map[string]interface{})
	for k, v := range sdm.Data() {
		newData[k] = v
	}
	return NewSafeDataMap(newData)
}

type SecPathNamer struct {
	aclCounter   int
	usedAclNames map[string]bool
}

// PolicyInfo 结构体定义
type PolicyInfo struct {
	Id       string
	Name     string
	FromZone string
	ToZone   string
}

// PolicyResult 是一个统一的返回结构体，用于简化策略相关函数的返回值处理
type PolicyResult struct {
	Keys        []string          // 存储生成的键列表
	CLIs        []string          // 生成的CLI命令列表
	FlyObject   map[string]string // 飞对象（用于存储额外的对象信息）
	CLIString   string            // CLI命令的字符串形式
	Error       error             // 如果发生错误，则存储错误信息
	IsGlobalNat bool              // 标识是否为全局NAT策略
}

// NewPolicyResult 创建一个新的 PolicyResult 实例
func NewPolicyResult() *PolicyResult {
	return &PolicyResult{
		CLIs:      []string{},
		FlyObject: make(map[string]string),
	}
}

// SetCLIs 设置 CLI 命令列表
func (pr *PolicyResult) SetCLIs(clis []string) {
	pr.CLIs = clis
	pr.CLIString = strings.Join(clis, "\n")
}

// AddCLI 添加单个 CLI 命令
func (pr *PolicyResult) AddCLI(cli string) {
	pr.CLIs = append(pr.CLIs, cli)
	pr.CLIString = strings.Join(pr.CLIs, "\n")
}

// SetFlyObject 设置飞对象
func (pr *PolicyResult) SetFlyObject(key, value string) {
	pr.FlyObject[key] = value
}

// SetError 设置错误信息
func (pr *PolicyResult) SetError(err error) {
	pr.Error = err
}

// IsValid 检查结果是否有效（没有错误）
func (pr *PolicyResult) IsValid() bool {
	return pr.Error == nil
}

// MergeFlyObjects 合并另一个 PolicyResult 的 FlyObject 到当前的 PolicyResult
func (pr *PolicyResult) MergeFlyObjects(otherFlyObjects map[string]string) {
	if pr.FlyObject == nil {
		pr.FlyObject = make(map[string]string)
	}
	for key, value := range otherFlyObjects {
		if existingValue, exists := pr.FlyObject[key]; exists {
			// 如果键已存在，则将值合并，用换行符分隔
			pr.FlyObject[key] = existingValue + "\n" + value
		} else {
			// 如果键不存在，直接添加
			pr.FlyObject[key] = value
		}
	}
}

// MergeCLIs 合并另一个 PolicyResult 的 CLIs 到当前的 PolicyResult
func (pr *PolicyResult) MergeCLIs(otherCLIs []string) {
	pr.CLIs = append(pr.CLIs, otherCLIs...)
	pr.CLIString = strings.Join(pr.CLIs, "\n")
}

// MergeFlyObjectAndCLIString 将 FlyObject 中的命令行合并到 CLIString 的前面，并返回合并后的字符串
func (pr *PolicyResult) MergeFlyObjectAndCLIString() string {
	var builder strings.Builder
	keys := []string{FlyObjectNetwork, FlyObjectVip, FlyObjectService, FlyObjectPool, FlyObjectAcl, FlyObjectSecurityPolicy, FlyObjectNat}

	// 首先添加 FlyObject 中的所有命令行
	for _, key := range keys {
		if v, ok := pr.FlyObject[key]; ok {
			builder.WriteString(v)
			builder.WriteString("\n")
		}
	}

	// 然后添加原有的 CLIString
	// builder.WriteString(pr.CLIString)

	return strings.TrimSpace(builder.String())
}

func (pr *PolicyResult) MergeFlyObjectAndCLIs() {
	clis := []string{}
	for _, value := range pr.FlyObject {
		clis = append(clis, value)
	}
	pr.CLIs = append(clis, pr.CLIs...)
}

type NameGeneratorFunc func(data interface{}, attempt int) string
type CheckFunction func(name string) bool

// 增强 CommonTemplates 以支持命名管理
func (ct *CommonTemplates) SetNamingManager(nm *NamingManager) {
	ct.namingManager = nm
}

type CommonTemplates struct {
	Node             firewall.FirewallNode
	SectionSeparator string
	// policyIDGenerator *PolicyIDGenerator
	// aclIDGenerator    *PolicyIDGenerator

	policyTemplate *IDTemplate
	aclTemplate    *IDTemplate

	om            *ObjectNameManager
	ts            Templates
	namingManager *NamingManager
	nameGenerator *NameGenerator // 统一的名称生成器
}

type Templates interface {
	GetTemplates(string) string
	GetTemplatesEntries(keys.Keys) []Entry
	GetTemplatesByKey(keys.Keys) string
}

// func NewCommonTemplates(node firewall.FirewallNode, ctx *firewall.PolicyContext, ts Templates) *CommonTemplates {
// 	spt := &CommonTemplates{
// 		Node: node,
// 		om:   NewObjectNameManager(),
// 		ts:   ts,
// 	}
// 	spt.SectionSeparator = tools.ConditionalT(ts.GetTemplatesByKey(keys.NewKeyBuilder("SectionSeparator")) == "", "!", ts.GetTemplatesByKey(keys.NewKeyBuilder("SectionSeparator")))

// 	template, _ := ctx.GetStringValue("policy_name_template")
// 	site, _ := ctx.GetStringValue("site")
// 	placeholders := map[string]func() string{
// 		"site": func() string {
// 			return site
// 		},
// 	}

// 	spt.policyIDGenerator = NewPolicyIDGenerator(template, func() firewall.NamerIterator {
// 		return node.(firewall.IteratorFirewall).PolicyIterator()
// 	}, placeholders)

// 	aclBase := 0
// 	if v, ok := ctx.Variables["aclBaseNumber"]; ok {
// 		aclBase, _ = strconv.Atoi(v.(string))
// 	}
// 	template, _ = ctx.GetStringValue("acl_name_template")
// 	template = tools.ConditionalT(template != "", template, "{SEQ:4}")
// 	spt.aclIDGenerator = NewPolicyIDGenerator(template, func() firewall.NamerIterator {
// 		return node.(firewall.IteratorFirewall).AclIterator()
// 	}, placeholders).
// 		WithStartID(aclBase).
// 		WithStep(1).
// 		WithMaxRetries(10).
// 		Initialize()

// 	return spt
// }

func NewCommonTemplates(node firewall.FirewallNode, ctx *firewall.PolicyContext, ts Templates, data map[string]interface{}) *CommonTemplates {
	spt := &CommonTemplates{
		Node: node,
		om:   NewObjectNameManager(),
		ts:   ts,
	}
	spt.SectionSeparator = tools.ConditionalT(ts.GetTemplatesByKey(keys.NewKeyBuilder("SectionSeparator")) == "", "!", ts.GetTemplatesByKey(keys.NewKeyBuilder("SectionSeparator")))

	// 使用 SafeDataMap 进行类型安全的访问
	safeData := NewSafeDataMap(data)

	// 安全获取 policy_name_template
	policyTemplate, _ := safeData.GetString(KeyPolicyNameTemplate)
	policyTemplate = tools.ConditionalT(policyTemplate != "", policyTemplate, tools.MaybeOk(ctx.GetStringValue("policy_name_template")))
	policyTemplate = tools.ConditionalT(policyTemplate != "", policyTemplate, "Policy_{SEQ:id:5:1:1:MAIN}")
	spt.policyTemplate = NewPolicyTemplate(policyTemplate, func() firewall.NamerIterator {
		return node.(firewall.IteratorFirewall).PolicyIterator()
	}).WithMaxRetries(10).Initialize()

	// 安全获取 acl_name_template
	aclTemplate, _ := safeData.GetString(KeyAclNameTemplate)
	aclTemplate = tools.ConditionalT(aclTemplate != "", aclTemplate, tools.MaybeOk(ctx.GetStringValue("acl_name_template")))
	aclTemplate = tools.ConditionalT(aclTemplate != "", aclTemplate, "{SEQ:id:4:1:1:MAIN}")
	spt.aclTemplate = NewPolicyTemplate(aclTemplate, func() firewall.NamerIterator {
		return node.(firewall.IteratorFirewall).AclIterator()
	}).WithMaxRetries(10).Initialize()

	// 初始化统一的名称生成器
	spt.nameGenerator = NewNameGenerator(node, spt.om)

	return spt
}

// // generatePolicyNameWithDimensions 使用维度生成策略名称
// func (ct *CommonTemplates) generatePolicyNameWithDimensions(dimensions *NamingDimensions, ctx *firewall.PolicyContext) (int, string) {
// 	if ct.namingManager != nil {
// 		// 使用命名管理器生成名称
// 		name := ct.namingManager.GenerateName(ct.namingManager.config.PolicyTemplate, dimensions, ctx)

// 		// 检查名称是否已存在，如果存在则添加序号
// 		finalName := ct.ensureUniqueName(name, func() firewall.NamerIterator {
// 			return ct.Node.(firewall.IteratorFirewall).PolicyIterator()
// 		})

// 		return 0, finalName // ID 可以后续处理
// 	}

// 	// 回退到原有方法
// 	return ct.generatePolicyName(ctx)
// }

// // ensureUniqueName 确保名称唯一性
// func (ct *CommonTemplates) ensureUniqueName(baseName string, iteratorFunc func() firewall.NamerIterator) string {
// 	iterator := iteratorFunc()
// 	existingNames := make(map[string]bool)

// 	for iterator.HasNext() {
// 		item := iterator.Next()
// 		if named, ok := item.(interface{ Name() string }); ok {
// 			existingNames[named.Name()] = true
// 		}
// 	}

// 	if !existingNames[baseName] {
// 		return baseName
// 	}

// 	// 添加序号直到找到唯一名称
// 	for i := 1; i < 1000; i++ {
// 		candidate := fmt.Sprintf("%s_%d", baseName, i)
// 		if !existingNames[candidate] {
// 			return candidate
// 		}
// 	}

// 	return baseName // 最后的回退
// }

// getPolicyIDGenerator 是一个新方法，用于获取或初始化 policyIDGenerator
// func (ct *CommonTemplates) generatePolicyName(ctx *firewall.PolicyContext) (int, string) {
// 	id, policyName := ct.policyIDGenerator.GenerateID()

// 	// 使用 ctx 中的 Variables 进行占位符替换
// 	for key, value := range ctx.Variables {
// 		placeholder := fmt.Sprintf("{%s}", key)
// 		v := fmt.Sprintf("%v", value)
// 		policyName = strings.ReplaceAll(policyName, placeholder, v)
// 	}

// 	return id, policyName
// }
// func (ct *CommonTemplates) generatePolicyName(ctx *firewall.PolicyContext) (int, string) {
//     mainID, policyName := ct.policyTemplate.Generate(ctx.Variables)

//     // 使用 ctx 中的 Variables 进行占位符替换
//     for key, value := range ctx.Variables {
//         placeholder := fmt.Sprintf("{%s}", key)
//         v := fmt.Sprintf("%v", value)
//         policyName = strings.ReplaceAll(policyName, placeholder, v)
//     }

//     return mainID, policyName
// }

func (ct *CommonTemplates) generatePolicyName(ctx *firewall.PolicyContext) (int, string) {
	variables := make(map[string]interface{})
	for key, value := range ctx.Variables {
		variables[key] = value
	}

	mainID, policyName := ct.policyTemplate.Generate(variables)

	// 使用 ctx 中的 Variables 进行额外的占位符替换（如果需要）
	for key, value := range ctx.Variables {
		placeholder := fmt.Sprintf("{%s}", key)
		v := fmt.Sprintf("%v", value)
		policyName = strings.ReplaceAll(policyName, placeholder, v)
	}

	return mainID, policyName
}

// func (ct *CommonTemplates) generateAclName(ctx *firewall.PolicyContext) (int, string) {
// 	mainID, aclName := ct.aclTemplate.Generate(ctx.Variables)
// 	return mainID, aclName
// }

func (ct *CommonTemplates) generateAclName(ctx *firewall.PolicyContext) (int, string) {
	variables := make(map[string]interface{})
	for key, value := range ctx.Variables {
		variables[key] = value
	}

	mainID, aclName := ct.aclTemplate.Generate(variables)

	// 使用 ctx 中的 Variables 进行额外的占位符替换（如果需要）
	for key, value := range ctx.Variables {
		placeholder := fmt.Sprintf("{%s}", key)
		v := fmt.Sprintf("%v", value)
		aclName = strings.ReplaceAll(aclName, placeholder, v)
	}

	return mainID, aclName
}

func (ct *CommonTemplates) generateUniqueObjectName(auto *keys.AutoIncrementKeys, obj interface{}, itFunc func() firewall.NamerIterator, templates *NamingTemplates, retryMethod string, useBaseFirst bool) (keys.Keys, bool, error) {
	return GenerateObjectName(auto, obj, itFunc, ct.Node, templates, retryMethod, ct.om, useBaseFirst)
}

func (ct *CommonTemplates) MakeServiceObjectCli(sg *service.Service, objectName, policyName string, data map[string]interface{}) *PolicyResult {
	return ct.makeServiceObjectCli(sg, objectName, policyName, data)
}

func (ct *CommonTemplates) makeServiceObjectCli(sg *service.Service, objectName, policyName string, data map[string]interface{}) (result *PolicyResult) {
	result = NewPolicyResult()
	srv := sg.Aggregate()
	// 使用 SafeDataMap 进行类型安全的访问
	safeData := NewSafeDataMap(data)

	keyList := []string{}
	builder := strings.Builder{}

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("ServiceObject", "OneLoop"))
	if objectName == "" {
		srv.EachDetailed(func(s service.ServiceEntry) bool {
			key, isNew, err := ct.generateServiceObjectName(s, data)
			if err != nil {
				result.SetError(fmt.Errorf("failed to generate service object name: %v", err))
				return false
			}

			sv := &service.Service{}
			sv.Add(s)
			if isNew {
				// 使用常量键名和类型安全的设置方法
				safeData.SetString(KeyObjectName, key.String())
				builder.WriteString(dsl.ServiceFormat(sv, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))
				builder.WriteString(ct.SectionSeparator)
				builder.WriteString("\n")
			}
			keyList = append(keyList, key.String())
			return true
		})
	} else {
		// 使用统一的名称生成器
		nameTemplate, _ := safeData.GetString(KeyServiceObjectNameTemplate)

		ctx := &NameGenerationContext{
			ObjectName:   objectName,
			Template:     nameTemplate,
			Data:         safeData.Data(),
			UseBaseFirst: true, // ✅ 修复：先尝试基础名称
			RetryMethod:  RetryMethodNext,
			Object:       srv,
			IteratorFunc: func() firewall.NamerIterator {
				return ct.Node.(firewall.IteratorFirewall).ServiceIterator()
			},
		}

		nameResult, err := ct.nameGenerator.Generate(ctx)
		if err != nil {
			result.SetError(fmt.Errorf("failed to generate object name for service group: %v", err))
			return result
		}

		// 记录警告（如果有）
		if len(nameResult.Warnings) > 0 {
			// 可以在这里记录警告到日志，暂时不处理
		}

		if nameResult.IsNew {
			// 使用常量键名和类型安全的设置方法
			safeData.SetString(KeyObjectName, nameResult.Name)
			builder.WriteString(dsl.ServiceFormat(srv, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))
			builder.WriteString(ct.SectionSeparator)
		}
		keyList = append(keyList, nameResult.Name)
	}

	result.SetFlyObject(FlyObjectService, builder.String())
	result.CLIString = builder.String()
	result.Keys = keyList
	return result
}

// func (ct *CommonTemplates) makeServiceObjectCli(sg *service.Service, objectName, policyName string, data map[string]interface{}) (result *PolicyResult) {
// 	result = NewPolicyResult()
// 	srv := sg.Aggregate()
// 	nameKeys := keys.NewKeyBuilder(objectName).Ignore("").Separator("_")
// 	keyList := []string{}
// 	builder := strings.Builder{}

// 	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("ServiceObject", "OneLoop"))
// 	if objectName == "" {
// 		srv.EachDetailed(func(s service.ServiceEntry) bool {
// 			key, isNew, err := ct.generateServiceObjectName(s, nameKeys.Ignore(""))
// 			if err != nil {
// 				result.SetError(fmt.Errorf("failed to generate service object name: %v", err))
// 				return false
// 			}

// 			sv := &service.Service{}
// 			sv.Add(s)
// 			if isNew {
// 				data["object_name"] = key.String()
// 				builder.WriteString(dsl.ServiceFormat(sv, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data))
// 				builder.WriteString(ct.SectionSeparator)
// 			}
// 			keyList = append(keyList, key.String())
// 			return true
// 		})
// 	} else {
// 		auto := keys.NewAutoIncrementKeys(nameKeys, 2)
// 		key, isNew, err := ct.generateUniqueObjectName(auto, srv, func() firewall.NamerIterator {
// 			return ct.Node.(firewall.IteratorFirewall).ServiceIterator()
// 		}, nil, RetryMethodNext)

// 		if err != nil {
// 			result.SetError(fmt.Errorf("failed to generate object name for service group: %v", err))
// 			return nil
// 		}

// 		if isNew {
// 			data["object_name"] = key.String()
// 			builder.WriteString(dsl.ServiceFormat(srv, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data))
// 			builder.WriteString(ct.SectionSeparator)
// 		}
// 		keyList = append(keyList, key.String())
// 	}

// 	result.SetFlyObject(FlyObjectService, builder.String())
// 	result.CLIString = builder.String()
// 	result.Keys = keyList
// 	return result
// }

// func (ct *CommonTemplates) generateServiceObjectName(s service.ServiceEntry, nameKeys keys.Keys) (keys.Keys, bool, error) {
// 	var key keys.Keys
// 	switch v := s.(type) {
// 	case *service.L3Protocol:
// 		if tools.ContainsT([]int{service.IP, service.TCP, service.UDP, service.ICMP, service.ICMP6}, int(s.Protocol())) {
// 			key = nameKeys.Add("SERVICE", strings.ToUpper(s.Protocol().String()))
// 		} else {
// 			key = nameKeys.Add("SERVICE", fmt.Sprintf("%d", s.Protocol()))
// 		}
// 	case *service.ICMPProto:
// 		key = nameKeys.Add("SERVICE", strings.ToUpper(s.Protocol().String()))
// 	case *service.L4Service:
// 		// layout := `{set:service.range_format="_"}{if:dst_port:count==1}{dst_port:compact}{else}{dst_port:compact}{endif}`
// 		// layout := ct.ts.GetTemplates("Service.portInObjectNameLayout")
// 		layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("ServiceObject", "CompactPorts"))
// 		key = nameKeys.Add(strings.ToUpper(s.Protocol().String()), dsl.ServiceEntryFormat(v, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
// 	}

// 	return ct.generateUniqueObjectName(keys.NewAutoIncrementKeys(key, 2), s, func() firewall.NamerIterator {
// 		return ct.Node.(firewall.IteratorFirewall).ServiceIterator()
// 	}, nil, RetryMethodNext)
// }

func (ct *CommonTemplates) generateServiceObjectName(s service.ServiceEntry, metaData map[string]interface{}) (keys.Keys, bool, error) {
	// 使用 SafeDataMap 进行类型安全的访问
	safeData := NewSafeDataMap(metaData)

	// 安全获取 service_object_name_template
	nameTemplate, _ := safeData.GetString(KeyServiceObjectNameTemplate)

	switch s.(type) {
	case *service.L4Service:
		layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("ServiceObject", "CompactPorts"))
		// 使用常量键名和类型安全的设置方法
		safeData.SetString(KeyCompactPort, dsl.ServiceEntryFormat(s, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))
	}

	name := strings.TrimSpace(dsl.ServiceEntryFormat(s, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))

	key := keys.NewKeyBuilder(name).Separator("_")

	return ct.generateUniqueObjectName(keys.NewAutoIncrementKeys(key, 2), s, func() firewall.NamerIterator {
		return ct.Node.(firewall.IteratorFirewall).ServiceIterator()
	}, nil, RetryMethodNext, true)
}

// nat server protocol tcp global 192.168.0.142 6081 inside 192.168.22.17 6081 rule ServerRule_16 description For_DMZ_Financial_YouChu_01_6081
// nat server protocol tcp global 58.217.205.15 22 inside 192.168.35.83 22 rule ServerRule_53 description For_OUT_SEC_PC_Protect_M.Plat22
func (ct *CommonTemplates) MakeStaticNatCli(from, out api.Port, intent *policy.Intent, ctx *firewall.PolicyContext) *PolicyResult {
	result := NewPolicyResult()

	// 使用 SafeDataMap 进行类型安全的访问
	safeData := NewSafeDataMap(nil)

	// 安全获取和设置值，使用常量键名
	if natRuleName, ok := ctx.GetStringValue("nat_rule_name"); ok {
		safeData.SetString(KeyNatRuleName, natRuleName)
	}
	if description, ok := ctx.GetStringValue("description"); ok {
		safeData.SetString(KeyDescription, description)
	}
	safeData.SetString(KeyInterfaceName, from.Name())

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("Nat", "Static", "OneLoop"))
	cli := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
	// ctx.WithValue("static_nat_cli", s)
	result.SetFlyObject(FlyObjectNat, cli)
	result.CLIString = cli

	return result
}

func (ct *CommonTemplates) UpdateAdvancedAcl(from, to api.Port, intent *policy.Intent, id int, aclName string, ctx *firewall.PolicyContext) (string, error) {
	// 使用 SafeDataMap 进行类型安全的访问
	safeData := NewSafeDataMap(nil)

	if v, ok := ctx.GetStringValue("objectStyle"); ok {
		safeData.SetString(KeyObjectStyle, v)
		safeData.SetString(KeySourceAddressObject, tools.MaybeOk(ctx.GetStringValue("sourceAddressObject")))
		safeData.SetString(KeyDestinationAddressObject, tools.MaybeOk(ctx.GetStringValue("destinationAddressObject")))
	}

	if id != 0 {
		safeData.SetInt(KeyAclId, id)
	}
	if aclName != "" {
		safeData.SetString(KeyAclName, aclName)
	}

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("ACL", "OneLoop"))
	clis := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())

	// 添加更新 ACL 的命令
	updateCommand := fmt.Sprintf(ct.ts.GetTemplates("ACL.Command.Update.format"), aclName)
	clis = updateCommand + "\n" + clis

	return strings.TrimRight(clis, "\n"), nil
}

func IsExist(node firewall.FirewallNode, ctx *firewall.PolicyContext, objectName string) bool {
	// 检查指定的对象是否存在
	if objectName != "" {
		_, exists := node.Network("", objectName)
		return exists
	}

	// 如果没有指定对象名，则检查源地址和目标地址对象
	srcObjName := ctx.GetSrcAddrObjName()
	if srcObjName != "" {
		_, srcExists := node.Network("", srcObjName)
		if srcExists {
			return true
		}
	}

	dstObjName := ctx.GetDstAddrObjName()
	if dstObjName != "" {
		_, dstExists := node.Network("", dstObjName)
		if dstExists {
			return true
		}
	}

	// 如果都不存在，返回 false
	return false
}

// MakeNetworkObjectCli 生成网络对象的CLI命令。
//
// 参数:
//   - from: api.Port 源端口
//   - out: api.Port 目标端口
//   - net: *network.NetworkGroup 网络组
//   - policeName: string 策略名称
//   - isSource: bool 是否为源地址
//   - ctx: *firewall.PolicyContext 策略上下文
//
// 返回值:
//   - []string: 生成的对象名称列表
//   - string: 生成的CLI命令
//   - error: 如果有错误发生则返回，否则为nil
//
// 功能描述:
//  1. 调用objectStyleSelector方法来决定对象创建的风格（单一规则或复杂规则）
//  2. 基于选定的风格，调用makeNetworkObjectCli方法来生成实际的CLI命令
//  3. 这个方法作为一个高层接口，封装了对象风格的选择和CLI命令的生成过程

func (ct *CommonTemplates) MakeNetworkObjectCli(fromZone, toZone string, net *network.NetworkGroup, objName, policeName string, isSource bool, ctx *firewall.PolicyContext, data map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()

	// style := ct.objectStyleSelector(fromZone, toZone, net, isSource, ctx)
	var style string
	if v, ok := data["securitypolicy.object_name_style"]; ok {
		style = v.(string)
	} else {
		style = "Group"
	}
	objectResult := ct.makeNetworkObjectCli(net, objName, policeName, isSource, style, ctx, data)

	if objectResult.Error != nil {
		return objectResult
	}

	result.MergeCLIs(objectResult.CLIs)
	result.Keys = objectResult.Keys
	result.SetFlyObject(FlyObjectNetwork, objectResult.CLIString)

	return result
}

// MakeNatVipOrPool 生成 NAT VIP 或 Pool 对象
// 参数与 MakeNetworkObjectCli 一致，但增加了 intent 参数用于获取 RealIp、RealPort 等信息
// 如果 intent.RealIp 存在，生成 VIP；如果 intent.Snat 存在，生成 Pool
// 统一使用 NetworkObject OneLoop 模板，通过数据标志区分 VIP、Pool 和普通网络对象
func (ct *CommonTemplates) MakeNatVipOrPool(fromZone, toZone string, net *network.NetworkGroup, objName, policeName string, isSource bool, intent *policy.Intent, ctx *firewall.PolicyContext, data map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()
	builder := strings.Builder{}

	// 获取 NetworkObject OneLoop 模板（VIP 和 Pool 都使用相同的模板）
	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("NetworkObject", "OneLoop"))
	if layout == "" {
		result.SetError(fmt.Errorf("NetworkObject OneLoop template not found"))
		return result
	}

	// 准备数据，包含 intent 相关信息
	vipData := make(map[string]interface{})
	for k, v := range data {
		vipData[k] = v
	}

	// 确定对象类型和相关数据
	var objType string                  // "VIP", "POOL", "NETWORK"
	var objNameTemplate string          // 命名模板
	var targetNet *network.NetworkGroup // 用于名称生成和唯一性检查的网络组
	var flyObjectType string            // FlyObject 类型

	// 判断是生成 VIP、Pool 还是 real_ip 网络对象
	if intent.RealIp != "" && intent.Dst() != nil && !intent.Dst().IsEmpty() {
		// 生成 VIP（用于 DNAT，FortiGate 风格）
		objType = "VIP"
		flyObjectType = FlyObjectVip
		vipData["make_vip"] = "true"
		vipData["real_ip"] = intent.RealIp
		if intent.RealPort != "" {
			vipData["real_port"] = intent.RealPort
		}
		if toPort, ok := data["toPort"].(string); ok && toPort != "" {
			vipData["toPort"] = toPort
		}
		targetNet = intent.Dst()

		// 获取 VIP 命名模板
		if t, ok := data["securitypolicy.vip_object_name_template"].(string); ok && t != "" {
			objNameTemplate = t
		} else if t, ok := data["network_object_name_template"].(string); ok && t != "" {
			objNameTemplate = t
		} else {
			policyName := ""
			if name, ok := data["policy_name"].(string); ok && name != "" {
				policyName = name
			} else if policeName != "" {
				policyName = policeName
			}
			objNameTemplate = policyName + "_VIP"
		}
	} else if data["make_vip"] == "true" && intent.RealIp != "" && net != nil && !net.IsEmpty() {
		// 生成 real_ip 网络对象（用于 ASA 等设备，不是 VIP）
		objType = "NETWORK"
		flyObjectType = FlyObjectNetwork
		// 移除 make_vip 标志，确保使用普通的 NetworkObject 模板
		delete(vipData, "make_vip")
		targetNet = net

		// 获取 real_ip 命名模板
		if t, ok := data["securitypolicy.real_ip_object_name_template"].(string); ok && t != "" {
			objNameTemplate = t
		} else if t, ok := data["network_object_name_template"].(string); ok && t != "" {
			objNameTemplate = t
		} else {
			policyName := ""
			if name, ok := data["policy_name"].(string); ok && name != "" {
				policyName = name
			} else if policeName != "" {
				policyName = policeName
			}
			objNameTemplate = policyName + "_real_ip"
		}
	} else if intent.Snat != "" && net != nil && !net.IsEmpty() {
		// 生成 Pool（用于 SNAT）
		objType = "POOL"
		flyObjectType = FlyObjectPool
		targetNet = net

		// 设置 Pool 相关数据
		vipData["make_snat"] = "true" // 设置 make_snat 标志，用于 Sangfor 和 FortiGate 的 NetworkObject 模板
		vipData["pool_name"] = ""     // 稍后设置
		vipData["pool_id"] = ""       // 稍后设置

		// 从网络组中提取 start 和 end（用于 Pool 模板）
		// 同时设置 first 和 last（用于 FortiGate 和 Sangfor 的 Pool 模板）
		net.EachDataRangeEntryAsAbbrNet(func(abbrNet network.AbbrNet) bool {
			if ipNet, ok := abbrNet.(*network.IPNet); ok {
				vipData["start"] = ipNet.IP.String()
				vipData["end"] = ipNet.IP.String()
				vipData["first"] = ipNet.IP.String()
				vipData["last"] = ipNet.IP.String()
				return false // 只取第一个
			} else if ipRange, ok := abbrNet.(*network.IPRange); ok {
				vipData["start"] = ipRange.Start.String()
				vipData["end"] = ipRange.End.String()
				vipData["first"] = ipRange.Start.String()
				vipData["last"] = ipRange.End.String()
				return false // 只取第一个
			}
			return true
		})

		// 获取 Pool 命名模板
		if t, ok := data["securitypolicy.snat_object_name_template"].(string); ok && t != "" {
			objNameTemplate = t
		} else if t, ok := data["network_object_name_template"].(string); ok && t != "" {
			objNameTemplate = t
		} else {
			policyName := ""
			if name, ok := data["policy_name"].(string); ok && name != "" {
				policyName = name
			} else if policeName != "" {
				policyName = policeName
			}
			objNameTemplate = policyName + "_POOL"
		}
	} else {
		// 既不是 VIP 也不是 Pool，返回错误
		result.SetError(fmt.Errorf("cannot determine VIP or Pool: RealIp=%s, Snat=%s, make_vip=%v", intent.RealIp, intent.Snat, data["make_vip"]))
		return result
	}

	// 统一生成对象名称
	var finalObjName string
	if objName != "" {
		// 如果指定了对象名称，直接使用并检查唯一性
		key := keys.NewKeyBuilder(objName).Separator("_")
		key, isNew, err := ct.generateUniqueObjectName(keys.NewAutoIncrementKeys(key, 2), targetNet, func() firewall.NamerIterator {
			return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
		}, nil, RetryMethodNext, true)
		if err != nil {
			result.SetError(err)
			return result
		}
		finalObjName = key.String()
		if !isNew {
			// 如果对象已存在，只返回名称，不生成 CLI
			result.Keys = append(result.Keys, finalObjName)
			return result
		}
	} else {
		// 使用模板生成对象名称
		var formattedName string
		if objType == "VIP" {
			// VIP 使用 IntentFormat（需要 intent 中的 dst 信息）
			formattedName = strings.TrimSpace(dsl.IntentFormat(intent, objNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), vipData))
		} else {
			// Pool 和 real_ip 网络对象使用 NetworkGroupFormat
			formattedName = strings.TrimSpace(dsl.NetworkGroupFormat(targetNet, objNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), vipData))
		}

		if formattedName == "" {
			result.SetError(fmt.Errorf("failed to generate %s object name from template", objType))
			return result
		}

		// 生成唯一名称
		nameKeys := keys.NewKeyBuilder(formattedName).Separator("_")
		auto := keys.NewAutoIncrementKeys(nameKeys, 2)
		key, isNew, err := ct.generateUniqueObjectName(auto, targetNet, func() firewall.NamerIterator {
			return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
		}, nil, RetryMethodNext, true)
		if err != nil {
			result.SetError(err)
			return result
		}
		finalObjName = key.String()
		if !isNew {
			// 如果对象已存在，只返回名称，不生成 CLI
			result.Keys = append(result.Keys, finalObjName)
			return result
		}
	}

	// 设置对象名称和相关数据
	vipData["object_name"] = finalObjName
	if objType == "POOL" {
		vipData["pool_name"] = finalObjName
		vipData["pool_id"] = finalObjName
	}

	// 对于 real_ip 网络对象，需要设置 isSingle 标志（ASA 模板使用此拼写）
	if objType == "NETWORK" && targetNet != nil {
		// 只有当网络组只有一个条目且是单个主机地址（/32 或单个 IP）时，才认为是单个地址
		count := 0
		isSingleHost := false
		targetNet.EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
			count++
			if count == 1 {
				// 检查第一个条目是否是单个主机地址
				if ipNet, ok := item.(*network.IPNet); ok {
					// 检查是否是 /32（IPv4）或 /128（IPv6）单个主机地址
					if ipNet.Type() == network.IPv4 && ipNet.Mask.Prefix() == 32 {
						isSingleHost = true
					} else if ipNet.Type() == network.IPv6 && ipNet.Mask.Prefix() == 128 {
						isSingleHost = true
					}
				}
			}
			return count <= 1 // 只检查第一个条目
		})
		if count == 1 && isSingleHost {
			vipData["isSingle"] = "true" // ASA 模板使用 isSingle（正确拼写）
		} else {
			vipData["isSingle"] = "false"
		}
	}

	// 统一渲染模板
	var cli string
	if objType == "VIP" {
		// VIP 使用 IntentFormat（需要 intent 中的 dst、service 等信息）
		cli = dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), vipData)
	} else {
		// Pool 和 real_ip 网络对象使用 NetworkGroupFormat
		cli = dsl.NetworkGroupFormat(targetNet, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), vipData)
		if cli == "" && objType == "POOL" {
			// Pool 如果 NetworkGroupFormat 失败，尝试使用 IntentFormat
			cli = dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), vipData)
		}
	}

	if cli != "" {
		builder.WriteString(cli)
		builder.WriteString(ct.SectionSeparator)
		result.Keys = append(result.Keys, finalObjName)
	}

	result.SetCLIs(strings.Split(builder.String(), "\n"))
	result.CLIString = builder.String()
	result.SetFlyObject(flyObjectType, result.CLIString)

	return result
}

const (
	SingleRule  = "SingleRule"
	ComplexRule = "ComplexRule"

	// Object style 命名方式
	EachDetailed = "EachDetailed" // 每个IP一个对象，使用模板命名
	Group        = "Group"        // 整个网络组一个对象，使用模板命名
	Vip          = "Vip"
)

// objectStyleSelector 决定如何创建网络对象的策略选择器。
//
// 参数:
//   - from: api.Port 源端口
//   - out: api.Port 目标端口
//   - net: *network.NetworkGroup 网络组
//   - isSource: bool 是否为源地址
//   - ctx: *firewall.PolicyContext 策略上下文
//
// 返回值:
//
//	string: 返回 "SingleRule" 或 "ComplexRule"，表示选择的对象创建风格
//
// 功能描述:
//  1. 根据给定的参数决定是使用单一规则还是复杂规则来创建网络对象
//  2. 考虑因素包括：是否为外部网络，网络组中的地址数量
//  3. 简而言之，外部网络使用复杂规则，内部网络倾向于单一规则
func (ct *CommonTemplates) objectStyleSelector(fromZone, toZone string, net *network.NetworkGroup, isSource bool, ctx *firewall.PolicyContext) string {
	// 从上下文中获取外部网络信息
	outsideMap, ok := ctx.GetValue("outside")

	// 根据是源地址还是目标地址，选择相应的区域名称
	zoneName := tools.ConditionalT(isSource, fromZone, toZone)

	var isOutside bool
	if ok {
		// 检查当前区域是否为外部网络
		_, isOutside = outsideMap.(map[string]string)[zoneName]
	}

	// 判断网络组中的地址数量是否大于16
	isLarge := tools.ConditionalT(net.Count().Int64() > 16, true, false)

	// 如果不是外部网络且地址数量不大，则使用单一规则
	if !isOutside && !isLarge {
		return SingleRule
	}

	// 否则使用复杂规则
	return ComplexRule
}

// makeNetworkObjectCliOld 旧的实现，保留用于向后兼容
func (ct *CommonTemplates) makeNetworkObjectCliOld(net *network.NetworkGroup, objName string, policeName string, isSource bool, style string, ctx *firewall.PolicyContext, data map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("NetworkObject", "OneLoop"))

	builder := strings.Builder{}

	// 使用 SafeDataMap 进行类型安全的访问
	safeData := NewSafeDataMap(data)

	// 安全获取 network_object_name_template
	nameTemplate, _ := safeData.GetString(KeyNetworkObjectNameTemplate)

	if isSource {
		safeData.SetString(KeyIsSource, "true")
	}
	if policeName != "" {
		safeData.SetString(KeyPolicyName, policeName)
	}

	if style == SingleRule {
		safeData.SetString(KeySingleRule, "true")
	}

	if objName != "" {
		// 如果指定了对象的名称， 会进行唯一性检查， 如果存在相同名称的对象，会在名称后面添加序号
		key := keys.NewKeyBuilder(objName).Separator("_")
		key, isNew, err := ct.generateUniqueObjectName(keys.NewAutoIncrementKeys(key, 2), net, func() firewall.NamerIterator {
			return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
		}, nil, RetryMethodNext, true)
		if err != nil {
			result.SetError(err)
			return result
		}

		if isNew {
			// 使用常量键名和类型安全的设置方法
			safeData.SetString(KeyObjectName, key.String())
			cli := dsl.NetworkGroupFormat(net, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
			// builder.WriteString(strings.TrimRight(cli, "\n"))
			builder.WriteString(cli)
			builder.WriteString(ct.SectionSeparator)
		}

		cli := builder.String()
		result.SetCLIs(strings.Split(cli, "\n"))
		result.Keys = append(result.Keys, key.String())
		result.CLIString = cli
		return result
	}

	keyList := []string{}
	if style == SingleRule {
		net.EachIP(func(ip *network.IP) bool {
			n, _ := network.ParseIPNet(ip.String())
			name := strings.TrimSpace(dsl.NetworkFormat(n, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))
			key := keys.NewKeyBuilder(name).Separator("_")

			ng := network.NewNetworkGroup()
			var isNew bool
			var err error

			if !ct.Node.HasObjectName(key.String()) {
				// 使用常量键名和类型安全的设置方法
				safeData.SetString(KeyObjectName, key.String())
				ng.AddString(ip.String())
				isNew = true
				keyList = append(keyList, key.String())
			} else {
				key, isNew, err = ct.generateUniqueObjectName(keys.NewAutoIncrementKeys(key, 2), ip, func() firewall.NamerIterator {
					return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
				}, nil, RetryMethodSuffix, false)
				if err != nil {
					result.SetError(err)
					return false
				}
				if isNew {
					// 使用常量键名和类型安全的设置方法
					safeData.SetString(KeyObjectName, key.String())
					ng.AddString(ip.String())

				}
				keyList = append(keyList, key.String())
			}

			if isNew {
				cli := dsl.NetworkGroupFormat(ng, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
				// builder.WriteString(strings.TrimRight(cli, "\n"))
				builder.WriteString(cli)
				builder.WriteString(ct.SectionSeparator)
				builder.WriteString("\n")
			}

			return true
		})
	} else {
		// ComplexRule 场景：使用统一的名称生成器
		// 从模板格式化名称
		formattedName := strings.TrimSpace(dsl.NetworkGroupFormat(net, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))

		ctx := &NameGenerationContext{
			ObjectName:   "", // ComplexRule 场景通常没有指定 objectName
			Template:     nameTemplate,
			Data:         safeData.Data(),
			UseBaseFirst: true, // ✅ 修复：先尝试基础名称（如果格式化成功）
			RetryMethod:  RetryMethodNext,
			Object:       net,
			IteratorFunc: func() firewall.NamerIterator {
				return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
			},
		}

		// 如果模板格式化成功，使用格式化后的名称
		if formattedName != "" {
			// 直接使用格式化后的名称作为基础名称
			nameKeys := keys.NewKeyBuilder(formattedName).Separator("")
			auto := keys.NewAutoIncrementKeys(nameKeys, 2)
			key, isNew, err := ct.generateUniqueObjectName(auto, net, ctx.IteratorFunc, nil, RetryMethodNext, true) // ✅ useBaseFirst = true

			if err != nil {
				result.SetError(err)
				return result
			}

			if isNew {
				safeData.SetString(KeyObjectName, key.String())
				cli := dsl.NetworkGroupFormat(net, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
				builder.WriteString(cli)
				builder.WriteString(ct.SectionSeparator)
			}

			keyList = append(keyList, key.String())
		} else {
			// 如果模板格式化失败，使用名称生成器（会处理回退）
			nameResult, err := ct.nameGenerator.Generate(ctx)
			if err != nil {
				result.SetError(err)
				return result
			}

			if nameResult.IsNew {
				safeData.SetString(KeyObjectName, nameResult.Name)
				cli := dsl.NetworkGroupFormat(net, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
				builder.WriteString(cli)
				builder.WriteString(ct.SectionSeparator)
			}

			keyList = append(keyList, nameResult.Name)
		}
	}

	cli := builder.String()
	result.SetCLIs(strings.Split(cli, "\n"))
	result.Keys = keyList
	result.CLIString = cli
	return result
}

// makeNetworkObjectCli 新的实现，支持 EachDetailed 和 Group 两种 object style 命名方式
// 两种命名方式都通过 network_object_name_template 生成名称，并考虑名称复用
func (ct *CommonTemplates) makeNetworkObjectCli(net *network.NetworkGroup, objName string, policeName string, isSource bool, style string, ctx *firewall.PolicyContext, data map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("NetworkObject", "OneLoop"))
	builder := strings.Builder{}

	// 使用 SafeDataMap 进行类型安全的访问
	safeData := NewSafeDataMap(data)

	// 安全获取 network_object_name_template
	nameTemplate, _ := safeData.GetString(KeyNetworkObjectNameTemplate)

	if isSource {
		safeData.SetString(KeyIsSource, "true")
	}
	if policeName != "" {
		safeData.SetString(KeyPolicyName, policeName)
	}

	// 设置 isSingle 属性，用于模板判断是否为单个地址
	// 检查模板类型以确定 isSingle 的判断逻辑
	// FortiGate: 只要网络组只有一个条目就认为是单个地址（可以是主机、子网或 IP 范围）
	// ASA: 只有当网络组只有一个条目且是单个主机地址（/32）时才认为是单个地址
	isFortiGate := strings.Contains(layout, "config firewall address") || strings.Contains(layout, "config firewall addrgrp")

	count := 0
	isSingleHost := false
	net.EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
		count++
		if count == 1 {
			// 检查第一个条目是否是单个主机地址
			if ipNet, ok := item.(*network.IPNet); ok {
				// 检查是否是 /32（IPv4）或 /128（IPv6）单个主机地址
				if ipNet.Type() == network.IPv4 && ipNet.Mask.Prefix() == 32 {
					isSingleHost = true
				} else if ipNet.Type() == network.IPv6 && ipNet.Mask.Prefix() == 128 {
					isSingleHost = true
				}
			}
		}
		return count <= 1 // 只检查第一个条目
	})

	// 根据设备类型设置 isSingle
	if isFortiGate {
		// FortiGate: 只要网络组只有一个条目就认为是单个地址
		if count == 1 {
			safeData.SetString("isSingle", "true")
		} else {
			safeData.SetString("isSingle", "false")
		}
	} else {
		// ASA 等其他设备: 只有当网络组只有一个条目且是单个主机地址时才认为是单个地址
		if count == 1 && isSingleHost {
			safeData.SetString("isSingle", "true")
		} else {
			safeData.SetString("isSingle", "false")
		}
	}

	// 如果指定了对象的名称，直接使用该名称并检查唯一性
	if objName != "" {
		key := keys.NewKeyBuilder(objName).Separator("_")
		key, isNew, err := ct.generateUniqueObjectName(keys.NewAutoIncrementKeys(key, 2), net, func() firewall.NamerIterator {
			return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
		}, nil, RetryMethodNext, true)
		if err != nil {
			result.SetError(err)
			return result
		}

		if isNew {
			safeData.SetString(KeyObjectName, key.String())
			cli := dsl.NetworkGroupFormat(net, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
			builder.WriteString(cli)
			builder.WriteString(ct.SectionSeparator)
		}

		cli := builder.String()
		result.SetCLIs(strings.Split(cli, "\n"))
		result.Keys = append(result.Keys, key.String())
		result.CLIString = cli
		return result
	}

	keyList := []string{}

	// 根据 style 选择命名方式
	switch style {
	case EachDetailed:
		// EachDetailed: 每个网络项一个对象，使用模板命名
		// 使用 Each 方法遍历所有网络项（类似于 EachDetailed）
		net.EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
			// 使用 network_object_name_template 为每个网络项生成名称
			formattedName := strings.TrimSpace(dsl.NetworkFormat(item, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))

			var key keys.Keys
			var isNew bool
			var err error

			// 将 network.AbbrNet 转换为可用于 generateUniqueObjectName 的类型
			// var obj interface{} = item
			ng := network.NewNetworkGroup()
			ng.Add(item)

			if formattedName != "" {
				// 使用格式化后的名称作为基础名称
				nameKeys := keys.NewKeyBuilder(formattedName).Separator("_")
				auto := keys.NewAutoIncrementKeys(nameKeys, 2)

				// 使用 generateUniqueObjectName 检查名称复用（如果对象相同则复用）
				key, isNew, err = ct.generateUniqueObjectName(auto, ng, func() firewall.NamerIterator {
					return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
				}, nil, RetryMethodSuffix, true) // useBaseFirst = true，先尝试基础名称
				if err != nil {
					result.SetError(err)
					return false
				}
				keyList = append(keyList, key.String())

				if isNew {
					safeData.SetString(KeyObjectName, key.String())
					cli := dsl.NetworkGroupFormat(ng, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
					builder.WriteString(cli)
					builder.WriteString(ct.SectionSeparator)
					builder.WriteString("\n")
				}
			} else {
				// 如果模板格式化失败，使用回退机制
				// 使用默认命名模板生成名称
				fallbackName := fmt.Sprintf("ADDR_%s", item.String())
				nameKeys := keys.NewKeyBuilder(fallbackName).Separator("_")
				auto := keys.NewAutoIncrementKeys(nameKeys, 2)

				key, isNew, err = ct.generateUniqueObjectName(auto, ng, func() firewall.NamerIterator {
					return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
				}, nil, RetryMethodSuffix, false)
				if err != nil {
					result.SetError(err)
					return false
				}

				if isNew {
					safeData.SetString(KeyObjectName, key.String())
					cli := dsl.NetworkGroupFormat(ng, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
					builder.WriteString(cli)
					builder.WriteString(ct.SectionSeparator)
					builder.WriteString("\n")
				}
				keyList = append(keyList, key.String())
			}

			return true
		})

	case Group:
		// Group: 整个网络组一个对象，使用模板命名
		// 如果网络组包含多个地址（isSingle == false），需要先为每个地址生成单独的对象，然后生成地址组
		if count > 1 {
			// 网络组包含多个地址，需要生成地址组
			// 先为每个地址生成单独的对象，直接生成而不递归调用，避免无限递归
			var memberObjectNames []string
			net.EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
				// 为每个地址生成单独的对象
				ng := network.NewNetworkGroup()
				ng.Add(item)

				// 使用 network_object_name_template 为每个地址生成名称
				itemFormattedName := strings.TrimSpace(dsl.NetworkFormat(item, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))
				if itemFormattedName == "" {
					itemFormattedName = fmt.Sprintf("ADDR_%s", item.String())
				}

				nameKeys := keys.NewKeyBuilder(itemFormattedName).Separator("_")
				auto := keys.NewAutoIncrementKeys(nameKeys, 2)

				// 先尝试基础名称，如果 ObjectNameManager 中已存在，则使用下一个名称
				baseKey := auto.GetBase()
				for ct.om.IsNameGenerated(baseKey.String()) {
					baseKey = auto.Next()
				}
				// 将基础名称添加到 ObjectNameManager，避免重复检查
				ct.om.AddGeneratedName(baseKey.String())

				// 检查设备上是否已存在同名对象
				// 注意：这里只检查名称，不比较网络组，避免调用 Network 方法导致递归
				itemKey := baseKey
				itemIsNew := true
				iterator := ct.Node.(firewall.IteratorFirewall).NetworkIterator()
				for iterator.HasNext() {
					obj := iterator.Next()
					if obj.Name() == itemKey.String() {
						// 如果设备上已存在同名对象，假设对象已存在（不匹配的情况很少见）
						// 为了避免递归调用 Network 方法，这里假设对象已存在
						itemIsNew = false
						break
					}
				}

				memberObjectNames = append(memberObjectNames, itemKey.String())

				if itemIsNew {
					// 生成单独的对象 CLI，直接使用 dsl.NetworkGroupFormat，不递归调用
					itemSafeData := NewSafeDataMap(safeData.Data())
					itemSafeData.SetString(KeyObjectName, itemKey.String())
					itemSafeData.SetString("isSingle", "true") // 单个地址对象
					itemCli := dsl.NetworkGroupFormat(ng, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), itemSafeData.Data())
					builder.WriteString(itemCli)
					builder.WriteString(ct.SectionSeparator)
					builder.WriteString("\n")
				}

				return true
			})

			// 检查是否有错误
			if result.Error != nil {
				return result
			}

			// 生成地址组名称
			formattedName := strings.TrimSpace(dsl.NetworkGroupFormat(net, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))
			if formattedName == "" {
				formattedName = "ADDR_GROUP"
			}

			nameKeys := keys.NewKeyBuilder(formattedName).Separator("")
			auto := keys.NewAutoIncrementKeys(nameKeys, 2)

			key, isNew, err := ct.generateUniqueObjectName(auto, net, func() firewall.NamerIterator {
				return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
			}, nil, RetryMethodNext, true)

			if err != nil {
				result.SetError(err)
				return result
			}

			if isNew {
				// 获取 AddressGroup 模板（如果存在），否则使用 NetworkObject 模板
				addressGroupLayout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("AddressGroup", "OneLoop"))
				if addressGroupLayout == "" {
					// 如果没有 AddressGroup 模板，回退到 NetworkObject 模板
					addressGroupLayout = layout
				}

				// 设置 object_name 和 member_objects（或 objectNames）用于地址组模板
				safeData.SetString(KeyObjectName, key.String())
				// 同时设置 member_objects 和 objectNames，以兼容不同的模板
				safeData.SetStringSlice("member_objects", memberObjectNames)
				safeData.SetStringSlice("objectNames", memberObjectNames)

				// 使用 AddressGroup 模板生成地址组 CLI
				cli := dsl.NetworkGroupFormat(net, addressGroupLayout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
				builder.WriteString(cli)
				builder.WriteString(ct.SectionSeparator)
			}

			// 只返回地址组的名称，不返回成员对象的名称
			keyList = []string{key.String()}
		} else {
			// 网络组只包含一个地址，直接生成地址对象
			formattedName := strings.TrimSpace(dsl.NetworkGroupFormat(net, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))

			var key keys.Keys
			var isNew bool
			var err error

			if formattedName != "" {
				// 使用格式化后的名称作为基础名称
				nameKeys := keys.NewKeyBuilder(formattedName).Separator("")
				auto := keys.NewAutoIncrementKeys(nameKeys, 2)

				// 生成唯一名称（考虑名称复用）
				key, isNew, err = ct.generateUniqueObjectName(auto, net, func() firewall.NamerIterator {
					return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
				}, nil, RetryMethodNext, true) // useBaseFirst = true

				if err != nil {
					result.SetError(err)
					return result
				}

				if isNew {
					safeData.SetString(KeyObjectName, key.String())
					cli := dsl.NetworkGroupFormat(net, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
					builder.WriteString(cli)
					builder.WriteString(ct.SectionSeparator)
				}

				keyList = append(keyList, key.String())
			} else {
				// 如果模板格式化失败，使用名称生成器（会处理回退）
				ctx := &NameGenerationContext{
					ObjectName:   "", // Group 场景通常没有指定 objectName
					Template:     nameTemplate,
					Data:         safeData.Data(),
					UseBaseFirst: true,
					RetryMethod:  RetryMethodNext,
					Object:       net,
					IteratorFunc: func() firewall.NamerIterator {
						return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
					},
				}

				nameResult, err := ct.nameGenerator.Generate(ctx)
				if err != nil {
					result.SetError(err)
					return result
				}

				if nameResult.IsNew {
					safeData.SetString(KeyObjectName, nameResult.Name)
					cli := dsl.NetworkGroupFormat(net, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
					builder.WriteString(cli)
					builder.WriteString(ct.SectionSeparator)
				}

				keyList = append(keyList, nameResult.Name)
			}
		}
	case Vip:
		formattedName := strings.TrimSpace(dsl.IntentFormat(ctx.Intent, nameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data()))
		var key keys.Keys
		var isNew bool
		var err error

		if formattedName != "" {
			// 使用格式化后的名称作为基础名称
			nameKeys := keys.NewKeyBuilder(formattedName).Separator("")
			auto := keys.NewAutoIncrementKeys(nameKeys, 2)

			// 生成唯一名称（考虑名称复用）
			key, isNew, err = ct.generateUniqueObjectName(auto, net, func() firewall.NamerIterator {
				return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
			}, nil, RetryMethodNext, true) // useBaseFirst = true

			if err != nil {
				result.SetError(err)
				return result
			}

			if isNew {
				safeData.SetString(KeyObjectName, key.String())
				cli := dsl.IntentFormat(ctx.Intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
				builder.WriteString(cli)
				builder.WriteString(ct.SectionSeparator)
			}

			keyList = append(keyList, key.String())
		} else {
			intent := ctx.Intent
			ctx := &NameGenerationContext{
				ObjectName:   "", // Group 场景通常没有指定 objectName
				Template:     nameTemplate,
				Data:         safeData.Data(),
				UseBaseFirst: true,
				RetryMethod:  RetryMethodNext,
				Object:       net,
				IteratorFunc: func() firewall.NamerIterator {
					return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
				},
			}

			nameResult, err := ct.nameGenerator.Generate(ctx)
			if err != nil {
				result.SetError(err)
				return result
			}

			if nameResult.IsNew {
				safeData.SetString(KeyObjectName, nameResult.Name)
				cli := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), safeData.Data())
				builder.WriteString(cli)
				builder.WriteString(ct.SectionSeparator)
			}

			keyList = append(keyList, nameResult.Name)
		}

	default:
		// 如果 style 不是 EachDetailed 或 Group，使用旧的实现
		return ct.makeNetworkObjectCliOld(net, objName, policeName, isSource, style, ctx, data)
	}

	cli := builder.String()
	result.SetCLIs(strings.Split(cli, "\n"))
	result.Keys = keyList
	result.CLIString = cli
	return result
}

// func (ct *CommonTemplates) MakeAclBaseSnatCli(from, out api.Port, intent *policy.Intent, ctx *firewall.PolicyContext) (string, error) {
// 	// om := NewObjectManager(spt)

// 	// Step 1: 查找适合改造的 NAT 规则
// 	natRule, err := ct.findSuitableNatRule(out, intent)
// 	if err != nil {
// 		return "", fmt.Errorf("failed to find suitable NAT rule: %w", err)
// 	}

// 	// Step 2: 处理 NAT 规则
// 	if natRule != nil {
// 		// 改造现有 NAT 规则
// 		return ct.modifyExistingNatRule(natRule, from, out, intent, ctx)
// 	} else {
// 		// 检查 address group 是否已被使用
// 		if ct.isAddressGroupUsed(intent.Snat) {
// 			return "", fmt.Errorf("address group %s is already in use", intent.Snat)
// 		}
// 		// 创建新的 SNAT 规则
// 		return ct.createNewAclBaseSnatRule(from, out, intent, ctx)
// 	}
// }

// func (ct *CommonTemplates) findSuitableNatRule(out api.Port, intent *policy.Intent) (firewall.FirewallNatRule, error) {
// 	snatIterator := ct.Node.(firewall.IteratorFirewall).SnatIterator()
// 	for snatIterator.HasNext() {
// 		nat := snatIterator.Next().(firewall.FirewallNatRule)
// 		ng, err := network.NewNetworkGroupFromString(intent.Snat)
// 		if err != nil {
// 			return nil, fmt.Errorf("failed to parse SNAT: %w", err)
// 		}

// 		if nat.Name() == out.Name() && nat.Translate().Src().MatchNetworkGroup(ng) {
// 			return nat, nil
// 		}
// 	}
// 	return nil, nil
// }

// func (ct *CommonTemplates) modifyExistingNatRule(natRule firewall.FirewallNatRule, from, out api.Port, intent *policy.Intent, ctx *firewall.PolicyContext) (string, error) {
// 	// 更新 NAT 规则对应的 ACL
// 	_, _, aclCli, err := ct.createOrUpdateAdvancedAcl(from, out, intent, nil, "TODO", ctx)
// 	// _, aclCli, err := spt.createOrUpdateAdvancedAcl(from, out, intent, natRule.aclName, ctx)
// 	if err != nil {
// 		return "", fmt.Errorf("failed to update ACL: %w", err)
// 	}

// 	return aclCli, nil
// }

// func (ct *CommonTemplates) createNewAclBaseSnatRule(from, out api.Port, intent *policy.Intent, ctx *firewall.PolicyContext) (string, error) {
// 	// // 创建新的 ACL

// 	clis := []string{}

// 	// Step 1: Create or Update Advanced ACL
// 	aclId, aclName, aclCli, err := ct.createOrUpdateAdvancedAcl(from, out, intent, nil, "", ctx)
// 	if err != nil {
// 		return "", err
// 	}
// 	clis = append(clis, aclCli)

// 	data := intent.MetaData
// 	// Step 2: Create or Update Address Group

// 	poolId, addrGroupCli, err := ct.createOrReuseNatAddressGroup(intent, ctx)
// 	if err != nil {
// 		return "", err
// 	}
// 	clis = append(clis, addrGroupCli)
// 	data["pool_id"] = poolId

// 	// Step 3: Generate NAT Outbound command
// 	natOutboundCmd, err := ct.generateNatOutboundCommand(poolId, aclName, ctx)
// 	if err != nil {
// 		return "", err
// 	}
// 	clis = append(clis, natOutboundCmd)

// 	return strings.Join(clis, "\n"), nil

// }

func (ct *CommonTemplates) isAddressGroupUsed(addressGroup string) bool {
	// 实现检查 address group 是否已被使用的逻辑
	// 这可能需要遍历现有的 NAT 规则或查询设备配置
	return false
}

func (ct *CommonTemplates) createOrUpdateAdvancedAcl(from, out api.Port, intent *policy.Intent, id *int, aclName string, ctx *firewall.PolicyContext) (aclId int, acl, cli string, err error) {
	if aclName != "" || id != nil {
		aclId := 0
		if id != nil {
			aclId = *id
		}
		cli, err := ct.UpdateAdvancedAcl(from, out, intent, aclId, aclName, ctx)
		if id != nil {
			return *id, aclName, cli, err
		}
		return 0, aclName, cli, err
	}

	aclId, aclName, clis, err := ct.MakeAdvancedAclCli(intent, ctx)
	return aclId, aclName, strings.Join(clis, "\n"), err
}

// CreateOrReuseNatAddressGroupOld 旧版本的 CreateOrReuseNatAddressGroup 函数，保留作为备份
func (ct *CommonTemplates) CreateOrReuseNatAddressGroupOld(intent *policy.Intent, ctx *firewall.PolicyContext, params map[string]interface{}) (string, string, error) {
	ng, err := network.NewNetworkGroupFromString(intent.Snat)
	if err != nil {
		return "", "", fmt.Errorf("failed to create network group from SNAT: %w", err)
	}

	// 使用 NatPoolIterator 来查找匹配的地址组
	iterator := ct.Node.(firewall.IteratorFirewall).NatPoolIterator()

	for iterator.HasNext() {
		pool := iterator.Next().(firewall.NatPool)
		if pool.MatchNetworkGroup(ng) {
			// 找到匹配的地址组，重用它
			ctx.WithValue("pool_id", pool.ID())
			return pool.ID(), fmt.Sprintf("# Reusing existing address group: %s", pool.Name()), nil
		}
	}

	// name, _ := ctx.GetStringValue("pool")
	// 如果没有找到匹配的地址组，创建新的
	// 尝试从 params 中获取 pool_id，如果没有则生成新的
	poolId, _ := params["pool_id"].(string)
	id := ct.Node.(firewall.PoolIdFirewall).NextPoolId(poolId)
	data := map[string]interface{}{
		"pool_id": id,
	}

	for k, v := range params {
		data[k] = v

	}
	if _, ok := data["pool_name"]; !ok {
		data["pool_name"] = id
	}

	builder := strings.Builder{}

	net := ng.GenerateNetwork()

	builder.WriteString(dsl.NetworkFormat(net, ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("Pool", "OneLoop")), dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data))

	return id, builder.String(), nil
}

// CreateOrReuseNatAddressGroup 创建或复用 NAT 地址组
// 完全基于 intent.Snat 来查询和创建 pool，不依赖 pool_id
// 支持通过 make_snat 控制是否创建 pool
// 支持通过 securitypolicy.snat_object_name_template 控制 pool 名称生成
// 支持通过 securitypolicy.* 传递设备特定参数
func (ct *CommonTemplates) CreateOrReuseNatAddressGroup(intent *policy.Intent, ctx *firewall.PolicyContext, params map[string]interface{}) (string, string, error) {
	// 1. 检查 make_snat 标志（向后兼容：如果不存在，默认创建 pool）
	if makeSnat, ok := params["make_snat"].(string); ok && makeSnat != "true" {
		// 如果 make_snat 明确设置为非 "true"，直接返回，不创建 pool
		return "", "", nil
	}

	// 2. 验证 intent.Snat 不为空
	if intent.Snat == "" {
		return "", "", fmt.Errorf("intent.Snat is empty")
	}

	// 3. 从 intent.Snat 创建 NetworkGroup（完全基于 snat 地址）
	ng, err := network.NewNetworkGroupFromString(intent.Snat)
	if err != nil {
		return "", "", fmt.Errorf("failed to create network group from SNAT: %w", err)
	}

	// 4. 通过 snat 地址查询匹配的 pool（完全基于 snat 网络组匹配）
	iterator := ct.Node.(firewall.IteratorFirewall).NatPoolIterator()
	for iterator.HasNext() {
		pool := iterator.Next().(firewall.NatPool)

		// 获取 pool 的 NetworkGroup（通过类型断言或接口方法）
		var poolNet *network.NetworkGroup
		// 尝试通过类型断言获取 NetworkGroup
		switch p := pool.(type) {
		case interface {
			Network(firewall.FirewallNode) *network.NetworkGroup
		}:
			poolNet = p.Network(ct.Node)
		default:
			// 如果无法直接获取，使用 MatchNetworkGroup 检查完全匹配
			if pool.MatchNetworkGroup(ng) {
				// 完全匹配，复用已有 pool
				ctx.WithValue("pool_id", pool.ID())
				return pool.ID(), fmt.Sprintf("# Reusing existing address group: %s", pool.Name()), nil
			}
			// 无法获取 NetworkGroup，跳过重叠检查
			continue
		}

		if poolNet == nil {
			continue
		}

		// 使用 NetworkGroupCmp 检查重叠关系
		_, mid, _ := network.NetworkGroupCmp(*poolNet, *ng)

		// 如果完全匹配（Same），复用已有 pool
		if poolNet.Same(ng) {
			ctx.WithValue("pool_id", pool.ID())
			return pool.ID(), fmt.Sprintf("# Reusing existing address group: %s", pool.Name()), nil
		}

		// 如果有重叠但不完全匹配，返回错误
		if mid != nil && !mid.IsEmpty() && !mid.Same(ng) {
			return "", "", fmt.Errorf("SNAT address %s overlaps with existing pool %s (ID: %s) but does not match exactly. Overlap: %s",
				intent.Snat, pool.Name(), pool.ID(), mid.String())
		}
	}

	// 5. 如果没有查询到匹配的 pool，创建新的 pool（完全基于 snat 地址）
	// 提取所有 securitypolicy.* 参数（去掉 securitypolicy. 前缀）
	data := make(map[string]interface{})
	for k, v := range params {
		// 如果是以 securitypolicy. 开头的参数，去掉前缀后添加到 data
		if strings.HasPrefix(k, "securitypolicy.") {
			key := strings.TrimPrefix(k, "securitypolicy.")
			// 跳过 snat_object_name_template，因为它用于生成 pool 名称，不是传递给模板的参数
			if key != "snat_object_name_template" {
				data[key] = v
			}
		} else {
			// 其他参数直接添加（除了 make_snat，它只是控制标志）
			if k != "make_snat" {
				data[k] = v
			}
		}
	}

	// 6. 生成 pool ID 或 pool 名称（不依赖 pool_id，完全基于 snat）
	var poolId string
	var poolName string

	// 如果存在 securitypolicy.snat_object_name_template，使用模板生成 pool 名称
	if snatTemplate, ok := params["securitypolicy.snat_object_name_template"].(string); ok && snatTemplate != "" {
		// 准备模板数据
		templateData := make(map[string]interface{})
		for k, v := range params {
			templateData[k] = v
		}
		// 添加 policy_name（如果存在）
		if policyName, ok := params["policy_name"].(string); ok {
			templateData["policy_name"] = policyName
		}
		// 从 ctx.Variables 中获取变量并添加到 templateData（用于 VAR: 变量解析）
		if ctx != nil && ctx.Variables != nil {
			for k, v := range ctx.Variables {
				// 如果 templateData 中还没有这个键，才添加（params 优先）
				if _, exists := templateData[k]; !exists {
					templateData[k] = v
				}
			}
		}
		// 使用 NetworkGroupFormat 格式化模板（基于 snat 网络组）
		formattedName := strings.TrimSpace(dsl.NetworkGroupFormat(ng, snatTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), templateData))
		if formattedName != "" && !strings.Contains(formattedName, "Unknown placeholder") {
			poolName = formattedName
			poolId = formattedName
		} else {
			// 如果模板格式化失败，使用 NextPoolId 生成（不传递 pool_id）
			poolId = ct.Node.(firewall.PoolIdFirewall).NextPoolId("")
			poolName = poolId
		}
	} else {
		// 如果没有模板，使用 NextPoolId 生成 pool ID（不传递 pool_id，完全基于 snat）
		poolId = ct.Node.(firewall.PoolIdFirewall).NextPoolId("")
		poolName = poolId
	}

	// 7. 设置 pool_id 和 pool_name
	data["pool_id"] = poolId
	if _, ok := data["pool_name"]; !ok {
		data["pool_name"] = poolName
	}

	// 8. 设置 make_snat 标志，用于 Sangfor 和 FortiGate 的 NetworkObject 模板区分 pool 和普通网络对象
	data["make_snat"] = "true"

	// 9. 统一处理 ASA 的 object_name 和 isSignle 逻辑，由模板自行判断
	data["object_name"] = poolName // ASA 的 pool name 就是 object name

	// 只有当网络组只有一个条目且是单个主机地址（/32 或单个 IP）时，才认为是单个地址
	count := 0
	isSingleHost := false
	ng.EachDataRangeEntryAsAbbrNet(func(item network.AbbrNet) bool {
		count++
		if count == 1 {
			// 检查第一个条目是否是单个主机地址
			if ipNet, ok := item.(*network.IPNet); ok {
				// 检查是否是 /32（IPv4）或 /128（IPv6）单个主机地址
				if ipNet.Type() == network.IPv4 && ipNet.Mask.Prefix() == 32 {
					isSingleHost = true
				} else if ipNet.Type() == network.IPv6 && ipNet.Mask.Prefix() == 128 {
					isSingleHost = true
				}
			}
		}
		return count <= 1 // 只检查第一个条目
	})
	if count == 1 && isSingleHost {
		data["isSignle"] = "true" // ASA Pool 模板使用 isSignle（拼写错误，但模板使用这个）
	} else {
		data["isSignle"] = "false"
	}

	// 9. 从网络组中提取 start 和 end（用于 Pool 模板，如 SecPath）
	// 这些值会被 Pool 模板使用，例如：nat address-group {pool_id} address {start} {end}
	// 同时设置 first 和 last（用于 FortiGate 和 Sangfor 的 Pool 模板）
	ng.EachDataRangeEntryAsAbbrNet(func(abbrNet network.AbbrNet) bool {
		if ipNet, ok := abbrNet.(*network.IPNet); ok {
			// 单个 IP 或子网，start 和 end 都是同一个 IP
			data["start"] = ipNet.IP.String()
			data["end"] = ipNet.IP.String()
			// 对于 FortiGate 和 Sangfor，使用 first 和 last
			data["first"] = ipNet.IP.String()
			data["last"] = ipNet.IP.String()
			return false // 只取第一个
		} else if ipRange, ok := abbrNet.(*network.IPRange); ok {
			// IP 范围，start 和 end 分别是范围的起始和结束 IP
			data["start"] = ipRange.Start.String()
			data["end"] = ipRange.End.String()
			// 对于 FortiGate 和 Sangfor，使用 first 和 last
			data["first"] = ipRange.Start.String()
			data["last"] = ipRange.End.String()
			return false // 只取第一个
		}
		return true
	})

	// 10. 生成 Pool CLI（基于 snat 网络组）
	builder := strings.Builder{}
	builder.WriteString(dsl.NetworkGroupFormat(ng, ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("Pool", "OneLoop")), dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data))

	return poolId, builder.String(), nil
}

func (ct *CommonTemplates) CreatePool(ng *network.NetworkGroup, name string, ctx *firewall.PolicyContext) (string, string, error) {
	// 尝试从 ctx 中获取 pool_id，如果没有则生成新的
	poolId, _ := ctx.GetStringValue("pool_id")
	id := ct.Node.(firewall.PoolIdFirewall).NextPoolId(poolId)
	data := map[string]interface{}{
		"id": id,
	}
	if name != "" {
		data["name"] = name
	}

	builder := strings.Builder{}

	net := ng.GenerateNetwork()

	builder.WriteString(dsl.NetworkFormat(net, ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("Pool", "OneLoop")), dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true)))

	return id, builder.String(), nil
}

func (ct *CommonTemplates) generateNatOutboundCommand(poolId, aclNumber string, ctx *firewall.PolicyContext) (string, error) {

	snatDescription, exists := ctx.GetStringValue("snatDescription")
	if !exists {
		return "", fmt.Errorf("snat description not found in context")
	}

	if exists {
		// return fmt.Sprintf("nat outbound %s address-group %s", aclNumber, addressGroupIndex), nil
		return "", nil
	}

	return fmt.Sprintf(ct.ts.GetTemplates("NAT.Outbound.Command.format"), aclNumber, poolId, snatDescription), nil
}

// nat address-group 9 name Snat-DMZ_EOP-access-ZhaoHang
//
//	address 192.168.0.138 192.168.0.138
// func (ct *CommonTemplates) MakeNatAddressGroupCli(intent *policy.Intent, ng *network.NetworkGroup) (string, error) {
// 	addrGroupName := intent.MetaData["addressGroupName"]
// 	index := intent.MetaData["addressGroupIndex"]
// 	clis := []string{
// 		fmt.Sprintf("nat address-group %s name %s", index, addrGroupName),
// 	}
// 	ng.Each(func(n network.AbbrNet) bool {
// 		clis = append(clis, dsl.NetworkFormat(n, ` address {start} {end}`))
// 		return true
// 	})

// 	return strings.Join(clis, "\n"), nil
// }

// nat static outbound 61.147.19.32 192.168.1.201 description 163_RZGLPT_CSJieKou01
// nat static outbound local-ip global-ip
// 1. 确定本地地址，就是intent的src地址
// 2. 确定映射后（全局）地址，就是snat ip
// 3. 确定description
// 4. 确定nat static outbound
func (ct *CommonTemplates) MakeStaticInOrOutboundCli(from, out api.Port, intent *policy.Intent, direction NatDirection, ctx *firewall.PolicyContext, d map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()
	builder := strings.Builder{}
	fromZone, toZone := "", ""

	// 注意：Sangfor 等防火墙的接口和 zone 没有关联，Port 可能不实现 ZoneFirewall 接口
	if from != nil {
		if zf, ok := from.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if out != nil {
		if zf, ok := out.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("Nat", "Static", "OneLoop"))
	data := map[string]interface{}{}
	if desc, ok := ctx.GetStringValue("description"); ok {
		data["description"] = desc
	}
	if intent.Snat != "" {
		data["snat"] = intent.Snat
	}
	if intent.RealIp != "" {
		data["real_ip"] = intent.RealIp
	}
	if intent.RealPort != "" {
		data["real_port"] = intent.RealPort
	}
	if s, ok := ctx.GetStringValue("nat_rule_name"); ok {
		data["nat_rule_name"] = s
	}

	data["direction"] = direction.String()

	if from != nil {
		data["fromPort"] = from.Name()
		data["fromZone"] = fromZone
	}
	if out != nil {
		data["toPort"] = out.Name()
		data["toZone"] = toZone
	}

	for k, v := range d {
		data[k] = v
	}

	builder.WriteString(dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data))
	builder.WriteString(ct.SectionSeparator)

	cliString := builder.String()
	result.SetCLIs(strings.Split(cliString, "\n"))
	result.CLIString = cliString
	result.SetFlyObject("NAT", cliString)

	return result
}

// func (ct *CommonTemplates) MakeAdvancedAclCli(intent *policy.Intent, ctx *firewall.PolicyContext) (int, string, []string, error) {
// 	id, aclName := ct.aclIDGenerator.GenerateID()

// 	data := map[string]interface{}{}
// 	if v, ok := ctx.GetStringValue("objectStyle"); ok {
// 		data["objectStyle"] = v
// 		data["sourceAddressObject"] = tools.MaybeOk(ctx.GetStringValue("sourceAddressObject"))
// 		data["destinationAddressObject"] = tools.MaybeOk(ctx.GetStringValue("destinationAddressObject"))
// 	}
// 	data["acl_name"] = aclName
// 	data["acl_id"] = id

// 	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("ACL", "Cross", "OneLoop"))
// 	clis := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)
// 	clis = strings.TrimSpace(clis) + "\n" + ct.SectionSeparator
// 	return id, aclName, strings.Split(clis, "\n"), nil
// }

func (ct *CommonTemplates) MakeAdvancedAclCli(intent *policy.Intent, ctx *firewall.PolicyContext) (int, string, []string, error) {
	aclId, aclName := ct.generateAclName(ctx)

	data := map[string]interface{}{}
	if v, ok := ctx.GetStringValue("objectStyle"); ok {
		data["objectStyle"] = v
		data["sourceAddressObject"] = tools.MaybeOk(ctx.GetStringValue("sourceAddressObject"))
		data["destinationAddressObject"] = tools.MaybeOk(ctx.GetStringValue("destinationAddressObject"))
	}
	data["acl_name"] = aclName
	data["acl_id"] = aclId

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("ACL", "OneLoop"))
	clis := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)
	clis = strings.TrimSpace(clis) + "\n" + ct.SectionSeparator
	return aclId, aclName, strings.Split(clis, "\n"), nil
}

// 1. 确定本地地址
// 2. 确定映射后（全局）地址，就是intent的dst地址
// 3. 确定description
// 4. 确定nat static inbound

func (ct *CommonTemplates) MakeStaticInboundCli(from, out api.Port, intent *policy.Intent, ctx *firewall.PolicyContext) *PolicyResult {
	result := NewPolicyResult()
	builder := strings.Builder{}

	data := map[string]interface{}{
		"real_ip":                intent.RealIp,
		"static_nat_description": fmt.Sprintf("NETACC_%s_%s", intent.TicketNumber, intent.SubTicket),
		"interface_name":         from.Name(),
	}
	if intent.RealPort != "" {
		data["real_port"] = intent.RealPort
	}

	_, ruleName := ct.generatePolicyName(ctx)
	data["static_nat_rule"] = ruleName

	cli := dsl.IntentFormat(intent, ct.ts.GetTemplates("NAT.Static.Inbound.Command.layout"), dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)
	builder.WriteString(cli)

	result.SetCLIs([]string{builder.String()})
	result.CLIString = builder.String()
	result.SetFlyObject(FlyObjectNat, result.CLIString)

	return result
}

func (ct *CommonTemplates) MakePolicyRuleCli(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions, datas ...map[string]interface{}) *PolicyResult {
	result := ct.makeCommonPolicyRuleCli(from, to, intent, ctx, opts, datas...)
	if !result.IsValid() {
		return result
	}

	result.SetFlyObject(FlyObjectSecurityPolicy, result.CLIString)
	return result
}

func (ct *CommonTemplates) MakePolicyBaseNatRuleCli(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions, datas ...map[string]interface{}) *PolicyResult {

	result := ct.makeCommonNatPolicyRuleCli(from, to, intent, ctx, opts, datas...)
	if !result.IsValid() {
		return result
	}

	result.IsGlobalNat = true
	return result
}

func (ct *CommonTemplates) makeCommonPolicyRuleCli(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions, datas ...map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()
	builder := strings.Builder{}
	fromZone, toZone := "", ""

	// 注意：Sangfor 等防火墙的接口和 zone 没有关联，Port 可能不实现 ZoneFirewall 接口
	if from != nil {
		if zf, ok := from.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if to != nil {
		if zf, ok := to.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("Policy", "OneLoop"))

	// For ASA, if Policy template is a placeholder (only comments), use ACL template instead
	// Check if layout only contains comments (starts with {comment: or {set:)
	if strings.TrimSpace(layout) != "" {
		trimmed := strings.TrimSpace(layout)
		// Check if it's only comments and set statements
		lines := strings.Split(trimmed, "\n")
		hasNonComment := false
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if line != "" && !strings.HasPrefix(line, "{comment:") && !strings.HasPrefix(line, "{set:") {
				hasNonComment = true
				break
			}
		}
		// If only comments, use ACL template for ASA
		if !hasNonComment {
			aclLayout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("ACL", "OneLoop"))
			if aclLayout != "" {
				layout = aclLayout
			}
		}
	}

	// Generate policy name
	var policyName string
	var policyId int
	policyId, policyName = ct.generatePolicyName(ctx)

	// For ASA, also generate ACL name since we're using ACL template
	aclId, aclName := ct.generateAclName(ctx)

	info := &PolicyInfo{
		FromZone: fromZone,
		ToZone:   toZone,
		// Id:       fmt.Sprintf("%d", policyId),
		// Name:     policyName,
	}

	data := map[string]interface{}{
		"sourceZones":      []interface{}{fromZone},
		"destinationZones": []interface{}{toZone},
		"policy_name":      policyName,
		"policy_id":        policyId,
		"action":           ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("Policy", "Command", "Permit")),
		"policyType":       tools.MaybeOk(ctx.GetStringValue("policyType")),
		"acl_name":         aclName,
		"acl_id":           aclId,
	}

	for _, d := range datas {
		if v, ok := d["securitypolicy.description_template"]; ok {
			data["description"] = dsl.MapFormat(d, v.(string), dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true))
		}
		for k, v := range d {
			data[k] = v
		}
	}
	if from != nil {
		data["fromPort"] = from.Name()
		data["fromZone"] = fromZone
	}
	if to != nil {
		data["toPort"] = to.Name()
		data["toZone"] = toZone
	}
	// if v, ok := ctx.GetStringValue("description"); ok {
	// 	data["description"] = v
	// }

	info.Id = fmt.Sprintf("%v", data["policy_id"])
	info.Name = data["policy_name"].(string)

	// Handle object style or non-object style
	// For FortiGate, always create objects (even if isObjectStyle is false)
	// because FortiGate policy requires object names, not direct IP addresses
	isFortiGate := strings.Contains(layout, "config firewall policy") && strings.Contains(layout, "set srcaddr")

	if opts.isObjectStyle || isFortiGate {
		objResult := ct.generateObjectStyleCli(intent, info, layout, ctx, data, opts)
		if !objResult.IsValid() {
			return objResult
		}
		builder.WriteString(objResult.CLIString)
		result.MergeFlyObjects(objResult.FlyObject)
	} else {
		rendered := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)
		builder.WriteString(rendered)
	}

	builder.WriteString(ct.SectionSeparator)

	// Split the builder string into lines
	lines := strings.Split(builder.String(), "\n")

	// Create a slice to store unique lines while preserving order
	uniqueLines := make([]string, 0, len(lines))
	seen := make(map[string]bool)

	// Iterate through the lines, adding only unique ones to the result
	for _, line := range lines {
		if !seen[line] {
			seen[line] = true
			uniqueLines = append(uniqueLines, line)
		}
	}

	// Set the deduplicated CLI commands
	result.SetCLIs(uniqueLines)
	result.CLIString = strings.Join(uniqueLines, "\n")

	result.SetFlyObject(FlyObjectSecurityPolicy, result.CLIString)
	return result
}

func (ct *CommonTemplates) makeCommonNatPolicyRuleCli(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions, datas ...map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()
	builder := strings.Builder{}
	fromZone, toZone := "", ""

	// 注意：Sangfor 等防火墙的接口和 zone 没有关联，Port 可能不实现 ZoneFirewall 接口
	if from != nil {
		if zf, ok := from.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if to != nil {
		if zf, ok := to.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}

	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("NatPolicy", "OneLoop"))

	// Generate policy name
	var policyName string
	var policyId int
	policyId, policyName = ct.generatePolicyName(ctx)
	info := &PolicyInfo{
		FromZone: fromZone,
		ToZone:   toZone,
		// Id:       fmt.Sprintf("%d", policyId),
		// Name:     policyName,
	}
	data := map[string]interface{}{
		"sourceZones":      []interface{}{fromZone},
		"destinationZones": []interface{}{toZone},
		"policy_name":      policyName,
		"policy_id":        policyId,
	}

	for _, d := range datas {
		for k, v := range d {
			data[k] = v
		}
	}

	if from != nil {
		data["fromPort"] = from.Name()
		data["fromZone"] = fromZone
	}
	if to != nil {
		data["toPort"] = to.Name()
		data["toZone"] = toZone
	}
	if v, ok := ctx.GetStringValue("description"); ok {
		data["description"] = v
	}

	info.Id = fmt.Sprintf("%v", data["policy_id"])
	info.Name = data["policy_name"].(string)

	switch opts.natType {
	case firewall.DYNAMIC_NAT:
		groupid, cli, err := ct.CreateOrReuseNatAddressGroup(intent, ctx, data)
		if err != nil {
			result.SetError(err)
			return result
		}
		// clis := []string{}

		result.SetFlyObject(FlyObjectPool, cli)
		result.CLIString = builder.String()
		data["pool_id"] = groupid
		data["pool_name"] = groupid
		// 设置 use_pool 标志，用于 NatPolicy 模板生成 NAT 配置
		data["use_pool"] = "true"
		// 设置 has_pool_id 标志，用于 DSL exist 检查
		data["has_pool_id"] = "true"
		// 如果 intent.Snat 存在，也设置 snat 变量（用于 NatPolicy 模板）
		if intent.Snat != "" {
			data["snat"] = intent.Snat
			data["has_snat"] = "true"
		}
	case firewall.DESTINATION_NAT:
		data["real_ip"] = intent.RealIp
		data["real_port"] = intent.RealPort
		// 设置 has_real_ip 和 has_real_port 标志，用于 DSL exist 检查
		if intent.RealIp != "" {
			data["has_real_ip"] = "true"
		}
		if intent.RealPort != "" {
			data["has_real_port"] = "true"
		}

	default:
		result.SetError(fmt.Errorf("unsupported NAT type: %v", opts.natType))
	}

	// Handle object style or non-object style
	if opts.isObjectStyle {
		// 调试：打印 data 中的关键变量
		// fmt.Printf("DEBUG makeCommonNatPolicyRuleCli data: has_pool_id=%v, has_snat=%v, pool_id=%v, snat=%v, has_real_ip=%v\n",
		// 	data["has_pool_id"], data["has_snat"], data["pool_id"], data["snat"], data["has_real_ip"])
		objResult := ct.generateObjectStyleCli(intent, info, layout, ctx, data, opts)
		if !objResult.IsValid() {
			return objResult
		}
		builder.WriteString(objResult.CLIString)
		result.MergeFlyObjects(objResult.FlyObject)
	} else {
		builder.WriteString(dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data))
	}

	builder.WriteString(ct.SectionSeparator)
	result.SetCLIs(strings.Split(builder.String(), "\n"))
	result.CLIString = builder.String()
	result.SetFlyObject(FlyObjectNat, result.CLIString)
	return result
}

type PolicyOptions struct {
	// isSetStyle                 bool
	isObjectStyle              bool
	natType                    firewall.NatType
	generateSourceObjects      bool
	generateDestinationObjects bool
	generateServiceObjects     bool
	natProcessMode             NatProcessMode
	natDirection               NatDirection
	natStyle                   NatStyle
	enableAclGeneration        bool
	enablePoolGeneration       bool
	staticNatRule              string
	staticNatDescription       string
}

type PolicyOption func(*PolicyOptions)

func WithObjectStyle(isObjectStyle bool) PolicyOption {
	return func(po *PolicyOptions) {
		po.isObjectStyle = isObjectStyle
	}
}

func WithSourceObjects(generate bool) PolicyOption {
	return func(po *PolicyOptions) {
		po.generateSourceObjects = generate
	}
}

func WithDestinationObjects(generate bool) PolicyOption {
	return func(po *PolicyOptions) {
		po.generateDestinationObjects = generate
	}
}

func WithServiceObjects(generate bool) PolicyOption {
	return func(po *PolicyOptions) {
		po.generateServiceObjects = generate
	}
}

func WithNatType(natType firewall.NatType) PolicyOption {
	return func(po *PolicyOptions) {
		po.natType = natType
	}
}

// PolicyOption构造函数
func WithNatProcessMode(mode NatProcessMode) PolicyOption {
	return func(opts *PolicyOptions) {
		opts.natProcessMode = mode
	}
}

func WithNatDirection(direction NatDirection) PolicyOption {
	return func(opts *PolicyOptions) {
		opts.natDirection = direction
	}
}

func WithNatStyle(style NatStyle) PolicyOption {
	return func(opts *PolicyOptions) {
		opts.natStyle = style
	}
}

func WithAclGeneration(enable bool) PolicyOption {
	return func(opts *PolicyOptions) {
		opts.enableAclGeneration = enable
	}
}

func WithPoolGeneration(enable bool) PolicyOption {
	return func(opts *PolicyOptions) {
		opts.enablePoolGeneration = enable
	}
}

func WithStaticNatRule(rule string) PolicyOption {
	return func(opts *PolicyOptions) {
		opts.staticNatRule = rule
	}
}

func WithStaticNatDescription(desc string) PolicyOption {
	return func(opts *PolicyOptions) {
		opts.staticNatDescription = desc
	}
}

func (ct *CommonTemplates) generateObjectStyleCli(intent *policy.Intent, policy *PolicyInfo, layout string, ctx *firewall.PolicyContext, data map[string]interface{}, opts *PolicyOptions) *PolicyResult {
	result := NewPolicyResult()
	builder := strings.Builder{}

	// 1. 处理源地址对象 (Src)
	if data["make_source"] == "true" {
		// 从 data 中获取命名模板，如果没有则使用默认模板
		srcTemplate := ""
		if t, ok := data["securitypolicy.src_object_name_template"].(string); ok && t != "" {
			srcTemplate = t
		} else if t, ok := data["network_object_name_template"].(string); ok && t != "" {
			srcTemplate = t
		} else {
			// 使用默认命名模板
			srcTemplate = "{policy_name}_src_addr"
		}

		d := map[string]interface{}{}
		for key := range data {
			d[key] = data[key]
		}
		// 设置命名模板
		d[KeyNetworkObjectNameTemplate] = srcTemplate
		d["is_source"] = "true"
		// 确保移除 make_vip 标志，源地址对象不是 VIP
		delete(d, "make_vip")

		srcResult := ct.MakeNetworkObjectCli(policy.FromZone, policy.ToZone, intent.Src(), "", policy.Name, true, ctx, d)
		if !srcResult.IsValid() {
			result.SetError(fmt.Errorf("failed to create source object cli: %v", srcResult.Error))
			return result
		}
		data["sourceObjects"] = srcResult.Keys
		data["src_objects"] = srcResult.Keys // 同时设置 src_objects 以匹配策略模板
		if len(srcResult.Keys) > 0 {
			data["has_source_objects"] = "true"
		}
		result.MergeFlyObjects(srcResult.FlyObject)
	}

	// 2. 处理目标地址对象 (Dst)
	if data["make_destination"] == "true" {
		// 从 data 中获取命名模板，如果没有则使用默认模板
		dstTemplate := ""
		if t, ok := data["securitypolicy.dst_object_name_template"].(string); ok && t != "" {
			dstTemplate = t
		} else if t, ok := data["network_object_name_template"].(string); ok && t != "" {
			dstTemplate = t
		} else {
			// 使用默认命名模板
			dstTemplate = "{policy_name}_dst_addr"
		}

		d := map[string]interface{}{}
		for key := range data {
			d[key] = data[key]
		}
		// 设置命名模板
		d[KeyNetworkObjectNameTemplate] = dstTemplate
		d["is_source"] = "false"
		// 确保移除 make_vip 标志，目标地址对象不是 VIP
		delete(d, "make_vip")

		dstResult := ct.MakeNetworkObjectCli(policy.FromZone, policy.ToZone, intent.Dst(), "", policy.Name, false, ctx, d)
		if !dstResult.IsValid() {
			result.SetError(fmt.Errorf("failed to create destination object cli: %v", dstResult.Error))
			return result
		}
		data["destinationObjects"] = dstResult.Keys
		data["dst_objects"] = dstResult.Keys // 同时设置 dst_objects 以匹配策略模板
		if len(dstResult.Keys) > 0 {
			data["has_destination_objects"] = "true"
		}
		result.MergeFlyObjects(dstResult.FlyObject)
	}

	// 3. 处理服务对象 (Service)
	if data["make_service"] == "true" {
		// 从 data 中获取命名模板，如果没有则使用默认模板
		serviceTemplate := ""
		if t, ok := data["securitypolicy.service_object_name_template"].(string); ok && t != "" {
			serviceTemplate = t
		} else if t, ok := data["service_object_name_template"].(string); ok && t != "" {
			serviceTemplate = t
		} else {
			// 使用默认命名模板
			// 注意：compact_port 是通过 ServiceObject.CompactPorts 模板生成的，如果为空则不存在
			// 使用 {if:exist:compact_port} 来检查 compact_port 是否存在（DSL 支持这种简写形式）
			serviceTemplate = "{policy_name}_{protocol}{if:exist:compact_port}_{compact_port}{endif}"
		}

		d := map[string]interface{}{}
		for key := range data {
			d[key] = data[key]
		}
		// 设置命名模板
		d[KeyServiceObjectNameTemplate] = serviceTemplate
		// 确保 policy_name 被传递（如果存在）
		if policyName, ok := data["policy_name"].(string); ok && policyName != "" {
			d["policy_name"] = policyName
		}

		srvResult := ct.MakeServiceObjectCli(intent.Service(), "", "", d)
		if !srvResult.IsValid() {
			result.SetError(fmt.Errorf("failed to create service object cli: %v", srvResult.Error))
			return result
		}
		data["serviceObjects"] = srvResult.Keys
		data["service_objects"] = srvResult.Keys // 同时设置 service_objects 以匹配策略模板
		if len(srvResult.Keys) > 0 {
			data["has_service_objects"] = "true"
		}
		result.MergeFlyObjects(srvResult.FlyObject)
	}

	// 4. 处理 real_ip 网络对象
	if data["make_real_ip"] == "true" && intent.RealIp != "" {
		// 从 data 中获取命名模板
		if realIpTemplate, ok := data["securitypolicy.real_ip_object_name_template"].(string); ok && realIpTemplate != "" {
			realIpNet, err := network.NewNetworkGroupFromString(intent.RealIp)
			if err == nil {
				d := map[string]interface{}{}
				for key := range data {
					d[key] = data[key]
				}
				// 设置命名模板
				d[KeyNetworkObjectNameTemplate] = realIpTemplate
				d["make_vip"] = "true"
				d["securitypolicy.object_name_style"] = Vip

				realIpResult := ct.MakeNatVipOrPool(policy.FromZone, policy.ToZone, realIpNet, "", policy.Name, false, intent, ctx, d)
				if realIpResult.IsValid() {
					realIpObj := ""
					if len(realIpResult.Keys) > 0 {
						realIpObj = realIpResult.Keys[0]
					}
					data["realIpObjects"] = realIpObj
					result.MergeFlyObjects(realIpResult.FlyObject)
				}
			}
		}
	}

	// 5. 处理 real_port 服务对象
	if data["make_real_port"] == "true" && intent.RealPort != "" {
		// 从 data 中获取命名模板
		if realPortTemplate, ok := data["securitypolicy.real_port_object_name_template"].(string); ok && realPortTemplate != "" {
			// 根据 intent.Service().Protocol() 创建服务对象
			protocol := intent.Service().Protocol()
			if protocol != service.IP {
				realPortSvc := &service.Service{}
				if protocol == service.TCP || protocol == service.UDP {
					port, err := strconv.Atoi(intent.RealPort)
					if err == nil {
						l4Port, err := service.NewL4Port(service.EQ, port, -1, 0)
						if err == nil {
							l4Svc, err := service.NewL4Service(service.IPProto(protocol), nil, l4Port)
							if err == nil {
								realPortSvc.Add(l4Svc)
								d := map[string]interface{}{}
								for key := range data {
									d[key] = data[key]
								}
								// 设置命名模板
								d[KeyServiceObjectNameTemplate] = realPortTemplate

								realPortResult := ct.MakeServiceObjectCli(realPortSvc, "", "", d)
								if realPortResult.IsValid() {
									realPortObj := ""
									if len(realPortResult.Keys) > 0 {
										realPortObj = realPortResult.Keys[0]
									}
									data["realServiceObjects"] = realPortObj
									result.MergeFlyObjects(realPortResult.FlyObject)
								}
							}
						}
					}
				}
			}
		}
	}

	// 6. 处理 SNAT 网络对象（用于动态 NAT）
	if data["make_snat"] == "true" && intent.Snat != "" {
		// 使用 CreateOrReuseNatAddressGroup 来创建或复用 NAT 地址组
		poolId, poolCli, err := ct.CreateOrReuseNatAddressGroup(intent, ctx, data)
		if err != nil {
			result.SetError(fmt.Errorf("failed to create or reuse NAT address group: %v", err))
			return result
		}
		// 将 pool ID 设置为 snatObjects
		data["snatObjects"] = poolId
		// 将生成的 pool CLI 添加到 FlyObject
		if poolCli != "" {
			result.SetFlyObject(FlyObjectPool, poolCli)
		}
		// 同时设置 pool_id 和 pool_name，以便在模板中使用
		data["pool_id"] = poolId
		if _, ok := data["pool_name"]; !ok {
			data["pool_name"] = poolId
		}
		// 设置 use_pool 标志，用于 NatPolicy 模板
		data["use_pool"] = "true"
		if sourceObjects, ok := data["sourceObjects"].([]string); ok && len(sourceObjects) > 0 {
			data["realIpObjects"] = sourceObjects[0]
		}
	}

	// // 7. 处理 DESTINATION_NAT - 生成 VIP（用于 FortiGate）
	// if opts.natType == firewall.DESTINATION_NAT && intent.RealIp != "" {
	// 	// 检查是否是 FortiGate（通过 layout 判断）
	// 	isFortiGate := strings.Contains(layout, "config firewall policy") || strings.Contains(layout, "set nat enable")

	// 	if isFortiGate {
	// 		// 对于 FortiGate，需要生成 VIP CLI
	// 		// 使用 NetworkObject OneLoop 模板生成 VIP
	// 		vipLayout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("NetworkObject", "OneLoop"))
	// 		if vipLayout != "" && intent.Dst() != nil && !intent.Dst().IsEmpty() {
	// 			// 准备 VIP 数据
	// 			vipData := map[string]interface{}{}
	// 			for k, v := range data {
	// 				vipData[k] = v
	// 			}

	// 			// 设置 make_vip 标志，触发 VIP 生成分支
	// 			vipData["make_vip"] = "true"

	// 			// // 设置 real_ip
	// 			// vipData["real_ip"] = intent.RealIp

	// 			// // 设置 real_port（如果有）
	// 			// if intent.RealPort != "" {
	// 			// 	vipData["real_port"] = intent.RealPort
	// 			// }

	// 			// 确保 toPort 正确设置
	// 			if toPort, ok := data["toPort"].(string); ok && toPort != "" {
	// 				vipData["toPort"] = toPort
	// 			}

	// 			// 准备目标网络组（用于模板中的 dst.first 和 dst.last）
	// 			dstNetGroup := network.NewNetworkGroup()
	// 			intent.Dst().EachDataRangeEntryAsAbbrNet(func(abbrNet network.AbbrNet) bool {
	// 				dstNetGroup.Add(abbrNet)
	// 				return false // 只取第一个用于 VIP
	// 			})

	// 			// 生成 VIP 对象名称
	// 			// 获取命名模板
	// 			vipNameTemplate := ""
	// 			if t, ok := data["securitypolicy.vip_object_name_template"].(string); ok && t != "" {
	// 				vipNameTemplate = t
	// 			} else if t, ok := data["network_object_name_template"].(string); ok && t != "" {
	// 				vipNameTemplate = t
	// 			} else {
	// 				// 使用默认命名模板
	// 				policyName := ""
	// 				if name, ok := data["policy_name"].(string); ok && name != "" {
	// 					policyName = name
	// 				} else {
	// 					policyName = policy.Name
	// 				}
	// 				vipNameTemplate = policyName + "_VIP"
	// 			}

	// 			// 生成 VIP 对象名称
	// 			vipObjName := ""
	// 			if formattedName := strings.TrimSpace(dsl.NetworkGroupFormat(dstNetGroup, vipNameTemplate, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), vipData)); formattedName != "" {
	// 				// 检查名称唯一性并生成唯一名称
	// 				nameKeys := keys.NewKeyBuilder(formattedName).Separator("_")
	// 				auto := keys.NewAutoIncrementKeys(nameKeys, 2)
	// 				key, _, err := ct.generateUniqueObjectName(auto, dstNetGroup, func() firewall.NamerIterator {
	// 					return ct.Node.(firewall.IteratorFirewall).NetworkIterator()
	// 				}, nil, RetryMethodNext, true)
	// 				if err == nil {
	// 					vipObjName = key.String()
	// 					vipData["object_name"] = vipObjName

	// 					// 生成 VIP CLI
	// 					// 注意：不要忽略前导空白，以保持 VIP CLI 的格式
	// 					vipCli := dsl.IntentFormat(intent, vipLayout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), vipData)
	// 					if vipCli != "" {
	// 						// 将 VIP CLI 添加到 FlyObject
	// 						result.SetFlyObject("STATIC_NAT", vipCli)
	// 						// 设置 use_vip 标志，用于 NatPolicy 模板
	// 						data["use_vip"] = "true"

	// 						// 将 VIP 对象名称添加到 destinationObjects，以便在 policy 中使用
	// 						if dstObjs, ok := data["destinationObjects"].([]string); ok {
	// 							data["destinationObjects"] = append(dstObjs, vipObjName)
	// 						} else {
	// 							data["destinationObjects"] = []string{vipObjName}
	// 						}
	// 						data["vip_name"] = vipObjName
	// 					}
	// 				}
	// 			}
	// 		}
	// 	}
	// }

	// 8. 生成最终 CLI
	if opts.isObjectStyle {
		data["objectStyle"] = true
	}

	rendered := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data)
	builder.WriteString(rendered)

	result.SetCLIs(strings.Split(builder.String(), "\n"))
	result.CLIString = builder.String()
	return result
}

func (ct *CommonTemplates) generateObjectStyleCliOld(intent *policy.Intent, policy *PolicyInfo, layout string, ctx *firewall.PolicyContext, data map[string]interface{}, opts *PolicyOptions) *PolicyResult {
	result := NewPolicyResult()
	builder := strings.Builder{}

	if opts.generateSourceObjects && data["make_source"] == "true" {
		d := map[string]interface{}{}
		for key := range data {
			d[key] = data[key]
		}

		srcResult := ct.MakeNetworkObjectCli(policy.FromZone, policy.ToZone, intent.Src(), "", policy.Name, true, ctx, d)
		if !srcResult.IsValid() {
			result.SetError(fmt.Errorf("failed to create source object cli: %v", srcResult.Error))
			return result
		}
		data["sourceObjects"] = srcResult.Keys
		result.MergeFlyObjects(srcResult.FlyObject)
	}

	if opts.generateDestinationObjects && data["make_destination"] == "true" {
		d := map[string]interface{}{}
		for key := range data {
			d[key] = data[key]
		}
		dstResult := ct.MakeNetworkObjectCli(policy.FromZone, policy.ToZone, intent.Dst(), "", policy.Name, false, ctx, d)
		if !dstResult.IsValid() {
			result.SetError(fmt.Errorf("failed to create destination object cli: %v", dstResult.Error))
			return result
		}
		data["destinationObjects"] = dstResult.Keys
		result.MergeFlyObjects(dstResult.FlyObject)
	}

	if opts.generateServiceObjects && data["make_service"] == "true" {
		d := map[string]interface{}{}
		for key := range data {
			d[key] = data[key]
		}
		srvResult := ct.MakeServiceObjectCli(intent.Service(), "", "", d)
		if !srvResult.IsValid() {
			result.SetError(fmt.Errorf("failed to create service object cli: %v", srvResult.Error))
			return result
		}
		data["serviceObjects"] = srvResult.Keys
		result.MergeFlyObjects(srvResult.FlyObject)
	}

	// Generate real_ip network object if it exists (for NAT scenarios)
	if realIp, ok := data[KeyRealIp].(string); ok && realIp != "" {
		realIpNet, err := network.NewNetworkGroupFromString(realIp)
		if err == nil {
			d := map[string]interface{}{}
			for key := range data {
				d[key] = data[key]
			}
			// Use a specific object name for real_ip, or generate one
			realIpObjName := fmt.Sprintf("%s_real_ip", policy.Name)
			realIpResult := ct.MakeNetworkObjectCli(policy.FromZone, policy.ToZone, realIpNet, realIpObjName, policy.Name, false, ctx, d)
			if realIpResult.IsValid() {
				realIpObj := realIpObjName
				if len(realIpResult.Keys) > 0 {
					realIpObj = realIpResult.Keys[0]
				}
				data["realIpObjects"] = realIpObj
				result.MergeFlyObjects(realIpResult.FlyObject)
			}
		}
	}

	// Generate real_port service object if it exists (for NAT scenarios with port translation)
	if realPort, ok := data[KeyRealPort].(string); ok && realPort != "" {
		// Create a service object for the real port
		// The protocol should match the intent service protocol
		protocol := intent.Service().Protocol()
		if protocol != service.IP {
			// Create a service with the real port
			realPortSvc := &service.Service{}
			if protocol == service.TCP || protocol == service.UDP {
				port, err := strconv.Atoi(realPort)
				if err == nil {
					l4Port, err := service.NewL4Port(service.EQ, port, -1, 0)
					if err == nil {
						l4Svc, err := service.NewL4Service(service.IPProto(protocol), nil, l4Port)
						if err == nil {
							realPortSvc.Add(l4Svc)
							d := map[string]interface{}{}
							for key := range data {
								d[key] = data[key]
							}
							// Use a specific object name for real_port, or generate one
							realPortObjName := fmt.Sprintf("%s_real_port", policy.Name)
							realPortResult := ct.MakeServiceObjectCli(realPortSvc, realPortObjName, policy.Name, d)
							if realPortResult.IsValid() {
								realPortObj := realPortObjName
								if len(realPortResult.Keys) > 0 {
									realPortObj = realPortResult.Keys[0]
								}
								data["realServiceObjects"] = realPortObj
								result.MergeFlyObjects(realPortResult.FlyObject)
							}
						}
					}
				}
			}
		}
	}

	if opts.isObjectStyle {
		data["objectStyle"] = true
	}

	builder.WriteString(dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), data))

	result.SetCLIs(strings.Split(builder.String(), "\n"))
	result.CLIString = builder.String()
	return result
}

func (ct *CommonTemplates) MakeNatCli(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, data map[string]interface{}, opts ...PolicyOption) *PolicyResult {
	// 解析选项
	options := &PolicyOptions{
		natProcessMode: PolicyBasedNat,        // 默认基于策略的NAT
		natDirection:   OutboundNat,           // 默认出站NAT
		natStyle:       PolicyIntegratedStyle, // 默认策略集成风格
		natType:        firewall.DYNAMIC_NAT,  // 默认动态NAT
	}
	for _, opt := range opts {
		opt(options)
	}

	var result *PolicyResult

	// 根据处理方式分发到不同的处理函数
	switch options.natProcessMode {
	case PolicyBasedNat:
		result = ct.makePolicyBasedNat(from, to, intent, ctx, options, data)
	// case AclBasedNat:
	// 	result = ct.makeAclBasedNat(from, to, intent, ctx, options)
	case StaticNat:
		result = ct.makeStaticNat(from, to, intent, ctx, options, data)
	case InterfaceNat:
		result = ct.makeInterfaceNat(from, to, intent, ctx, options)
	case DynamicNat: // 新增的处理方式
		result = ct.makeDynamicNatCli(from, to, intent, ctx, options, data)
	default:
		result = NewPolicyResult()
		result.SetError(fmt.Errorf("unsupported NAT process mode: %v", options.natProcessMode))
	}
	result.MergeFlyObjectAndCLIs()
	return result
}

func (ct *CommonTemplates) makePolicyBasedNat(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions, datas ...map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()

	// 使用现有的 MakePolicyBaseNatRuleCli 方法
	natResult := ct.MakePolicyBaseNatRuleCli(from, to, intent, ctx, opts, datas...)
	if !natResult.IsValid() {
		return natResult
	}

	result.MergeFlyObjects(natResult.FlyObject)
	result.SetCLIs(natResult.CLIs)
	result.CLIString = natResult.CLIString
	return result
}

// func (ct *CommonTemplates) makeAclBasedNat(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions) *PolicyResult {
// 	result := NewPolicyResult()

// 	// 使用现有的 MakeAclBaseSnatCli 方法
// 	cli, err := ct.MakeAclBaseSnatCli(from, to, intent, ctx)
// 	if err != nil {
// 		result.SetError(err)
// 		return result
// 	}

// 	result.SetCLIs(strings.Split(cli, "\n"))
// 	result.CLIString = cli
// 	return result
// }

func (ct *CommonTemplates) makeStaticNat(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions, data map[string]interface{}) *PolicyResult {
	return ct.MakeStaticInOrOutboundCli(from, to, intent, opts.natDirection, ctx, data)
}

func (ct *CommonTemplates) makeInterfaceNat(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions) *PolicyResult {
	result := NewPolicyResult()

	// 实现接口级NAT的逻辑
	// 这里可能需要根据具体设备和需求来实现

	return result
}

func (ct *CommonTemplates) makeDynamicNatCli(from, to api.Port, intent *policy.Intent, ctx *firewall.PolicyContext, opts *PolicyOptions, data map[string]interface{}) *PolicyResult {
	result := NewPolicyResult()
	builder := strings.Builder{}

	// 生成或复用 NAT 地址池
	// 注意：如果 intent.Snat 为空，CreateOrReuseNatAddressGroup 会返回错误
	// 但对于某些场景（如不需要 SNAT），应该允许继续生成 NAT 规则
	poolId, poolCli, err := ct.CreateOrReuseNatAddressGroup(intent, ctx, data)
	if err != nil {
		// 如果 intent.Snat 为空，可能是正常的（不需要 SNAT），不应该直接返回错误
		// 只有在明确需要 SNAT 但创建失败时才返回错误
		if intent.Snat == "" {
			// SNAT 为空，可能是正常的，继续生成 NAT 规则（不设置 pool）
			poolId = ""
			poolCli = ""
		} else {
			// SNAT 不为空但创建失败，返回错误
			result.SetError(fmt.Errorf("failed to create or reuse NAT address group: %v", err))
			return result
		}
	}
	if poolCli != "" {
		result.SetFlyObject(FlyObjectPool, poolCli)
	}

	fromZone, toZone := "", ""

	// 注意：Sangfor 等防火墙的接口和 zone 没有关联，Port 可能不实现 ZoneFirewall 接口
	if from != nil {
		if zf, ok := from.(firewall.ZoneFirewall); ok {
			fromZone = zf.Zone()
		}
	}
	if to != nil {
		if zf, ok := to.(firewall.ZoneFirewall); ok {
			toZone = zf.Zone()
		}
	}

	// 准备数据
	natData := map[string]interface{}{
		"sourceZones":      []interface{}{fromZone},
		"destinationZones": []interface{}{toZone},
		"direction":        opts.natDirection.String(),
		"natType":          "dynamic",
		"description":      fmt.Sprintf("NETACC_%s_%s", intent.TicketNumber, intent.SubTicket),
	}

	// 只有当 poolId 不为空时才设置 pool 相关字段
	if poolId != "" {
		natData["pool_id"] = poolId
		natData["pool_name"] = poolId // 假设池名和ID相同
		// 设置 transfer_type 为 IPGROUP，使用 pool_id 作为 transfer_ipgroup
		natData["transfer_type"] = "IPGROUP"
		natData["transfer_ipgroup"] = poolId
	}

	if desc, ok := ctx.GetStringValue("description"); ok {
		natData["description"] = desc
	}
	if intent.Snat != "" {
		natData["snat"] = intent.Snat
	}
	if intent.RealIp != "" {
		natData["real_ip"] = intent.RealIp
	}
	if intent.RealPort != "" {
		natData["real_port"] = intent.RealPort
	}
	if s, ok := ctx.GetStringValue("nat_rule_name"); ok {
		natData["nat_rule_name"] = s
		natData["nat_name"] = s
	} else {
		// 如果没有指定 nat_rule_name，生成一个默认名称
		natData["nat_name"] = fmt.Sprintf("NETACC_%s_%s", intent.TicketNumber, intent.SubTicket)
	}

	natData["direction"] = opts.natDirection.String()

	if from != nil {
		natData["fromPort"] = from.Name()
		natData["fromZone"] = fromZone
	}
	if to != nil {
		natData["toPort"] = to.Name()
		natData["toZone"] = toZone
	}

	// 合并 data 中的参数（可能包含 make_source, make_destination, make_service 等）
	for k, v := range data {
		natData[k] = v
	}

	// 如果需要生成对象（根据 data 中的 make_source, make_destination, make_service 标志）
	// 生成源地址对象
	if natData["make_source"] == "true" && opts.generateSourceObjects {
		srcResult := ct.MakeNetworkObjectCli(fromZone, toZone, intent.Src(), "", "", true, ctx, natData)
		if srcResult.IsValid() && len(srcResult.Keys) > 0 {
			natData["src_objects"] = srcResult.Keys
			result.MergeFlyObjects(srcResult.FlyObject)
		}
	}

	// 生成目标地址对象
	if natData["make_destination"] == "true" && opts.generateDestinationObjects {
		dstResult := ct.MakeNetworkObjectCli(fromZone, toZone, intent.Dst(), "", "", false, ctx, natData)
		if dstResult.IsValid() && len(dstResult.Keys) > 0 {
			natData["dst_objects"] = dstResult.Keys
			result.MergeFlyObjects(dstResult.FlyObject)
		}
	}

	// 生成服务对象
	if natData["make_service"] == "true" && opts.generateServiceObjects {
		srvResult := ct.MakeServiceObjectCli(intent.Service(), "", "", natData)
		if srvResult.IsValid() && len(srvResult.Keys) > 0 {
			natData["service_objects"] = srvResult.Keys
			result.MergeFlyObjects(srvResult.FlyObject)
		}
	}

	// 生成 NAT 规则
	layout := ct.ts.GetTemplatesByKey(keys.NewKeyBuilder("Nat", "Dynamic", "OneLoop"))

	// 如果需要生成 ACL
	if opts.enableAclGeneration {
		aclId, aclName, aclClis, err := ct.MakeAdvancedAclCli(intent, ctx)
		if err != nil {
			result.SetError(fmt.Errorf("failed to generate ACL: %v", err))
			return result
		}
		result.SetFlyObject(FlyObjectAcl, strings.Join(aclClis, "\n"))
		natData["acl_name"] = aclName
		natData["acl_id"] = aclId
	}
	natCli := dsl.IntentFormat(intent, layout, dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true), natData)
	builder.WriteString(natCli)
	builder.WriteString(ct.SectionSeparator)
	result.SetCLIs(strings.Split(builder.String(), "\n"))
	result.CLIString = builder.String()
	result.SetFlyObject(FlyObjectNat, result.CLIString)

	return result
}

// Merge 将 src map 合并到 dst map 中。
// 如果 key 已存在，则使用 "\n" 连接值。
func Merge(dst, src map[string]string) {
	for key, value := range src {
		if existingValue, exists := dst[key]; exists {
			// 如果 key 已存在，使用 "\n" 连接值
			dst[key] = strings.Join([]string{existingValue, value}, "\n")
		} else {
			// 如果 key 不存在，直接添加
			dst[key] = value
		}
	}
}

package common

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"regexp"
	"strings"
	"time"
)

// ConfigSnippets 配置片段（按类型组织）
type ConfigSnippets struct {
	NetworkObjectSnippet string // 所有Network Object的完整配置块
	ServiceObjectSnippet string // 所有Service Object的完整配置块（如果有）
	PolicySnippet        string // 所有Policy的完整配置块
	NatSnippet           string // 所有NAT规则的完整配置块（如果有）
	AclSnippet           string // 所有ACL的完整配置块（如果有）
}

// ConfigInference 配置推断结果
type ConfigInference struct {
	PolicyNameTemplate        string
	PolicyNameExamples        []string
	NetworkObjectNameTemplate string
	NetworkObjectExamples     []string
	ServiceObjectNameTemplate string
	ServiceObjectExamples     []string
	ObjectStyle               ObjectStyleConfig
}

// ObjectStyleConfig 对象样式配置
type ObjectStyleConfig struct {
	ObjectStyle       bool `json:"object_style"`
	SourceObject      bool `json:"source_object"`
	DestinationObject bool `json:"destination_object"`
	ServiceObject     bool `json:"service_object"`
}

// ParseFirewallConfig 读取防火墙配置文件
func ParseFirewallConfig(filename string) (string, error) {
	data, err := os.ReadFile(filename)
	if err != nil {
		return "", fmt.Errorf("failed to read config file: %w", err)
	}
	return string(data), nil
}

// ExtractConfigSnippets 按类型提取所有相关配置片段（使用大模型）
func ExtractConfigSnippets(config string, firewallType string, configExample string, extractor *LLMExtractor) (*ConfigSnippets, error) {
	snippets := &ConfigSnippets{}

	// 提取 Network Object 配置片段
	var err error
	snippets.NetworkObjectSnippet, err = extractor.ExtractNetworkObjects(config, firewallType, configExample)
	if err != nil {
		// 如果提取失败，返回空字符串而不是错误（允许部分提取）
		snippets.NetworkObjectSnippet = ""
	}

	// 提取 Service Object 配置片段
	snippets.ServiceObjectSnippet, err = extractor.ExtractServiceObjects(config, firewallType, configExample)
	if err != nil {
		snippets.ServiceObjectSnippet = ""
	}

	// 提取 Policy 配置片段
	snippets.PolicySnippet, err = extractor.ExtractPolicies(config, firewallType, configExample)
	if err != nil {
		snippets.PolicySnippet = ""
	}

	// 提取 NAT 配置片段
	snippets.NatSnippet, err = extractor.ExtractNatRules(config, firewallType, configExample)
	if err != nil {
		snippets.NatSnippet = ""
	}

	// 提取 ACL 配置片段
	snippets.AclSnippet, err = extractor.ExtractAclRules(config, firewallType, configExample)
	if err != nil {
		snippets.AclSnippet = ""
	}

	return snippets, nil
}

// extractNetworkObjects 提取所有 ip address-set 配置
func extractNetworkObjects(config string) string {
	var builder strings.Builder
	lines := strings.Split(config, "\n")

	inAddressSet := false
	var currentBlock strings.Builder

	for _, line := range lines {
		trimmed := strings.TrimSpace(line)

		// 检测 address-set 开始
		if strings.HasPrefix(trimmed, "ip address-set ") {
			if inAddressSet {
				// 保存前一个块
				builder.WriteString(currentBlock.String())
				builder.WriteString("\n")
			}
			currentBlock.Reset()
			currentBlock.WriteString(line)
			currentBlock.WriteString("\n")
			inAddressSet = true
		} else if inAddressSet {
			// 继续收集 address-set 内容
			if strings.HasPrefix(trimmed, " address ") ||
				strings.HasPrefix(trimmed, " description ") ||
				trimmed == "#" {
				currentBlock.WriteString(line)
				currentBlock.WriteString("\n")
				if trimmed == "#" {
					// 块结束
					builder.WriteString(currentBlock.String())
					builder.WriteString("\n")
					currentBlock.Reset()
					inAddressSet = false
				}
			} else if trimmed != "" && !strings.HasPrefix(trimmed, " ") {
				// 新的配置块开始，结束当前 address-set
				if currentBlock.Len() > 0 {
					builder.WriteString(currentBlock.String())
					builder.WriteString("\n")
					currentBlock.Reset()
				}
				inAddressSet = false
			}
		}
	}

	// 处理最后一个块
	if currentBlock.Len() > 0 {
		builder.WriteString(currentBlock.String())
		builder.WriteString("\n")
	}

	return builder.String()
}

// extractServiceObjects 提取所有 object-group service 配置
func extractServiceObjects(config string) string {
	var builder strings.Builder
	lines := strings.Split(config, "\n")

	inServiceGroup := false
	var currentBlock strings.Builder

	for _, line := range lines {
		trimmed := strings.TrimSpace(line)

		// 检测 service group 开始
		if strings.HasPrefix(trimmed, "object-group service ") {
			if inServiceGroup {
				builder.WriteString(currentBlock.String())
				builder.WriteString("\n")
			}
			currentBlock.Reset()
			currentBlock.WriteString(line)
			currentBlock.WriteString("\n")
			inServiceGroup = true
		} else if inServiceGroup {
			if strings.HasPrefix(trimmed, " service ") ||
				strings.HasPrefix(trimmed, " description ") ||
				trimmed == "#" {
				currentBlock.WriteString(line)
				currentBlock.WriteString("\n")
				if trimmed == "#" {
					builder.WriteString(currentBlock.String())
					builder.WriteString("\n")
					currentBlock.Reset()
					inServiceGroup = false
				}
			} else if trimmed != "" && !strings.HasPrefix(trimmed, " ") {
				if currentBlock.Len() > 0 {
					builder.WriteString(currentBlock.String())
					builder.WriteString("\n")
					currentBlock.Reset()
				}
				inServiceGroup = false
			}
		}
	}

	if currentBlock.Len() > 0 {
		builder.WriteString(currentBlock.String())
		builder.WriteString("\n")
	}

	return builder.String()
}

// extractPolicies 提取所有 security-policy rule name 配置
func extractPolicies(config string) string {
	var builder strings.Builder
	lines := strings.Split(config, "\n")

	inSecurityPolicy := false
	var currentBlock strings.Builder

	for i, line := range lines {
		trimmed := strings.TrimSpace(line)

		// 检测 security-policy 开始
		if trimmed == "security-policy" {
			inSecurityPolicy = true
			currentBlock.Reset()
			continue
		}

		if !inSecurityPolicy {
			continue
		}

		// 检测 rule name 开始（可能以空格开头，也可能没有）
		if strings.HasPrefix(trimmed, "rule name ") || strings.HasPrefix(trimmed, " rule name ") {
			if currentBlock.Len() > 0 {
				// 保存前一个规则
				builder.WriteString(currentBlock.String())
				builder.WriteString("\n")
			}
			currentBlock.Reset()
			currentBlock.WriteString(line)
			currentBlock.WriteString("\n")
			continue
		}

		// 如果在security-policy块内
		if inSecurityPolicy {
			// 检查是否是新的配置块开始（不是策略内容）
			if trimmed == "#" {
				// 块结束标记
				if currentBlock.Len() > 0 {
					builder.WriteString(currentBlock.String())
					builder.WriteString("\n")
					currentBlock.Reset()
				}
				inSecurityPolicy = false
			} else if trimmed != "" && !strings.HasPrefix(line, " ") && !strings.HasPrefix(line, "\t") && !strings.HasPrefix(trimmed, "rule name ") {
				// 新的配置块开始（不是以空格或制表符开头的策略内容）
				// 检查下一行是否是rule name
				nextIsRuleName := false
				if i+1 < len(lines) {
					nextTrimmed := strings.TrimSpace(lines[i+1])
					nextIsRuleName = strings.HasPrefix(nextTrimmed, "rule name ") || strings.HasPrefix(nextTrimmed, " rule name ")
				}
				if !nextIsRuleName {
					// 不是策略内容，结束security-policy块
					if currentBlock.Len() > 0 {
						builder.WriteString(currentBlock.String())
						builder.WriteString("\n")
						currentBlock.Reset()
					}
					inSecurityPolicy = false
				} else {
					// 下一行是rule name，继续收集当前规则
					currentBlock.WriteString(line)
					currentBlock.WriteString("\n")
				}
			} else {
				// 继续收集策略内容（以空格或制表符开头的行或空行）
				currentBlock.WriteString(line)
				currentBlock.WriteString("\n")
			}
		}
	}

	// 处理最后一个规则
	if currentBlock.Len() > 0 {
		builder.WriteString(currentBlock.String())
		builder.WriteString("\n")
	}

	return builder.String()
}

// extractNatRules 提取所有 NAT 规则
func extractNatRules(config string) string {
	var builder strings.Builder
	lines := strings.Split(config, "\n")

	inNatPolicy := false
	inRule := false
	var currentBlock strings.Builder

	for _, line := range lines {
		trimmed := strings.TrimSpace(line)

		if strings.HasPrefix(trimmed, "nat global-policy") {
			inNatPolicy = true
			continue
		}

		if !inNatPolicy {
			continue
		}

		if strings.HasPrefix(trimmed, " rule name ") {
			if inRule {
				builder.WriteString(currentBlock.String())
				builder.WriteString("\n")
			}
			currentBlock.Reset()
			currentBlock.WriteString(line)
			currentBlock.WriteString("\n")
			inRule = true
		} else if inRule {
			if strings.HasPrefix(trimmed, " ") || trimmed == "" {
				currentBlock.WriteString(line)
				currentBlock.WriteString("\n")
			} else if trimmed != "#" {
				if currentBlock.Len() > 0 {
					builder.WriteString(currentBlock.String())
					builder.WriteString("\n")
					currentBlock.Reset()
				}
				inRule = false
				if !strings.HasPrefix(trimmed, "nat ") {
					inNatPolicy = false
				}
			}
		}
	}

	if currentBlock.Len() > 0 {
		builder.WriteString(currentBlock.String())
		builder.WriteString("\n")
	}

	return builder.String()
}

// extractAclRules 提取所有 ACL 配置
func extractAclRules(config string) string {
	var builder strings.Builder
	lines := strings.Split(config, "\n")

	inAcl := false
	var currentBlock strings.Builder

	for _, line := range lines {
		trimmed := strings.TrimSpace(line)

		if strings.HasPrefix(trimmed, "acl ") || strings.HasPrefix(trimmed, "acl number ") {
			if inAcl {
				builder.WriteString(currentBlock.String())
				builder.WriteString("\n")
			}
			currentBlock.Reset()
			currentBlock.WriteString(line)
			currentBlock.WriteString("\n")
			inAcl = true
		} else if inAcl {
			if strings.HasPrefix(trimmed, " ") || trimmed == "" || trimmed == "#" {
				currentBlock.WriteString(line)
				currentBlock.WriteString("\n")
				if trimmed == "#" {
					builder.WriteString(currentBlock.String())
					builder.WriteString("\n")
					currentBlock.Reset()
					inAcl = false
				}
			} else {
				if currentBlock.Len() > 0 {
					builder.WriteString(currentBlock.String())
					builder.WriteString("\n")
					currentBlock.Reset()
				}
				inAcl = false
			}
		}
	}

	if currentBlock.Len() > 0 {
		builder.WriteString(currentBlock.String())
		builder.WriteString("\n")
	}

	return builder.String()
}

// LLMInferenceClient 大模型客户端接口
type LLMInferenceClient interface {
	InferNetworkObjectTemplate(snippet string, firewallType string, configExample string) (string, error)
	InferServiceObjectTemplate(snippet string, firewallType string, configExample string) (string, error)
	InferPolicyTemplate(snippet string, firewallType string, configExample string) (string, error)
	AnalyzeObjectStyle(policySnippet string) (ObjectStyleConfig, error)
}

// OllamaClient Ollama客户端实现
type OllamaClient struct {
	BaseURL    string
	Model      string
	HTTPClient *http.Client
}

// NewOllamaClient 创建新的Ollama客户端
func NewOllamaClient(baseURL, model string) *OllamaClient {
	if baseURL == "" {
		baseURL = "http://localhost:11434"
	}
	if model == "" {
		model = "qwen3-coder:30b"
	}
	return &OllamaClient{
		BaseURL: baseURL,
		Model:   model,
		HTTPClient: &http.Client{
			Timeout: 60 * time.Second, // 设置60秒超时
		},
	}
}

// callOllama 调用Ollama API
func (c *OllamaClient) callOllama(prompt string) (string, error) {
	url := fmt.Sprintf("%s/api/generate", c.BaseURL)
	startTime := time.Now()

	// 打印调用记录
	log.Printf("[Ollama] 开始调用 API")
	log.Printf("[Ollama] URL: %s", url)
	log.Printf("[Ollama] Model: %s", c.Model)
	log.Printf("[Ollama] Prompt 长度: %d 字符", len(prompt))
	if len(prompt) > 200 {
		log.Printf("[Ollama] Prompt 预览: %s...", prompt[:200])
	} else {
		log.Printf("[Ollama] Prompt: %s", prompt)
	}

	payload := map[string]interface{}{
		"model":  c.Model,
		"prompt": prompt,
		"stream": false,
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		log.Printf("[Ollama] 错误: 序列化请求失败: %v", err)
		return "", fmt.Errorf("failed to marshal request: %w", err)
	}
	log.Printf("[Ollama] 请求体大小: %d 字节", len(jsonData))

	// 创建带超时的上下文
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		log.Printf("[Ollama] 错误: 创建请求失败: %v", err)
		return "", fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	log.Printf("[Ollama] 发送 HTTP 请求...")
	resp, err := c.HTTPClient.Do(req)
	duration := time.Since(startTime)
	if err != nil {
		log.Printf("[Ollama] 错误: HTTP 请求失败 (耗时: %v): %v", duration, err)
		return "", fmt.Errorf("failed to call Ollama API: %w", err)
	}
	defer resp.Body.Close()

	log.Printf("[Ollama] HTTP 响应状态: %d (耗时: %v)", resp.StatusCode, duration)

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		log.Printf("[Ollama] 错误响应体: %s", string(body))
		return "", fmt.Errorf("ollama API returned status %d: %s", resp.StatusCode, string(body))
	}

	var result map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		log.Printf("[Ollama] 错误: 解析响应失败: %v", err)
		return "", fmt.Errorf("failed to decode response: %w", err)
	}

	response, ok := result["response"].(string)
	if !ok {
		log.Printf("[Ollama] 错误: 响应格式无效")
		return "", fmt.Errorf("invalid response format")
	}

	log.Printf("[Ollama] 响应长度: %d 字符", len(response))
	if len(response) > 200 {
		log.Printf("[Ollama] 响应预览: %s...", response[:200])
	} else {
		log.Printf("[Ollama] 响应: %s", response)
	}
	log.Printf("[Ollama] 调用完成 (总耗时: %v)", time.Since(startTime))

	return response, nil
}

// InferNetworkObjectTemplate 推断网络对象命名模板
func (c *OllamaClient) InferNetworkObjectTemplate(snippet string, firewallType string, configExample string) (string, error) {
	prompt := BuildPromptForNetworkObject(snippet, firewallType, configExample, getTemplateHint())
	response, err := c.callOllama(prompt)
	if err != nil {
		return "", err
	}
	return extractTemplateFromResponse(response), nil
}

// InferServiceObjectTemplate 推断服务对象命名模板
func (c *OllamaClient) InferServiceObjectTemplate(snippet string, firewallType string, configExample string) (string, error) {
	prompt := BuildPromptForServiceObject(snippet, firewallType, configExample, getTemplateHint())
	response, err := c.callOllama(prompt)
	if err != nil {
		return "", err
	}
	return extractTemplateFromResponse(response), nil
}

// InferPolicyTemplate 推断策略命名模板
func (c *OllamaClient) InferPolicyTemplate(snippet string, firewallType string, configExample string) (string, error) {
	prompt := BuildPromptForPolicy(snippet, firewallType, configExample, getTemplateHint())
	response, err := c.callOllama(prompt)
	if err != nil {
		return "", err
	}
	return extractTemplateFromResponse(response), nil
}

// AnalyzeObjectStyle 分析对象样式
func (c *OllamaClient) AnalyzeObjectStyle(policySnippet string) (ObjectStyleConfig, error) {
	prompt := BuildPromptForObjectStyle(policySnippet)
	response, err := c.callOllama(prompt)
	if err != nil {
		return ObjectStyleConfig{}, err
	}

	// 尝试从响应中提取JSON
	jsonStr := extractJSONFromResponse(response)

	var config ObjectStyleConfig
	if err := json.Unmarshal([]byte(jsonStr), &config); err != nil {
		return ObjectStyleConfig{}, fmt.Errorf("failed to parse object style config: %w", err)
	}

	return config, nil
}

// extractJSONFromResponse 从响应中提取JSON
func extractJSONFromResponse(response string) string {
	// 尝试找到JSON块
	jsonPattern := regexp.MustCompile(`\{[^{}]*"object_style"[^{}]*\}`)
	matches := jsonPattern.FindString(response)
	if matches != "" {
		return matches
	}

	// 如果没有找到，尝试提取整个响应
	return response
}

// extractTemplateFromResponse 从响应中提取模板内容，去除键名和引号
func extractTemplateFromResponse(response string) string {
	response = strings.TrimSpace(response)

	// 移除可能的代码块标记
	response = strings.TrimPrefix(response, "```yaml")
	response = strings.TrimPrefix(response, "```")
	response = strings.TrimSuffix(response, "```")
	response = strings.TrimSpace(response)

	// 如果响应包含 YAML 键名格式，提取值部分
	// 匹配类似: policy_name_template: "..." 或 policy_name_template: ...
	// 或 network_object_name_template: |\n  ... (多行)
	keyPattern := regexp.MustCompile(`(?i)(?:policy_name_template|network_object_name_template|service_object_name_template)\s*:\s*`)

	if keyPattern.MatchString(response) {
		// 找到键名位置
		loc := keyPattern.FindStringIndex(response)
		if loc != nil {
			valuePart := response[loc[1]:]
			valuePart = strings.TrimSpace(valuePart)

			// 处理引号包裹的值
			if strings.HasPrefix(valuePart, `"`) && strings.HasSuffix(valuePart, `"`) {
				valuePart = strings.Trim(valuePart, `"`)
			} else if strings.HasPrefix(valuePart, `'`) && strings.HasSuffix(valuePart, `'`) {
				valuePart = strings.Trim(valuePart, `'`)
			} else if strings.HasPrefix(valuePart, "|") {
				// 处理 YAML 字面块样式 |\n  content
				lines := strings.Split(valuePart, "\n")
				if len(lines) > 1 {
					// 移除第一行的 |，然后处理后续行的缩进
					var result strings.Builder
					for i, line := range lines[1:] {
						if i > 0 {
							result.WriteString("\n")
						}
						// 移除前导空格（通常是2个空格）
						trimmed := strings.TrimLeft(line, " ")
						result.WriteString(trimmed)
					}
					return strings.TrimSpace(result.String())
				}
			}

			return strings.TrimSpace(valuePart)
		}
	}

	// 如果没有匹配到键名格式，直接返回清理后的响应
	return strings.TrimSpace(response)
}

// BuildPromptForNetworkObject 构建Network Object推理提示词
func BuildPromptForNetworkObject(snippet string, firewallType string, configExample string, templateHint string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请分析以下Network Object配置片段，推断出命名模板。

防火墙类型：%s

配置示例（帮助理解格式）：
%s

配置片段：
%s

模板系统说明：
%s

示例配置（config.yaml格式）：
network_object_name_template: |
  {VAR:object_name}

或更复杂的示例：
network_object_name_template: |
  {VAR:policy_name}_{VAR:is_source}_addr{VAR:suffix}

请分析配置片段中的对象命名模式，推断出IDTemplate格式的命名模板（使用{VAR:name}、{DATE:name:format}、{SEQ:name:width:start:step:MAIN}）。
只输出模板内容，不要输出其他内容。`, firewallType, configExample, snippet, templateHint)
}

// BuildPromptForServiceObject 构建Service Object推理提示词
func BuildPromptForServiceObject(snippet string, firewallType string, configExample string, templateHint string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请分析以下Service Object配置片段，推断出命名模板。

防火墙类型：%s

配置示例（帮助理解格式）：
%s

配置片段：
%s

模板系统说明：
%s

示例配置（config.yaml格式）：
service_object_name_template: |
  {VAR:policy_name}_{VAR:protocol}_{VAR:port}

或更简单的示例：
service_object_name_template: |
  {VAR:object_name}

请分析配置片段中的服务对象命名模式，推断出IDTemplate格式的命名模板（使用{VAR:name}、{DATE:name:format}、{SEQ:name:width:start:step:MAIN}）。
只输出模板内容，不要输出其他内容。`, firewallType, configExample, snippet, templateHint)
}

// BuildPromptForPolicy 构建Policy推理提示词
func BuildPromptForPolicy(snippet string, firewallType string, configExample string, templateHint string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请分析以下Policy配置片段，推断出策略命名模板。

防火墙类型：%s

配置示例（帮助理解格式）：
%s

配置片段：
%s

模板系统说明：
%s

示例配置（config.yaml格式）：
policy_name_template: |
  {VAR:site}_policy_{SEQ:id:4:1:1:MAIN}

或更简单的示例：
policy_name_template: |
  JiS_policy_{SEQ:id:4:1:1:MAIN}

请分析配置片段中的策略命名模式，推断出IDTemplate格式的命名模板。注意：
- 如果策略名称包含序号（如 JiS_policy_2524），应该使用 {SEQ:id:4:1:1:MAIN} 格式
- 如果策略名称包含站点前缀（如 JiS），应该使用 {VAR:site} 变量
- 普通文本（如 "policy", "_"）直接写在模板中
- 只输出模板内容，不要输出其他内容。`, firewallType, configExample, snippet, templateHint)
}

// BuildPromptForObjectStyle 构建对象样式分析提示词
func BuildPromptForObjectStyle(policySnippet string) string {
	return fmt.Sprintf(`你是一个防火墙配置分析专家。请分析以下Policy配置片段，判断是否使用对象样式。

配置片段：
%s

分析要求：
1. 检查策略中是否使用 "address-set" 或 "address-object"（对象样式）
2. 检查策略中是否直接使用IP地址（非对象样式）
3. 统计使用对象样式的策略数量和直接IP的策略数量
4. 判断 source、destination、service 是否使用对象

请以JSON格式输出结果：
{
  "object_style": true/false,
  "source_object": true/false,
  "destination_object": true/false,
  "service_object": true/false
}

只输出JSON，不要输出其他内容。`, policySnippet)
}

// getTemplateHint 获取模板系统说明
func getTemplateHint() string {
	return `模板系统使用IDTemplate格式（基于naming_template.go实现），支持以下语法：

1. 变量字段：{VAR:name}
   - 用于变量替换，如 {VAR:site} 会被替换为实际值
   - 示例：JiS_{VAR:site}_policy_2524

2. 日期字段：{DATE:name:format}
   - name: 日期字段名称
   - format: 日期格式，支持 YYYYMMDD, YYYY-MM-DD 等
   - 示例：{DATE:date:YYYYMMDD} 会生成 20241223

3. 序列号字段：{SEQ:name:width:start:step:MAIN:NORENDER}
   - name: 序列号字段名称
   - width: 数字宽度（如4表示0001）
   - start: 起始值（如1）
   - step: 步长（如1）
   - MAIN: 可选标记，表示这是主ID
   - NORENDER: 可选标记，表示不参与渲染（用于匹配但不显示）
   - 示例：{SEQ:id:4:1:1:MAIN} 会生成 0001, 0002, 0003...

Policy命名模板示例：
- JiS_policy_{SEQ:id:4:1:1:MAIN}
- {VAR:site}_policy_{SEQ:id:4:1:1:MAIN}
- {VAR:site}_policy_{DATE:date:YYYYMMDD}_{SEQ:id:4:1:1:MAIN}

NetworkObject命名模板示例：
- {VAR:policy_name}_{VAR:is_source}_addr{SEQ:suffix:2:1:1}
- {VAR:object_name}

ServiceObject命名模板示例：
- {VAR:policy_name}_{VAR:protocol}{VAR:port}
- {VAR:object_name}

注意：
- 所有普通文本直接写，不需要特殊标记
- 变量名使用下划线分隔（如 policy_name, is_source）
- 序列号会自动补零到指定宽度
- 多个字段可以组合使用`
}

// GenerateConfigYAML 生成config.yaml格式输出
func GenerateConfigYAML(inference *ConfigInference) string {
	var builder strings.Builder

	builder.WriteString("# 反向生成的配置\n")
	builder.WriteString("# 基于防火墙配置文件分析得出\n\n")

	// Policy命名模板
	if inference.PolicyNameTemplate != "" {
		builder.WriteString("policy_name_template: |\n")
		lines := strings.Split(inference.PolicyNameTemplate, "\n")
		for _, line := range lines {
			builder.WriteString("  ")
			builder.WriteString(line)
			builder.WriteString("\n")
		}
		if len(inference.PolicyNameExamples) > 0 {
			builder.WriteString("# 匹配示例: ")
			builder.WriteString(strings.Join(inference.PolicyNameExamples[:min(3, len(inference.PolicyNameExamples))], ", "))
			builder.WriteString("\n")
		}
		builder.WriteString("\n")
	}

	// Network Object命名模板
	if inference.NetworkObjectNameTemplate != "" {
		builder.WriteString("network_object_name_template: |\n")
		lines := strings.Split(inference.NetworkObjectNameTemplate, "\n")
		for _, line := range lines {
			builder.WriteString("  ")
			builder.WriteString(line)
			builder.WriteString("\n")
		}
		if len(inference.NetworkObjectExamples) > 0 {
			builder.WriteString("# 匹配示例: ")
			builder.WriteString(strings.Join(inference.NetworkObjectExamples[:min(3, len(inference.NetworkObjectExamples))], ", "))
			builder.WriteString("\n")
		}
		builder.WriteString("\n")
	}

	// Service Object命名模板
	if inference.ServiceObjectNameTemplate != "" {
		builder.WriteString("service_object_name_template: |\n")
		lines := strings.Split(inference.ServiceObjectNameTemplate, "\n")
		for _, line := range lines {
			builder.WriteString("  ")
			builder.WriteString(line)
			builder.WriteString("\n")
		}
		if len(inference.ServiceObjectExamples) > 0 {
			builder.WriteString("# 匹配示例: ")
			builder.WriteString(strings.Join(inference.ServiceObjectExamples[:min(3, len(inference.ServiceObjectExamples))], ", "))
			builder.WriteString("\n")
		}
		builder.WriteString("\n")
	}

	// 对象样式配置
	builder.WriteString("# 对象样式配置\n")
	builder.WriteString(fmt.Sprintf("securitypolicy.object_style: \"%v\"\n", inference.ObjectStyle.ObjectStyle))
	builder.WriteString(fmt.Sprintf("securitypolicy.source_object: \"%v\"\n", inference.ObjectStyle.SourceObject))
	builder.WriteString(fmt.Sprintf("securitypolicy.destination_object: \"%v\"\n", inference.ObjectStyle.DestinationObject))
	builder.WriteString(fmt.Sprintf("securitypolicy.service_object: \"%v\"\n", inference.ObjectStyle.ServiceObject))

	return builder.String()
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// ReverseEngineerConfig 反向工程配置的主函数
func ReverseEngineerConfig(configFile string, firewallType string, configExample string, ollamaURL, model string) (*ConfigInference, error) {
	// 1. 解析配置文件
	config, err := ParseFirewallConfig(configFile)
	if err != nil {
		return nil, fmt.Errorf("failed to parse config: %w", err)
	}

	// 2. 创建Ollama客户端
	client := NewOllamaClient(ollamaURL, model)

	// 3. 创建LLM提取器
	extractor := NewLLMExtractor(client)

	// 4. 提取配置片段（使用大模型）
	snippets, err := ExtractConfigSnippets(config, firewallType, configExample, extractor)
	if err != nil {
		return nil, fmt.Errorf("failed to extract config snippets: %w", err)
	}

	// 5. 推断配置
	inference := &ConfigInference{}

	// 推断策略命名模板
	if snippets.PolicySnippet != "" {
		policyTemplate, err := client.InferPolicyTemplate(snippets.PolicySnippet, firewallType, configExample)
		if err != nil {
			return nil, fmt.Errorf("failed to infer policy template: %w", err)
		}
		inference.PolicyNameTemplate = strings.TrimSpace(policyTemplate)
		// 提取示例
		inference.PolicyNameExamples = extractPolicyExamples(snippets.PolicySnippet)
	}

	// 推断网络对象命名模板
	if snippets.NetworkObjectSnippet != "" {
		networkTemplate, err := client.InferNetworkObjectTemplate(snippets.NetworkObjectSnippet, firewallType, configExample)
		if err != nil {
			return nil, fmt.Errorf("failed to infer network object template: %w", err)
		}
		inference.NetworkObjectNameTemplate = strings.TrimSpace(networkTemplate)
		// 提取示例
		inference.NetworkObjectExamples = extractNetworkObjectExamples(snippets.NetworkObjectSnippet)
	}

	// 推断服务对象命名模板
	if snippets.ServiceObjectSnippet != "" {
		serviceTemplate, err := client.InferServiceObjectTemplate(snippets.ServiceObjectSnippet, firewallType, configExample)
		if err != nil {
			return nil, fmt.Errorf("failed to infer service object template: %w", err)
		}
		inference.ServiceObjectNameTemplate = strings.TrimSpace(serviceTemplate)
		// 提取示例
		inference.ServiceObjectExamples = extractServiceObjectExamples(snippets.ServiceObjectSnippet)
	}

	// 分析对象样式
	if snippets.PolicySnippet != "" {
		objectStyle, err := client.AnalyzeObjectStyle(snippets.PolicySnippet)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze object style: %w", err)
		}
		inference.ObjectStyle = objectStyle
	}

	return inference, nil
}

// extractPolicyExamples 从策略片段中提取示例
func extractPolicyExamples(snippet string) []string {
	var examples []string
	re := regexp.MustCompile(`rule name\s+(\S+)`)
	matches := re.FindAllStringSubmatch(snippet, 20)
	for _, match := range matches {
		if len(match) > 1 {
			examples = append(examples, match[1])
		}
	}
	return examples
}

// extractNetworkObjectExamples 从网络对象片段中提取示例
func extractNetworkObjectExamples(snippet string) []string {
	var examples []string
	re := regexp.MustCompile(`ip address-set\s+(\S+)`)
	matches := re.FindAllStringSubmatch(snippet, 20)
	for _, match := range matches {
		if len(match) > 1 {
			examples = append(examples, match[1])
		}
	}
	return examples
}

// extractServiceObjectExamples 从服务对象片段中提取示例
func extractServiceObjectExamples(snippet string) []string {
	var examples []string
	re := regexp.MustCompile(`object-group service\s+(\S+)`)
	matches := re.FindAllStringSubmatch(snippet, 20)
	for _, match := range matches {
		if len(match) > 1 {
			examples = append(examples, match[1])
		}
	}
	return examples
}

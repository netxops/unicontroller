package common

import (
	"testing"
	"time"

	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	"github.com/stretchr/testify/assert"
)

// mockNamerIterator 实现 NamerIterator 接口
type mockNamerIterator struct {
	policies []string
	index    int
	// mu       sync.Mutex
}

// NewMockNamerIterator 创建一个新的 mockNamerIterator
func NewMockNamerIterator(policies []string) *mockNamerIterator {
	return &mockNamerIterator{
		policies: policies,
	}
}

// HasNext 检查是否还有下一个元素
func (m *mockNamerIterator) HasNext() bool {
	// m.mu.Lock()
	// defer m.mu.Unlock()
	return m.index < len(m.policies)
}

// Next 返回下一个元素
func (m *mockNamerIterator) Next() firewall.Namer {
	// m.mu.Lock()
	// defer m.mu.Unlock()
	if m.HasNext() {
		policy := m.policies[m.index]
		m.index++
		return mockNamer{name: policy}
	}
	return nil
}

// Reset 重置迭代器
func (m *mockNamerIterator) Reset() {
	// m.mu.Lock()
	m.index = 0
	// m.mu.Unlock()
}

// mockNamer 实现 Namer 接口
type mockNamer struct {
	name string
}

func (m mockNamer) Name() string {
	return m.name
}

func TestNewPolicyTemplate(t *testing.T) {
	template := "{VAR:zone}_{VAR:type}_policy{SEQ:id:3:100:1}_{DATE:date:YYYYMMDD}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{}
	}
	pt := NewPolicyTemplate(template, getIterator)

	if pt.template != template {
		t.Errorf("Expected template %s, got %s", template, pt.template)
	}

	if len(pt.fields) != 4 {
		t.Errorf("Expected 4 fields, got %d", len(pt.fields))
	}

	if len(pt.sequence) != 0 {
		t.Errorf("Expected 0 sequences, got %d", len(pt.sequence))
	}
}

func TestPolicyTemplateGenerate(t *testing.T) {
	template := "{VAR:zone}_{VAR:type}_policy{SEQ:id:3:100:1}_{DATE:date:YYYYMMDD}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{}
	}
	pt := NewPolicyTemplate(template, getIterator).Initialize()

	vars := map[string]interface{}{
		"zone": "DMZ",
		"type": "SEC",
	}

	_, result := pt.Generate(vars)
	expected := "DMZ_SEC_policy100_" + time.Now().Format("20060102")

	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}

	// Test sequence increment
	_, result = pt.Generate(vars)
	expected = "DMZ_SEC_policy101_" + time.Now().Format("20060102")

	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
}

func TestPolicyTemplateExtract(t *testing.T) {
	template := "{VAR:zone}_{VAR:type}_policy{SEQ:id:3:100:1}_{DATE:date:YYYYMMDD}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{
			policies: []string{"DMZ_SEC_policy102_20230520"},
		}
	}
	pt := NewPolicyTemplate(template, getIterator).Initialize()

	policy := "DMZ_SEC_policy102_20230520"
	info, err := pt.Extract(policy)

	if err != nil {
		t.Errorf("Unexpected error: %v", err)
	}

	expectedInfo := map[string]string{
		"zone": "DMZ",
		"type": "SEC",
		"id":   "102",
		"date": "20230520",
	}

	for key, value := range expectedInfo {
		if info[key] != value {
			t.Errorf("Expected %s for key %s, got %s", value, key, info[key])
		}
	}

	if pt.GetLastSequence("id") != 102 {
		t.Errorf("Expected last sequence 102, got %d", pt.GetLastSequence("id"))
	}
}

func TestPolicyTemplateSetLastSequence(t *testing.T) {
	template := "{VAR:zone}_{VAR:type}_policy{SEQ:id:3:100:1}_{DATE:date:YYYYMMDD}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{}
	}
	pt := NewPolicyTemplate(template, getIterator).Initialize()

	// 设置一个固定的时间
	fixedTime := time.Date(2023, 5, 1, 0, 0, 0, 0, time.UTC)
	pt.WithCurrentTime(fixedTime)
	pt.WithLastDate("date", fixedTime)

	// 设置最后的序列号
	pt.SetLastSequence("id", 150)

	if pt.GetLastSequence("id") != 150 {
		t.Errorf("Expected last sequence 150, got %d", pt.GetLastSequence("id"))
	}

	vars := map[string]interface{}{
		"zone": "DMZ",
		"type": "SEC",
	}

	// 生成第一个策略名称
	_, result := pt.Generate(vars)
	expected := "DMZ_SEC_policy151_20230501"
	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}

	// 模拟日期变化
	newTime := fixedTime.AddDate(0, 0, 1) // 增加一天
	pt.WithCurrentTime(newTime)

	// 生成新日期的第一个策略名称
	_, result = pt.Generate(vars)
	expected = "DMZ_SEC_policy100_20230502" // 序列号应该重置为起始值
	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}

	// 再次生成，确保序列号正确递增
	_, result = pt.Generate(vars)
	expected = "DMZ_SEC_policy101_20230502"
	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
}

func TestPolicyTemplateInvalidExtract(t *testing.T) {
	template := "{VAR:zone}_{VAR:type}_policy{SEQ:id:3:100:1}_{DATE:date:YYYYMMDD}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{}
	}
	pt := NewPolicyTemplate(template, getIterator).Initialize()

	policy := "INVALID_POLICY_FORMAT"
	_, err := pt.Extract(policy)

	if err == nil {
		t.Error("Expected error for invalid policy format, got nil")
	}
}

func TestPolicyTemplateMultipleSequences(t *testing.T) {
	template := "{VAR:prefix}_policy_{SEQ:daily:2:1:1}_{SEQ:global:4:1000:1}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{}
	}
	pt := NewPolicyTemplate(template, getIterator).Initialize()

	vars := map[string]interface{}{
		"prefix": "TEST",
	}

	_, result1 := pt.Generate(vars)
	expected1 := "TEST_policy_01_1000"

	if result1 != expected1 {
		t.Errorf("Expected %s, got %s", expected1, result1)
	}

	_, result2 := pt.Generate(vars)
	expected2 := "TEST_policy_02_1001"

	if result2 != expected2 {
		t.Errorf("Expected %s, got %s", expected2, result2)
	}
}

func TestPolicyTemplateDateFormat(t *testing.T) {
	template := "{VAR:prefix}_{DATE:date:YYYY-MM-DD}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{}
	}
	pt := NewPolicyTemplate(template, getIterator).Initialize()

	vars := map[string]interface{}{
		"prefix": "TEST",
	}

	_, result := pt.Generate(vars)
	expected := "TEST_" + time.Now().Format("2006-01-02")

	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
}

func TestPolicyTemplateInitialization(t *testing.T) {
	template := "{VAR:zone}_policy{SEQ:id:3:100:1}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{
			policies: []string{
				"DMZ_policy102",
				"DMZ_policy103",
				"DMZ_policy105",
			},
		}
	}
	pt := NewPolicyTemplate(template, getIterator).Initialize()

	if pt.GetLastSequence("id") != 105 {
		t.Errorf("Expected last sequence 105, got %d", pt.GetLastSequence("id"))
	}

	vars := map[string]interface{}{
		"zone": "DMZ",
	}

	_, result := pt.Generate(vars)
	expected := "DMZ_policy106"

	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
}

func TestVariousPolicyTemplates(t *testing.T) {
	testCases := []struct {
		name     string
		template string
		policies []string
		expected string
		testTime time.Time
	}{
		{
			name:     "JSJS-702 Template",
			template: "{DATE:date:YYYYMMDD}_{SEQ:id:2:1:1}",
			policies: []string{"20241021_11", "20241021_12", "20241022_01"},
			expected: "20241022_02",
			testTime: time.Date(2024, 10, 22, 0, 0, 0, 0, time.UTC),
		},
		{
			name:     "YiZ403DMZ Template",
			template: "YiZ403DMZ_SEC_MobileAPPGW_RZBB_policy{SEQ:id:3:169:1}",
			policies: []string{"YiZ403DMZ_SEC_MobileAPPGW_RZBB_policy169", "YiZ403DMZ_SEC_MobileAPPGW_RZBB_policy170"},
			expected: "YiZ403DMZ_SEC_MobileAPPGW_RZBB_policy171",
		},
		{
			name:     "YiZ_DMZ Template",
			template: "YiZ_DMZ_policy{SEQ:id:3:10:1}",
			policies: []string{"YiZ_DMZ_policy010", "YiZ_DMZ_policy011"},
			expected: "YiZ_DMZ_policy012",
		},
		{
			name:     "YiZ303 Template",
			template: "YiZ303_policy_{SEQ:id:4:1124:1}",
			policies: []string{"YiZ303_policy_1124", "YiZ303_policy_1125", "YiZ303_policy_1126"},
			expected: "YiZ303_policy_1127",
		},
		{
			name:     "iboc Template",
			template: "iboc_policy_{DATE:date:YYYYMMDD}_{SEQ:id:1:1:1}",
			policies: []string{"iboc_policy_20250422_7", "iboc_policy_20250424_1", "iboc_policy_20250428_1"},
			expected: "iboc_policy_20250429_1",
			testTime: time.Date(2025, 4, 29, 0, 0, 0, 0, time.UTC),
		},
		{
			name:     "LY Template",
			template: "LY_policy_{SEQ:id:4:1248:1}",
			policies: []string{"LY_policy_1248", "LY_policy_1249", "LY_policy_1250"},
			expected: "LY_policy_1251",
		},
		{
			name:     "JiS_DMZ Template",
			template: "JiS_DMZ_{SEQ:id:3:689:1}",
			policies: []string{"JiS_DMZ_689", "JiS_DMZ_690", "JiS_DMZ_691"},
			expected: "JiS_DMZ_692",
		},
		{
			name:     "JiS Template",
			template: "JiS_policy_{SEQ:id:4:2913:1}",
			policies: []string{"JiS_policy_2913", "JiS_policy_2914", "JiS_policy_2915"},
			expected: "JiS_policy_2916",
		},
		{
			name:     "GL4F Template",
			template: "GL4F-policy{SEQ:id:4:4388:1}",
			policies: []string{"GL4F-policy4388", "GL4F-policy4389", "GL4F-policy4390", "GL4F-policy4391"},
			expected: "GL4F-policy4392",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			getIterator := func() firewall.NamerIterator {
				return NewMockNamerIterator(tc.policies)
			}
			pt := NewPolicyTemplate(tc.template, getIterator).Initialize().WithCurrentTime(tc.testTime)

			_, result := pt.Generate(map[string]interface{}{})
			if result != tc.expected {
				t.Errorf("Expected %s, got %s", tc.expected, result)
			}
		})
	}
}

func TestPolicyTemplateWithMainID(t *testing.T) {
	t.Run("Generate with Main ID", func(t *testing.T) {
		template := "Policy-{SEQ:id:4:1:1:MAIN}-{DATE:date:YYYYMMDD}"
		pt := NewPolicyTemplate(template, func() firewall.NamerIterator {
			return &mockNamerIterator{}
		}).Initialize()

		pt.WithCurrentTime(time.Date(2025, 8, 3, 0, 0, 0, 0, time.UTC))

		mainID, name := pt.Generate(nil)
		assert.Equal(t, 1, mainID)
		assert.Equal(t, "Policy-0001-20250803", name)

		mainID, name = pt.Generate(nil)
		assert.Equal(t, 2, mainID)
		assert.Equal(t, "Policy-0002-20250803", name)
	})

	t.Run("Extract Main ID", func(t *testing.T) {
		template := "Policy-{SEQ:id:4:1:1:MAIN}-{DATE:date:YYYYMMDD}"
		pt := NewPolicyTemplate(template, func() firewall.NamerIterator {
			return &mockNamerIterator{}
		}).Initialize()

		info, err := pt.Extract("Policy-0003-20230101")
		assert.NoError(t, err)
		assert.Equal(t, "0003", info["id"])
		assert.Equal(t, "20230101", info["date"])
		assert.Equal(t, 3, pt.GetLastSequence("id"))
	})

	t.Run("Generate with Date Change", func(t *testing.T) {
		template := "Policy-{SEQ:id:4:1:1:MAIN}-{DATE:date:YYYYMMDD}"
		pt := NewPolicyTemplate(template, func() firewall.NamerIterator {
			return &mockNamerIterator{
				policies: []string{
					"Policy-0001-20230101",
					"Policy-0002-20230101",
					"Policy-0003-20230101",
				},
			}
		}).Initialize()

		pt.WithCurrentTime(time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC))
		mainID, name := pt.Generate(nil)
		assert.Equal(t, 4, mainID)
		assert.Equal(t, "Policy-0004-20230101", name)

		pt.WithCurrentTime(time.Date(2023, 1, 2, 0, 0, 0, 0, time.UTC))
		mainID, name = pt.Generate(nil)
		assert.Equal(t, 1, mainID)
		assert.Equal(t, "Policy-0001-20230102", name)

		mainID, name = pt.Generate(nil)
		assert.Equal(t, 2, mainID)
		assert.Equal(t, "Policy-0002-20230102", name)
	})

	t.Run("Initialize with Existing Policies", func(t *testing.T) {
		template := "Policy-{SEQ:id:4:1:1:MAIN}-{DATE:date:YYYYMMDD}"
		pt := NewPolicyTemplate(template, func() firewall.NamerIterator {
			return &mockNamerIterator{
				policies: []string{
					"Policy-0001-20230101",
					"Policy-0002-20230101",
					"Policy-0003-20230102",
				},
			}
		}).Initialize()

		assert.Equal(t, 3, pt.GetLastSequence("id"))

		pt.WithCurrentTime(time.Date(2023, 1, 2, 0, 0, 0, 0, time.UTC))
		mainID, name := pt.Generate(nil)
		assert.Equal(t, 4, mainID)
		assert.Equal(t, "Policy-0004-20230102", name)
	})

	// t.Run("Multiple SEQ Fields with Main ID", func(t *testing.T) {
	// 	template := "{SEQ:group:2:1:1}-{SEQ:id:4:1:1:MAIN}-{DATE:date:YYYYMMDD}"
	// 	pt := NewPolicyTemplate(template, func() firewall.NamerIterator {
	// 		return &mockNamerIterator{}
	// 	}).Initialize()

	// 	mainID, name := pt.Generate(nil)
	// 	assert.Equal(t, 1, mainID)
	// 	assert.Regexp(t, `^01-0001-\d{8}$`, name)

	// 	mainID, name = pt.Generate(nil)
	// 	assert.Equal(t, 2, mainID)
	// 	assert.Regexp(t, `^01-0002-\d{8}$`, name)

	// 	pt.SetLastSequence("group", 1)
	// 	mainID, name = pt.Generate(nil)
	// 	assert.Equal(t, 3, mainID)
	// 	assert.Regexp(t, `^02-0003-\d{8}$`, name)
	// })

	t.Run("Main ID with Custom Start and Step", func(t *testing.T) {
		template := "Policy-{SEQ:id:3:100:10:MAIN}-{DATE:date:YYYYMMDD}"
		pt := NewPolicyTemplate(template, func() firewall.NamerIterator {
			return &mockNamerIterator{}
		}).Initialize()

		mainID, name := pt.Generate(nil)
		assert.Equal(t, 100, mainID)
		assert.Regexp(t, `^Policy-100-\d{8}$`, name)

		mainID, name = pt.Generate(nil)
		assert.Equal(t, 110, mainID)
		assert.Regexp(t, `^Policy-110-\d{8}$`, name)
	})

	t.Run("Main ID Persistence Across Date Changes", func(t *testing.T) {
		template := "Policy-{SEQ:id:4:1:1:MAIN}-{DATE:date:YYYYMMDD}"
		pt := NewPolicyTemplate(template, func() firewall.NamerIterator {
			return &mockNamerIterator{
				policies: []string{
					"Policy-0001-20230101",
					"Policy-0002-20230101",
					"Policy-0003-20230102",
					"Policy-0004-20230102",
				},
			}
		}).Initialize()

		pt.WithCurrentTime(time.Date(2023, 1, 2, 0, 0, 0, 0, time.UTC))
		mainID, _ := pt.Generate(nil)
		assert.Equal(t, 5, mainID)

		pt.WithCurrentTime(time.Date(2023, 1, 3, 0, 0, 0, 0, time.UTC))
		mainID, _ = pt.Generate(nil)
		assert.Equal(t, 1, mainID)
	})
}

func TestPolicyTemplateNoRender(t *testing.T) {
	template := "TEST_ACL_{SEQ:id1:2:1:1}{SEQ:id2:4:3000:1:MAIN:NORENDER}"
	getIterator := func() firewall.NamerIterator {
		return &mockNamerIterator{}
	}
	pt := NewPolicyTemplate(template, getIterator).Initialize()

	variables := map[string]interface{}{}

	// 第一次生成
	mainID, result := pt.Generate(variables)
	assert.Equal(t, 3000, mainID, "First main ID should be 3000")
	assert.Equal(t, "TEST_ACL_01", result, "First generated string should be TEST_ACL_01")

	// 第二次生成
	mainID, result = pt.Generate(variables)
	assert.Equal(t, 3001, mainID, "Second main ID should be 3001")
	assert.Equal(t, "TEST_ACL_02", result, "Second generated string should be TEST_ACL_02")

	// 第三次生成
	mainID, result = pt.Generate(variables)
	assert.Equal(t, 3002, mainID, "Third main ID should be 3002")
	assert.Equal(t, "TEST_ACL_03", result, "Third generated string should be TEST_ACL_03")

	// 测试 Extract 方法
	extractedValues, err := pt.Extract("TEST_ACL_04")
	assert.NoError(t, err, "Extract should not return an error")
	assert.Equal(t, "04", extractedValues["id1"], "Extracted id1 should be 04")
	assert.NotContains(t, extractedValues, "id2", "Extracted values should not contain id2")

	// 验证序列号的状态
	assert.Equal(t, 4, pt.GetLastSequence("id1"), "Last sequence for id1 should be 4")
	assert.Equal(t, 3002, pt.GetLastSequence("id2"), "Last sequence for id2 should be 3002")
}

package common

import (
	"fmt"
	"regexp"
	"strings"

	"github.com/netxops/keys"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	"github.com/netxops/utils/dsl"
)

// NameGenerationResult 名称生成结果
type NameGenerationResult struct {
	Name         string   // 最终生成的名称
	IsNew        bool     // 是否为新对象
	Warnings     []string // 警告信息
	Errors       []error  // 错误信息
	FallbackUsed bool     // 是否使用了回退机制
	TemplateUsed bool     // 是否使用了模板
}

// NameGenerationContext 名称生成上下文
type NameGenerationContext struct {
	// 输入参数
	ObjectName string                 // 提供的对象名称（回退值）
	Template   string                 // 模板字符串
	Data       map[string]interface{} // 变量数据
	Context    *firewall.PolicyContext // 策略上下文

	// 配置
	UseBaseFirst bool   // 是否先尝试基础名称
	RetryMethod  string // 重试方法
	MaxRetries   int    // 最大重试次数

	// 对象信息
	Object       interface{}                     // 要命名的对象
	IteratorFunc func() firewall.NamerIterator   // 迭代器函数
	Node         firewall.FirewallNode           // 防火墙节点

	// 内部状态
	ObjectNameManager *ObjectNameManager // 名称管理器
}

// NameGenerationStrategy 名称生成策略接口
type NameGenerationStrategy interface {
	GenerateName(ctx *NameGenerationContext) (*NameGenerationResult, error)
}

// TemplateFirstStrategy 模板优先策略
type TemplateFirstStrategy struct{}

// GenerateName 生成名称（模板优先策略）
func (s *TemplateFirstStrategy) GenerateName(ctx *NameGenerationContext) (*NameGenerationResult, error) {
	result := &NameGenerationResult{
		Warnings: []string{},
		Errors:   []error{},
	}

	// 步骤1: 验证模板
	if ctx.Template != "" {
		if err := s.validateTemplate(ctx.Template, ctx.Data); err != nil {
			result.Warnings = append(result.Warnings, fmt.Sprintf("Template validation warning: %v", err))
			// 如果模板无效，回退到 objectName
			if ctx.ObjectName == "" {
				return nil, fmt.Errorf("template invalid and no fallback name: %w", err)
			}
			result.Name = ctx.ObjectName
			result.FallbackUsed = true
			return s.ensureUnique(ctx, result)
		}
	}

	// 步骤2: 尝试模板格式化
	var name string
	if ctx.Template != "" {
		formattedName, err := s.formatTemplate(ctx.Template, ctx.Data)
		if err != nil {
			result.Warnings = append(result.Warnings, fmt.Sprintf("Template formatting failed: %v", err))
		} else if formattedName != "" {
			name = formattedName
			result.TemplateUsed = true
		}
	}

	// 步骤3: 回退到 objectName
	if name == "" {
		if ctx.ObjectName == "" {
			return nil, fmt.Errorf("no valid name generated and no fallback provided")
		}
		name = ctx.ObjectName
		result.FallbackUsed = true
		result.Warnings = append(result.Warnings, "Using fallback name")
	}

	result.Name = name

	// 步骤4: 唯一性检查和生成
	return s.ensureUnique(ctx, result)
}

// validateTemplate 验证模板
func (s *TemplateFirstStrategy) validateTemplate(template string, data map[string]interface{}) error {
	if template == "" {
		return nil
	}

	// 提取必需的变量（简单的正则匹配）
	// 匹配 {variable_name} 格式
	re := regexp.MustCompile(`\{([a-zA-Z_][a-zA-Z0-9_]*)\}`)
	matches := re.FindAllStringSubmatch(template, -1)

	// 检查变量是否存在
	missingVars := []string{}
	for _, match := range matches {
		if len(match) > 1 {
			varName := match[1]
			// 跳过 DSL 关键字
			if !s.isDSLKeyword(varName) {
				if _, exists := data[varName]; !exists {
					missingVars = append(missingVars, varName)
				}
			}
		}
	}

	if len(missingVars) > 0 {
		return fmt.Errorf("missing required variables: %v", missingVars)
	}

	return nil
}

// isDSLKeyword 检查是否为 DSL 关键字
func (s *TemplateFirstStrategy) isDSLKeyword(name string) bool {
	dslKeywords := []string{
		"if", "exist", "else", "endif", "for", "in", "endfor",
		"isHost", "isNetwork", "isRange", "isFull", "hasType", "hasCode",
		"ip", "mask", "start", "end", "protocol", "type", "code",
		"src_port", "dst_port", "compact", "dotted", "wildcard", "lower",
	}
	for _, keyword := range dslKeywords {
		if name == keyword {
			return true
		}
	}
	return false
}

// formatTemplate 格式化模板
func (s *TemplateFirstStrategy) formatTemplate(template string, data map[string]interface{}) (string, error) {
	if template == "" {
		return "", nil
	}

	// 使用 DSL 格式化
	formatted := strings.TrimSpace(dsl.MapFormat(
		data,
		template,
		dsl.NewDSLParserOptions().WithIgnoreLeadingWhitespace(true),
	))

	// 验证结果
	if formatted == "" {
		return "", fmt.Errorf("template resulted in empty string")
	}

	return formatted, nil
}

// ensureUnique 确保名称唯一性
func (s *TemplateFirstStrategy) ensureUnique(ctx *NameGenerationContext, result *NameGenerationResult) (*NameGenerationResult, error) {
	if result.Name == "" {
		return nil, fmt.Errorf("cannot ensure uniqueness for empty name")
	}

	nameKeys := keys.NewKeyBuilder(result.Name).Separator("")
	auto := keys.NewAutoIncrementKeys(nameKeys, 2)

	// 根据 UseBaseFirst 决定初始键
	// 这里我们已经有了基础名称，所以应该先尝试基础名称
	useBaseFirst := ctx.UseBaseFirst
	if result.TemplateUsed || result.FallbackUsed {
		// 如果使用了模板或回退，说明我们有有效的基础名称，应该先尝试
		useBaseFirst = true
	}

	// 使用统一的唯一性检查
	key, isNew, err := GenerateObjectName(
		auto,
		ctx.Object,
		ctx.IteratorFunc,
		ctx.Node,
		nil, // 模板在格式化阶段已处理
		ctx.RetryMethod,
		ctx.ObjectNameManager,
		useBaseFirst,
	)

	if err != nil {
		return nil, fmt.Errorf("failed to ensure unique name: %w", err)
	}

	result.Name = key.String()
	result.IsNew = isNew
	return result, nil
}

// NameGenerator 统一的名称生成器
type NameGenerator struct {
	strategy NameGenerationStrategy
	node     firewall.FirewallNode
	om       *ObjectNameManager
}

// NewNameGenerator 创建新的名称生成器
func NewNameGenerator(node firewall.FirewallNode, om *ObjectNameManager) *NameGenerator {
	return &NameGenerator{
		strategy: &TemplateFirstStrategy{}, // 默认策略
		node:     node,
		om:       om,
	}
}

// WithStrategy 设置生成策略
func (ng *NameGenerator) WithStrategy(strategy NameGenerationStrategy) *NameGenerator {
	ng.strategy = strategy
	return ng
}

// Generate 生成名称
func (ng *NameGenerator) Generate(ctx *NameGenerationContext) (*NameGenerationResult, error) {
	// 设置默认值
	if ctx.MaxRetries == 0 {
		ctx.MaxRetries = 10
	}
	if ctx.RetryMethod == "" {
		ctx.RetryMethod = RetryMethodNext
	}
	if ctx.ObjectNameManager == nil {
		ctx.ObjectNameManager = ng.om
	}
	if ctx.Node == nil {
		ctx.Node = ng.node
	}

	// 使用策略生成名称
	return ng.strategy.GenerateName(ctx)
}


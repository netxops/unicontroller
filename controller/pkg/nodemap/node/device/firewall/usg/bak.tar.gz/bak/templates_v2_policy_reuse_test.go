package usg

import (
	"strings"
	"testing"

	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	v2 "github.com/netxops/l2service/pkg/nodemap/node/device/firewall/common/v2"
	"github.com/netxops/utils/network"
	"github.com/netxops/utils/policy"
	"github.com/netxops/utils/service"
	"github.com/stretchr/testify/assert"
)

// ==================== 策略复用后的策略生成测试（12.10） ====================

// TestPolicyReuseAfter_AddSourceAddress 测试12.10.1 复用策略后仅添加源地址
func TestPolicyReuseAfter_AddSourceAddress(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	// 第一次：创建策略 (src1, dst1, svc1)
	intent1 := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent1,
	}

	metaData1 := map[string]interface{}{
		"policy_name":                  "REUSE_AFTER_POLICY",
		"securitypolicy.address_style": "object",
		"securitypolicy.service_style": "object",
		"network_object_name_template": "REUSE_AFTER_ADDR",
		"service_object_name_template": "REUSE_AFTER_SVC",
	}

	result1, err := templates.MakePolicyV2(from, to, intent1, ctx, metaData1)
	assert.NoError(t, err)
	assert.NotNil(t, result1)

	// 加载第一次的策略
	if len(result1.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result1.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())
	}

	// 第二次：复用策略，添加 src2
	intent2 := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.2.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx2 := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent2,
	}

	metaData2 := map[string]interface{}{
		"policy_name":                    "REUSE_AFTER_POLICY",
		"securitypolicy.reuse_policy":    true,
		"securitypolicy.address_style":   "object",
		"securitypolicy.service_style":   "object",
		"network_object_name_template":   "REUSE_AFTER_ADDR",
		"service_object_name_template":   "REUSE_AFTER_SVC",
	}

	result2, err := templates.MakePolicyV2(from, to, intent2, ctx2, metaData2)
	assert.NoError(t, err)
	assert.NotNil(t, result2)

	// 验证复用
	if result2.IsReused {
		assert.True(t, result2.IsReused, "应该复用已存在的策略")
		assert.Equal(t, result1.PolicyName, result2.ReusedPolicyName, "复用的策略名称应该匹配")
		t.Logf("策略已复用: %s", result2.ReusedPolicyName)
		t.Logf("生成的CLI（应该仅包含新增的源地址）:\n%s", result2.CLIString)
	} else {
		t.Logf("策略未复用（可能因为匹配逻辑或防火墙不支持）")
	}
}

// TestPolicyReuseAfter_AddDestinationAddress 测试12.10.2 复用策略后仅添加目标地址
func TestPolicyReuseAfter_AddDestinationAddress(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	// 第一次：创建策略 (src1, dst1, svc1)
	intent1 := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent1,
	}

	metaData1 := map[string]interface{}{
		"policy_name":                  "REUSE_AFTER_POLICY_DST",
		"securitypolicy.address_style": "object",
		"securitypolicy.service_style": "object",
		"network_object_name_template": "REUSE_AFTER_ADDR",
		"service_object_name_template": "REUSE_AFTER_SVC",
	}

	result1, err := templates.MakePolicyV2(from, to, intent1, ctx, metaData1)
	assert.NoError(t, err)
	assert.NotNil(t, result1)

	// 加载第一次的策略
	if len(result1.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result1.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())
	}

	// 第二次：复用策略，添加 dst2
	intent2 := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.1.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx2 := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent2,
	}

	metaData2 := map[string]interface{}{
		"policy_name":                    "REUSE_AFTER_POLICY_DST",
		"securitypolicy.reuse_policy":    true,
		"securitypolicy.address_style":   "object",
		"securitypolicy.service_style":   "object",
		"network_object_name_template":   "REUSE_AFTER_ADDR",
		"service_object_name_template":   "REUSE_AFTER_SVC",
	}

	result2, err := templates.MakePolicyV2(from, to, intent2, ctx2, metaData2)
	assert.NoError(t, err)
	assert.NotNil(t, result2)

	// 验证复用
	if result2.IsReused {
		assert.True(t, result2.IsReused, "应该复用已存在的策略")
		t.Logf("策略已复用: %s", result2.ReusedPolicyName)
		t.Logf("生成的CLI（应该仅包含新增的目标地址）:\n%s", result2.CLIString)
	} else {
		t.Logf("策略未复用（可能因为匹配逻辑或防火墙不支持）")
	}
}

// TestPolicyReuseAfter_AddService 测试12.10.3 复用策略后仅添加服务
func TestPolicyReuseAfter_AddService(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	// 第一次：创建策略 (src1, dst1, svc1)
	intent1 := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent1,
	}

	metaData1 := map[string]interface{}{
		"policy_name":                  "REUSE_AFTER_POLICY_SVC",
		"securitypolicy.address_style": "object",
		"securitypolicy.service_style": "object",
		"network_object_name_template": "REUSE_AFTER_ADDR",
		"service_object_name_template": "REUSE_AFTER_SVC",
	}

	result1, err := templates.MakePolicyV2(from, to, intent1, ctx, metaData1)
	assert.NoError(t, err)
	assert.NotNil(t, result1)

	// 加载第一次的策略
	if len(result1.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result1.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())
	}

	// 第二次：复用策略，添加 svc2
	intent2 := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:443"),
		),
	}

	ctx2 := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent2,
	}

	metaData2 := map[string]interface{}{
		"policy_name":                    "REUSE_AFTER_POLICY_SVC",
		"securitypolicy.reuse_policy":    true,
		"securitypolicy.address_style":   "object",
		"securitypolicy.service_style":   "object",
		"network_object_name_template":   "REUSE_AFTER_ADDR",
		"service_object_name_template":   "REUSE_AFTER_SVC",
	}

	result2, err := templates.MakePolicyV2(from, to, intent2, ctx2, metaData2)
	assert.NoError(t, err)
	assert.NotNil(t, result2)

	// 验证复用
	if result2.IsReused {
		assert.True(t, result2.IsReused, "应该复用已存在的策略")
		t.Logf("策略已复用: %s", result2.ReusedPolicyName)
		t.Logf("生成的CLI（应该仅包含新增的服务）:\n%s", result2.CLIString)
	} else {
		t.Logf("策略未复用（可能因为匹配逻辑或防火墙不支持）")
	}
}

// TestPolicyReuseAfter_AddMultipleItems 测试12.10.4 复用策略后添加多个差异项
func TestPolicyReuseAfter_AddMultipleItems(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	// 第一次：创建策略 (src1, dst1, svc1)
	intent1 := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent1,
	}

	metaData1 := map[string]interface{}{
		"policy_name":                  "REUSE_AFTER_POLICY_MULTI",
		"securitypolicy.address_style": "object",
		"securitypolicy.service_style": "object",
		"network_object_name_template": "REUSE_AFTER_ADDR",
		"service_object_name_template": "REUSE_AFTER_SVC",
	}

	result1, err := templates.MakePolicyV2(from, to, intent1, ctx, metaData1)
	assert.NoError(t, err)
	assert.NotNil(t, result1)

	// 加载第一次的策略
	if len(result1.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result1.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())
	}

	// 第二次：复用策略，添加 src2, dst2, svc2
	intent2 := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.2.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.1.0/24"),
			service.NewServiceMust("tcp:443"),
		),
	}

	ctx2 := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent2,
	}

	metaData2 := map[string]interface{}{
		"policy_name":                    "REUSE_AFTER_POLICY_MULTI",
		"securitypolicy.reuse_policy":    true,
		"securitypolicy.address_style":   "object",
		"securitypolicy.service_style":   "object",
		"network_object_name_template":   "REUSE_AFTER_ADDR",
		"service_object_name_template":   "REUSE_AFTER_SVC",
	}

	result2, err := templates.MakePolicyV2(from, to, intent2, ctx2, metaData2)
	assert.NoError(t, err)
	assert.NotNil(t, result2)

	// 验证复用
	if result2.IsReused {
		assert.True(t, result2.IsReused, "应该复用已存在的策略")
		t.Logf("策略已复用: %s", result2.ReusedPolicyName)
		t.Logf("生成的CLI（应该包含所有新增的差异项）:\n%s", result2.CLIString)
	} else {
		t.Logf("策略未复用（可能因为匹配逻辑或防火墙不支持）")
	}
}


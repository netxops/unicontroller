package usg

import (
	"strings"
	"testing"

	"github.com/netxops/l2service/pkg/nodemap/api"
	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	v2 "github.com/netxops/l2service/pkg/nodemap/node/device/firewall/common/v2"
	"github.com/netxops/l2service/pkg/nodemap/node/processor"
	"github.com/netxops/utils/network"
	"github.com/netxops/utils/policy"
	"github.com/netxops/utils/service"
	"github.com/stretchr/testify/assert"
)

// NewTestUsgNodeV2 创建用于v2测试的USG节点
func NewTestUsgNodeV2() *UsgNode {
	usg := &UsgNode{
		policySet: &PolicySet{
			policySet: []*Policy{},
		},
		nats: &Nats{
			destinationNatRules: []*NatRule{},
			sourceNatRules:      []*NatRule{},
			natPolicyRules:      []*NatRule{},
			natServers:          []*NatRule{},
			addressGroups:       make(map[string]*AddressGroup),
			insidePools:         make(map[string]*NatPool),
			globalPools:         make(map[string]*NatPool),
		},
	}

	usg.objectSet = NewUsgObjectSet(usg)
	usg.policySet.objects = usg.objectSet
	usg.nats.objects = usg.objectSet
	usg.nats.node = usg

	return usg
}

// // NewUsgPort 创建USG端口（用于测试）
// func NewUsgPort(name, zone string) *UsgPort {
// 	p := node.NewPort(name, "", nil, nil)
// 	return &UsgPort{
// 		NodePort: *p,
// 	}
// }

// verifyFlyConfigObjects 验证FlyConfig后对象是否正确创建
func verifyFlyConfigObjects(t *testing.T, node *UsgNode, result interface{}) {
	t.Helper()

	switch r := result.(type) {
	case *v2.PolicyResult:
		// 验证源地址对象
		for _, objName := range r.SourceObjects {
			obj, exists := node.Network("", objName)
			assert.True(t, exists, "源地址对象 %s 应该存在", objName)
			if exists {
				assert.NotNil(t, obj, "源地址对象 %s 不应该为nil", objName)
			}
		}
		// 验证目标地址对象
		for _, objName := range r.DestinationObjects {
			obj, exists := node.Network("", objName)
			assert.True(t, exists, "目标地址对象 %s 应该存在", objName)
			if exists {
				assert.NotNil(t, obj, "目标地址对象 %s 不应该为nil", objName)
			}
		}
		// 验证服务对象（注意：某些服务对象可能无法被FlyConfig正确解析，但CLI已生成）
		for _, objName := range r.ServiceObjects {
			obj, exists := node.Service(objName)
			if exists {
				assert.NotNil(t, obj, "服务对象 %s 不应该为nil", objName)
			} else {
				t.Logf("Note: Service object %s may not be parsed correctly by FlyConfig, but CLI was generated", objName)
			}
		}
	case *v2.NatPolicyResult:
		// 验证源地址对象
		for _, objName := range r.SourceObjects {
			obj, exists := node.Network("", objName)
			assert.True(t, exists, "源地址对象 %s 应该存在", objName)
			if exists {
				assert.NotNil(t, obj, "源地址对象 %s 不应该为nil", objName)
			}
		}
		// 验证目标地址对象
		for _, objName := range r.DestinationObjects {
			obj, exists := node.Network("", objName)
			assert.True(t, exists, "目标地址对象 %s 应该存在", objName)
			if exists {
				assert.NotNil(t, obj, "目标地址对象 %s 不应该为nil", objName)
			}
		}
		// 验证服务对象（注意：某些服务对象可能无法被FlyConfig正确解析，但CLI已生成）
		for _, objName := range r.ServiceObjects {
			obj, exists := node.Service(objName)
			if exists {
				assert.NotNil(t, obj, "服务对象 %s 不应该为nil", objName)
			} else {
				t.Logf("Note: Service object %s may not be parsed correctly by FlyConfig, but CLI was generated", objName)
			}
		}
		// 验证VIP/MIP对象（DNAT）
		if r.VipMipName != "" {
			t.Logf("VIP/MIP对象名称: %s", r.VipMipName)
		}
		// 验证SNAT_POOL对象（SNAT）
		if r.SnatPoolName != "" {
			t.Logf("SNAT_POOL对象名称: %s", r.SnatPoolName)
		}
	}
}

// verifyInputNatResult 验证InputNat返回的数据
func verifyInputNatResult(t *testing.T, result processor.AbstractMatchResult, intent *policy.Intent, to api.Port, expectedAction firewall.Action) {
	t.Helper()

	if !assert.NotNil(t, result, "InputNat不应该返回空，NAT规则应该匹配") {
		t.Fatalf("InputNat返回nil，测试失败")
		return
	}

	// 验证类型
	natResult, ok := result.(*firewall.NatMatchResult)
	if !ok {
		t.Fatalf("InputNat返回结果类型错误，期望 *firewall.NatMatchResult，实际 %T", result)
		return
	}

	// 验证Action
	action := natResult.Action()
	t.Logf("InputNat result: Action=%d (期望=%d)", action, int(expectedAction))
	if action != int(expectedAction) {
		t.Logf("警告：NAT规则未匹配，Action=%d (期望=%d)", action, int(expectedAction))
		t.Logf("可能的原因：")
		t.Logf("  - 服务对象未正确创建")
		t.Logf("  - VIP/MIP对象未正确创建")
		t.Logf("  - NAT策略CLI格式不正确")
		t.Logf("  - Zone配置不正确")
	} else {
		t.Logf("✓ NAT规则匹配成功")
	}

	// 验证Rule和Translate
	rule := natResult.Rule()
	if rule != nil {
		t.Logf("匹配的NAT规则: %s", rule.Cli())

		// 验证规则中的Translate方法
		ruleTranslate := rule.Translate()
		if ruleTranslate != nil {
			t.Logf("规则中的Translate定义:")
			if ruleTranslate.Dst() != nil && !ruleTranslate.Dst().IsEmpty() {
				t.Logf("  - Dst: %s", ruleTranslate.Dst().String())
			}
			if ruleTranslate.Src() != nil && !ruleTranslate.Src().IsEmpty() {
				t.Logf("  - Src: %s", ruleTranslate.Src().String())
			}
			if ruleTranslate.Service() != nil && !ruleTranslate.Service().IsEmpty() {
				t.Logf("  - Service: %s", ruleTranslate.Service().String())
			}
		} else {
			t.Logf("警告：规则中的Translate为nil")
		}
	}

	// 验证TranslateTo（DNAT）- 只在匹配成功时验证
	if action == int(firewall.NAT_MATCHED) {
		translateTo := natResult.TranslateTo()
		if assert.NotNil(t, translateTo, "DNAT应该返回转换后的intent") {
			t.Logf("转换后的Intent:")
			t.Logf("  原始Intent: Src=%s, Dst=%s, Service=%s",
				intent.Src().String(), intent.Dst().String(), intent.Service().String())
			t.Logf("  转换后Intent: Src=%s, Dst=%s, Service=%s",
				translateTo.Src().String(), translateTo.Dst().String(), translateTo.Service().String())

			// 验证目标地址转换（DNAT）
			if intent.RealIp != "" {
				if translateTo.Dst() != nil {
					expectedDst := intent.RealIp
					actualDst := translateTo.Dst().String()
					t.Logf("DNAT地址转换: %s -> %s", intent.Dst().String(), actualDst)
					assert.Contains(t, actualDst, expectedDst, "DNAT应该转换到正确的目标地址")

					// 验证转换后的地址与规则中的translate一致（如果规则有定义）
					if rule != nil && rule.Translate() != nil {
						ruleTranslate := rule.Translate()
						if ruleTranslate.Dst() != nil && !ruleTranslate.Dst().IsEmpty() {
							ruleDstStr := ruleTranslate.Dst().String()
							t.Logf("规则Translate.Dst: %s, 转换后Dst: %s", ruleDstStr, actualDst)
						}
					}
				} else {
					t.Errorf("DNAT转换后Dst()为nil，但RealIp不为空")
				}
			}

			// 验证端口转换（DNAT）
			if intent.RealPort != "" {
				if translateTo.Service() != nil {
					actualService := translateTo.Service().String()
					t.Logf("DNAT端口转换: %s -> %s", intent.Service().String(), actualService)
					assert.Contains(t, actualService, intent.RealPort, "DNAT应该转换到正确的端口")

					// 验证转换后的服务与规则中的translate一致（如果规则有定义）
					if rule != nil && rule.Translate() != nil {
						ruleTranslate := rule.Translate()
						if ruleTranslate.Service() != nil && !ruleTranslate.Service().IsEmpty() {
							ruleSvcStr := ruleTranslate.Service().String()
							t.Logf("规则Translate.Service: %s, 转换后Service: %s", ruleSvcStr, actualService)
						}
					}
				} else {
					t.Errorf("DNAT转换后Service()为nil，但RealPort不为空")
				}
			}

			// 验证源地址保持不变（DNAT通常不改变源地址）
			if translateTo.Src() != nil {
				originalSrc := intent.Src().String()
				translatedSrc := translateTo.Src().String()
				if originalSrc != "" && translatedSrc != "" {
					t.Logf("源地址验证: %s -> %s (DNAT通常不改变源地址)", originalSrc, translatedSrc)
				}
			}
		} else {
			t.Errorf("DNAT匹配成功但TranslateTo()为nil")
		}
	} else if action != int(firewall.NAT_MATCHED) {
		t.Logf("生成的CLI用于调试:")
	}

	// 验证FromPort
	fromPort := natResult.FromPort()
	assert.NotNil(t, fromPort, "源端口不应该为nil")
}

// verifyOutputNatResult 验证OutputNat返回的数据
func verifyOutputNatResult(t *testing.T, result processor.AbstractMatchResult, intent *policy.Intent, from, to api.Port, expectedAction firewall.Action) {
	t.Helper()

	if result == nil {
		t.Logf("OutputNat返回nil，可能的原因：")
		t.Logf("  - NAT策略CLI未正确解析（pool_id格式问题）")
		t.Logf("  - SNAT_POOL对象未正确创建")
		t.Logf("  - Zone配置不正确")
		return
	}

	// 验证类型
	natResult, ok := result.(*firewall.NatMatchResult)
	if !ok {
		t.Fatalf("OutputNat返回结果类型错误，期望 *firewall.NatMatchResult，实际 %T", result)
		return
	}

	// 验证Action
	action := natResult.Action()
	t.Logf("OutputNat result: Action=%d (期望=%d)", action, int(expectedAction))
	if action != int(expectedAction) {
		t.Logf("警告：NAT规则未匹配，Action=%d (期望=%d)", action, int(expectedAction))
		t.Logf("可能的原因：pool_id格式问题导致策略未正确解析")
	} else {
		t.Logf("✓ NAT规则匹配成功")
	}

	// 验证Rule和Translate
	rule := natResult.Rule()
	if rule != nil {
		t.Logf("匹配的NAT规则: %s", rule.Cli())

		// 验证规则中的Translate方法
		ruleTranslate := rule.Translate()
		if ruleTranslate != nil {
			t.Logf("规则中的Translate定义:")
			if ruleTranslate.Dst() != nil && !ruleTranslate.Dst().IsEmpty() {
				t.Logf("  - Dst: %s", ruleTranslate.Dst().String())
			}
			if ruleTranslate.Src() != nil && !ruleTranslate.Src().IsEmpty() {
				t.Logf("  - Src: %s", ruleTranslate.Src().String())
			}
			if ruleTranslate.Service() != nil && !ruleTranslate.Service().IsEmpty() {
				t.Logf("  - Service: %s", ruleTranslate.Service().String())
			}
		} else {
			t.Logf("警告：规则中的Translate为nil")
		}
	}

	// 验证TranslateTo（SNAT）- 只在匹配成功时验证
	if action == int(firewall.NAT_MATCHED) {
		translateTo := natResult.TranslateTo()
		if assert.NotNil(t, translateTo, "SNAT应该返回转换后的intent") {
			t.Logf("转换后的Intent:")
			t.Logf("  原始Intent: Src=%s, Dst=%s, Service=%s",
				intent.Src().String(), intent.Dst().String(), intent.Service().String())
			t.Logf("  转换后Intent: Src=%s, Dst=%s, Service=%s",
				translateTo.Src().String(), translateTo.Dst().String(), translateTo.Service().String())

			// 验证源地址转换（SNAT）
			if intent.Snat != "" {
				if translateTo.Src() != nil {
					actualSrc := translateTo.Src().String()
					t.Logf("SNAT地址转换: %s -> %s", intent.Src().String(), actualSrc)
					assert.NotEmpty(t, actualSrc, "SNAT应该转换源地址")

					// 验证转换后的地址与规则中的translate一致（如果规则有定义）
					if rule != nil && rule.Translate() != nil {
						ruleTranslate := rule.Translate()
						if ruleTranslate.Src() != nil && !ruleTranslate.Src().IsEmpty() {
							ruleSrcStr := ruleTranslate.Src().String()
							t.Logf("规则Translate.Src: %s, 转换后Src: %s", ruleSrcStr, actualSrc)
						}
					}
				} else {
					t.Errorf("SNAT转换后Src()为nil，但Snat不为空")
				}
			}

			// 验证目标地址保持不变（SNAT通常不改变目标地址）
			if translateTo.Dst() != nil {
				originalDst := intent.Dst().String()
				translatedDst := translateTo.Dst().String()
				if originalDst != "" && translatedDst != "" {
					t.Logf("目标地址验证: %s -> %s (SNAT通常不改变目标地址)", originalDst, translatedDst)
				}
			}

			// 验证服务保持不变（SNAT通常不改变服务）
			if translateTo.Service() != nil {
				originalSvc := intent.Service().String()
				translatedSvc := translateTo.Service().String()
				if originalSvc != "" && translatedSvc != "" {
					t.Logf("服务验证: %s -> %s (SNAT通常不改变服务)", originalSvc, translatedSvc)
				}
			}
		} else {
			t.Errorf("SNAT匹配成功但TranslateTo()为nil")
		}
	}

	// 验证FromPort和OutPort
	fromPort := natResult.FromPort()
	assert.NotNil(t, fromPort, "源端口不应该为nil")

	outPort := natResult.OutPort()
	assert.NotNil(t, outPort, "目标端口不应该为nil")
}

// TestMakeAddressObjectV2_SingleAddress 测试单个地址对象生成
func TestMakeAddressObjectV2_SingleAddress(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	// 创建测试intent
	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
	}

	metaData := map[string]interface{}{
		"network_object_name_template": "TEST_ADDR",
		"policy_name":                  "TEST_POLICY",
	}

	// 测试源地址对象
	t.Run("SourceAddress", func(t *testing.T) {
		result, err := templates.MakeAddressObjectV2(intent, true, ctx, metaData)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.False(t, result.IsGroup, "单个地址不应是组")
		assert.Len(t, result.ObjectNames, 1)
		assert.NotEmpty(t, result.CLIString)

		// 打印调试信息
		t.Logf("Generated object name: %s", result.ObjectNames[0])
		t.Logf("Generated CLI:\n%s", result.CLIString)

		// 验证CLI格式 - USG格式：ip address-set <name> type object
		assert.Contains(t, result.CLIString, "ip address-set")
		assert.Contains(t, result.CLIString, "type object")
		assert.Contains(t, result.CLIString, "address")
		assert.Contains(t, result.CLIString, "192.168.1.0")
		// USG使用mask格式（255.255.255.0）
		assert.Contains(t, result.CLIString, "mask")

		// 通过FlyConfig加载并验证
		node.FlyConfig(result.CLIString)
		obj, exists := node.Network("", result.ObjectNames[0])
		assert.True(t, exists, "地址对象应该存在")
		if exists {
			assert.NotNil(t, obj, "地址对象不应该为nil")
		}
	})

	// 测试目标地址对象
	t.Run("DestinationAddress", func(t *testing.T) {
		result, err := templates.MakeAddressObjectV2(intent, false, ctx, metaData)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.False(t, result.IsGroup, "单个地址不应是组")
		assert.Len(t, result.ObjectNames, 1)
		assert.NotEmpty(t, result.CLIString)

		t.Logf("Generated object name: %s", result.ObjectNames[0])
		t.Logf("Generated CLI:\n%s", result.CLIString)

		// 验证CLI格式
		assert.Contains(t, result.CLIString, "ip address-set")
		assert.Contains(t, result.CLIString, "10.0.0.0")
		assert.Contains(t, result.CLIString, "mask")
	})
}

// TestMakeServiceObjectV2 测试服务对象生成
func TestMakeServiceObjectV2(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
	}

	metaData := map[string]interface{}{
		"service_object_name_template": "TEST_SVC",
		"policy_name":                  "TEST_POLICY",
	}

	result, err := templates.MakeServiceObjectV2(intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.Len(t, result.ObjectNames, 1)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated service object name: %s", result.ObjectNames[0])
	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI格式 - USG格式：ip service-set <name> type object
	assert.Contains(t, result.CLIString, "ip service-set")
	assert.Contains(t, result.CLIString, "type object")
	assert.Contains(t, result.CLIString, "service protocol")
	assert.Contains(t, result.CLIString, "tcp")
	assert.Contains(t, result.CLIString, "destination-port")
	assert.Contains(t, result.CLIString, "80")

	// 通过FlyConfig加载并验证
	node.FlyConfig(result.CLIString)
	obj, exists := node.Service(result.ObjectNames[0])
	if exists {
		assert.NotNil(t, obj, "服务对象不应该为nil")
	} else {
		t.Logf("Note: Service object may not be parsed correctly by FlyConfig, but CLI was generated")
	}
}

// TestMakePolicyV2 测试安全策略生成
func TestMakePolicyV2(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"policy_name": "TEST_POLICY",
	}

	result, err := templates.MakePolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI格式 - USG格式：security-policy ... rule name <name>
	assert.Contains(t, result.CLIString, "security-policy")
	assert.Contains(t, result.CLIString, "rule name")
	// 策略名称可能是TEST_POLICY或POLICY_OBJECT（如果命名模板未生效）
	assert.True(t, strings.Contains(result.CLIString, "TEST_POLICY") || strings.Contains(result.CLIString, "POLICY_OBJECT"), "应该包含策略名称")
	assert.Contains(t, result.CLIString, "source-zone")
	assert.Contains(t, result.CLIString, "destination-zone")
	assert.Contains(t, result.CLIString, "action")

	// 验证对象创建
	verifyFlyConfigObjects(t, node, result)

	// 通过FlyConfig加载并验证策略匹配
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证策略匹配
		matchResult := node.InputPolicy(intent, from, to)
		assert.NotNil(t, matchResult, "策略应该匹配")
		if matchResult != nil {
			policyResult, ok := matchResult.(*firewall.PolicyMatchResult)
			if ok {
				action := policyResult.Action()
				t.Logf("Policy match result: Action=%d", action)
			}
		}
	}
}

// TestMakeNatPolicyV2_DNAT 测试DNAT策略生成
func TestMakeNatPolicyV2_DNAT(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "NAT_TEST",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "NAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI格式 - USG格式：nat global-policy ... action dnat ip-address ...
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "rule name")
	assert.Contains(t, result.CLIString, "action dnat ip-address")
	assert.Contains(t, result.CLIString, "192.168.1.100")
	assert.Contains(t, result.CLIString, "local-port")
	assert.Contains(t, result.CLIString, "80")

	// 通过FlyConfig加载并验证NAT匹配
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证对象创建（在FlyConfig之后）
		verifyFlyConfigObjects(t, node, result)

		// 验证InputNat匹配
		inputNatResult := node.InputNat(intent, to)
		verifyInputNatResult(t, inputNatResult, intent, to, firewall.NAT_MATCHED)
	}
}

// TestMakePolicyV2_IPService 测试策略中 service 为 ip 的情况
func TestMakePolicyV2_IPService(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("ip"),
		),
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"policy_name":                  "IP_POLICY",
		"securitypolicy.address_style": "object",
		"securitypolicy.service_style": "object",
		"network_object_name_template": "TEST_ADDR",
		"service_object_name_template": "TEST_SVC",
	}

	result, err := templates.MakePolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证 CLI 中包含 service-port ip（USG 在策略中使用 service protocol ip，在 NAT 中使用 service-port ip）
	assert.Contains(t, result.CLIString, "service protocol ip", "当 service 为 ip 时，应该生成 service protocol ip")

	// 验证不生成 service 对象（ip 协议不需要 service 对象）
	assert.Empty(t, result.ServiceObjects, "当 service 为 ip 时，不应该生成 service 对象")

	// 通过FlyConfig加载并验证
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证对象创建
		verifyFlyConfigObjects(t, node, result)
	}
}

// TestMakeNatPolicyV2_IPService 测试NAT策略中 service 为 ip 的情况
func TestMakeNatPolicyV2_IPService(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	// 测试 DNAT
	t.Run("DNAT", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.100"),
				service.NewServiceMust("ip"),
			),
			RealIp: "192.168.1.100",
		}

		ctx := &firewall.PolicyContext{
			Node:      node,
			Variables: make(map[string]interface{}),
			Intent:    intent,
		}

		metaData := map[string]interface{}{
			"natpolicy.name_template":      "NAT_IP_TEST",
			"natpolicy.use_service_object": true,
		}

		result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.NotEmpty(t, result.CLIString)

		t.Logf("Generated CLI:\n%s", result.CLIString)

		// 验证 CLI 中包含 service-port ip（USG 的 NAT 模板使用 service-port ip）
		assert.Contains(t, result.CLIString, "service-port ip", "当 service 为 ip 时，应该生成 service-port ip")

		// 验证不生成 service 对象（ip 协议不需要 service 对象）
		assert.Empty(t, result.ServiceObjects, "当 service 为 ip 时，不应该生成 service 对象")

		// 通过FlyConfig加载并验证
		if len(result.FlyObject) > 0 {
			allCLI := strings.Builder{}
			for _, cli := range result.FlyObject {
				allCLI.WriteString(cli)
				allCLI.WriteString("\n")
			}
			node.FlyConfig(allCLI.String())

			// 验证对象创建
			verifyFlyConfigObjects(t, node, result)

			// 验证InputNat匹配
			inputNatResult := node.InputNat(intent, to)
			verifyInputNatResult(t, inputNatResult, intent, to, firewall.NAT_MATCHED)
		}
	})

	// 测试 SNAT
	t.Run("SNAT", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("ip"),
			),
			Snat: "203.0.113.1",
		}

		ctx := &firewall.PolicyContext{
			Node:      node,
			Variables: make(map[string]interface{}),
			Intent:    intent,
		}

		metaData := map[string]interface{}{
			"natpolicy.name_template":      "SNAT_IP_TEST",
			"natpolicy.use_service_object": true,
		}

		result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.NotEmpty(t, result.CLIString)

		t.Logf("Generated CLI:\n%s", result.CLIString)

		// 验证 CLI 中包含 service-port ip（USG 的 NAT 模板使用 service-port ip）
		assert.Contains(t, result.CLIString, "service-port ip", "当 service 为 ip 时，应该生成 service-port ip")

		// 验证不生成 service 对象（ip 协议不需要 service 对象）
		assert.Empty(t, result.ServiceObjects, "当 service 为 ip 时，不应该生成 service 对象")

		// 通过FlyConfig加载并验证
		if len(result.FlyObject) > 0 {
			allCLI := strings.Builder{}
			for _, cli := range result.FlyObject {
				allCLI.WriteString(cli)
				allCLI.WriteString("\n")
			}
			node.FlyConfig(allCLI.String())

			// 验证对象创建
			verifyFlyConfigObjects(t, node, result)

			// 验证OutputNat匹配
			outputNatResult := node.OutputNat(intent, from, to)
			verifyOutputNatResult(t, outputNatResult, intent, from, to, firewall.NAT_MATCHED)
		}
	})
}

// TestMakeNatPolicyV2_SNAT 测试SNAT策略生成
func TestMakeNatPolicyV2_SNAT(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.100", // 单IP（real_ip和snat都是单IP）
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "SNAT_TEST",
		"natpolicy.use_service_object": true,
		"snat_pool_type":               "POOL",
		"snat_object_name_template":    "SNAT_POOL_{snat}",
		"service_object_name_template": "SNAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI格式 - USG格式：nat global-policy ... action snat address-group ...
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "rule name")
	assert.Contains(t, result.CLIString, "action snat address-group")

	// 通过FlyConfig加载并验证NAT匹配
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证对象创建（在FlyConfig之后）
		verifyFlyConfigObjects(t, node, result)

		// 验证OutputNat匹配
		outputNatResult := node.OutputNat(intent, from, to)
		verifyOutputNatResult(t, outputNatResult, intent, from, to, firewall.NAT_MATCHED)
	}
}

// TestGetReuseNatObject 测试GetReuseNatObject接口
// USG的逻辑：
//   - DNAT: 根据dnat_object_type配置，可能使用MIP（address-group）或INLINE
//   - SNAT: 根据snat_object_type配置，可能使用SNAT_POOL（address-group）、INTERFACE或INLINE
func TestGetReuseNatObject(t *testing.T) {
	node := NewTestUsgNodeV2()

	// 测试1: DNAT + MIP + 找到复用对象
	t.Run("DNAT_MIP_Found", func(t *testing.T) {
		// 先创建一个MIP address-group
		realIp := "192.168.1.100"
		realIpNg := network.NewNetworkGroupFromStringMust(realIp)

		ag := &AddressGroup{
			GroupNumber: "1",
			N:           realIpNg,
			Sections: []*AddressSection{
				{
					StartIP: realIp,
					EndIP:   realIp,
					Network: realIpNg,
				},
			},
		}
		node.nats.addressGroups["1"] = ag

		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.100"),
				service.NewServiceMust("ip"),
			),
			RealIp: realIp,
		}

		// 显式配置为MIP
		metaData := map[string]interface{}{
			"dnat_object_type": "MIP",
		}

		name, reused := node.GetReuseNatObject("DNAT", intent, metaData)
		assert.True(t, reused, "应该找到复用的MIP对象")
		assert.Equal(t, "1", name, "应该返回正确的address-group编号")
	})

	// 测试2: DNAT + MIP + 未找到复用对象
	t.Run("DNAT_MIP_NotFound", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.101"),
				service.NewServiceMust("ip"),
			),
			RealIp: "192.168.1.200", // 不存在的地址
		}

		metaData := map[string]interface{}{
			"dnat_object_type": "MIP",
		}

		name, reused := node.GetReuseNatObject("DNAT", intent, metaData)
		assert.False(t, reused, "不应该找到复用的对象")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试3: DNAT + MIP + 缺少real_ip
	t.Run("DNAT_MIP_NoRealIp", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.102"),
				service.NewServiceMust("ip"),
			),
			// RealIp为空
		}

		metaData := map[string]interface{}{
			"dnat_object_type": "MIP",
		}

		name, reused := node.GetReuseNatObject("DNAT", intent, metaData)
		assert.False(t, reused, "缺少real_ip时不应该找到对象")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试4: DNAT + INLINE类型
	t.Run("DNAT_INLINE_Type", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.103"),
				service.NewServiceMust("ip"),
			),
			RealIp: "192.168.1.100",
		}

		metaData := map[string]interface{}{
			"dnat_object_type": "INLINE",
		}

		name, reused := node.GetReuseNatObject("DNAT", intent, metaData)
		assert.False(t, reused, "INLINE类型不需要生成对象，应该返回false")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试5: SNAT + SNAT_POOL + 找到复用对象
	t.Run("SNAT_SNAT_POOL_Found", func(t *testing.T) {
		// 先创建一个SNAT address-group
		snatIp := "203.0.113.200"
		snatNg := network.NewNetworkGroupFromStringMust(snatIp)

		ag := &AddressGroup{
			GroupNumber: "2",
			N:           snatNg,
			Sections: []*AddressSection{
				{
					StartIP: snatIp,
					EndIP:   snatIp,
					Network: snatNg,
				},
			},
		}
		node.nats.addressGroups["2"] = ag

		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: snatIp,
		}

		// 默认配置为SNAT_POOL
		metaData := map[string]interface{}{}

		name, reused := node.GetReuseNatObject("SNAT", intent, metaData)
		assert.True(t, reused, "应该找到复用的SNAT_POOL对象")
		assert.Equal(t, "2", name, "应该返回正确的address-group编号")
	})

	// 测试6: SNAT + SNAT_POOL + 未找到复用对象
	t.Run("SNAT_SNAT_POOL_NotFound", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: "203.0.113.300", // 不存在的地址
		}

		metaData := map[string]interface{}{}

		name, reused := node.GetReuseNatObject("SNAT", intent, metaData)
		assert.False(t, reused, "不应该找到复用的对象")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试7: SNAT + SNAT_POOL + 缺少snat
	t.Run("SNAT_SNAT_POOL_NoSnat", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			// Snat为空
		}

		metaData := map[string]interface{}{}

		name, reused := node.GetReuseNatObject("SNAT", intent, metaData)
		assert.False(t, reused, "缺少snat时不应该找到对象")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试8: SNAT + INTERFACE类型
	t.Run("SNAT_INTERFACE_Type", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: "203.0.113.200",
		}

		metaData := map[string]interface{}{
			"snat_object_type": "INTERFACE",
		}

		name, reused := node.GetReuseNatObject("SNAT", intent, metaData)
		assert.False(t, reused, "INTERFACE类型不需要生成对象，应该返回false")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试9: SNAT + INLINE类型
	t.Run("SNAT_INLINE_Type", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: "203.0.113.200",
		}

		metaData := map[string]interface{}{
			"snat_object_type": "INLINE",
		}

		name, reused := node.GetReuseNatObject("SNAT", intent, metaData)
		assert.False(t, reused, "INLINE类型不需要生成对象，应该返回false")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试10: SNAT + SNAT_POOL + 显式配置
	t.Run("SNAT_SNAT_POOL_Configured", func(t *testing.T) {
		// 使用之前创建的address-group
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: "203.0.113.200",
		}

		metaData := map[string]interface{}{
			"snat_object_type": "SNAT_POOL",
		}

		name, reused := node.GetReuseNatObject("SNAT", intent, metaData)
		assert.True(t, reused, "应该找到复用的SNAT_POOL对象")
		assert.Equal(t, "2", name, "应该返回正确的address-group编号")
	})

	// 测试11: DNAT + MIP + IP范围匹配
	t.Run("DNAT_MIP_IPRangeMatch", func(t *testing.T) {
		// 创建一个IP范围的address-group
		realIp := "192.168.1.101"
		realIpNg := network.NewNetworkGroupFromStringMust(realIp)

		ag := &AddressGroup{
			GroupNumber: "3",
			N:           realIpNg,
			Sections: []*AddressSection{
				{
					StartIP: "192.168.1.100",
					EndIP:   "192.168.1.110",
					Network: network.NewNetworkGroupFromStringMust("192.168.1.100-192.168.1.110"),
				},
			},
		}
		node.nats.addressGroups["3"] = ag

		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.101"),
				service.NewServiceMust("ip"),
			),
			RealIp: realIp,
		}

		metaData := map[string]interface{}{
			"dnat_object_type": "MIP",
		}

		name, reused := node.GetReuseNatObject("DNAT", intent, metaData)
		assert.True(t, reused, "应该找到匹配的IP范围MIP对象")
		assert.Equal(t, "3", name, "应该返回正确的address-group编号")
	})

	// 测试12: SNAT + SNAT_POOL + 多个address-groups
	t.Run("SNAT_SNAT_POOL_MultiplePools", func(t *testing.T) {
		// 创建多个SNAT address-groups
		snatIp1 := "203.0.113.201"
		snatNg1 := network.NewNetworkGroupFromStringMust(snatIp1)
		ag1 := &AddressGroup{
			GroupNumber: "4",
			N:           snatNg1,
			Sections: []*AddressSection{
				{
					StartIP: snatIp1,
					EndIP:   snatIp1,
					Network: snatNg1,
				},
			},
		}
		node.nats.addressGroups["4"] = ag1

		snatIp2 := "203.0.113.202"
		snatNg2 := network.NewNetworkGroupFromStringMust(snatIp2)
		ag2 := &AddressGroup{
			GroupNumber: "5",
			N:           snatNg2,
			Sections: []*AddressSection{
				{
					StartIP: snatIp2,
					EndIP:   snatIp2,
					Network: snatNg2,
				},
			},
		}
		node.nats.addressGroups["5"] = ag2

		// 测试第一个pool
		intent1 := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: snatIp1,
		}

		metaData := map[string]interface{}{}

		name1, reused1 := node.GetReuseNatObject("SNAT", intent1, metaData)
		assert.True(t, reused1, "应该找到第一个pool")
		assert.Equal(t, "4", name1, "应该返回第一个pool的编号")

		// 测试第二个pool
		intent2 := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: snatIp2,
		}

		name2, reused2 := node.GetReuseNatObject("SNAT", intent2, metaData)
		assert.True(t, reused2, "应该找到第二个pool")
		assert.Equal(t, "5", name2, "应该返回第二个pool的编号")
		assert.NotEqual(t, name1, name2, "两个pool的编号应该不同")
	})

	// 测试13: DNAT + MIP + 无效real_ip
	t.Run("DNAT_MIP_InvalidRealIp", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.104"),
				service.NewServiceMust("ip"),
			),
			RealIp: "invalid_ip", // 无效的IP地址
		}

		metaData := map[string]interface{}{
			"dnat_object_type": "MIP",
		}

		name, reused := node.GetReuseNatObject("DNAT", intent, metaData)
		assert.False(t, reused, "无效real_ip时不应该找到对象")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试14: SNAT + SNAT_POOL + 无效snat
	t.Run("SNAT_SNAT_POOL_InvalidSnat", func(t *testing.T) {
		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: "invalid_snat", // 无效的IP地址
		}

		metaData := map[string]interface{}{}

		name, reused := node.GetReuseNatObject("SNAT", intent, metaData)
		assert.False(t, reused, "无效snat时不应该找到对象")
		assert.Empty(t, name, "应该返回空字符串")
	})

	// 测试15: DNAT + MIP + addressGroups为nil
	t.Run("DNAT_MIP_NilAddressGroups", func(t *testing.T) {
		// 创建一个addressGroups为nil的节点
		nodeNilGroups := NewTestUsgNodeV2()
		nodeNilGroups.nats.addressGroups = nil

		intent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.105"),
				service.NewServiceMust("ip"),
			),
			RealIp: "192.168.1.100",
		}

		metaData := map[string]interface{}{
			"dnat_object_type": "MIP",
		}

		name, reused := nodeNilGroups.GetReuseNatObject("DNAT", intent, metaData)
		assert.False(t, reused, "addressGroups为nil时不应该找到对象")
		assert.Empty(t, name, "应该返回空字符串")
	})
}

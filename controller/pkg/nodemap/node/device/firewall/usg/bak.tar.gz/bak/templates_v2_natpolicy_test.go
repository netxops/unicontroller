package usg

import (
	"strings"
	"testing"

	"github.com/netxops/l2service/pkg/nodemap/node/device/firewall"
	v2 "github.com/netxops/l2service/pkg/nodemap/node/device/firewall/common/v2"
	"github.com/netxops/utils/network"
	"github.com/netxops/utils/policy"
	"github.com/netxops/utils/service"
	"github.com/stretchr/testify/assert"
)

// ==================== NAT策略测试（13章） ====================

// TestMakeNatPolicyV2_SimpleDNAT 测试13.1 简单DNAT策略
func TestMakeNatPolicyV2_SimpleDNAT(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "NAT_TEST",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "NAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI格式 - USG格式：nat global-policy ... action dnat ip-address ...
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "rule name")
	assert.Contains(t, result.CLIString, "action dnat ip-address")
	assert.Contains(t, result.CLIString, "192.168.1.100")
	assert.Contains(t, result.CLIString, "local-port")
	assert.Contains(t, result.CLIString, "80")

	// 通过FlyConfig加载并验证NAT匹配
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证对象创建（在FlyConfig之后）
		verifyFlyConfigObjects(t, node, result)

		// 验证InputNat匹配
		inputNatResult := node.InputNat(intent, to)
		verifyInputNatResult(t, inputNatResult, intent, to, firewall.NAT_MATCHED)
	}
}

// TestMakeNatPolicyV2_SimpleSNAT 测试13.2 简单SNAT策略
func TestMakeNatPolicyV2_SimpleSNAT(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "SNAT_TEST",
		"natpolicy.use_service_object": true,
		"snat_pool_type":               "POOL",
		"snat_object_name_template":    "SNAT_POOL_{snat}",
		"service_object_name_template": "SNAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI格式 - USG格式：nat global-policy ... action snat address-group ...
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "rule name")
	assert.Contains(t, result.CLIString, "action snat address-group")

	// 通过FlyConfig加载并验证NAT匹配
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证对象创建（在FlyConfig之后）
		verifyFlyConfigObjects(t, node, result)

		// 验证OutputNat匹配
		outputNatResult := node.OutputNat(intent, from, to)
		verifyOutputNatResult(t, outputNatResult, intent, from, to, firewall.NAT_MATCHED)
	}
}

// TestMakeNatPolicyV2_ComplexDNAT 测试13.3 复杂DNAT策略
func TestMakeNatPolicyV2_ComplexDNAT(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	// 创建包含多个网络和服务的intent
	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100,203.0.113.101"),
			service.NewServiceMust("tcp:8080,8081"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "COMPLEX_DNAT",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "COMPLEX_SVC",
		"service_group_name_template": "COMPLEX_SVC_GROUP",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI包含NAT策略定义
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "action dnat")

	// 通过FlyConfig加载并验证
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证对象创建
		verifyFlyConfigObjects(t, node, result)

		// 验证InputNat匹配（使用第一个目标地址）
		testIntent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				network.NewNetworkGroupFromStringMust("203.0.113.100"),
				service.NewServiceMust("tcp:8080"),
			),
			RealIp:   "192.168.1.100",
			RealPort: "80",
		}
		inputNatResult := node.InputNat(testIntent, to)
		verifyInputNatResult(t, inputNatResult, testIntent, to, firewall.NAT_MATCHED)
	}
}

// TestMakeNatPolicyV2_ComplexSNAT 测试13.4 复杂SNAT策略
func TestMakeNatPolicyV2_ComplexSNAT(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	// 创建包含多个网络和服务的intent
	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24,192.168.2.0/24"),
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			service.NewServiceMust("tcp:80,443"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "COMPLEX_SNAT",
		"natpolicy.use_service_object": true,
		"snat_pool_type":               "POOL",
		"snat_object_name_template":    "SNAT_POOL_{snat}",
		"service_object_name_template": "COMPLEX_SVC",
		"service_group_name_template": "COMPLEX_SVC_GROUP",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI包含NAT策略定义
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "action snat")

	// 通过FlyConfig加载并验证
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证对象创建
		verifyFlyConfigObjects(t, node, result)

		// 验证OutputNat匹配（使用第一个源地址）
		testIntent := &policy.Intent{
			PolicyEntry: *policy.NewPolicyEntryWithAll(
				network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
				network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
				service.NewServiceMust("tcp:80"),
			),
			Snat: "203.0.113.0/24",
		}
		outputNatResult := node.OutputNat(testIntent, from, to)
		verifyOutputNatResult(t, outputNatResult, testIntent, from, to, firewall.NAT_MATCHED)
	}
}

// TestMakeNatPolicyV2_TranslateValidation_DNAT 测试13.5 DNAT转换验证
func TestMakeNatPolicyV2_TranslateValidation_DNAT(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_VALIDATION",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "DNAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)

	// 通过FlyConfig加载
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证InputNat匹配和转换
		inputNatResult := node.InputNat(intent, to)
		verifyInputNatResult(t, inputNatResult, intent, to, firewall.NAT_MATCHED)

		// 验证转换后的地址和端口
		if inputNatResult != nil {
			natResult, ok := inputNatResult.(*firewall.NatMatchResult)
			if ok && natResult.Action() == int(firewall.NAT_MATCHED) {
				translateTo := natResult.TranslateTo()
				if translateTo != nil {
					// 验证目标地址转换
					if translateTo.Dst() != nil {
						translatedDst := translateTo.Dst().String()
						t.Logf("转换后的目标地址: %s (期望包含: %s)", translatedDst, intent.RealIp)
						assert.Contains(t, translatedDst, intent.RealIp, "DNAT应该转换到正确的目标地址")
					}

					// 验证端口转换
					if translateTo.Service() != nil {
						translatedSvc := translateTo.Service().String()
						t.Logf("转换后的服务: %s (期望包含: %s)", translatedSvc, intent.RealPort)
						assert.Contains(t, translatedSvc, intent.RealPort, "DNAT应该转换到正确的端口")
					}
				}
			}
		}
	}
}

// TestMakeNatPolicyV2_TranslateValidation_SNAT 测试13.6 SNAT转换验证
func TestMakeNatPolicyV2_TranslateValidation_SNAT(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "SNAT_VALIDATION",
		"natpolicy.use_service_object": true,
		"snat_pool_type":               "POOL",
		"snat_object_name_template":    "SNAT_POOL_{snat}",
		"service_object_name_template": "SNAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)

	// 通过FlyConfig加载
	if len(result.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())

		// 验证OutputNat匹配和转换
		outputNatResult := node.OutputNat(intent, from, to)
		verifyOutputNatResult(t, outputNatResult, intent, from, to, firewall.NAT_MATCHED)

		// 验证转换后的源地址
		if outputNatResult != nil {
			natResult, ok := outputNatResult.(*firewall.NatMatchResult)
			if ok && natResult.Action() == int(firewall.NAT_MATCHED) {
				translateTo := natResult.TranslateTo()
				if translateTo != nil {
					// 验证源地址转换
					if translateTo.Src() != nil {
						translatedSrc := translateTo.Src().String()
						t.Logf("转换后的源地址: %s (期望在SNAT地址池范围内: %s)", translatedSrc, intent.Snat)
						assert.NotEmpty(t, translatedSrc, "SNAT应该转换源地址")
						// 转换后的地址应该在SNAT地址池范围内
						assert.True(t, strings.Contains(translatedSrc, "203.0.113") || strings.Contains(intent.Snat, "203.0.113"),
							"转换后的源地址应该在SNAT地址池范围内")
					}
				}
			}
		}
	}
}

// TestMakeNatPolicyV2_InlineMode 测试13.7 DNAT内联模式
func TestMakeNatPolicyV2_InlineMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "INLINE_DNAT",
		"natpolicy.dnat.inline_mode":   true,
		"natpolicy.use_service_object": false,
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 内联模式应该直接在NAT策略中包含IP和端口
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "action dnat ip-address")
	assert.Contains(t, result.CLIString, "192.168.1.100")
	assert.Contains(t, result.CLIString, "local-port")
	assert.Contains(t, result.CLIString, "80")
}

// TestMakeNatPolicyV2_ServiceObjectMode 测试13.8 服务对象模式
func TestMakeNatPolicyV2_ServiceObjectMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "SERVICE_OBJECT_DNAT",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "NAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 服务对象模式应该使用服务对象
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "service")
	// 验证服务对象已创建
	assert.NotEmpty(t, result.ServiceObjects, "应该生成服务对象")
}

// ==================== DNAT源地址控制测试（13.2.4-13.2.6） ====================

// TestMakeNatPolicyV2_DNATSourceControl_Required 测试13.2.4 DNAT源地址控制（required）
func TestMakeNatPolicyV2_DNATSourceControl_Required(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_SOURCE_REQUIRED",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.dnat.source_style":  "required",
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "DNAT_SVC",
		"network_object_name_template": "DNAT_SRC_ADDR",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.SourceObjects, "required模式应该生成源地址对象")
	assert.Contains(t, result.CLIString, "nat global-policy")
}

// TestMakeNatPolicyV2_DNATSourceControl_Optional 测试13.2.5 DNAT源地址控制（optional）
func TestMakeNatPolicyV2_DNATSourceControl_Optional(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_SOURCE_OPTIONAL",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.dnat.source_style":  "optional",
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "DNAT_SVC",
		"network_object_name_template": "DNAT_SRC_ADDR",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	// optional模式且源网络非空时，应该生成源地址对象
	assert.NotEmpty(t, result.SourceObjects, "optional模式且源网络非空时应该生成源地址对象")
}

// TestMakeNatPolicyV2_DNATSourceControl_None 测试13.2.6 DNAT源地址控制（none）
func TestMakeNatPolicyV2_DNATSourceControl_None(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_SOURCE_NONE",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.dnat.source_style":  "none",
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "DNAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.Empty(t, result.SourceObjects, "none模式不应该生成源地址对象")
}

// TestMakeNatPolicyV2_DNATVIPReuse 测试13.2.7 DNAT VIP/MIP复用
func TestMakeNatPolicyV2_DNATVIPReuse(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_VIP_REUSE",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_REUSE",
		"service_object_name_template": "DNAT_SVC",
	}

	// 第一次创建DNAT策略
	result1, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result1)

	// 加载第一次的策略
	if len(result1.FlyObject) > 0 {
		allCLI := strings.Builder{}
		for _, cli := range result1.FlyObject {
			allCLI.WriteString(cli)
			allCLI.WriteString("\n")
		}
		node.FlyConfig(allCLI.String())
	}

	// 第二次创建相同real_ip和real_port的DNAT策略
	result2, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result2)

	// 验证VIP复用
	if result2.IsReused {
		assert.True(t, result2.IsReused, "应该复用已存在的VIP")
		assert.Equal(t, result1.VipMipName, result2.VipMipName, "VipMipName应该相同")
		t.Logf("VIP已复用: %s", result2.VipMipName)
	} else {
		t.Logf("VIP未复用（可能因为匹配逻辑或防火墙不支持）")
	}
}

// ==================== SNAT目标地址控制测试（13.3.7-13.3.9） ====================

// TestMakeNatPolicyV2_SNATDestinationControl_Required 测试13.3.7 SNAT目标地址控制（required）
func TestMakeNatPolicyV2_SNATDestinationControl_Required(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":           "SNAT_DEST_REQUIRED",
		"natpolicy.snat.destination_style": "required",
		"natpolicy.use_service_object":     true,
		"snat_pool_type":                    "POOL",
		"snat_object_name_template":        "SNAT_POOL_{snat}",
		"service_object_name_template":     "SNAT_SVC",
		"network_object_name_template":      "SNAT_DST_ADDR",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.DestinationObjects, "required模式应该生成目标地址对象")
	assert.Contains(t, result.CLIString, "nat global-policy")
}

// TestMakeNatPolicyV2_SNATDestinationControl_Optional 测试13.3.8 SNAT目标地址控制（optional）
func TestMakeNatPolicyV2_SNATDestinationControl_Optional(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":           "SNAT_DEST_OPTIONAL",
		"natpolicy.snat.destination_style": "optional",
		"natpolicy.use_service_object":     true,
		"snat_pool_type":                    "POOL",
		"snat_object_name_template":        "SNAT_POOL_{snat}",
		"service_object_name_template":     "SNAT_SVC",
		"network_object_name_template":      "SNAT_DST_ADDR",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	// optional模式且目标网络非空时，应该生成目标地址对象
	assert.NotEmpty(t, result.DestinationObjects, "optional模式且目标网络非空时应该生成目标地址对象")
}

// TestMakeNatPolicyV2_SNATDestinationControl_None 测试13.3.9 SNAT目标地址控制（none）
func TestMakeNatPolicyV2_SNATDestinationControl_None(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":           "SNAT_DEST_NONE",
		"natpolicy.snat.destination_style": "none",
		"natpolicy.use_service_object":     true,
		"snat_pool_type":                    "POOL",
		"snat_object_name_template":        "SNAT_POOL_{snat}",
		"service_object_name_template":     "SNAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.Empty(t, result.DestinationObjects, "none模式不应该生成目标地址对象")
}

// TestMakeNatPolicyV2_SNATInlineMode 测试13.3.6 SNAT内联模式
func TestMakeNatPolicyV2_SNATInlineMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "SNAT_INLINE",
		"natpolicy.snat.inline_mode":  true,
		"natpolicy.use_service_object": true,
		"service_object_name_template": "SNAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)
	assert.Empty(t, result.SnatPoolName, "内联模式不应该生成SNAT_POOL对象")
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "action snat")
}

// TestMakeNatPolicyV2_SNATAutoTypeDetection 测试13.3.11 SNAT自动类型检测（单个IP）
func TestMakeNatPolicyV2_SNATAutoTypeDetection(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.1", // 单个IP
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "SNAT_AUTO_DETECT",
		"natpolicy.use_service_object": true,
		"service_object_name_template": "SNAT_SVC",
		// 不提供snat_pool_type，应该自动检测为INLINE
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	t.Logf("SNAT类型: %s", result.NatType)
	// 单个IP应该自动识别为INLINE类型或使用默认POOL类型
	assert.NotEmpty(t, result.CLIString)
}

// ==================== NAT策略状态测试（13.6） ====================

// TestMakeNatPolicyV2_Enable 测试13.6 NAT策略状态测试
func TestMakeNatPolicyV2_Enable(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	// 测试13.6.1 enable="enable"（启用策略）
	t.Run("Enable", func(t *testing.T) {
		metaData := map[string]interface{}{
			"natpolicy.name_template":      "NAT_ENABLE",
			"natpolicy.enable":              "enable",
			"natpolicy.dnat.inline_mode":   false,
			"natpolicy.use_service_object": true,
			"vip_name_template":            "VIP_{dst_network}_{dst_port}",
			"service_object_name_template": "NAT_SVC",
		}

		result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Contains(t, result.CLIString, "nat global-policy")
		// USG的策略默认启用，CLI中可能包含enable或不包含disable
	})

	// 测试13.6.2 enable="disable"（禁用策略）
	t.Run("Disable", func(t *testing.T) {
		metaData := map[string]interface{}{
			"natpolicy.name_template":      "NAT_DISABLE",
			"natpolicy.enable":              "disable",
			"natpolicy.dnat.inline_mode":   false,
			"natpolicy.use_service_object": true,
			"vip_name_template":            "VIP_{dst_network}_{dst_port}",
			"service_object_name_template": "NAT_SVC",
		}

		result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Contains(t, result.CLIString, "nat global-policy")
		// 禁用策略，CLI中可能包含disable或其他禁用标识
	})

	// 测试13.6.3 enable默认值
	t.Run("DefaultEnable", func(t *testing.T) {
		metaData := map[string]interface{}{
			"natpolicy.name_template":      "NAT_DEFAULT",
			"natpolicy.dnat.inline_mode":   false,
			"natpolicy.use_service_object": true,
			"vip_name_template":            "VIP_{dst_network}_{dst_port}",
			"service_object_name_template": "NAT_SVC",
			// 不提供enable
		}

		result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Contains(t, result.CLIString, "nat global-policy")
		// 默认启用策略，CLI中不包含disable
	})
}

// ==================== NAT策略对象模式vs内联模式组合测试（13.9） ====================

// TestMakeNatPolicyV2_DNATAllObjectMode 测试13.9.1 DNAT全对象模式
func TestMakeNatPolicyV2_DNATAllObjectMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_ALL_OBJECT",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.dnat.source_style":  "required",
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "DNAT_SVC",
		"network_object_name_template": "DNAT_SRC_ADDR",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.VipMipName, "应该生成VIP/MIP对象")
	assert.NotEmpty(t, result.SourceObjects, "应该生成源地址对象")
	assert.NotEmpty(t, result.ServiceObjects, "应该生成服务对象")
}

// TestMakeNatPolicyV2_DNATMixedMode 测试13.9.2 DNAT混合模式（VIP对象+内联地址+内联服务）
func TestMakeNatPolicyV2_DNATMixedMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_MIXED",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.dnat.source_style":  "none",
		"natpolicy.use_service_object": false,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.VipMipName, "应该生成VIP/MIP对象")
	assert.Empty(t, result.SourceObjects, "不应该生成源地址对象")
	assert.Empty(t, result.ServiceObjects, "不应该生成服务对象")
}

// TestMakeNatPolicyV2_DNATAllInlineMode 测试13.9.3 DNAT全内联模式
func TestMakeNatPolicyV2_DNATAllInlineMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_ALL_INLINE",
		"natpolicy.dnat.inline_mode":   true,
		"natpolicy.dnat.source_style":  "none",
		"natpolicy.use_service_object": false,
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.Empty(t, result.VipMipName, "不应该生成VIP对象")
	assert.Empty(t, result.SourceObjects, "不应该生成源地址对象")
	assert.Empty(t, result.ServiceObjects, "不应该生成服务对象")
	assert.Contains(t, result.CLIString, "192.168.1.100", "CLI中应该直接包含real_ip")
	assert.Contains(t, result.CLIString, "80", "CLI中应该直接包含real_port")
}

// TestMakeNatPolicyV2_SNATAllObjectMode 测试13.9.4 SNAT全对象模式
func TestMakeNatPolicyV2_SNATAllObjectMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":           "SNAT_ALL_OBJECT",
		"natpolicy.snat.inline_mode":      false,
		"snat_pool_type":                    "POOL",
		"natpolicy.snat.destination_style": "required",
		"natpolicy.use_service_object":     true,
		"snat_object_name_template":        "SNAT_POOL_{snat}",
		"service_object_name_template":     "SNAT_SVC",
		"network_object_name_template":     "SNAT_DST_ADDR",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.SnatPoolName, "应该生成SNAT_POOL对象")
	assert.NotEmpty(t, result.DestinationObjects, "应该生成目标地址对象")
	assert.NotEmpty(t, result.ServiceObjects, "应该生成服务对象")
}

// TestMakeNatPolicyV2_SNATMixedMode 测试13.9.5 SNAT混合模式（POOL对象+内联地址+内联服务）
func TestMakeNatPolicyV2_SNATMixedMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":           "SNAT_MIXED",
		"natpolicy.snat.inline_mode":      false,
		"snat_pool_type":                    "POOL",
		"natpolicy.snat.destination_style": "none",
		"natpolicy.use_service_object":     false,
		"snat_object_name_template":        "SNAT_POOL_{snat}",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.SnatPoolName, "应该生成SNAT_POOL对象")
	assert.Empty(t, result.DestinationObjects, "不应该生成目标地址对象")
	assert.Empty(t, result.ServiceObjects, "不应该生成服务对象")
}

// TestMakeNatPolicyV2_SNATAllInlineMode 测试13.9.6 SNAT全内联模式
func TestMakeNatPolicyV2_SNATAllInlineMode(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("trust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("untrust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
		Snat: "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":           "SNAT_ALL_INLINE",
		"natpolicy.snat.inline_mode":      true,
		"natpolicy.snat.destination_style": "none",
		"natpolicy.use_service_object":     false,
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.Empty(t, result.SnatPoolName, "不应该生成SNAT_POOL对象")
	assert.Empty(t, result.DestinationObjects, "不应该生成目标地址对象")
	assert.Empty(t, result.ServiceObjects, "不应该生成服务对象")
	assert.Contains(t, result.CLIString, "203.0.113.0", "CLI中应该直接包含snat地址")
}

// TestMakeNatPolicyV2_DNATPortRange 测试13.2.8 DNAT端口范围场景
func TestMakeNatPolicyV2_DNATPortRange(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("0.0.0.0/0"),
			network.NewNetworkGroupFromStringMust("203.0.113.100"),
			service.NewServiceMust("tcp:8080-8090"),
		),
		RealIp:   "192.168.1.100",
		RealPort: "80-90",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template":      "DNAT_PORT_RANGE",
		"natpolicy.dnat.inline_mode":   false,
		"natpolicy.use_service_object": true,
		"vip_name_template":            "VIP_{dst_network}_{dst_port}",
		"service_object_name_template": "DNAT_SVC",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.NotEmpty(t, result.CLIString)

	t.Logf("Generated CLI:\n%s", result.CLIString)

	// 验证CLI包含端口范围格式
	assert.Contains(t, result.CLIString, "nat global-policy")
	assert.Contains(t, result.CLIString, "action dnat ip-address")
	assert.Contains(t, result.CLIString, "192.168.1.100")
	// 验证端口范围（可能以不同格式出现）
	assert.True(t,
		strings.Contains(result.CLIString, "80-90") ||
			strings.Contains(result.CLIString, "80") && strings.Contains(result.CLIString, "90") ||
			strings.Contains(result.CLIString, "8080-8090") ||
			strings.Contains(result.CLIString, "8080") && strings.Contains(result.CLIString, "8090"),
		"CLI应该包含端口范围格式")
}

// ==================== NAT策略错误处理测试（13.10） ====================

// TestMakeNatPolicyV2_DNATAndSNATBothExist 测试13.10.2 DNAT和SNAT同时存在错误（如果防火墙不支持）
func TestMakeNatPolicyV2_DNATAndSNATBothExist(t *testing.T) {
	node := NewTestUsgNodeV2()
	templates := v2.NewCommonTemplatesV2(node, v2.NewUsgTemplatesV2())

	from := NewUsgPort("GigabitEthernet0/0/0", "", nil, nil).WithZone("untrust")
	to := NewUsgPort("GigabitEthernet0/0/1", "", nil, nil).WithZone("trust")

	// 同时提供RealIp和Snat
	intent := &policy.Intent{
		PolicyEntry: *policy.NewPolicyEntryWithAll(
			network.NewNetworkGroupFromStringMust("192.168.1.0/24"),
			network.NewNetworkGroupFromStringMust("10.0.0.0/24"),
			service.NewServiceMust("tcp:80"),
		),
		RealIp: "192.168.1.100",
		Snat:   "203.0.113.0/24",
	}

	ctx := &firewall.PolicyContext{
		Node:      node,
		Variables: make(map[string]interface{}),
		Intent:    intent,
	}

	metaData := map[string]interface{}{
		"natpolicy.name_template": "BOTH_NAT",
	}

	result, err := templates.MakeNatPolicyV2(from, to, intent, ctx, metaData)
	// 根据防火墙实现，可能返回错误或正确处理为双向NAT
	if err != nil {
		t.Logf("同时提供DNAT和SNAT返回错误（预期行为）: %v", err)
		assert.Error(t, err, "同时提供DNAT和SNAT应该返回错误（如果防火墙不支持）")
	} else {
		t.Logf("同时提供DNAT和SNAT被正确处理（可能支持双向NAT）")
		assert.NotNil(t, result)
		// 如果支持双向NAT，应该生成相应的CLI
		if result != nil {
			t.Logf("Generated CLI:\n%s", result.CLIString)
		}
	}
}

